package com.discover.performance.memo

object MemoConstants {
    def createMemoRequest(productEnrollmentId: String): String = {
        "{\n" +
            "  \"memoText\": \"Enrolled into ITP\",\n" +
            "  \"productEnrollmentId\": \"" + productEnrollmentId + "\"\n" +
         "}"
    }
}
