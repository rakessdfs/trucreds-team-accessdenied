package com.discover.performance.accountactivity

object AccountActivityConstants {
  def createActivityRequest(productEnrollmentId: String): String = {
    "{\n" +
      "  \"productEnrollmentId\": \"" + productEnrollmentId + "\",\n" +
      "  \"activityCode\": \"EUR\",\n" +
      "  \"newData\": \"foo@bar.com\",\n" +
      "  \"previousData\": \"test\",\n" +
      "  \"operator\": \"test\",\n" +
      "  \"requestDate\": \"" + "2021-02-16 20:34:59" + "\"\n" +
      "}"

  }
}
