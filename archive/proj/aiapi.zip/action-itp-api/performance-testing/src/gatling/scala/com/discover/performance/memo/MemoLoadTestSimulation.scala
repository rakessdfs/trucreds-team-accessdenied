package com.discover.performance.memo

import scala.concurrent.duration._

class MemoLoadTestSimulation extends {
  override val totalSubmissions = 75
  override val duration = 60 seconds
} with MemoSimulator(totalSubmissions, duration) {}
