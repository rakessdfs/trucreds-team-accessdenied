package com.discover.performance.memo

import com.discover.performance.memo.MemoConstants.createMemoRequest
import io.gatling.core.Predef._
import io.gatling.core.structure.ScenarioBuilder
import io.gatling.http.Predef._
import io.gatling.http.protocol.HttpProtocolBuilder

import scala.concurrent.duration.FiniteDuration
import scala.util.Properties

case class MemoSimulator(totalSubmissions: Int, duration: FiniteDuration) extends Simulation {

  val memoUrl: String = Properties.propOrElse(
    "actionITPUrl",
    "http://localhost:9001")

  val httpProtocol: HttpProtocolBuilder = http
    .baseUrl(memoUrl + "/enterprise/products/action/itp").disableWarmUp

  val headersEnroll = Map(
    "HTTP_AUTH_TOKEN" -> "893842924",
    "X-DFSUSER-USER-ID" -> "testuser",
    "Content-Type" -> "application/json"
  )

  val productEnrollmentId: String = "90901234567890"

  val postMemos: ScenarioBuilder = scenario("CreateMemos")
    .exec(http("Create V1 Memo")
      .post("/v1/memo")
      .body(StringBody(createMemoRequest(productEnrollmentId)))
      .headers(headersEnroll)
      .check(status.is(201)))

  val getMemos: ScenarioBuilder = scenario("GetMemos")
    .exec(http("Get V1 Memo")
      .get("/v1/memo/" + productEnrollmentId)
      .headers(headersEnroll)
      .check(status.is(200)))

  setUp(
    postMemos.inject(heavisideUsers(totalSubmissions) during duration),
    getMemos.inject(heavisideUsers(totalSubmissions) during duration)
  ).protocols(httpProtocol).assertions(
    details("Create V1 Memo").successfulRequests.percent.gte(100),
    details("Create V1 Memo").responseTime.mean.lte(11000),
    details("Create V1 Memo").requestsPerSec.gte(1),
    details("Get V1 Memo").successfulRequests.percent.gte(100),
    details("Get V1 Memo").responseTime.mean.lte(11000),
    details("Get V1 Memo").requestsPerSec.gte(1),
  )
}
