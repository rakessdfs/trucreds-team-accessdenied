package com.discover.performance.call

object CallConstants {
  def createRecordCallRequest(): String = {
    "{\n" +
      "  \"customerType\": \"ITP_BM\",\n" +
      "  \"productEnrollmentId\": \"457821487\",\n" +
      "  \"tagType\": \"" + "CANCEL" + "\"\n" +
      "}"
  }
}
