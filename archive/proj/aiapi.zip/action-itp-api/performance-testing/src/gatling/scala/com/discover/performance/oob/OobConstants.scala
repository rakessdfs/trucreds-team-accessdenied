package com.discover.performance.oob

object OobConstants {
    def createUnlockUserRequest(productEnrollmentId: String): String = {
        "{\n" +
            "  \"custUserKey\": \"" + productEnrollmentId + "\"\n" +
         "}"
    }

    def createSendCodeRequest(channelCode: String, channelValue: String, peid: String, firstName: String, lastName: String): String = {
        "{\n" +
            "  \"channelCode\": \"" + channelCode + "\",\n" +
            "  \"channelValue\": \""+ channelValue +"\",\n" +
            "  \"custUserKey\": \""+ peid +"\",\n" +
            "  \"customerFirstName\": \""+ firstName +"\",\n" +
            "  \"customerLastName\": \""+ lastName +"\"\n" +
         "}"
    }

    def createValidateCodeRequest(peid: String, inputCode: String, lockCustomer: Boolean): String = {
            "{\n" +
                "  \"custUserKey\": \""+ peid +"\",\n" +
                "  \"inputCode\": \""+ inputCode +"\",\n" +
                "  \"lockCustomer\": \""+ lockCustomer +"\"\n" +
             "}"
        }
}
