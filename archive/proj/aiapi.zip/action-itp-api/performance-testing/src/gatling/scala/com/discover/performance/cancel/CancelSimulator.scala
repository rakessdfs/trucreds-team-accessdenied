package com.discover.performance.cancel

import io.gatling.core.Predef._
import io.gatling.core.structure.ScenarioBuilder
import io.gatling.http.Predef._
import io.gatling.http.protocol.HttpProtocolBuilder

import scala.concurrent.duration.FiniteDuration
import scala.util.Properties

case class CancelSimulator(totalSubmissions: Int, duration: FiniteDuration) extends Simulation {

  val memoUrl: String = Properties.propOrElse(
    "actionITPUrl",
    "http://localhost:9001")

  val httpProtocol: HttpProtocolBuilder = http
    .baseUrl(memoUrl + "/enterprise/products/action/itp/v1").disableWarmUp

  val headersEnroll = Map(
    "HTTP_AUTH_TOKEN" -> "893842924",
    "X-DFSUSER-USER-ID" -> "testuser",
    "Content-Type" -> "application/json"
  )

  val postCustomerCancelMembership: ScenarioBuilder = scenario("CancelCall")
    .exec(http("Cancel Call")
      .post("/cancel/membership")
      .queryParam("cancelReasonCode", "P")
      .queryParam("productEnrollmentId", "457821487")
      .headers(headersEnroll)
      .check(status.is(200)))

  setUp(
    postCustomerCancelMembership.inject(heavisideUsers(totalSubmissions) during duration)
  ).protocols(httpProtocol).assertions(
    details("Cancel Call").successfulRequests.percent.gte(100),
    details("Cancel Call").responseTime.mean.lte(11000),
    details("Cancel Call").requestsPerSec.gte(1)
  )
}
