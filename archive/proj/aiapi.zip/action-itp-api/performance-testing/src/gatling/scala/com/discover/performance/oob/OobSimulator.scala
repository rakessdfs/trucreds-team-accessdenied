package com.discover.performance.oob

import com.discover.performance.oob.OobConstants.createUnlockUserRequest
import com.discover.performance.oob.OobConstants.createSendCodeRequest
import com.discover.performance.oob.OobConstants.createValidateCodeRequest
import io.gatling.core.Predef._
import io.gatling.core.structure.ScenarioBuilder
import io.gatling.http.Predef._
import io.gatling.http.protocol.HttpProtocolBuilder

import scala.concurrent.duration.FiniteDuration
import scala.util.Properties

case class OobSimulator(totalSubmissions: Int, duration: FiniteDuration) extends Simulation {

  val localhostUrl: String = Properties.propOrElse(
    "actionITPUrl",
    "http://localhost:9001")

  val httpProtocol: HttpProtocolBuilder = http
    .baseUrl(localhostUrl + "/enterprise/products/action/itp").disableWarmUp

  val headersEnroll = Map(
    "HTTP_AUTH_TOKEN" -> "893842924",
    "X-DFSUSER-USER-ID" -> "testuser",
    "Content-Type" -> "application/json"
  )

  val productEnrollmentId: String = "90901234567890"
  val channelCode: String = "EM"
  val channelValue: String = "foo@bar.com"
  val firstName: String = "Hello"
  val lastName: String = "World"
  val inputCode: String = "12345"

  val unlockUser: ScenarioBuilder = scenario("UnlockUser")
    .exec(http("OOB Unlock User")
      .post("/v1/unlockUser")
      .body(StringBody(createUnlockUserRequest(productEnrollmentId)))
      .headers(headersEnroll)
      .check(status.is(200)))

  val getStatus: ScenarioBuilder = scenario("GetStatus")
    .exec(http("OOB Get User Status")
      .get("/v1/getStatus/" + productEnrollmentId)
      .headers(headersEnroll)
      .check(status.is(200)))

  val sendCode: ScenarioBuilder = scenario("SendCode")
      .exec(http("OOB Send Code")
        .post("/v1/sendCode")
        .body(StringBody(createSendCodeRequest(channelCode, channelValue, productEnrollmentId, firstName, lastName)))
        .headers(headersEnroll)
        .check(status.is(200)))

  val validateCode: ScenarioBuilder = scenario("ValidateCode")
        .exec(http("OOB Validate Code")
          .post("/v1/validateCode")
          .body(StringBody(createValidateCodeRequest(productEnrollmentId, inputCode, lockCustomer = false)))
          .headers(headersEnroll)
          .check(status.is(200)))

  setUp(
    unlockUser.inject(heavisideUsers(totalSubmissions) during duration),
    getStatus.inject(heavisideUsers(totalSubmissions) during duration),
    sendCode.inject(heavisideUsers(totalSubmissions) during duration),
    validateCode.inject(heavisideUsers(totalSubmissions) during duration),
  ).protocols(httpProtocol).assertions(
    details("OOB Unlock User").successfulRequests.percent.gte(100),
    details("OOB Unlock User").responseTime.mean.lte(11000),
    details("OOB Unlock User").requestsPerSec.gte(1),
    details("OOB Get User Status").successfulRequests.percent.gte(100),
    details("OOB Get User Status").responseTime.mean.lte(11000),
    details("OOB Get User Status").requestsPerSec.gte(1),
    details("OOB Send Code").successfulRequests.percent.gte(100),
    details("OOB Send Code").responseTime.mean.lte(11000),
    details("OOB Send Code").requestsPerSec.gte(1),
    details("OOB Validate Code").successfulRequests.percent.gte(100),
    details("OOB Validate Code").responseTime.mean.lte(11000),
    details("OOB Validate Code").requestsPerSec.gte(1),
  )
}
