package com.discover.performance.call

import com.discover.performance.call.CallConstants.createRecordCallRequest
import io.gatling.core.Predef._
import io.gatling.core.structure.ScenarioBuilder
import io.gatling.http.Predef._
import io.gatling.http.protocol.HttpProtocolBuilder

import scala.concurrent.duration.FiniteDuration
import scala.util.Properties

case class CallSimulator(totalSubmissions: Int, duration: FiniteDuration) extends Simulation {

  val memoUrl: String = Properties.propOrElse(
    "actionITPUrl",
    "http://localhost:9001")

  val httpProtocol: HttpProtocolBuilder = http
    .baseUrl(memoUrl + "/enterprise/products/action/itp/v1").disableWarmUp

  val headersEnroll = Map(
    "HTTP_AUTH_TOKEN" -> "893842924",
    "X-DFSUSER-USER-ID" -> "testuser",
    "Content-Type" -> "application/json"
  )

  val postRecordCall: ScenarioBuilder = scenario("RecordCall")
    .exec(http("Record Call")
      .post("/recordCall")
      .body(StringBody(createRecordCallRequest()))
      .headers(headersEnroll)
      .check(status.is(200)))

  setUp(
    postRecordCall.inject(heavisideUsers(totalSubmissions) during duration)
  ).protocols(httpProtocol).assertions(
    details("Record Call").successfulRequests.percent.gte(100),
    details("Record Call").responseTime.mean.lte(11000),
    details("Record Call").requestsPerSec.gte(1)
  )
}
