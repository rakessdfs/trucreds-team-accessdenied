package com.discover.performance.oob

import scala.concurrent.duration._

class OobLoadTestSimulation extends {
  override val totalSubmissions = 75
  override val duration = 60 seconds
} with OobSimulator(totalSubmissions, duration) {}
