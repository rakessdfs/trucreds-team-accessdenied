package com.discover.performance.membership

import io.gatling.core.Predef._
import io.gatling.core.structure.ScenarioBuilder
import io.gatling.http.Predef._
import io.gatling.http.protocol.HttpProtocolBuilder

import scala.concurrent.duration.FiniteDuration
import scala.util.Properties

case class MembershipSimulator(totalSubmissions: Int, duration: FiniteDuration) extends Simulation {

  val membershipUrl: String = Properties.propOrElse(
    "actionITPUrl",
    "http://localhost:9001")

  val httpProtocol: HttpProtocolBuilder = http
    .baseUrl(membershipUrl + "/enterprise/products/action/itp").disableWarmUp

  val headersEnroll = Map(
    "HTTP_AUTH_TOKEN" -> "893842924",
    "X-DFSUSER-USER-ID" -> "testuser",
    "Content-Type" -> "application/json"
  )

  val partyId: String = "909090"
  val peid: String = "12345"
  val customerType: String = "ITP_BM"
  val subscriberId: String = "7856562"

  val fetchMembershipInfo: ScenarioBuilder = scenario("FetchMembership")
    .exec(http("Get V1 Membership Info")
      .get("/v1/membership?partyId=" + partyId)
      .headers(headersEnroll)
      .check(status.is(200)))

  val fetchBillingDetails: ScenarioBuilder = scenario("FetchBilling")
    .exec(http("Get V1 Billing Details")
      .get("/v1/membership/billing?customerType=" + customerType + "&partyId=" + partyId + "&peid=" + peid +
        "&subscriberId=" + subscriberId)
      .headers(headersEnroll)
      .check(status.is(200)))

  val fetchRequestReasons: ScenarioBuilder = scenario("FetchRequestReasons")
    .exec(http("Get V1 Cancellation Request Reasons")
      .get("/v1/requestreasons/query?customerType=" + customerType)
      .headers(headersEnroll)
      .check(status.is(200)))

  setUp(
    fetchMembershipInfo.inject(heavisideUsers(totalSubmissions) during duration),
    fetchBillingDetails.inject(heavisideUsers(totalSubmissions) during duration),
    fetchRequestReasons.inject(heavisideUsers(totalSubmissions) during duration),
  ).protocols(httpProtocol).assertions(
    details("Get V1 Membership Info").successfulRequests.percent.gte(100),
    details("Get V1 Membership Info").responseTime.mean.lte(11000),
    details("Get V1 Membership Info").requestsPerSec.gte(1),
    details("Get V1 Billing Details").successfulRequests.percent.gte(100),
    details("Get V1 Billing Details").responseTime.mean.lte(11000),
    details("Get V1 Billing Details").requestsPerSec.gte(1),
    details("Get V1 Cancellation Request Reasons").successfulRequests.percent.gte(100),
    details("Get V1 Cancellation Request Reasons").responseTime.mean.lte(11000),
    details("Get V1 Cancellation Request Reasons").requestsPerSec.gte(1),
  )
}
