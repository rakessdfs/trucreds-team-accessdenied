package com.discover.performance.membership

import scala.concurrent.duration._

class MembershipLoadTestSimulation extends {
  override val totalSubmissions = 70
  override val duration = 60 seconds
} with MembershipSimulator(totalSubmissions, duration) {}
