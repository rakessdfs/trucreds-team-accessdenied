package com.discover.performance.accountactivity

import com.discover.performance.accountactivity.AccountActivityConstants.createActivityRequest
import io.gatling.core.Predef._
import io.gatling.core.structure.ScenarioBuilder
import io.gatling.http.Predef._
import io.gatling.http.protocol.HttpProtocolBuilder

import scala.concurrent.duration.FiniteDuration
import scala.util.Properties

case class AccountActivitySimulator(totalSubmissions: Int, duration: FiniteDuration) extends Simulation {

  val memoUrl: String = Properties.propOrElse(
    "actionITPUrl",
    "http://localhost:9001")

  val httpProtocol: HttpProtocolBuilder = http
    .baseUrl(memoUrl + "/enterprise/products/action/itp/v1").disableWarmUp

  val headersEnroll = Map(
    "HTTP_AUTH_TOKEN" -> "893842924",
    "X-DFSUSER-USER-ID" -> "testuser",
    "Content-Type" -> "application/json"
  )

  val productEnrollmentId: String = "457821487"

  val postActivity: ScenarioBuilder = scenario("CreateActivity")
    .exec(http("Create Activity")
      .post("/accountActivity")
      .body(StringBody(createActivityRequest(productEnrollmentId)))
      .headers(headersEnroll)
      .check(status.is(201)))

  val getActivity: ScenarioBuilder = scenario("GetActivity")
    .exec(http("Get Activity")
      .get("/accountActivity/" + productEnrollmentId)
      .headers(headersEnroll)
      .check(status.is(200)))

  setUp(
    postActivity.inject(heavisideUsers(totalSubmissions) during duration),
    getActivity.inject(heavisideUsers(totalSubmissions) during duration)
  ).protocols(httpProtocol).assertions(
    details("Create Activity").successfulRequests.percent.gte(100),
    details("Create Activity").responseTime.mean.lte(11000),
    details("Create Activity").requestsPerSec.gte(1),
    details("Get Activity").successfulRequests.percent.gte(100),
    details("Get Activity").responseTime.mean.lte(11000),
    details("Get Activity").requestsPerSec.gte(1),
  )
}
