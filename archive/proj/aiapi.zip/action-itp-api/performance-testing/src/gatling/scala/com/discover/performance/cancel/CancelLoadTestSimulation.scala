package com.discover.performance.cancel
import scala.concurrent.duration._

class CancelLoadTestSimulation extends {
  override val totalSubmissions = 75
  override val duration = 60 seconds
} with CancelSimulator(totalSubmissions, duration) {}
