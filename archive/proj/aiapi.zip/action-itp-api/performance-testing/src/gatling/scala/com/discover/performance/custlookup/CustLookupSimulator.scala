package com.discover.performance.custlookup

import com.discover.performance.custlookup.CustLookupConstants.customerSearchRequest
import io.gatling.core.Predef._
import io.gatling.core.structure.ScenarioBuilder
import io.gatling.http.Predef._
import io.gatling.http.protocol.HttpProtocolBuilder

import scala.concurrent.duration.FiniteDuration
import scala.util.Properties

case class CustLookupSimulator(totalSubmissions: Int, duration: FiniteDuration) extends Simulation {

  val custLookupUrl: String = Properties.propOrElse(
    "actionITPUrl",
    "http://localhost:9001")

  val httpProtocol: HttpProtocolBuilder = http
    .baseUrl(custLookupUrl + "/enterprise/products/action/itp").disableWarmUp

  val headersEnroll = Map(
    "HTTP_AUTH_TOKEN" -> "893842924",
    "X-DFSUSER-USER-ID" -> "testuser",
    "Content-Type" -> "application/json"
  )

  val partyId: String = "100007975"

  val getCustomerInfo: ScenarioBuilder = scenario("CustomerInfo")
    .exec(http("Get V1 Customer Info")
      .get("/v1/customer/pii?party-id=" + partyId)
      .headers(headersEnroll)
      .check(status.is(200)))

  val postCustomerSearch: ScenarioBuilder = scenario("CustomerSearch")
    .exec(http("Customer Search V1")
      .post("/v1/customer/search")
      .body(StringBody(customerSearchRequest()))
      .headers(headersEnroll)
      .check(status.is(200)))

  setUp(
    getCustomerInfo.inject(heavisideUsers(totalSubmissions) during duration),
    postCustomerSearch.inject(heavisideUsers(totalSubmissions) during duration)
  ).protocols(httpProtocol).assertions(
    details("Get V1 Customer Info").successfulRequests.percent.gte(100),
    details("Get V1 Customer Info").responseTime.mean.lte(11000),
    details("Get V1 Customer Info").requestsPerSec.gte(1),
    details("Customer Search V1").successfulRequests.percent.gte(100),
    details("Customer Search V1").responseTime.mean.lte(11000),
    details("Customer Search V1").requestsPerSec.gte(1),
  )
}
