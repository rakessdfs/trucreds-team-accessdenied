package com.discover.performance.custlookup

import scala.concurrent.duration._

class CustLookupLoadTestSimulation extends {
  override val totalSubmissions = 70
  override val duration = 60 seconds
} with CustLookupSimulator(totalSubmissions, duration) {}
