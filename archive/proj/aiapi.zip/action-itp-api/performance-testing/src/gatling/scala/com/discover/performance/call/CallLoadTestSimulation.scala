package com.discover.performance.call

import scala.concurrent.duration._

class CallLoadTestSimulation extends {
  override val totalSubmissions = 75
  override val duration = 60 seconds
} with CallSimulator(totalSubmissions, duration) {}