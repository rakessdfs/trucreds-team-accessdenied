package com.discover.performance.custlookup

object CustLookupConstants {
    def customerSearchRequest(): String = {
        "{\n" +
            "  \"firstName\": \"TestUser\",\n" +
            "  \"lastName\": \"LastName\",\n" +
            "  \"dateOfBirth\": \"11/22/1950\",\n" +
            "  \"peidOrSubscriberId\": \"\"\n" +
         "}"
    }
}
