#!/usr/bin/env bash

mkdir tmp-load-test
TMPDIR="$(pwd)/tmp-load-test"
export TMPDIR
#
export GRADLE_OPTS="-Djava.io.tmpdir=$TMPDIR"

../gradlew clean gatlingRun -DactionITPUrl="${APP_BASE_URL}"
#../gradlew clean gatlingRun -DactionITPUrl="http://localhost:8080"