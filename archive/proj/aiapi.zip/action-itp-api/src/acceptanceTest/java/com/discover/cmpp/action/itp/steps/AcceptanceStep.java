package com.discover.cmpp.action.itp.steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.spring.CucumberContextConfiguration;
import org.junit.Assert;

@CucumberContextConfiguration
public class AcceptanceStep {

    @Given("Customer Lookup endpoint is created")
    public void customer_lookup_endpoint_created(Integer int1) {
        // write code here that turns the phrase above into concrete actions
    }

    @When("Customer Lookup endpoint is called with a valid partyId")
    public void customer_lookup_with_partyId() {
        // do nothing
    }

    @Then("Response returns customer info")
    public void returnsCustomerInfo() {
        Assert.assertTrue(true);
    }
} 