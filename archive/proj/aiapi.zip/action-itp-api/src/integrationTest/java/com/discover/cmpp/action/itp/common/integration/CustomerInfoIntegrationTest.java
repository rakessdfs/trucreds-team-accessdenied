package com.discover.cmpp.action.itp.common.integration;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.custlookup.CustLookUpConstants;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;

import static com.discover.cmpp.action.itp.test.utils.TestUtils.getStringContent;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import com.discover.cmpp.action.itp.common.AbstractIntegrationTest;

class CustomerInfoIntegrationTest extends AbstractIntegrationTest {

    @Value("classpath:data/valid-cust-pii-info-response.json")
    Resource validCustPiiInfoResponse;

    @Value("classpath:data/valid-cust-pii-info-response-empty-pii.json")
    Resource validCustPiiInfoResponseEmptyPii;

    @ParameterizedTest
    @CsvSource({
            "123456",
            "1234568",
            "1234569",
    })
    @DisplayName("Fetch cds customer information successfully")
    void canFetchMembership_whenValidPartyIdProvided(String partyId) throws Exception {
        TestUtils.setWiremockCloakService();
        TestUtils.setWiremockCdsService();
        TestUtils.setWiremockProductsApiService();
        mockMvc.perform(get(TestUtils.contextPath + CustLookUpConstants.CUST_PII_INFO_URL + "?party-id=" + partyId)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .headers(httpHeaders))
                .andExpect(status().isOk())
                .andExpect(content().json(getStringContent(validCustPiiInfoResponse)));
    }

    @Test
    @DisplayName("Fetch cds customer information successfully and return empty Pii when location data contains more " +
            "than one phone, address, or email")
    void customerInfo_returnsEmptyPii_WhenLocationDataContainsMoreThanOnePhoneAddressOrEmail() throws Exception {
        TestUtils.setWiremockCloakService();
        TestUtils.setWiremockCdsService();
        TestUtils.setWiremockProductsApiService();
        mockMvc.perform(get(TestUtils.contextPath + CustLookUpConstants.CUST_PII_INFO_URL + "?party-id=1234567")
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .headers(httpHeaders))
                .andExpect(status().isOk())
                .andExpect(content().json(getStringContent(validCustPiiInfoResponseEmptyPii)));
    }

    @Test
    @DisplayName("Fetch cds customer information api should return 500 when invalid agent id")
    void whenInValidAgentIdProvided_returns500() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + CustLookUpConstants.CUST_PII_INFO_URL)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .headers(httpHeaders))
                .andExpect(status().is5xxServerError());
    }

    @Test
    @DisplayName("Fetch cds customer information api should return 401 when unauthorized")
    void whenUnauthorized_returns401() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + CustLookUpConstants.CUST_PII_INFO_URL + "?party-id=123456")
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .contentType(APPLICATION_JSON))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1001")))
                .andExpect(jsonPath("$.error_description", Matchers.equalTo("Unauthorized!")));
    }

    @Test
    @DisplayName("Fetch cds customer information api should return 404 when invalid url is provided")
    void whenInvalidUrlIsProvided_returns404() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + "/test-url")
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .headers(httpHeaders))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("Fetch cds customer information api should return 500 when there is an internal server error")
    void whenInternalServerError_returns500() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_MEMBERSHIP_PATH + "?partyId=5555")
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .headers(httpHeaders))
                .andExpect(status().is5xxServerError());
    }
}
