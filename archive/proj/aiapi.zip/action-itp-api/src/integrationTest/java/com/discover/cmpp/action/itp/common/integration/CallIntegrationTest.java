package com.discover.cmpp.action.itp.common.integration;

import com.discover.cmpp.action.itp.call.CallConstants;
import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;

import static com.discover.cmpp.action.itp.test.utils.TestUtils.getStringContent;
import static com.discover.cmpp.jwt.utils.JwtIntegrationTestHelper.httpAuthHeaders;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import com.discover.cmpp.action.itp.common.AbstractIntegrationTest;

class CallIntegrationTest extends AbstractIntegrationTest {

    @Value("classpath:data/bad-record-call-request.json")
    Resource badRecordCallRequest;

    @Value("classpath:data/invalid-record-call-request.json")
    Resource invalidRecordCallRequest;

    @Value("classpath:data/valid-record-call-request.json")
    Resource validRecordCallRequest;

    @Test
    @DisplayName("Can successfully record call when valid request is given")
    void canRecordCall_whenValidRequest() throws Exception {
        TestUtils.setWiremockCiscoRestApi();
        TestUtils.setWiremockVerintRestApi();

        mockMvc.perform(post(TestUtils.contextPath + CallConstants.RECORD_CALL_URL)
                .headers(httpHeaders)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .contentType(APPLICATION_JSON)
                .content(getStringContent(validRecordCallRequest)))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("Throws 400 bad request error for bad request")
    void whenBadRequest_recordCall_returns400() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + CallConstants.RECORD_CALL_URL)
                .headers(httpHeaders)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .contentType(APPLICATION_JSON)
                .content(getStringContent(badRecordCallRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("Record call should return 401 when no JWT is provided")
    void whenNoJwtProvided_recordCall_returns401() throws Exception {

        mockMvc.perform(post(TestUtils.contextPath + CallConstants.RECORD_CALL_URL)
                .contentType(APPLICATION_JSON)
                .content(getStringContent(validRecordCallRequest)))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1001")))
                .andExpect(jsonPath("$.error_description", Matchers.equalTo("Unauthorized!")));
    }


    @Test
    @DisplayName("Record call should return 403 when wrong scope JWT is provided")
    void whenInvalidJwtIsProvided_recordCall_returns403() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + CallConstants.RECORD_CALL_URL)
                .headers(httpAuthHeaders("WRONG_SCOPE"))
                .contentType(APPLICATION_JSON)
                .content(getStringContent(validRecordCallRequest)))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1003")))
                .andExpect(jsonPath("$.error_description",
                        Matchers.equalTo("Forbidden - Not authorized to access the resource!")));
    }

    @Test
    @DisplayName("Record call returns 500 when verint api call tagging is not successful")
    void whenVerintTaggingFails_recordCall_returns500() throws Exception {
        TestUtils.setWiremockCiscoRestApi();
        TestUtils.setWiremockVerintRestApi();

        mockMvc.perform(post(TestUtils.contextPath + CallConstants.RECORD_CALL_URL)
                .headers(httpHeaders)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .contentType(APPLICATION_JSON)
                .content(getStringContent(invalidRecordCallRequest)))
                .andExpect(status().isInternalServerError());
    }

    @Test
    @DisplayName("Record call returns 500 when cisco api getting extension is not successful")
    void whenGetExtensionFails_recordCall_returns500() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + CallConstants.RECORD_CALL_URL)
                .headers(httpHeaders)
                .header(ActionItpConstants.AGENT_ID, "extensionFails")
                .contentType(APPLICATION_JSON)
                .content(getStringContent(validRecordCallRequest)))
                .andExpect(status().isInternalServerError());
    }

    @Test
    @DisplayName("Record call returns 500 when verint api contact endpoint (verification) is not successful")
    void whenVerifyCallFails_recordCall_returns500() throws Exception {
        TestUtils.setWiremockCiscoRestApi();
        TestUtils.setWiremockVerintRestApi();

        mockMvc.perform(post(TestUtils.contextPath + CallConstants.RECORD_CALL_URL)
                .headers(httpHeaders)
                .header(ActionItpConstants.AGENT_ID, "invalidContact")
                .contentType(APPLICATION_JSON)
                .content(getStringContent(validRecordCallRequest)))
                .andExpect(status().isInternalServerError());
    }

    @Test
    @DisplayName("Record call returns 500 when verint contact endpoint indicates there's no active call")
    void whenNoActiveCall_recordCall_returns500() throws Exception {
        TestUtils.setWiremockCiscoRestApi();
        TestUtils.setWiremockVerintRestApi();

        mockMvc.perform(post(TestUtils.contextPath + CallConstants.RECORD_CALL_URL)
                .headers(httpHeaders)
                .header(ActionItpConstants.AGENT_ID, "noCallActive")
                .contentType(APPLICATION_JSON)
                .content(getStringContent(validRecordCallRequest)))
                .andExpect(status().isInternalServerError());
    }
}
