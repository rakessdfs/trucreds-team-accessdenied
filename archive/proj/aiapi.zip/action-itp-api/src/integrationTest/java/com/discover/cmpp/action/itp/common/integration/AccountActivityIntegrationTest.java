package com.discover.cmpp.action.itp.common.integration;

import com.discover.cmpp.action.itp.accountactivity.AccountActivityCodeEntity;
import com.discover.cmpp.action.itp.accountactivity.AccountActivityCodeRepository;
import com.discover.cmpp.action.itp.accountactivity.AccountActivityEntity;
import com.discover.cmpp.action.itp.accountactivity.AccountActivityRepository;
import com.discover.cmpp.action.itp.common.AbstractIntegrationTest;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import static com.discover.cmpp.action.itp.accountactivity.AccountActivityConstants.FETCH_ACCOUNT_ACTIVITY_CODES_URL;
import static com.discover.cmpp.jwt.utils.JwtIntegrationTestHelper.httpAuthHeaders;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class AccountActivityIntegrationTest extends AbstractIntegrationTest {

    @Autowired
    private AccountActivityRepository accountActivityRepository;

    @Autowired
    private AccountActivityCodeRepository accountActivityCodeRepository;

    @BeforeEach
    void setup() {
        accountActivityCodeRepository.deleteAll();
        String str = "1986-04-08 12:30";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        LocalDateTime dateTime = LocalDateTime.parse(str, formatter);
        AccountActivityCodeEntity codeEntity = AccountActivityCodeEntity.builder()
                .activityCode("code1")
                .activityDesc("desc1")
                .category("category1")
                .createTs(dateTime)
                .updateTs(null)
                .build();
        accountActivityCodeRepository.save(codeEntity);

        AccountActivityCodeEntity codeEntity2 = AccountActivityCodeEntity.builder()
                .activityCode("code2")
                .activityDesc("desc2")
                .category("category2")
                .createTs(dateTime)
                .updateTs(null)
                .build();
        accountActivityCodeRepository.save(codeEntity2);
    }

    @Test
    @DisplayName("Fetch Account Activity api can fetch activity from Db successfully")
    void canFetchAccountActivity_whenValidPEIDProvided() throws Exception {
        TestUtils.setWiremockProductEnrollmentApiService();
        TestUtils.setWiremockCsidReportingService();
        AccountActivityCodeEntity codeEntity = AccountActivityCodeEntity.builder()
                .activityCode("account-activity")
                .activityDesc("desc")
                .category("category")
                .createTs(LocalDateTime.now())
                .updateTs(null)
                .build();
        accountActivityCodeRepository.save(codeEntity);

        AccountActivityEntity entity = AccountActivityEntity.builder()
                .productEnrollmentId("123456789")
                .activityCode(codeEntity)
                .previousData("previous")
                .newData("new")
                .operator("operator")
                .requestDate(LocalDateTime.now())
                .createTs(LocalDateTime.now())
                .updateTs(null)
                .build();
        accountActivityRepository.save(entity);

        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_ACCOUNT_ACTIVITY_PATH + "123456789")
                .headers(httpHeaders)
                .contentType(APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("Fetch Account Activity api should return 401 when no JWT is provided")
    void whenInvalidJwtProvided_fetchAccountActivity_returns401() throws Exception {

        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_ACCOUNT_ACTIVITY_PATH + "123456789")
                .contentType(APPLICATION_JSON))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1001")))
                .andExpect(jsonPath("$.error_description", Matchers.equalTo("Unauthorized!")));
    }


    @Test
    @DisplayName("Fetch Account Activity api should return 403 when wrong scope JWT is provided")
    void whenInvalidJwtIsProvided_fetchAccountActivity_returns403() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_ACCOUNT_ACTIVITY_PATH + "123456789")
                .headers(httpAuthHeaders("WRONG_SCOPE"))
                .contentType(APPLICATION_JSON))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1003")))
                .andExpect(jsonPath("$.error_description",
                        Matchers.equalTo("Forbidden - Not authorized to access the resource!")));
    }

    @Test
    @DisplayName("Fetch Account Activity api should return 404 when invalid url is provided")
    void whenInvalidUrlIsProvided_fetchAccountActivity_returns404() throws Exception {
        mockMvc.perform(
                get(TestUtils.contextPath + "test" + TestUtils.FETCH_ACCOUNT_ACTIVITY_PATH + "123456789")
                        .headers(httpHeaders)
                        .contentType(APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("Fetch Account Activity Constants By Code Success")
    void canFetchAccountActivityConstants_whenValidCode() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + FETCH_ACCOUNT_ACTIVITY_CODES_URL)
                .headers(httpHeaders)
                .param("activityCode", "code1")
                .contentType(APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.*", Matchers.isA(ArrayList.class)))
                .andExpect(jsonPath("$.*", Matchers.hasSize(1)))
                .andExpect(jsonPath("$[0].activityCode", Matchers.is("code1")));
    }

    @Test
    @DisplayName("Fetch Account Activity Constants By Category Success")
    void canFetchAccountActivityConstants_whenValidCategory() throws Exception {

        mockMvc.perform(get(TestUtils.contextPath + FETCH_ACCOUNT_ACTIVITY_CODES_URL)
                .headers(httpHeaders)
                .param("category", "category1")
                .contentType(APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.*", Matchers.isA(ArrayList.class)))
                .andExpect(jsonPath("$.*", Matchers.hasSize(1)))
                .andExpect(jsonPath("$[0].activityCode", Matchers.is("code1")));
    }

    @Test
    @DisplayName("Fetch Account Activity Constants with no parameters Success")
    void canFetchAccountActivityConstants_noParameters() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + FETCH_ACCOUNT_ACTIVITY_CODES_URL)
                .headers(httpHeaders)
                .contentType(APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.*", Matchers.isA(ArrayList.class)))
                .andExpect(jsonPath("$.*", Matchers.hasSize(2)))
                .andExpect(jsonPath("$[*].activityCode",
                        Matchers.containsInAnyOrder("code1", "code2")));
    }

    @Test
    @DisplayName("Fetch Account Activity Constants And Expect a 204 if no entries are found")
    void canFetchAccountActivityConstants_noContent() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + FETCH_ACCOUNT_ACTIVITY_CODES_URL)
                .param("activityCode", "NotFound")
                .headers(httpHeaders)
                .contentType(APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("Fetch Account Activity Constants And Expect a Bad Request when too many characters in code")
    void canFetchAccountActivityConstants_badRequest() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + FETCH_ACCOUNT_ACTIVITY_CODES_URL)
                .param("activityCode", "01234567890123456789OVERTWENTYCHARACTERS")
                .headers(httpHeaders)
                .contentType(APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }
}
