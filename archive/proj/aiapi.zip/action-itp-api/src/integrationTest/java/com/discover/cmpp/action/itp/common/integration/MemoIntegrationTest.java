package com.discover.cmpp.action.itp.common.integration;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.memo.MemoConstants;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;

import static com.discover.cmpp.action.itp.test.utils.TestUtils.getStringContent;
import static com.discover.cmpp.jwt.utils.JwtIntegrationTestHelper.httpAuthHeaders;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import com.discover.cmpp.action.itp.common.AbstractIntegrationTest;

class MemoIntegrationTest extends AbstractIntegrationTest {

    @Value("classpath:data/valid-create-memo-request.json")
    Resource validCreateMemoRequest;

    @Value("classpath:data/invalid-create-memo-request.json")
    Resource inValidCreateMemoRequest;

    @Test
    @DisplayName("CreateMemo api can created and saved in Db successfully")
    void canCreateMemo_whenValidMemoProvided() throws Exception {
        TestUtils.setWiremockCdsTranslationService();
        TestUtils.setWiremockCloakService();
        TestUtils.setWiremockCdsService();
        TestUtils.setWiremockProductsApiService();
        TestUtils.setWiremockMemoFluxService();
        mockMvc.perform(post(TestUtils.contextPath + MemoConstants.CREATE_MEMO_URL).headers(httpHeaders)
                .contentType(APPLICATION_JSON).header(ActionItpConstants.AGENT_ID, "agent1")
                .content(getStringContent(validCreateMemoRequest)))
                .andExpect(status().isCreated());
    }

    @Test
    @DisplayName("CreateMemo api can created and saved in Db successfully and fail publishing flux message")
    void canCreateMemo_whenValidMemoProvidedAndFluxFails() throws Exception {
        TestUtils.setWiremockCdsTranslationService();
        TestUtils.setWiremockCloakService();
        TestUtils.setWiremockCdsService();
        TestUtils.setWiremockProductsApiService();
        TestUtils.setWiremockMemoFluxService();
        mockMvc.perform(post(TestUtils.contextPath + MemoConstants.CREATE_MEMO_URL).headers(httpHeaders)
                .contentType(APPLICATION_JSON).header(ActionItpConstants.AGENT_ID, "agent1")
                .content(getStringContent(inValidCreateMemoRequest)))
                .andExpect(status().is5xxServerError());
    }

    @Test
    @DisplayName("CreateMemo api should return 401 when no JWT is provided")
    void whenInvalidJwtProvided_returns401() throws Exception {

        mockMvc.perform(post(TestUtils.contextPath + MemoConstants.CREATE_MEMO_URL)
                .contentType(APPLICATION_JSON).header(ActionItpConstants.AGENT_ID, "agent1")
                .content(getStringContent(validCreateMemoRequest)))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1001")))
                .andExpect(jsonPath("$.error_description", Matchers.equalTo("Unauthorized!")));
    }

    @Test
    @DisplayName("CreateMemo api should return 403 when wrong scope JWT is provided")
    void whenInvalidJwtIsProvided_returns403() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + MemoConstants.CREATE_MEMO_URL)
                .headers(httpAuthHeaders("WRONG_SCOPE")).contentType(APPLICATION_JSON)
                .header(ActionItpConstants.AGENT_ID, "agent1").content(getStringContent(validCreateMemoRequest)))
                .andExpect(status().isForbidden()).andExpect(jsonPath("$.error", Matchers.equalTo("1003")))
                .andExpect(jsonPath("$.error_description",
                        Matchers.equalTo("Forbidden - Not authorized to access the resource!")));
    }

    @Test
    @DisplayName("CreateMemo api should return 404 when invalid url is provided")
    void whenInvalidUrlIsProvided_returns404() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + MemoConstants.CREATE_MEMO_URL + "test").headers(httpHeaders)
                .contentType(APPLICATION_JSON).content(getStringContent(validCreateMemoRequest)))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("CreateMemo api should return 400 when bad request is provided")
    void whenBadRequestIsProvided_returns400() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + MemoConstants.CREATE_MEMO_URL).headers(httpHeaders)
                .header(ActionItpConstants.AGENT_ID, "agent1")
                .contentType(APPLICATION_JSON)
                .content("{\n" + " \"memoText\": \"\",\n" + " \"productEnrollmentId\": \"\"\n" + "}"))
                .andExpect(status().isBadRequest())
                .andExpect(content().json("{\n" + " \"errors\": { \n"
                        + "  \"1011\": \"Invalid memoText can't be null or blank\",\n"
                        + "  \"1012\": \"Invalid productEnrollmentId can't be null or blank\"\n" + " }\n" + "}"));
    }

    @Test
    @DisplayName("Fetch Memo api can fetch memo from Db successfully")
    void canFetchMemo_whenValidPEIDProvided() throws Exception {
        TestUtils.setWiremockCdsTranslationService();
        TestUtils.setWiremockCdsService();
        TestUtils.setWiremockCloakService();
        TestUtils.setWiremockProductsApiService();
        mockMvc.perform(post(TestUtils.contextPath + MemoConstants.CREATE_MEMO_URL).headers(httpHeaders)
                .contentType(APPLICATION_JSON).header(ActionItpConstants.AGENT_ID, "agent1")
                .content(getStringContent(validCreateMemoRequest)))
                .andExpect(status().isCreated());

        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_MEMO_PATH + "457821487").headers(httpHeaders)
                .contentType(APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("Fetch Memo api should return 401 when no JWT is provided")
    void whenInvalidJwtProvided_fetchMemo_returns401() throws Exception {

        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_MEMO_PATH + "457821487")
                .contentType(APPLICATION_JSON))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1001")))
                .andExpect(jsonPath("$.error_description", Matchers.equalTo("Unauthorized!")));
    }


    @Test
    @DisplayName("Fetch Memo api should return 403 when wrong scope JWT is provided")
    void whenInvalidJwtIsProvided_fetchMemo_returns403() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_MEMO_PATH + "457821487")
                .headers(httpAuthHeaders("WRONG_SCOPE")).contentType(APPLICATION_JSON))
                .andExpect(status().isForbidden()).andExpect(jsonPath("$.error", Matchers.equalTo("1003")))
                .andExpect(jsonPath("$.error_description",
                        Matchers.equalTo("Forbidden - Not authorized to access the resource!")));
    }

    @Test
    @DisplayName("Fetch Memo api should return 404 when invalid url is provided")
    void whenInvalidUrlIsProvided_fetchMemo_returns404() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + "test" + TestUtils.FETCH_MEMO_PATH).headers(httpHeaders)
                .contentType(APPLICATION_JSON).param("productEnrollmentId", "457821487"))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("Fetch Memo api should return 400 when bad request is provided")
    void whenBadRequestIsProvided_fetchMemo_returns400() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_MEMO_PATH + " ").headers(httpHeaders)
                .header(ActionItpConstants.AGENT_ID, "agent1")
                .contentType(APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(content().json("{\n" + " \"errors\": { \n"
                        + "  \"1012\": \"Invalid productEnrollmentId can't be null or blank\"\n" + " }\n" + "}"));
    }
}
