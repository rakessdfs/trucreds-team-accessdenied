package com.discover.cmpp.action.itp.common.integration;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.languagesettings.LanguageSettingsConstants;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;

import static com.discover.cmpp.action.itp.test.utils.TestUtils.getStringContent;
import static com.discover.cmpp.jwt.utils.JwtIntegrationTestHelper.httpAuthHeaders;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import com.discover.cmpp.action.itp.common.AbstractIntegrationTest;

class LanguageSettingsIntegrationTest extends AbstractIntegrationTest {

    @Value("classpath:data/valid-language-settings-request.json")
    Resource validLanguageSettingsRequest;

    @Value("classpath:data/invalid-language-settings-request.json")
    Resource invalidLanguageSettingsRequest;

    @Test
    @DisplayName("Create Language Settings when Valid Request is passed")
    void createLanguageSettings_whenValidRequest() throws Exception {

        mockMvc.perform(post(TestUtils.contextPath + LanguageSettingsConstants.SAVE_LANGUAGE_URL)
                .headers(httpHeaders)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .contentType(APPLICATION_JSON)
                .content(getStringContent(validLanguageSettingsRequest)))
                .andExpect(status().is2xxSuccessful());
    }

    @Test
    @DisplayName("Error creating Language Settings when invalid Request is passed")
    void errorCreateLanguageSettings_whenInvalidRequest() throws Exception {

        mockMvc.perform(post(TestUtils.contextPath + LanguageSettingsConstants.SAVE_LANGUAGE_URL)
                .headers(httpHeaders)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .contentType(APPLICATION_JSON)
                .content(getStringContent(invalidLanguageSettingsRequest)))
                .andExpect(status().is4xxClientError());
    }

    @Test
    @DisplayName("Create Language Settings return 401 when no JWT is provided")
    void createLanguageSettings_returns401() throws Exception {

        mockMvc.perform(get(TestUtils.contextPath + LanguageSettingsConstants.SAVE_LANGUAGE_URL)
                .contentType(APPLICATION_JSON))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1001")))
                .andExpect(jsonPath("$.error_description", Matchers.equalTo("Unauthorized!")));
    }


    @Test
    @DisplayName("Create Language Settings return 403 when wrong scope JWT is provided")
    void whenInvalidJwtIsProvided_createLanguageSettings_returns403() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + LanguageSettingsConstants.SAVE_LANGUAGE_URL)
                .headers(httpAuthHeaders("WRONG_SCOPE"))
                .contentType(APPLICATION_JSON))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1003")))
                .andExpect(jsonPath("$.error_description",
                        Matchers.equalTo("Forbidden - Not authorized to access the resource!")));
    }

    @Test
    @DisplayName("Create Language Settings return 404 when invalid url is provided")
    void whenInvalidUrlIsProvided_createLanguageSettings_returns404() throws Exception {
        mockMvc.perform(
                get(TestUtils.contextPath + "test" + LanguageSettingsConstants.SAVE_LANGUAGE_URL + "123456789")
                        .headers(httpHeaders)
                        .contentType(APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("Fetch Language Settings from Db successfully")
    void canFetchLanguageSettings_whenValidPEIDProvided() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + TestUtils.LANGUAGE_PATH)
                .headers(httpHeaders)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .contentType(APPLICATION_JSON)
                .content(getStringContent(validLanguageSettingsRequest)))
                .andExpect(status().is2xxSuccessful());

        mockMvc.perform(get(TestUtils.contextPath + TestUtils.LANGUAGE_PATH + "/9090123456789012345")
                .headers(httpHeaders)
                .contentType(APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("Fetch Language Settings api should return 401 when no JWT is provided")
    void whenInvalidJwtProvided_fetchLanguageSettings_returns401() throws Exception {

        mockMvc.perform(get(TestUtils.contextPath + TestUtils.LANGUAGE_PATH + "/123456789")
                .contentType(APPLICATION_JSON))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1001")))
                .andExpect(jsonPath("$.error_description", Matchers.equalTo("Unauthorized!")));
    }


    @Test
    @DisplayName("Fetch Language Settings api should return 403 when wrong scope JWT is provided")
    void whenInvalidJwtIsProvided_fetchLanguageSettings_returns403() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + TestUtils.LANGUAGE_PATH + "/123456789")
                .headers(httpAuthHeaders("WRONG_SCOPE"))
                .contentType(APPLICATION_JSON))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1003")))
                .andExpect(jsonPath("$.error_description",
                        Matchers.equalTo("Forbidden - Not authorized to access the resource!")));
    }

    @Test
    @DisplayName("Fetch Language Settings api should return 404 when invalid url is provided")
    void whenInvalidUrlIsProvided_fetchLanguageSettings_returns404() throws Exception {
        mockMvc.perform(
                get(TestUtils.contextPath + "test" + TestUtils.LANGUAGE_PATH + "/123456789")
                        .headers(httpHeaders)
                        .contentType(APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }
}
