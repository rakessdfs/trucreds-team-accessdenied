package com.discover.cmpp.action.itp.common.integration;

import com.discover.cmpp.action.itp.accountcenter.customer.profile.CustomerProfileConstants;
import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;

import static com.discover.cmpp.action.itp.test.utils.TestUtils.getStringContent;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import com.discover.cmpp.action.itp.common.AbstractIntegrationTest;

class CustomerProfileIntegrationTest extends AbstractIntegrationTest {

    @Value("classpath:data/valid-update-customer-profile-info-response.json")
    Resource validCustomerProfileInfoResponse;

    @Value("classpath:data/valid-update-customer-profile-info-request.json")
    Resource validCustomerProfileInfoRequest;

    @Value("classpath:data/invalid-update-customer-profile-info-request-no-data.json")
    Resource invalidCustomerProfileInfoRequestNoData;

    @Value("classpath:data/invalid-update-customer-profile-info-request-phone-number.json")
    Resource invalidUpdateCustomerProfileInfoRequestPhoneNumber;

    @Value("classpath:data/valid-update-customer-profile-info-request-returns-500.json")
    Resource validUpdateCustomerProfileInfoReturns500;

    @Test
    @DisplayName("Customer Update API can update customer profile using Account Center api")
    void canUpdateCustomerProfileInfo_whenValidAgentId_PartyId_ProductId_Provided() throws Exception {
        TestUtils.setWiremockAccountCenterService();
        mockMvc.perform(post(TestUtils.contextPath + CustomerProfileConstants.UPDATE_CUST_PROFILE_INFO_URL)
                .headers(httpHeaders)
                .contentType(APPLICATION_JSON)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .header(ActionItpConstants.PARTY_ID_HEADER, "1234567")
                .header(ActionItpConstants.X_DFSUSER_PEID, "1234567")
                .content(getStringContent(validCustomerProfileInfoRequest)))
                .andExpect(status().isOk()).andExpect(header()
                .string("Content-Type", "application/json"))
                .andExpect(content().json(getStringContent(validCustomerProfileInfoResponse)));

    }

    @Test
    @DisplayName("Account Center Api should return 204 when there is no data to be updated in Cds")
    void whenAccountCenterApi_returns204() throws Exception {
        TestUtils.setWiremockAccountCenterService();
        mockMvc.perform(post(TestUtils.contextPath + CustomerProfileConstants.UPDATE_CUST_PROFILE_INFO_URL)
                .headers(httpHeaders)
                .contentType(APPLICATION_JSON)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .header(ActionItpConstants.PARTY_ID_HEADER, "1234567")
                .header(ActionItpConstants.X_DFSUSER_PEID, "1234567")
                .content(getStringContent(invalidCustomerProfileInfoRequestNoData)))
                .andExpect(status().isNoContent());

    }

    @Test
    @DisplayName("Account Center Api should return 400 when partyId is empty")
    void whenPartyIdIsEmpty_returns400() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + CustomerProfileConstants.UPDATE_CUST_PROFILE_INFO_URL)
                .headers(httpHeaders)
                .header(ActionItpConstants.PARTY_ID_HEADER, "")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(getStringContent(validCustomerProfileInfoRequest)))
                .andExpect(status().isBadRequest())
                .andExpect(content()
                        .json("{\n" + " \"errors\": { \n" + "  \"4001\": \"Invalid PartyId " +
                                "must be all numeric\"\n" + " }\n" + "}"));

    }

    @Test
    @DisplayName("Account Center Api should return 400 when partyId is not numeric")
    void whenPartyIdIsNotNumeric_returns400() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + CustomerProfileConstants.UPDATE_CUST_PROFILE_INFO_URL)
                .headers(httpHeaders)
                .header(ActionItpConstants.PARTY_ID_HEADER, "ABCD")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(getStringContent(validCustomerProfileInfoRequest)))
                .andExpect(status().isBadRequest())
                .andExpect(content()
                        .json("{\n" + " \"errors\": { \n" + "  \"4001\": \"Invalid PartyId " +
                                "must be all numeric\"\n" + " }\n" + "}"));

    }

    @Test
    @DisplayName("Account Center Api should return 400 when phone number is invalids")
    void whenPhoneNumberIsInvalid_returns400() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + CustomerProfileConstants.UPDATE_CUST_PROFILE_INFO_URL)
                .headers(httpHeaders)
                .contentType(APPLICATION_JSON)
                .header(ActionItpConstants.PARTY_ID_HEADER, "1234567")
                .header(ActionItpConstants.X_DFSUSER_PEID, "1234567")
                .content(getStringContent(invalidUpdateCustomerProfileInfoRequestPhoneNumber)))
                .andExpect(status().isBadRequest())
                .andExpect(content().json("{\n" + " \"errors\": { \n" +
                        "  \"4005\": \"Invalid Phone number should be numeric and exactly 10 \"\n"
                        + " }\n" + "}"));

    }

    @Test
    @DisplayName("Account Center Api should return 500 when fails to update customer data")
    void whenAccountCenterFailstoUpdate_Throws500() throws Exception {
        TestUtils.setWiremockAccountCenterService();
        mockMvc.perform(post(TestUtils.contextPath + CustomerProfileConstants.UPDATE_CUST_PROFILE_INFO_URL)
                .headers(httpHeaders)
                .contentType(APPLICATION_JSON)
                .header(ActionItpConstants.PARTY_ID_HEADER, "1234567")
                .header(ActionItpConstants.X_DFSUSER_PEID, "1234567")
                .content(getStringContent(validUpdateCustomerProfileInfoReturns500)))
                .andExpect(status().isInternalServerError());

    }
}
