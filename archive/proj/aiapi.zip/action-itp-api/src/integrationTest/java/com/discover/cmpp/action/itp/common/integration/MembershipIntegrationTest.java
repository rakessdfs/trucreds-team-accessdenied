package com.discover.cmpp.action.itp.common.integration;

import com.discover.cmpp.action.itp.test.utils.TestUtils;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.test.web.servlet.MvcResult;

import static com.discover.cmpp.action.itp.test.utils.TestUtils.getStringContent;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import com.discover.cmpp.action.itp.common.AbstractIntegrationTest;

class MembershipIntegrationTest extends AbstractIntegrationTest {

    @Value("classpath:data/valid-fetch-membership-response-ff.json")
    Resource validFetchMembershipResponseFF;

    @Value("classpath:data/valid-fetch-membership-response-bm.json")
    Resource validFetchMembershipResponseEnrlFailRsnBM;

    @Value("classpath:data/valid-fetch-membership-response-cancel-rsn-bm.json")
    Resource validFetchMembershipResponseCancelRsnBM;

    @Value("classpath:data/valid-fetch-billing-response.json")
    Resource validFetchBillingResponse;

    @Value("classpath:data/valid-fetch-billing-date-response.json")
    Resource validFetchBillingDateResponse;

    @Value("classpath:data/valid-fetch-billing-null-response.json")
    Resource validFetchBillingNullResponse;

    @Test
    @DisplayName("Fetch Membership api can fetch membership info successfully - Friend and Family customer")
    void canFetchMembership_whenValidPartyIdProvided_FF() throws Exception {
        TestUtils.setWiremockCdsService();
        TestUtils.setWiremockProductEnrollmentApiService();
        TestUtils.setWiremockProductsApiService();

        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_MEMBERSHIP_PATH + "?partyId=1111")
                .header("X-DFSUSER-USER-ID", "11")
                .headers(httpHeaders))
                .andExpect(status().isOk())
                .andExpect(content().json(getStringContent(validFetchMembershipResponseFF)));
    }

    @Test
    @DisplayName("Fetch Membership api can fetch membership info successfully - Broad Market Customer - Enrolled Failed Reason")
    void canFetchMembership_whenValidPartyIdProvided_Enrl_Fail_Rsn_BM() throws Exception {
        TestUtils.setWiremockCdsService();
        TestUtils.setWiremockProductsApiService();
        TestUtils.setWiremockProductEnrollmentApiService();
        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_MEMBERSHIP_PATH + "?partyId=2222")
                .header("X-DFSUSER-USER-ID", "11")
                .headers(httpHeaders))
                .andExpect(status().isOk())
                .andExpect(content().json(getStringContent(validFetchMembershipResponseEnrlFailRsnBM)));
    }

    @Test
    @DisplayName("Fetch Membership api can fetch membership info successfully - Broad Market Customer - Cancellation Reason")
    void canFetchMembership_whenValidPartyIdProvided_Cancel_Rsn_BM() throws Exception {
        TestUtils.setWiremockCdsService();
        TestUtils.setWiremockProductsApiService();
        TestUtils.setWiremockProductEnrollmentApiService();
        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_MEMBERSHIP_PATH + "?partyId=3333")
                .header("X-DFSUSER-USER-ID", "11")
                .headers(httpHeaders))
                .andExpect(status().isOk())
                .andExpect(content().json(getStringContent(validFetchMembershipResponseCancelRsnBM)));
    }

    @Test
    @DisplayName("Fetch Membership api should return 400 when invalid agent id")
    void whenInValidAgentIdProvided_returns400() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_MEMBERSHIP_PATH + "?partyId=1111")
                .header("X-DFSUSER-USER-ID", "")
                .headers(httpHeaders))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("Fetch Membership api should return 401 when unauthorized")
    void whenUnauthorized_returns401() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_MEMBERSHIP_PATH + "?partyId=1111")
                .header("X-DFSUSER-USER-ID", "abc123")
                .contentType(APPLICATION_JSON))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1001")))
                .andExpect(jsonPath("$.error_description", Matchers.equalTo("Unauthorized!")));
    }

    @Test
    @DisplayName("Fetch Membership api should return 404 when invalid url is provided")
    void whenInvalidUrlIsProvided_returns404() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + "/test-url")
                .header("X-DFSUSER-USER-ID", "123456789")
                .headers(httpHeaders))
                .andExpect(status().isNotFound());
    }

    @Test
    @Disabled("please review")
    @DisplayName("Fetch Membership api should return 500 when there is an internal server error")
    void whenInternalServerError_returns500() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_MEMBERSHIP_PATH + "?partyId=5555")
                .header("X-DFSUSER-USER-ID", "333333333")
                .headers(httpHeaders))
                .andExpect(status().is5xxServerError());
    }

    // Billing
    @Test
    @DisplayName("Fetch Billing api can fetch billing info successfully for FNF customer")
    void canFetchBillingForFnf_returns200_whenValidPeidProvided() throws Exception {

        TestUtils.setWiremockCsidSubscriberApi();
        TestUtils.setWiremockProductReferralApi();
        TestUtils.setWiremockCardCustomerDataApi();
        TestUtils.setWiremockAccountNumberApi();
        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_BILLING_PATH + "?peid=54321&subscriberId=PDCD203432229473040&customerType=ITP_FF&partyId=12345")
                .header("X-DFSUSER-USER-ID", "15")
                .headers(httpHeaders))
                .andExpect(status().isOk())
                .andExpect(content().json(getStringContent(validFetchBillingResponse)));
    }

    @Test
    @DisplayName("Fetch Billing api can fetch billing info successfully for BM customer")
    void canFetchBillingForBm_returns200_whenValidPeidProvided() throws Exception {
        TestUtils.setWiremockProductsApiService();
        TestUtils.setWiremockCsidSubscriberApi();
        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_BILLING_PATH + "?peid=54322&subscriberId=PDCD203432229473040&customerType=ITP_BM&partyId=4444")
                .header("X-DFSUSER-USER-ID", "15")
                .headers(httpHeaders))
                .andExpect(status().isOk())
                .andExpect(content().json(getStringContent(validFetchBillingNullResponse)));
    }

    @Test
    @DisplayName("Fetch Billing api can fetch billing info successfully for BM CAN/PCN customer")
    void canFetchBillingForBmCanPcn_returns200_whenValidPeidProvided() throws Exception {

        TestUtils.setWiremockProductsApiService();
        TestUtils.setWiremockCsidSubscriberApi();
        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_BILLING_PATH + "?peid=54322&subscriberId=PDCD203432229473040&customerType=ITP_BM&partyId=3333")
                .header("X-DFSUSER-USER-ID", "15")
                .headers(httpHeaders))
                .andExpect(status().isOk())
                .andExpect(content().json(getStringContent(validFetchBillingNullResponse)));
    }

    @Test
    @DisplayName("Fetch Billing should return 400 for null or blank peid")
    void canFetchBilling_returns400_whenPeidIsNullOrBlank() throws Exception {
        MvcResult result = mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_BILLING_PATH + "?peid=&subscriberId=PD12&customerType=ITP_FF&partyId=12345")
                .header("X-DFSUSER-USER-ID", "15")
                .headers(httpHeaders))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertThat(result.getResponse().getContentAsString(), containsString("Invalid productEnrollmentId can't be null or blank"));
    }

    @Test
    @DisplayName("Fetch Billing should return 400 when peid is invalid")
    void canFetchBilling_returns400_whenPeidIsInvalid() throws Exception {
        TestUtils.setWiremockProductReferralApi();
        MvcResult result = mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_BILLING_PATH + "?peid=1&subscriberId=PD12&customerType=ITP_FF&partyId=12345")
                .header("X-DFSUSER-USER-ID", "15")
                .headers(httpHeaders))
                .andExpect(status().is4xxClientError())
                .andReturn();
        assertTrue(result.getResponse().getContentAsString().contains("Invalid Data In Product Enrollment Id. Size Should Be 19 Numbers Starting With 9090"));
    }

    @Test
    @DisplayName("Fetch Billing should return 400 for peid not found")
    void canFetchBilling_returns400_whenPeidNotFound() throws Exception {
        TestUtils.setWiremockProductReferralApi();
        MvcResult result = mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_BILLING_PATH + "?peid=2&subscriberId=PD12&customerType=ITP_FF&partyId=12345")
                .header("X-DFSUSER-USER-ID", "15")
                .headers(httpHeaders))
                .andExpect(status().is4xxClientError())
                .andReturn();
        assertTrue(result.getResponse().getContentAsString().contains("PEID not found"));
    }

    @Test
    @DisplayName("Fetch billing should return 401 when unauthorized")
    void canFetchBilling_returns401_whenInvalidPeidProvided() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_BILLING_PATH + "?peid=3&subscriberId=PD12&customerType=ITP_FF&partyId=12345")
                .header("X-DFSUSER-USER-ID", "15")
                .contentType(APPLICATION_JSON))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1001")))
                .andExpect(jsonPath("$.error_description", Matchers.equalTo("Unauthorized!")));
    }

    @Test
    @DisplayName("Fetch Billing should return 500 for internal server error")
    void canFetchBilling_returns500_whenInternalServerError() throws Exception {
        TestUtils.setWiremockProductReferralApi();
        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_BILLING_PATH + "?peid=4&subscriberId=PD12&customerType=ITP_FF&partyId=12345")
                .header("X-DFSUSER-USER-ID", "15")
                .headers(httpHeaders))
                .andExpect(status().is5xxServerError());
    }
}
