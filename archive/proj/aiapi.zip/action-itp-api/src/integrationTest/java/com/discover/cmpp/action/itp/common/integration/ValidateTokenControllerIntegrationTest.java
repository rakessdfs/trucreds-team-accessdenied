package com.discover.cmpp.action.itp.common.integration;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.session.ValidateTokenInput;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static com.discover.cmpp.jwt.utils.JwtIntegrationTestHelper.httpAuthHeaders;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import com.discover.cmpp.action.itp.common.AbstractIntegrationTest;

class ValidateTokenControllerIntegrationTest extends AbstractIntegrationTest {

    @Test
    @DisplayName("Validate ValidateTokenInput API can validate valid jwtToken using JwtActionItpUtil")
    void canReturnUserName_whenAnValidJwtTokenIsReceived() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + ActionItpConstants.JWT_TOKEN_VALIDATE_URL).headers(httpHeaders)
                .contentType(APPLICATION_JSON)
                .content(getValidRequest("testUser")))
                .andExpect(status().isOk()).andExpect(header().string("Content-Type", "application/json"))
                .andExpect(jsonPath("$.username", Matchers.equalTo("testUser")));
    }

    @Test
    @DisplayName("Validate ValidateTokenInput API can validate invalid jwtToken using JwtActionItpUtil")
    void canReturnUnauthorizedStatus_whenAnInValidJwtTokenIsReceived() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + ActionItpConstants.JWT_TOKEN_VALIDATE_URL).headers(httpHeaders)
                .contentType(APPLICATION_JSON).content(getInvalidRequest()))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("Validate ValidateTokenInput API should return 401 when no AUTH_TOKEN jwt is provided")
    void whenNoAuthTokenIsProvided_returns401() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + ActionItpConstants.JWT_TOKEN_VALIDATE_URL).contentType(APPLICATION_JSON)
                .content(getValidRequest("testUser"))).andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1001")))
                .andExpect(jsonPath("$.error_description", Matchers.equalTo("Unauthorized!")));
    }

    @Test
    @DisplayName("Validate ValidateTokenInput API should return 403 when wrong scope AUTH_TOKEN jwt is provided")
    void whenInvalidAuthTokenIsProvided_returns403() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + ActionItpConstants.JWT_TOKEN_VALIDATE_URL).headers(httpAuthHeaders("WRONG_SCOPE"))
                .contentType(APPLICATION_JSON).content(getInvalidRequest()))
                .andExpect(status().isForbidden()).andExpect(jsonPath("$.error", Matchers.equalTo("1003")))
                .andExpect(jsonPath("$.error_description",
                        Matchers.equalTo("Forbidden - Not authorized to access the resource!")));
    }

    @Test
    @DisplayName("Validate ValidateTokenInput API should return 404 when invalid url is provided")
    void whenInvalidUrlIsProvided_returns404() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + ActionItpConstants.JWT_TOKEN_VALIDATE_URL + "test").headers(httpHeaders)
                .contentType(APPLICATION_JSON).content(getInvalidRequest()))
                .andExpect(status().isNotFound());
    }

    private String getValidRequest(String username) throws JsonProcessingException {
        return objectMapper.writeValueAsString(ValidateTokenInput
                .builder()
                .jwtToken(jwtActionItpUtil.generateJwtToken(username)).build());
    }

    private String getInvalidRequest() throws JsonProcessingException {
        return objectMapper.writeValueAsString(ValidateTokenInput
                .builder()
                .jwtToken("INVALID TOKEN").build());
    }


}
