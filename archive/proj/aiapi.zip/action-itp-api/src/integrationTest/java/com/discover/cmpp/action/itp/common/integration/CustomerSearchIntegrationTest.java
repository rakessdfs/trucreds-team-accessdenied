package com.discover.cmpp.action.itp.common.integration;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.custlookup.CustLookUpConstants;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;

import static com.discover.cmpp.action.itp.test.utils.TestUtils.getStringContent;
import static com.discover.cmpp.jwt.utils.JwtIntegrationTestHelper.httpAuthHeaders;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import com.discover.cmpp.action.itp.common.AbstractIntegrationTest;

class CustomerSearchIntegrationTest extends AbstractIntegrationTest {

    @Value("classpath:data/valid-cust-pii-look-up-request.json")
    Resource validCustLookUpRequest;

    @Value("classpath:data/valid-cust-pii-look-up-response.json")
    Resource validCustLookUpResponse;

    @Value("classpath:data/valid-cust-pii-look-up-single-response.json")
    Resource validCustLookUpSingleResponse;

    @Value("classpath:data/invalid-cust-pii-look-up-request.json")
    Resource invalidCustLookUpRequest;

    @Value("classpath:data/valid-cust-pii-look-up-request-peid.json")
    Resource validCustLookUpRequestPeid;

    @Value("classpath:data/valid-cust-pii-look-up-request-subscriberId.json")
    Resource validCustLookUpRequestSubscriberId;

    @Test
    @DisplayName("Cust Look Api can get customer pii query data from CDS")
    void canReturnCustomerPiiSearch_whenValidSearchProvided() throws Exception {
        TestUtils.setWiremockCdsTranslationService();
        TestUtils.setWiremockCloakService();
        TestUtils.setWiremockCdsService();
        mockMvc.perform(post(TestUtils.contextPath + CustLookUpConstants.CUST_PII_LOOK_UP_URL).headers(httpHeaders)
                .contentType(APPLICATION_JSON)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .content(getStringContent(validCustLookUpRequest)))
                .andExpect(status().isOk()).andExpect(header().string("Content-Type", "application/json"))
                .andExpect(content().json(getStringContent(validCustLookUpResponse)));
    }

    @Test
    @DisplayName("Cust Look Api should return 204 when customer not found in CDS")
    void whenCustNotFound_returns200() throws Exception {
        TestUtils.setWiremockCdsTranslationService();
        TestUtils.setWiremockCloakService();
        TestUtils.setWiremockCdsService();
        mockMvc.perform(post(TestUtils.contextPath + CustLookUpConstants.CUST_PII_LOOK_UP_URL).headers(httpHeaders)
                .contentType(APPLICATION_JSON)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .content(getStringContent(invalidCustLookUpRequest)))
                .andExpect(status().isOk())
                .andExpect(content().json("{\n" +
                        "  \"customers\": []\n" +
                        "}"));
    }

    @Test
    @DisplayName("Cust Look Api should return 401 when no JWT is provided")
    void whenNoJwtIsProvided_returns401() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + CustLookUpConstants.CUST_PII_LOOK_UP_URL).contentType(APPLICATION_JSON)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .content(getStringContent(validCustLookUpRequest)))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1001")))
                .andExpect(jsonPath("$.error_description", Matchers.equalTo("Unauthorized!")));
    }

    @Test
    @DisplayName("Cust Look Api should return 403 when wrong scope JWT is provided")
    void whenInvalidJwtIsProvided_returns403() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + CustLookUpConstants.CUST_PII_LOOK_UP_URL).headers(httpAuthHeaders("WRONG_SCOPE"))
                .contentType(APPLICATION_JSON)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .content(getStringContent(validCustLookUpRequest)))
                .andExpect(status().isForbidden()).andExpect(jsonPath("$.error", Matchers.equalTo("1003")))
                .andExpect(jsonPath("$.error_description",
                        Matchers.equalTo("Forbidden - Not authorized to access the resource!")));
    }

    @Test
    @DisplayName("Cust Look Api should return 404 when invalid url is provided")
    void whenInvalidUrlIsProvided_returns404() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + CustLookUpConstants.CUST_PII_LOOK_UP_URL + "test").headers(httpHeaders)
                .contentType(APPLICATION_JSON)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .content(getStringContent(validCustLookUpRequest)))
                .andExpect(status().isNotFound());
    }

    //@Test
    @DisplayName("Cust Look Api should return 400 when bad request is provided")
    void whenBadRequestIsProvided_returns400() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + CustLookUpConstants.CUST_PII_LOOK_UP_URL).headers(httpHeaders)
                .contentType(APPLICATION_JSON)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .content("{\n" + " \"dateOfBirth\": \"01/011970\",\n" + " \"firstName\": \"\",\n"
                        + " \"lastName\": \"\",\n" + " \"ssn\": \"123-45-6789\"\n" + "}"))
                .andExpect(status().isBadRequest())
                .andExpect(content().json("{\n" + " \"errors\": { \n" + "  \"1002\": \"Invalid Date Of Birth\",\n"
                        + "  \"1004\": \"Invalid Last Name\",\n" + "  \"1008\": \"Invalid First Name\"\n" + " }\n" + "}"));
    }

    @Test
    @DisplayName("Cust Look Api should return 200 for valid Peid")
    void whenCustFoundWithValidPeid_returns200() throws Exception {
        TestUtils.setWiremockCdsTranslationService();
        TestUtils.setWiremockCloakService();
        TestUtils.setWiremockCdsService();
        mockMvc.perform(post(TestUtils.contextPath + CustLookUpConstants.CUST_PII_LOOK_UP_URL).headers(httpHeaders)
                .contentType(APPLICATION_JSON)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .content(getStringContent(validCustLookUpRequestPeid)))
                .andExpect(status().isOk()).andExpect(header().string("Content-Type", "application/json"))
                .andExpect(content().json(getStringContent(validCustLookUpSingleResponse)));
    }

    @Test
    @DisplayName("Cust Look Api should return 200 for valid SubscriberId ")
    void whenCustFoundWithValidSubscriberId_returns200() throws Exception {
        TestUtils.setWiremockCdsTranslationService();
        TestUtils.setWiremockProductEnrollmentApiService();
        TestUtils.setWiremockCloakService();
        TestUtils.setWiremockCdsService();
        mockMvc.perform(post(TestUtils.contextPath + CustLookUpConstants.CUST_PII_LOOK_UP_URL).headers(httpHeaders)
                .contentType(APPLICATION_JSON)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .content(getStringContent(validCustLookUpRequestSubscriberId)))
                .andExpect(status().isOk()).andExpect(header().string("Content-Type", "application/json"))
                .andExpect(content().json(getStringContent(validCustLookUpSingleResponse)));
    }
}
