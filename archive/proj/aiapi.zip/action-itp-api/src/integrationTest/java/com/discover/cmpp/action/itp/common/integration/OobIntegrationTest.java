package com.discover.cmpp.action.itp.common.integration;

import com.discover.cmpp.action.itp.oob.OobConstants;
import com.discover.cmpp.action.itp.oob.OobSoapIntegrationTestConfiguration;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ContextConfiguration;

import static com.discover.cmpp.action.itp.test.utils.TestUtils.getStringContent;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import com.discover.cmpp.action.itp.common.AbstractIntegrationTest;

@ContextConfiguration(classes = OobSoapIntegrationTestConfiguration.class)
class OobIntegrationTest extends AbstractIntegrationTest {

    @Value("classpath:data/valid-oob-unlock-user-request.json")
    Resource unlockUserSuccessRequest;

    @Value("classpath:data/valid-oob-unlock-user-response.json")
    Resource unlockUserSuccessResponse;

    @Value("classpath:data/valid-oob-validate-code-request.json")
    Resource validateCodeSuccessRequest;

    @Value("classpath:data/valid-oob-lock-user-request.json")
    Resource lockUserSuccessRequest;

    @Value("classpath:data/valid-oob-validate-code-response.json")
    Resource validateCodeSuccessResponse;

    @Value("classpath:data/valid-oob-lock-user-response.json")
    Resource lockUserSuccessResponse;

    @Value("classpath:data/valid-oob-validate-code-locked-request.json")
    Resource validateCodeLockedRequest;

    @Value("classpath:data/valid-oob-validate-code-exception-request.json")
    Resource validateCodeExceptionRequest;

    @Value("classpath:data/valid-oob-send-code-request.json")
    Resource sendCodeSuccessRequest;

    @Value("classpath:data/valid-oob-send-code-response.json")
    Resource sendCodeSuccessResponse;

    @Value("classpath:data/valid-oob-send-code-locked-request.json")
    Resource sendCodeLockedRequest;

    @Value("classpath:data/valid-oob-send-code-exception-request.json")
    Resource sendCodeExceptionRequest;

    @Value("classpath:data/valid-oob-get-status-response.json")
    Resource getStatusSuccessResponse;

    @Value("classpath:data/valid-oob-get-status-error-response.json")
    Resource getStatusErrorResponse;

    @Value("classpath:data/valid-oob-unlock-code-cust-key-long-exception-request.json")
    Resource unlockCodeCustKeyLongExceptionRequest;

    @Value("classpath:data/valid-oob-unlock-code-cust-key-empty-exception-request.json")
    Resource unlockCodeCustKeyEmptyExceptionRequest;

    @Value("classpath:data/valid-oob-unlock-code-cust-key-not-exist-exception-request.json")
    Resource unlockCodeCustKeyNotExistExceptionRequest;

    @Test
    @DisplayName("Unlock User OOB returns a successful response")
    void unlockUser_succeeds_whenValidRequest() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + OobConstants.UNLOCK_USER_URL)
                .headers(httpHeaders)
                .header("X-DFSUSER-USER-ID", "cxcxcxc")
                .content(getStringContent(unlockUserSuccessRequest)))
                .andExpect(status().isOk())
                .andExpect(content().json(getStringContent(unlockUserSuccessResponse)));
    }

    @Test
    @DisplayName("UnlockUser OOB Code throws oob exception when Cust Key is empty - invalid response")
    void unlockUser_CustKeyEmpty_throwsException_whenBadResponse() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + OobConstants.UNLOCK_USER_URL)
                .headers(httpHeaders)
                .header("X-DFSUSER-USER-ID", "cxcxcxc")
                .content(getStringContent(unlockCodeCustKeyEmptyExceptionRequest)))
                .andExpect(status().is4xxClientError())
                .andExpect(content().json("{\n" + " \"errors\": { \n"
                        + "  \"1041\": \"CUST USER KEY IS NULL OR EMPTY\"\n" + " }\n" + "}"));
    }

    @Test
    @DisplayName("UnlockUser OOB Code throws oob exception when Cust Key does not exist - invalid response")
    void unlockUser_CustKeyDoesNotExist_throwsException_whenBadResponse() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + OobConstants.UNLOCK_USER_URL)
                .headers(httpHeaders)
                .header("X-DFSUSER-USER-ID", "cxcxcxc")
                .content(getStringContent(unlockCodeCustKeyNotExistExceptionRequest)))
                .andExpect(status().is4xxClientError())
                .andExpect(content().json("{\n" + " \"errors\": { \n"
                        + "  \"1042\": \"User does not exist\"\n" + " }\n" + "}"));
    }

    @Test
    @DisplayName("UnlockUser OOB Code throws oob exception when Cust Key is too long - invalid response")
    void unlockUser_CustKeyLong_throwsException_whenBadResponse() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + OobConstants.UNLOCK_USER_URL)
                .headers(httpHeaders)
                .header("X-DFSUSER-USER-ID", "cxcxcxc")
                .content(getStringContent(unlockCodeCustKeyLongExceptionRequest)))
                .andExpect(status().is4xxClientError())
                .andExpect(content().json("{\n" + " \"errors\": { \n"
                        + "  \"1043\": \"CUST USER KEY TOO LONG\"\n" + " }\n" + "}"));
    }

    @Test
    @DisplayName("Validate OOB Code returns a successful response")
    void validateCode_succeeds_whenValidRequest() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + OobConstants.VALIDATE_CODE_URL)
                .headers(httpHeaders)
                .content(getStringContent(validateCodeSuccessRequest)))
                .andExpect(status().isOk())
                .andExpect(content().json(getStringContent(validateCodeSuccessResponse)));
    }

    @Test
    @DisplayName("Validate OOB Code throws oob exception when invalid response")
    void validateCode_throwsException_whenBadResponse() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + OobConstants.VALIDATE_CODE_URL)
                .headers(httpHeaders)
                .content(getStringContent(validateCodeExceptionRequest)))
                .andExpect(status().isInternalServerError())
                .andExpect(content().json("{\n" + " \"errors\": { \n"
                        + "  \"1040\": \"OOB Service Failure\"\n" + " }\n" + "}"));
    }

    @Test
    @DisplayName("Validate OOB Code throws oob exception when negative return code")
    void validateCode_throwsException_whenNegativeReturnCode() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + OobConstants.VALIDATE_CODE_URL)
                .headers(httpHeaders)
                .content(getStringContent(validateCodeLockedRequest)))
                .andExpect(status().isInternalServerError())
                .andExpect(content().json("{\n" + " \"errors\": { \n"
                        + "  \"1040\": \"OOB Service Failure\"\n" + " }\n" + "}"));
    }

    @Test
    @DisplayName("Validate OOB Code throws 401 when unauthorized")
    void validateCode_throwsException_whenUnauthorized() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + OobConstants.VALIDATE_CODE_URL)
                .content(getStringContent(validateCodeLockedRequest)))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1001")))
                .andExpect(jsonPath("$.error_description", Matchers.equalTo("Unauthorized!")));
    }

    @Test
    @DisplayName("Locking customer through validate OOB Code returns a successful response")
    void validateCode_lockCustomer_succeeds_whenValidRequest() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + OobConstants.VALIDATE_CODE_URL)
                .headers(httpHeaders)
                .content(getStringContent(lockUserSuccessRequest)))
                .andExpect(status().isOk())
                .andExpect(content().json(getStringContent(lockUserSuccessResponse)));
    }

    @Test
    @DisplayName("Send OOB Code returns a successful response")
    void sendCode_succeeds_whenValidRequest() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + OobConstants.SEND_CODE_URL)
                .headers(httpHeaders)
                .header("X-DFSUSER-USER-ID", "cxcxcxc")
                .content(getStringContent(sendCodeSuccessRequest)))
                .andExpect(status().isOk())
                .andExpect(content().json(getStringContent(sendCodeSuccessResponse)));
    }

    @Test
    @DisplayName("Validate OOB Code throws oob exception when invalid response")
    void sendCode_throwsException_whenBadResponse() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + OobConstants.SEND_CODE_URL)
                .headers(httpHeaders)
                .header("X-DFSUSER-USER-ID", "cxcxcxc")
                .content(getStringContent(sendCodeExceptionRequest)))
                .andExpect(status().isInternalServerError())
                .andExpect(content().json("{\n" + " \"errors\": { \n"
                        + "  \"1040\": \"OOB Service Failure\"\n" + " }\n" + "}"));
    }

    @Test
    @DisplayName("Validate OOB Code throws 401 when unauthorized")
    void sendCode_throwsException_whenUnauthorized() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + OobConstants.SEND_CODE_URL)
                .content(getStringContent(sendCodeLockedRequest)))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1001")))
                .andExpect(jsonPath("$.error_description", Matchers.equalTo("Unauthorized!")));
    }

    @Test
    @DisplayName("OOB Get Status success path")
    void getStatus_succeeds_whenValidRequest() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_STATUS_PATH + "123456789")
                .headers(httpHeaders))
                .andExpect(status().isOk())
                .andExpect(content().json(getStringContent(getStatusSuccessResponse)));
    }

    @Test
    @DisplayName("OOB Get Status error response when api is not successful")
    void getStatus_errorResponse_whenOobError() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_STATUS_PATH + "999999999")
                .headers(httpHeaders))
                .andExpect(status().isInternalServerError())
                .andExpect(content().json("{\n" + " \"errors\": { \n"
                        + "  \"1040\": \"OOB Service Failure\"\n" + " }\n" + "}"));
    }

    @Test
    @DisplayName("OOB Get Status throws exception when unauthorized")
    void getStatus_throwsException_whenUnauthorized() throws Exception {
        mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_STATUS_PATH + "123456789"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1001")))
                .andExpect(jsonPath("$.error_description", Matchers.equalTo("Unauthorized!")));
    }
}
