package com.discover.cmpp.action.itp.common.integration;

import com.discover.cmpp.action.itp.cancel.CancelConstants;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;

import static com.discover.cmpp.action.itp.test.utils.TestUtils.getStringContent;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import com.discover.cmpp.action.itp.common.AbstractIntegrationTest;

class CancelIntegrationTest extends AbstractIntegrationTest {

    @Value("classpath:data/valid-cancel-request.json")
    Resource validCancelRequest;

    @Test
    @DisplayName("Create valid cancel membership")
    void canCreateValidCancelMembership() throws Exception {
        TestUtils.setWiremockProductEnrollmentApiService();
        TestUtils.setWiremockCancelApi();
        mockMvc.perform(post(TestUtils.contextPath + CancelConstants.CANCEL_REQUEST_API_URL)
                .header("X-DFSUSER-USER-ID", "testRacf")
                .param(CancelConstants.PRODUCT_ENROLLMENT_ID, "9090512345812345678")
                .param(CancelConstants.CANCEL_RSN_CDE, "DNW")
                .headers(httpHeaders)
                .contentType(APPLICATION_JSON)
                .content(getStringContent(validCancelRequest)))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("Cancel Membership throws Internal Server Error")
    void canCreateValidCancelMembership_InternalServerError() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + CancelConstants.CANCEL_REQUEST_API_URL)
                .header("X-DFSUSER-USER-ID", "testRacf")
                .param(CancelConstants.PRODUCT_ENROLLMENT_ID, "9090912345812345678")
                .param(CancelConstants.CANCEL_RSN_CDE, "XYZ")
                .headers(httpHeaders)
                .contentType(APPLICATION_JSON)
                .content(getStringContent(validCancelRequest)))
                .andExpect(status().isInternalServerError());
    }
}
