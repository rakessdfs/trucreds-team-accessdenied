package com.discover.cmpp.action.itp.common.integration;

import com.discover.cmpp.action.itp.authentication.ldap.AgentAuthConstants;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import com.discover.cmpp.action.itp.common.AbstractIntegrationTest;

import static com.discover.cmpp.action.itp.test.utils.TestUtils.getStringContent;
import static com.discover.cmpp.jwt.utils.JwtIntegrationTestHelper.httpAuthHeaders;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class AgentAuthIntegrationTest extends AbstractIntegrationTest {

    @Value("classpath:data/valid-agent-auth-request.json")
    Resource validAgentAuthRequest;
    @Value("classpath:data/invalid-agent-auth-request.json")
    Resource inValidAgentAuthRequest;
    @Value("classpath:data/invalid-pwd-agent-auth-request.json")
    Resource inValidPwdAgentAuthRequest;
    @Value("classpath:data/invalid-userName-agent-auth-request.json")
    Resource inValidUserNameAgentAuthRequest;

    //@Test
    @DisplayName("Agent Auth API can authenticate user using LDAP")
    void canReturnUserDetails_whenAnValidUserCredtIsReceived() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + AgentAuthConstants.AGENT_AUTH_URL).headers(httpHeaders)
                .contentType(APPLICATION_JSON).content(getStringContent(validAgentAuthRequest)))
                .andExpect(status().isOk()).andExpect(header().string("Content-Type", "application/json"))
                .andExpect(jsonPath("$.userName", Matchers.equalTo("wseng04")));
    }

    @Test
    @DisplayName("Agent Auth API can authenticate invalid user using LDAP")
    void canReturnUserNotAuthMessage_whenAnInvalidUserCredtIsReceived() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + AgentAuthConstants.AGENT_AUTH_URL).headers(httpHeaders)
                .contentType(APPLICATION_JSON).content(getStringContent(inValidAgentAuthRequest)))
                .andExpect(status().isUnauthorized()).andExpect(header().string("Content-Type", "application/json"))
                .andExpect(content()
                        .json("{\n" + " \"errors\": { \n" + "  \"1009\": \"User not authenticated\"\n" + " }\n" + "}"));
    }

    @Test
    @DisplayName("Agent Auth API should return 401 when no JWT is provided")
    void whenNoJwtIsProvided_returns401() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + AgentAuthConstants.AGENT_AUTH_URL).contentType(APPLICATION_JSON)
                .content(getStringContent(validAgentAuthRequest))).andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error", Matchers.equalTo("1001")))
                .andExpect(jsonPath("$.error_description", Matchers.equalTo("Unauthorized!")));
    }

    @Test
    @DisplayName("Agent Auth API should return 403 when wrong scope JWT is provided")
    void whenInvalidJwtIsProvided_returns403() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + AgentAuthConstants.AGENT_AUTH_URL).headers(httpAuthHeaders("WRONG_SCOPE"))
                .contentType(APPLICATION_JSON).content(getStringContent(validAgentAuthRequest)))
                .andExpect(status().isForbidden()).andExpect(jsonPath("$.error", Matchers.equalTo("1003")))
                .andExpect(jsonPath("$.error_description",
                        Matchers.equalTo("Forbidden - Not authorized to access the resource!")));
    }

    @Test
    @DisplayName("Agent Auth API should return 400 when invalid password is provided")
    void canReturnInvalidPasswordtMessage_whenAnInvalidPasswordIsReceived() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + AgentAuthConstants.AGENT_AUTH_URL).headers(httpHeaders)
                .contentType(APPLICATION_JSON).content(getStringContent(inValidPwdAgentAuthRequest)))
                .andExpect(status().isBadRequest()).andExpect(header().string("Content-Type", "application/json"))
                .andExpect(content()
                        .json("{\n" + " \"errors\": { \n" + "  \"1006\": \"Invalid Password\"\n" + " }\n" + "}"));
    }

    @Test
    @DisplayName("Agent Auth API should return 400 when invalid UserName is provided")
    void canReturnInvalidUserNameMessage_whenAnInvalidUserNameIsReceived() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + AgentAuthConstants.AGENT_AUTH_URL).headers(httpHeaders)
                .contentType(APPLICATION_JSON).content(getStringContent(inValidUserNameAgentAuthRequest)))
                .andExpect(status().isBadRequest()).andExpect(header().string("Content-Type", "application/json"))
                .andExpect(content()
                        .json("{\n" + " \"errors\": { \n" + "  \"1005\": \"Invalid Username\"\n" + " }\n" + "}"));
    }

    @Test
    @DisplayName("Agent Auth API should return 404 when invalid url is provided")
    void whenInvalidUrlIsProvided_returns404() throws Exception {
        mockMvc.perform(post(TestUtils.contextPath + AgentAuthConstants.AGENT_AUTH_URL + "test").headers(httpHeaders)
                .contentType(APPLICATION_JSON).content(getStringContent(inValidPwdAgentAuthRequest)))
                .andExpect(status().isNotFound());
    }

}
