package com.discover.cmpp.action.itp;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "classpath:features",
        plugin = {"pretty",
                "html:build/reports/cucumber-reports/smokeTest.html",
                "json:build/reports/cucumber-reports/smoke-test-results.json"},
        glue = {"com.discover.cmpp.action.itp.steps"})
public class SmokeTest {

}
