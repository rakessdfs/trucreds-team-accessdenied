package com.discover.cmpp.action.itp.steps;

import com.discover.cmpp.action.itp.ActionItpClient;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CustomerLookupSteps {

    private ActionItpClient actionItpClient = new ActionItpClient();

    @Given("customer lookup endpoint")
    public void customerLookupEndpoint() {
        actionItpClient.setUp("/enterprise/products/action/itp/v1/customer/pii");
    }

    @When("customer lookup endpoint has been called")
    public void customerLookupEndpointHasBeenCalled() {
        actionItpClient.customerLookupIsRequested();
    }

    @Then("customer lookup response received successfully")
    public void customerLookupResponseReceivedSuccessfully() {
        actionItpClient.customerLookupSuccessfulResponse();
    }
}
