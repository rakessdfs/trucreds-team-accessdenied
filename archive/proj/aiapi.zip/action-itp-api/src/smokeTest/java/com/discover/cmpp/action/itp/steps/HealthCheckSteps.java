package com.discover.cmpp.action.itp.steps;

import com.discover.cmpp.action.itp.ActionItpClient;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.spring.CucumberContextConfiguration;

@CucumberContextConfiguration
public class HealthCheckSteps {

    private ActionItpClient actionItpClient = new ActionItpClient();

    @Given("health check endpoint")
    public void healthCheckEndpoint() {
        actionItpClient.setUp("/enterprise/products/action/itp/v1/healthcheck");
    }

    @When("health check endpoint has been called")
    public void healthCheckEndpointHasBeenCalled() {
        actionItpClient.healthCheckIsCalled();
    }

    @Then("health check response received successfully")
    public void healthCheckResponseReceivedSuccessfully() {
        actionItpClient.healthCheckSuccessfulResponse();
    }
}
