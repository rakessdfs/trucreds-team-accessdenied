package com.discover.cmpp.action.itp;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.springframework.stereotype.Component;

import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

@Component
public class ActionItpClient {

    public Response response;
    String httpAuthToken;
    String requestUrl;

    public void setUp(String endpoint) {
        RestAssured.proxy("proxy-app.discoverfinancial.com", 8080);
        String baseUrl = System.getProperty("baseUrl");
        this.httpAuthToken = System.getProperty("httpAuthToken");
        this.requestUrl = baseUrl + endpoint;
    }

    public void healthCheckIsCalled() {
        response = given()
                .contentType("application/json")
                .when().get(requestUrl);
    }

    public void healthCheckSuccessfulResponse() {
        response.then().statusCode(200);
        String status = response.then().extract().body().jsonPath().getString("status");
        assertEquals("UP", status);
    }

    public void customerLookupIsRequested() {
        response = given()
                .contentType("application/json")
                .header("HTTP_AUTH_TOKEN", httpAuthToken)
                .header("X-DFSUSER-USER-ID", "test123")
                .queryParam("party-id", "102645412")
                .when().get(requestUrl);
    }

    public void customerLookupSuccessfulResponse() {
        response.then().statusCode(200);
    }
}
