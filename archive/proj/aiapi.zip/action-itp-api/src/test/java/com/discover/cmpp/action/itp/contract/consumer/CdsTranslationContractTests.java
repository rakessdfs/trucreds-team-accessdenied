package com.discover.cmpp.action.itp.contract.consumer;

import com.discover.cmpp.action.itp.custlookup.CdsCustTranslationAccessClient;
import com.discover.cmpp.action.itp.custlookup.model.cdstranslation.CdsTranslationReqSrcCodeResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;


// This has a different config because cds apis still don't appear to have
// stubs in the maven-internal-test repo of nexus 3
@AutoConfigureStubRunner(repositoryRoot = "https://nexus2.discoverfinancial.com/repository/maven-internal-prod")
@TestPropertySource(properties = {
        "stubrunner.ids=com.discoverfinancial.cds:custtrans:+:stubs:${stubrunner.runningstubs.custtrans.port}",
        "cdsTranslationalAccess.service.baseUrl=http://localhost:${stubrunner.runningstubs.custtrans.port}/enterprise/customer/translation/v2",
})
class CdsTranslationContractTests extends AbstractConsumerTest {

    @Autowired
    private CdsCustTranslationAccessClient cdsCustTranslationAccessClient;

    private Map<String, String> headerMap;

    @BeforeEach
    public void setup() {
        headerMap = mockRestClientCommonHeader();
    }

    @Test
    void cdsCustSearchSuccess() {

        headerMap.put("X-USER-ID", "ITP");
        headerMap.put("X-REQUEST-ID", "testRACF");
        ResponseEntity<List<CdsTranslationReqSrcCodeResponse>> response =
                cdsCustTranslationAccessClient.getIsItpUser(headerMap,
                "94");

        assertEquals(200, response.getStatusCode().value());
        assertEquals("9090123456789012345", response.getBody().get(0).getSrcSysCustId());
        assertEquals("PD", response.getBody().get(0).getAplnDataSrcCde());
    }
}