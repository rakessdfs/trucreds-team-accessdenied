package com.discover.cmpp.action.itp.contract;

import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.session.JwtActionItpUtil;
import com.discover.cmpp.action.itp.common.session.ValidateTokenController;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import io.restassured.module.mockmvc.RestAssuredMockMvc;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.setup.StandaloneMockMvcBuilder;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
abstract class SessionBase {

    @InjectMocks
    private ValidateTokenController validateTokenController;

    @Mock
    private JwtActionItpUtil jwtActionItpUtil;

    @BeforeEach
    void setup() throws ActionItpException {

        MockitoAnnotations.openMocks(this);
        when(jwtActionItpUtil.getUserNameFromJwtToken(anyString())).thenReturn("testagent");

        when(jwtActionItpUtil.validateJwtToken("valid-jwt-token"))
                .thenReturn(true);
        when(jwtActionItpUtil.validateJwtToken("invalid-jwt-token"))
                .thenThrow(new ActionItpException("Invalid token"));

        StandaloneMockMvcBuilder standaloneMockMvcBuilder =
                MockMvcBuilders.standaloneSetup(validateTokenController)
                        .addPlaceholderValue("api.context-path", TestUtils.contextPath);

        RestAssuredMockMvc.standaloneSetup(standaloneMockMvcBuilder);
    }
}
