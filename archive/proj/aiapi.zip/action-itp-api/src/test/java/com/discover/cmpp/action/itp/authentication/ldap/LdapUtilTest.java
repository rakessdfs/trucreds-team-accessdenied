package com.discover.cmpp.action.itp.authentication.ldap;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.discover.cmpp.action.itp.authentication.ldap.LdapUtil.DfsiLdapRebind;
import com.novusnet.ldap.dsutil.DSManager;
import com.novusnet.ldap.dsutil.UserEntry;

import netscape.ldap.LDAPConnection;
import netscape.ldap.LDAPException;
import netscape.ldap.LDAPRebindAuth;
import netscape.ldap.util.ConnectionPool;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

class LdapUtilTest {
    @InjectMocks
    LdapUtil ldapUtil = new LdapUtil();
    @Mock
    DfsiLdapRebind DFSILDAPRebind;
    @Mock
    LDAPConnection ld;
    @Mock
    DSManager ds;
    @Mock
    ConnectionPool connectionPool;
    @Mock
    LdapConfigManager ldapConfigManager;
    @Mock
    ConnectionPool makeConnPool;
    private static final String USER = "SHIELD_API_LDAP_USER";
    private static final String LDAP_EXCEPTION = "ldapException";
    private static final String POOL_INIT = "poolInitialized";

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testGetConnection() throws LDAPException {
        setupLdapConfigManager();
        when(ldapConfigManager.getMaxpoolsize()).thenReturn(1);
        when(ldapConfigManager.getMinpoolsize()).thenReturn(1);
        assertNotNull(ldapUtil.getConnection());
    }

    @Test
    void testDFSILDAPRebind() {
        DFSILDAPRebind = ldapUtil.new DfsiLdapRebind(ld);
        LDAPRebindAuth rebindAuth = DFSILDAPRebind.getRebindAuthentication("", 0);
        assertNotNull(rebindAuth);
    }

    @Test
    void testAuthenticate() {
        ReflectionTestUtils.setField(ldapUtil, POOL_INIT, true);
        ReflectionTestUtils.setField(ldapUtil, "ldapConnectionPool", null);
        assertDoesNotThrow(() -> ldapUtil.authenticate(USER, USER));
    }

    @Test
    void testAuthenticateInitPool() {
        setupLdapConfigManager();
        when(ldapConfigManager.getMaxpoolsize()).thenReturn(1);
        when(ldapConfigManager.getMinpoolsize()).thenReturn(1);
        assertDoesNotThrow(() -> ldapUtil.authenticate(USER, USER));
    }

    @Test
    void testAuthenticateLDAPException() {
        setupLdapConfigManager();
        assertThrows(LDAPException.class, () -> ldapUtil.authenticate(USER, USER));
    }

    @Test
    void testAuthenticateInitPoolEncryptionError() {
        ReflectionTestUtils.setField(ldapUtil, "ldapConnectionPool", null);
        ReflectionTestUtils.setField(ldapUtil, POOL_INIT, false);
        when(ldapConfigManager.isPwdEncrypted()).thenReturn(true);
        when(ldapConfigManager.getBindpwd()).thenReturn("UHYsZjtTTH59OE5oWFwiLEw=");
        assertThrows(LDAPException.class, () -> ldapUtil.authenticate(USER, USER));
    }

    @Test
    void testGetUserEntryRacfNull() {
        ReflectionTestUtils.setField(ldapUtil, POOL_INIT, true);
        final UserEntry userEntry = assertDoesNotThrow(() -> ldapUtil.getUserEntry(null));
        assertNull(userEntry);
    }

    @Test
    void testGetUserEntry() throws LDAPException {
        UserEntry user = Mockito.mock(UserEntry.class);
        when(ds.getUserEntry(anyString())).thenReturn(user);
        ReflectionTestUtils.setField(ldapUtil, POOL_INIT, true);
        ReflectionTestUtils.setField(ldapUtil, "ldapConnectionPool", connectionPool);
        UserEntry userResult = assertDoesNotThrow(() -> ldapUtil.getUserEntry(USER));
        assertNotNull(userResult);
    }

    @Test
    void testGetUserEntryNull() throws LDAPException {
        UserEntry user = null;
        when(ds.getUserEntry(anyString())).thenReturn(user);
        ReflectionTestUtils.setField(ldapUtil, POOL_INIT, true);
        ReflectionTestUtils.setField(ldapUtil, "ldapConnectionPool", connectionPool);
        UserEntry userResult = assertDoesNotThrow(() -> ldapUtil.getUserEntry(USER));
        assertNull(userResult);
    }

    @Test
    void testGetUserEntryError() throws LDAPException {
        when(ds.getUserEntry(anyString())).thenThrow(new LDAPException());
        ReflectionTestUtils.setField(ldapUtil, "ldapConnectionPool", connectionPool);
        assertThrows(LDAPException.class, () -> ldapUtil.getUserEntry(USER));
    }

    @Test
    void testAuthenticateException() throws LDAPException {
        ReflectionTestUtils.setField(ldapUtil, POOL_INIT, true);
        LDAPException ldapException = new LDAPException(LDAP_EXCEPTION);
        when(ds.bind(anyString(), anyString())).thenThrow(ldapException);
        assertThrows(LDAPException.class, () -> ldapUtil.authenticate(USER, USER));
    }

    @Test
    void testGetDSManager() {
        setupLdapConfigManager();
        when(ldapConfigManager.getMaxpoolsize()).thenReturn(1);
        when(ldapConfigManager.getMinpoolsize()).thenReturn(1);
        final DSManager dsManager = assertDoesNotThrow(() -> ldapUtil.getDsManager());
        assertNotNull(dsManager);
    }

    private void setupLdapConfigManager() {
        ReflectionTestUtils.setField(ldapUtil, "ldapConnectionPool", null);
        ReflectionTestUtils.setField(ldapUtil, POOL_INIT, false);
        when(ldapConfigManager.getServer()).thenReturn("d-vds.rw.discoverfinancial.com");
        when(ldapConfigManager.getPortnumber()).thenReturn(389);
        when(ldapConfigManager.getBindid()).thenReturn("SHIELD_API_LDAP_USER");
        when(ldapConfigManager.getBinddn()).thenReturn("uid=SHIELD_API_LDAP_USER,ou=Apps,ou=Admin,o=DFSI");
        when(ldapConfigManager.isPwdEncrypted()).thenReturn(false);
        when(ldapConfigManager.getBindpwd()).thenReturn("Pv,f;SL~}8NhX\",L");
    }
}
