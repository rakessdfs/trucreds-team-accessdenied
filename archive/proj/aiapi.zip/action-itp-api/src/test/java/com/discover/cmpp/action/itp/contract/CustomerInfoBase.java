package com.discover.cmpp.action.itp.contract;

import com.discover.cmpp.action.itp.cloak.CloakException;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ActionItpExceptionHandler;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.custlookup.CustLookUpController;
import com.discover.cmpp.action.itp.custlookup.CustLookUpException;
import com.discover.cmpp.action.itp.custlookup.CustLookUpService;
import com.discover.cmpp.action.itp.custlookup.model.CustomerInfoResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.Address;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import io.restassured.module.mockmvc.RestAssuredMockMvc;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.setup.StandaloneMockMvcBuilder;

import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
public abstract class CustomerInfoBase {
    @InjectMocks
    private CustLookUpController controller;

    @Mock
    private CustLookUpService custLookUpService;

    @BeforeEach
    public void setup() throws ActionItpException, CloakException, CustLookUpException {
        MockitoAnnotations.openMocks(this);
        // Customer info tests
        when(custLookUpService.customerInfo("testRACF", "111111")).thenReturn(getCustomerInfoResponse());
        when(custLookUpService.customerInfo("nullAgentID", "222222")).thenThrow(new ActionItpException(ValidationConstants.AGENT_ID_INVALID_EC));
        when(custLookUpService.customerInfo("testRACF500", "444444")).thenThrow(new NullPointerException());

        StandaloneMockMvcBuilder standaloneMockMvcBuilder = MockMvcBuilders.standaloneSetup(controller)
                .addPlaceholderValue("api.context-path", TestUtils.contextPath)
                .setControllerAdvice(new ActionItpExceptionHandler());
        RestAssuredMockMvc.standaloneSetup(standaloneMockMvcBuilder);
    }

    private CustomerInfoResponse getCustomerInfoResponse() {
        CustomerInfoResponse custLookupResponse = new CustomerInfoResponse();
        custLookupResponse.setSsn("1234");
        custLookupResponse.setPrimaryPhone("0987654321");
        custLookupResponse.setLastName("AZARIYA");
        custLookupResponse.setFirstName("TWANEY");
        custLookupResponse.setEmail("user123@user.com");
        custLookupResponse.setDateOfBirth("01/01/1970");

        Address address = new Address();
        address.setAddressLine1("line 1");
        address.setAddressLine2("line 2");
        address.setBarCode("0");
        address.setCityName("New York");
        address.setCountryCode("USA");
        address.setForbidAutoFormatting(false);
        address.setPostalCode("12345");
        address.setStateOrSectionCode("NY");

        custLookupResponse.setAddress(address);

        return custLookupResponse;
    }
}
