package com.discover.cmpp.action.itp.common.health;

import com.discover.cmpp.action.itp.common.CloudPropertiesConfiguration;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.info.BuildProperties;
import org.springframework.cloud.config.client.ConfigClientProperties;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.function.Supplier;

import static com.discover.cmpp.action.itp.test.utils.TestUtils.successfulApiStatus;
import static com.discover.cmpp.action.itp.test.utils.TestUtils.unsuccessfulApiStatus;
import static java.util.concurrent.Executors.newFixedThreadPool;
import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.mockito.PowerMockito.mock;

@ExtendWith(SpringExtension.class)
class HealthCheckServiceTest {
    private static final String UP = "UP";
    private static final String DOWN = "DOWN";

    private HealthCheckResponseOutput healthResponse;

    @Mock
    private CloudPropertiesConfiguration mockFeatureToggleProperties;

    @Mock
    private ConfigClientProperties properties;

    @Mock
    private BuildProperties mockBuildProperties;

    @Mock
    private ThreadPoolTaskExecutor mockThreadPoolTaskExecutor;

    @Mock
    private ThreadPoolExecutor mockThreadPoolExecutor;

    @Mock
    private ConfigClientProperties.Credentials credentials;

    @Mock
    private Supplier<String> mockStatusSupplier;

    @InjectMocks
    private HealthCheckServiceImpl subject;


    @BeforeEach
    void setUp() {
        healthResponse = HealthCheckResponseOutput.builder()
                .status(UP)
                .buildNumber("someBuildNumber")
                .configServerStatus(successfulApiStatus("configServerUrl"))
                .featureToggles(CloudPropertiesConfiguration.builder()
                        .publishMemoToAnalytics(true)
                        .newCancelApiEnabled(true)
                        .oobLockNumberOfCalls(2)
                        .configServerHealthCheckEnabled(true)
                        .build())
                .build();

        when(mockBuildProperties.getVersion()).thenReturn("someBuildNumber");

        when(mockFeatureToggleProperties.isPublishMemoToAnalytics()).thenReturn(true);
        when(mockFeatureToggleProperties.isNewCancelApiEnabled()).thenReturn(true);
        when(mockFeatureToggleProperties.getOobLockNumberOfCalls()).thenReturn(2);
        when(mockFeatureToggleProperties.isConfigServerHealthCheckEnabled()).thenReturn(true);
        when(mockThreadPoolTaskExecutor.getThreadPoolExecutor()).thenReturn((ThreadPoolExecutor) newFixedThreadPool(4));
        when(properties.getCredentials(0)).thenReturn(credentials);
        when(credentials.getUri()).thenReturn("configServerUrl");
    }

    @Test
    @DisplayName("Should return status: UP when all other statuses are UP")
    void performHealthCheck_whenAllStatusesAreUp_thenReturnStatusUp() {
        assertThat(subject.performHealthCheck().getStatus()).isEqualTo(UP);
    }

    @Test
    @DisplayName("Should return status: DOWN when InterruptedException is thrown")
    void performHealthCheck_whenInterruptedExceptionIsThrown_thenReturnStatusDown() throws InterruptedException {
        when(mockThreadPoolTaskExecutor.getThreadPoolExecutor()).thenReturn(mockThreadPoolExecutor);
        when(mockThreadPoolExecutor.invokeAll(any())).thenThrow(InterruptedException.class);

        assertThat(subject.performHealthCheck()).isEqualTo(HealthCheckResponseOutput.builder()
                .status(DOWN)
                .buildNumber("someBuildNumber")
                .build());

        verify(mockThreadPoolExecutor).invokeAll(any());
    }

    @Test
    @DisplayName("Should return status: DOWN when InterruptedException is thrown")
    void performHealthCheck_when_Mapping_InterruptedExceptionIsThrown_thenReturnStatusDown() throws InterruptedException {
        Future<ExternalSystemQueryTask> futures = CompletableFuture
                .completedFuture(new ExternalSystemQueryTask(mockStatusSupplier, "someService"));
        List<String> list = mock(List.class);
        when(mockThreadPoolTaskExecutor.getThreadPoolExecutor()).thenReturn(mockThreadPoolExecutor);
        when(mockThreadPoolExecutor.invokeAll(any())).thenAnswer(invocation -> {
            Object[] args = invocation.getArguments();
            return Arrays.asList(futures);
        });
        when(list.get(0)).thenThrow(new RuntimeException());
        assertThat(subject.performHealthCheck()).isEqualTo(HealthCheckResponseOutput.builder()
                .status(DOWN)
                .buildNumber("someBuildNumber")
                .build());

        verify(mockThreadPoolExecutor).invokeAll(any());
    }

    @Test
    @DisplayName("Should return buildNumber")
    void performHealthCheck_shouldReturnBuildNumber() {
        assertThat(subject.performHealthCheck().getBuildNumber()).isEqualTo("someBuildNumber");

        verify(mockBuildProperties).getVersion();
    }

    @Test
    @DisplayName("Should return configServerHealthCheckStatus: True when configServerStatus is UP")
    void performHealthCheck_whenConfigServerHealthCheckStatusIsTrue_thenReturnConfigServerStatusUp() {
        assertThat(subject.performHealthCheck().getConfigServerStatus().getStatus()).isEqualTo(UP);
    }

    @Test
    @DisplayName("Should return configServerHealthCheckStatus: False when configServerStatus is DOWN")
    void performHealthCheck_whenConfigServerHealthCheckStatusIsFalse_thenReturnConfigServerStatusDown() {
        when(mockFeatureToggleProperties.isConfigServerHealthCheckEnabled()).thenReturn(false);
        healthResponse.setStatus("DOWN");
        healthResponse.setConfigServerStatus(unsuccessfulApiStatus("configServerUrl"));
        assertThat(subject.performHealthCheck().getConfigServerStatus().getStatus()).isEqualTo(DOWN);
    }
}
