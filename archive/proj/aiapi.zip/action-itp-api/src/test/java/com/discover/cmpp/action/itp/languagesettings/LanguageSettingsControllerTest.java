package com.discover.cmpp.action.itp.languagesettings;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.languagesettings.model.LanguageSettingsRequest;
import com.discover.cmpp.action.itp.languagesettings.model.LanguageSettingsResponse;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.util.NestedServletException;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class LanguageSettingsControllerTest {

    @InjectMocks
    LanguageSettingsController languageSettingsController;
    @Mock
    LanguageSettingsService languageSettingsService;
    private MockMvc mockMvc;
    private LanguageSettingsRequest languageSettingsRequest;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(languageSettingsController)
                .addPlaceholderValue("api.context-path", TestUtils.contextPath).build();
        languageSettingsRequest = new LanguageSettingsRequest();
        languageSettingsRequest.setLanguageCode("EN");
        languageSettingsRequest.setProductEnrollmentId("9090123456789012345");
    }

    @Test
    void test_createLanguageSettings_Success() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(languageSettingsRequest);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + TestUtils.LANGUAGE_PATH)
                .contentType("application/json")
                .header(ActionItpConstants.AGENT_ID, "agent1")
                .content(requestJson)).andExpect(status().isCreated()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }

    @Test
    void test_createLanguageSettings_badRequest() throws Exception {
        LanguageSettingsRequest languageSettingsRequest;
        languageSettingsRequest = new LanguageSettingsRequest();
        languageSettingsRequest.setLanguageCode("EN");
        languageSettingsRequest.setProductEnrollmentId(null);
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(languageSettingsRequest);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + TestUtils.LANGUAGE_PATH)
                .contentType("application/json")
                .header(ActionItpConstants.AGENT_ID, "agent1")
                .content(requestJson)).andExpect(status().isBadRequest()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }

    @Test
    void test_createLanguageSettings_internalServerError() throws Exception {
        Mockito.doThrow(new LanguageSettingsException("Error")).when(languageSettingsService).saveLanguageSettings(any(), eq(""));
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(languageSettingsRequest);
        assertThrows(NestedServletException.class, () -> mockMvc.perform(post(
                TestUtils.contextPath + TestUtils.LANGUAGE_PATH)
                .contentType("application/json")
                .header(ActionItpConstants.AGENT_ID, "")
                .content(requestJson)));

    }

    @Test
    void test_fetchLanguageSettings_internalServerError() throws Exception {
        Mockito.doThrow(new LanguageSettingsException("Error occurred"))
                .when(languageSettingsService).fetchLanguageSettings(any());
        assertThrows(NestedServletException.class, () -> mockMvc.perform(get(
                TestUtils.contextPath + TestUtils.LANGUAGE_PATH + "/12345")));
    }

    @Test
    void test_fetchLanguageSettings() throws Exception {
        Mockito.when(languageSettingsService.fetchLanguageSettings(any())).thenReturn(new LanguageSettingsResponse());

        MvcResult result = mockMvc.perform(
                get(TestUtils.contextPath + TestUtils.LANGUAGE_PATH + "/12345"))
                .andExpect(status().isOk()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }
}
