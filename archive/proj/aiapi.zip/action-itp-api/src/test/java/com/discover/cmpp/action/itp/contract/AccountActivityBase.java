package com.discover.cmpp.action.itp.contract;

import com.discover.cmpp.action.itp.accountactivity.AccountActivityCodeEntity;
import com.discover.cmpp.action.itp.accountactivity.AccountActivityController;
import com.discover.cmpp.action.itp.accountactivity.AccountActivityDto;
import com.discover.cmpp.action.itp.accountactivity.AccountActivityEntity;
import com.discover.cmpp.action.itp.accountactivity.AccountActivityException;
import com.discover.cmpp.action.itp.accountactivity.AccountActivityService;
import com.discover.cmpp.action.itp.accountactivity.AccountActivityUtil;
import com.discover.cmpp.action.itp.accountactivity.model.AccountActivityCodeRequest;
import com.discover.cmpp.action.itp.accountactivity.model.AccountActivityResponse;
import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.ActionItpExceptionHandler;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.flux.schema.AccountActivityPayload;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import io.restassured.module.mockmvc.RestAssuredMockMvc;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.setup.StandaloneMockMvcBuilder;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static com.discover.cmpp.action.itp.common.validation.ValidationConstants.FAILED_TO_GET_CODE_ENTITIES_EC;
import static com.discover.cmpp.action.itp.common.validation.ValidationConstants.NO_CODE_ENTITIES_EC;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
public abstract class AccountActivityBase {

    @InjectMocks
    private AccountActivityController controller;

    @Mock
    private AccountActivityService activityService;

    @BeforeEach
    public void setup() throws AccountActivityException {
        MockitoAnnotations.openMocks(this);
        when(activityService.fetchAccountActivityByPeid("200"))
                .thenReturn(getAccountActivityResponse());
        when(activityService.fetchAccountActivityByPeid("204"))
                .thenThrow(new AccountActivityException(ValidationConstants.PEID_NO_CONTENT_EC));
        when(activityService.fetchAccountActivityByPeid("500"))
                .thenThrow(new NullPointerException("Simulate 500 error"));
        Mockito.doThrow(new AccountActivityException(ActionItpConstants.API_INTERNAL_SERVER_ERROR))
                .when(activityService).createActivity(getAccountActivityMessage());

        when(activityService.fetchAccountActivityCodes(null, null))
                .thenReturn(getAccountActivityCodes_NoParamsResponse());
        when(activityService.fetchAccountActivityCodes("WMS", null))
                .thenReturn(getAccountActivityCodes_CodeParamResponse());
        when(activityService.fetchAccountActivityCodes(null, "testCat"))
                .thenReturn(getAccountActivityCodes_NoParamsResponse());
        when(activityService.fetchAccountActivityCodes("204", null))
                .thenThrow(new AccountActivityException(NO_CODE_ENTITIES_EC));
        when(activityService.fetchAccountActivityCodes(null, "DBERROR"))
                .thenThrow(new AccountActivityException(FAILED_TO_GET_CODE_ENTITIES_EC));

        Mockito.doThrow(new AccountActivityException(ValidationConstants.INVALID_CATEGORY_EC))
                .when(activityService).createAccountActivityCode(getAccountActivityCodeBadRequest());
        Mockito.doThrow(new AccountActivityException(ActionItpConstants.API_INTERNAL_SERVER_ERROR))
                .when(activityService).createAccountActivityCode(getAccountActivityCodeMessage());

        MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter = new
                MappingJackson2HttpMessageConverter();
        mappingJackson2HttpMessageConverter.setObjectMapper(new ObjectMapper()
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
                .registerModule(new JavaTimeModule()));

        StandaloneMockMvcBuilder standaloneMockMvcBuilder = MockMvcBuilders.standaloneSetup(controller)
                .addPlaceholderValue("api.context-path", TestUtils.contextPath)
                .setControllerAdvice(new ActionItpExceptionHandler());
        RestAssuredMockMvc.standaloneSetup(standaloneMockMvcBuilder.setMessageConverters(mappingJackson2HttpMessageConverter));
    }

    private AccountActivityResponse getAccountActivityResponse() {
        LocalDateTime localDateTime1 = LocalDateTime.of(2021, 1, 31, 20, 28, 57);
        LocalDateTime localDateTime2 = LocalDateTime.of(2021, 5, 30, 20, 28, 57);
        AccountActivityCodeEntity codeEntity1 = AccountActivityCodeEntity.builder()
                .accountActivityCodeId(37L)
                .activityCode("activityTestCode1")
                .activityDesc("activityTestDesc1")
                .category("testCategory1")
                .createTs(localDateTime1)
                .updateTs(null)
                .build();
        AccountActivityEntity activity1 = AccountActivityEntity.builder()
                .accountActivityId(12L)
                .productEnrollmentId("200")
                .activityCode(codeEntity1)
                .previousData("previousTestData1")
                .newData("newTestData1")
                .operator("operator1")
                .requestDate(localDateTime1)
                .createTs(localDateTime1)
                .updateTs(null)
                .build();

        AccountActivityCodeEntity codeEntity2 = AccountActivityCodeEntity.builder()
                .accountActivityCodeId(38L)
                .activityCode("activityTestCode2")
                .activityDesc("activityTestDesc2")
                .category("testCategory2")
                .createTs(localDateTime2)
                .updateTs(null)
                .build();
        AccountActivityEntity activity2 = AccountActivityEntity.builder()
                .accountActivityId(13L)
                .productEnrollmentId("200")
                .activityCode(codeEntity2)
                .previousData("previousTestData2")
                .newData("newTestData2")
                .operator("operator2")
                .requestDate(localDateTime2)
                .createTs(localDateTime2)
                .updateTs(null)
                .build();

        List<AccountActivityDto> activityList = new ArrayList<>();
        activityList.add(AccountActivityUtil.convertAccountActivityEntityToAccountActivityDto(activity1));
        activityList.add(AccountActivityUtil.convertAccountActivityEntityToAccountActivityDto(activity2));
        AccountActivityResponse response = new AccountActivityResponse();
        response.setAccountActivityList(activityList);
        return response;
    }

    private AccountActivityPayload getCreateActivityRequest() {
        AccountActivityPayload createActivityRequest = new AccountActivityPayload();
        createActivityRequest.setActivityCode("500");
        createActivityRequest.setOperator("ONLINE");
        createActivityRequest.setProductEnrollmentId("457821487");
        createActivityRequest.setRequestDate("2021-02-16 20:34:59");
        return createActivityRequest;
    }

    private AccountActivityPayload getAccountActivityMessage() {
        AccountActivityPayload accountActivityPayload = new AccountActivityPayload();
        accountActivityPayload.setActivityCode("500");
        accountActivityPayload.setOperator("ONLINE");
        accountActivityPayload.setProductEnrollmentId("457821487");
        accountActivityPayload.setRequestDate("2021-02-16 20:34:59");
        return accountActivityPayload;
    }

    private AccountActivityCodeRequest getAccountActivityCodeMessage() {
        AccountActivityCodeRequest accountActivityCodeRequest = new AccountActivityCodeRequest();
        accountActivityCodeRequest.setActivityCode("500");
        accountActivityCodeRequest.setActivityDesc("ITP Friends and Family - Welcome E-mail Sent");
        accountActivityCodeRequest.setCategory("ITP Products Referral");
        return accountActivityCodeRequest;
    }

    private AccountActivityCodeRequest getAccountActivityCodeBadRequest() {
        AccountActivityCodeRequest accountActivityCodeRequest = new AccountActivityCodeRequest();
        accountActivityCodeRequest.setActivityCode("WMF");
        accountActivityCodeRequest.setActivityDesc("ITP Friends and Family - Welcome E-mail Sent");
        accountActivityCodeRequest.setCategory("");
        return accountActivityCodeRequest;
    }

    private List<AccountActivityCodeEntity> getAccountActivityCodes_NoParamsResponse() {
        ArrayList<AccountActivityCodeEntity> entities = new ArrayList<>();
        entities.add(getCodeEntity1());
        entities.add(getCodeEntity2());
        return entities;
    }

    private List<AccountActivityCodeEntity> getAccountActivityCodes_CodeParamResponse() {
        ArrayList<AccountActivityCodeEntity> entities = new ArrayList<>();
        entities.add(getCodeEntity1());
        return entities;
    }

    private AccountActivityCodeEntity getCodeEntity1() {
        LocalDateTime localDateTime1 = LocalDateTime.of(2022, 6, 8, 16, 22, 26);
        return AccountActivityCodeEntity.builder()
                .accountActivityCodeId(98L)
                .activityCode("WMS")
                .activityDesc("ITP LVL CHG 8 TO 9 SUCCESS - Welcome E-mail Sent")
                .category("Product Change Event Batch")
                .createTs(localDateTime1)
                .updateTs(localDateTime1)
                .build();
    }

    private AccountActivityCodeEntity getCodeEntity2() {
        LocalDateTime localDateTime1 = LocalDateTime.of(2022, 6, 8, 16, 22, 26);
        return AccountActivityCodeEntity.builder()
                .accountActivityCodeId(99L)
                .activityCode("PDU")
                .activityDesc("ITP LVL CHG 8 TO 9 SUCCESS - Pearl DB Updated")
                .category("Product Change Event Batch")
                .createTs(localDateTime1)
                .updateTs(localDateTime1)
                .build();
    }
}
