package com.discover.cmpp.action.itp.contract.consumer;

import com.discover.cmpp.action.itp.membership.CsidSubscriberClient;
import com.discover.cmpp.action.itp.membership.model.CsidApiResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

@AutoConfigureStubRunner(ids = {
        "com.discover.cmpp.itp.csid:itp-csid-subscriber-api:+:stubs:"
})
@TestPropertySource(properties = {
        "csidSubscriberApi.service.baseUrl=http://localhost:${stubrunner.runningstubs.itp-csid-subscriber-api.port}" // /cardissuer/itp/csid/subscriber
})
class ItpCsidSubscriberApiContractTests extends AbstractConsumerTest {

    @Autowired
    private CsidSubscriberClient csidSubscriberClient;

    private Map<String, String> headerMap;

    @BeforeEach
    public void setup() {
        headerMap = mockRestClientCommonHeader();
    }

    @Test
    void getBillingStatusSuccess() {
        ResponseEntity<CsidApiResponse> response = csidSubscriberClient.getBillingStatus(headerMap,
                "PDTV123456789012345");

        String actualDate = response.getBody().getResponseObject().getResponse().getSubscriberData().getNextBillDate();

        assertEquals(200, response.getStatusCode().value());
        assertEquals("20200215", actualDate);
    }
}