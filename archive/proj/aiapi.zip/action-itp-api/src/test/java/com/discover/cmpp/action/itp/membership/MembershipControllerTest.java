package com.discover.cmpp.action.itp.membership;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.membership.model.MembershipResponse;
import com.discover.cmpp.action.itp.membership.model.RequestReason;
import com.discover.cmpp.action.itp.membership.model.RequestReasonResponse;
import com.discover.cmpp.action.itp.membership.model.billing.BillingResponse;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import java.util.ArrayList;
import java.util.List;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class MembershipControllerTest {

    @InjectMocks
    private MembershipController membershipController;
    @Mock
    private MembershipService membershipService;
    private MockMvc mockMvc;

    @BeforeEach
    public void setUp() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(membershipController)
                .addPlaceholderValue("api.context-path", TestUtils.contextPath).build();
    }

    @Test
    void testFetchMembershipInformation() throws Exception {
        MembershipResponse response = new MembershipResponse();
        response.setSubscriberNumber("test-sub-num");
        response.setEnrollmentFailedReason("test-fail-reason");
        response.setEnrollmentStatus("enrolled");
        response.setCancellationDate("2021-05-24");
        response.setEnrollmentDate("2021-05-24");
        response.setProductEnrollmentId("1234");
        Mockito.when(membershipService.fetchItpMembershipInformation(anyString(), anyString())).thenReturn(response);
        MvcResult result = mockMvc.perform(get(TestUtils.contextPath + MembershipConstants.FETCH_MEMBERSHIP_URL)
                .param(MembershipConstants.PARTY_ID_PARAM,"123")
                .header(ActionItpConstants.AGENT_ID, "agent1")).andExpect(status().is2xxSuccessful()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }

    @Test//(expected = Exception.class)
    void testFetchMembershipInformation5xxError() throws MembershipException, Exception {
        Mockito.when(membershipService.fetchItpMembershipInformation(anyString(), anyString())).thenThrow(new MembershipException("error"));
        assertThrows(Exception.class, () -> mockMvc.perform(get(TestUtils.contextPath + MembershipConstants.FETCH_MEMBERSHIP_URL)
                .param(MembershipConstants.PARTY_ID_PARAM,"123")
                .header(ActionItpConstants.AGENT_ID, "agent1")));
    }

    @Test
    void testFetchBillingInformation() throws Exception {
        BillingResponse expectedBillingResponse = new BillingResponse();
        expectedBillingResponse.setPcmFirstName("Scottie");
        expectedBillingResponse.setPcmLastName("Pippen");
        expectedBillingResponse.setPcmAccountNumber("555555555");
        expectedBillingResponse.setPresenceOfSecondary("No");
        expectedBillingResponse.setNextBillingDate("20210222");

        Mockito.when(membershipService.fetchItpBillingInformation(any(), any(), any(), any())).thenReturn(expectedBillingResponse);

        mockMvc.perform(get(TestUtils.contextPath + MembershipConstants.FETCH_BILLING_URL)
                .param(MembershipConstants.PEID_PARAM, "12345")
                .param(MembershipConstants.SUBSCRIBER_ID_PARAM, "PD12")
                .param(MembershipConstants.CUSTOMER_TYPE_PARAM, "ITP_FF")
                .param(MembershipConstants.PARTY_ID_PARAM, "12345")
                .header(ActionItpConstants.AGENT_ID, "agent1"))
                .andExpect(status().is2xxSuccessful())
                .andExpect( jsonPath("$.pcmFirstName", is(expectedBillingResponse.getPcmFirstName())))
                .andExpect( jsonPath("$.pcmLastName", is(expectedBillingResponse.getPcmLastName())))
                .andExpect( jsonPath("$.pcmAccountNumber", is(expectedBillingResponse.getPcmAccountNumber())))
                .andExpect( jsonPath("$.presenceOfSecondary", is(expectedBillingResponse.getPresenceOfSecondary())))
                .andReturn();
    }

    @Test
    void testFetchBillingInformation_ItpBm() throws Exception {
        BillingResponse expectedBillingResponse = new BillingResponse();
        expectedBillingResponse.setNextBillingDate("20200222");

        Mockito.when(membershipService.fetchItpBillingInformation(any(), any(), any(), any())).thenReturn(expectedBillingResponse);

        mockMvc.perform(get(TestUtils.contextPath + MembershipConstants.FETCH_BILLING_URL)
                .param(MembershipConstants.PEID_PARAM, "12345")
                .param(MembershipConstants.SUBSCRIBER_ID_PARAM, "PD12")
                .param(MembershipConstants.CUSTOMER_TYPE_PARAM, "ITP_BM")
                .param(MembershipConstants.PARTY_ID_PARAM, "12345")
                .header(ActionItpConstants.AGENT_ID, "agent1"))
                .andExpect(status().is2xxSuccessful())
                .andExpect( jsonPath("$.nextBillingDate", is(expectedBillingResponse.getNextBillingDate())))
                .andReturn();
    }

    @Test
    void testFetchBillingInformation4xxError() throws Exception {
        Mockito.when(membershipService.fetchItpBillingInformation(any(), any(),any(),any())).thenThrow(new MembershipException(ValidationConstants.PEID_NOT_FOUND_EC));

        assertThrows(Exception.class, () -> mockMvc.perform(get(TestUtils.contextPath + MembershipConstants.FETCH_BILLING_URL)
                .param(MembershipConstants.PEID_PARAM,"123")
                .param(MembershipConstants.SUBSCRIBER_ID_PARAM, "PD12")
                .param(MembershipConstants.CUSTOMER_TYPE_PARAM, "ITP_BM")
                .param(MembershipConstants.PARTY_ID_PARAM, "12345")
                .header(ActionItpConstants.AGENT_ID, "agent1")).andExpect(status().is4xxClientError()).andReturn() );
    }

    @Test
    void testFetchBillingInformation5xxError() throws Exception {
        Mockito.when(membershipService.fetchItpBillingInformation(any(), any(),any(),any())).thenThrow(new MembershipException("error"));
        assertThrows(Exception.class, () ->  mockMvc.perform(get(TestUtils.contextPath + MembershipConstants.FETCH_BILLING_URL)
                .param(MembershipConstants.PEID_PARAM,"123")
                .param(MembershipConstants.SUBSCRIBER_ID_PARAM, "PD12")
                .param(MembershipConstants.CUSTOMER_TYPE_PARAM, "ITP_BM")
                .param(MembershipConstants.PARTY_ID_PARAM, "12345")
                .header(ActionItpConstants.AGENT_ID, "agent1")).andExpect(status().is5xxServerError()).andReturn());
    }

    @Test
    void testFetchRequestReasons() throws Exception {
        RequestReasonResponse requestReasonResponse = new RequestReasonResponse();
        List<RequestReason> requestReasonList = new ArrayList<>();
        RequestReason requestReason = new RequestReason();
        requestReason.setCode("CODE");
        requestReason.setDescription("DESC");
        requestReasonList.add(requestReason);
        requestReasonResponse.setRequestReasons(requestReasonList);

        Mockito.when(membershipService.fetchRequestReasons(anyString(), anyString())).thenReturn(requestReasonResponse);
        MvcResult result = mockMvc.perform(get(TestUtils.contextPath + MembershipConstants.FETCH_REQUEST_REASONS_URL)
                .param(MembershipConstants.CUSTOMER_TYPE_PARAM,"ITP_BM")
                .header(ActionItpConstants.AGENT_ID, "agent1")).andExpect(status().is2xxSuccessful()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }

    @Test
    void testFetchRequestReasons5xxError() throws MembershipException, Exception {
        Mockito.when(membershipService.fetchRequestReasons(anyString(), anyString())).thenThrow(new RequestReasonsException("error"));
        assertThrows(Exception.class, () -> mockMvc.perform(get(TestUtils.contextPath + MembershipConstants.FETCH_REQUEST_REASONS_URL)
                .param(MembershipConstants.CUSTOMER_TYPE_PARAM,"ITP_BM")
                .header(ActionItpConstants.AGENT_ID, "agent1")).andExpect(status().is5xxServerError()).andReturn());
    }
}
