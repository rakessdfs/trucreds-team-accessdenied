package com.discover.cmpp.action.itp.memo;

import com.discover.cmpp.action.itp.cloak.CloakException;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.CloudPropertiesConfiguration;
import com.discover.cmpp.action.itp.custlookup.CustLookUpException;
import com.discover.cmpp.action.itp.custlookup.CustLookUpService;
import com.discover.cmpp.action.itp.custlookup.model.CustomerPii;
import com.discover.cmpp.action.itp.custlookup.model.CustomerSearchRequest;
import com.discover.cmpp.action.itp.custlookup.model.CustomerSearchResponse;
import com.discover.cmpp.action.itp.flux.FluxException;
import com.discover.cmpp.action.itp.flux.publish.memo.MemoPublishService;
import com.discover.cmpp.action.itp.flux.schema.MemoMessage;
import com.discover.cmpp.action.itp.membership.MembershipException;
import com.discover.cmpp.action.itp.membership.MembershipService;
import com.discover.cmpp.action.itp.membership.model.MembershipEntity;
import com.discover.cmpp.action.itp.membership.model.MembershipInfo;
import com.discover.cmpp.action.itp.membership.model.MembershipListResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.dao.DataIntegrityViolationException;

import javax.validation.constraints.Null;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.discover.cmpp.action.itp.common.ActionItpConstants.ITB_PRODUCT_TYPE_CODE;
import static com.discover.cmpp.action.itp.common.ActionItpConstants.ITF_PRODUCT_TYPE_CODE;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class MemoServiceTest {

    @Mock
    MemoRepository memoRepository;

    @Mock
    MemoPublishService memoPublishService;

    @Mock
    CustLookUpService custLookUpService;

    @Mock
    CloudPropertiesConfiguration cloudPropertiesConfiguration;

    @Mock
    MembershipService membershipService;


    @InjectMocks
    private MemoServiceImpl memoService;

    MemoEntity memoEntity;

    private CreateMemoRequest request;

    @BeforeEach
    public void init() {
        MockitoAnnotations.openMocks(this);
        request = new CreateMemoRequest();
        request.setMemoText("Enrolled");
        request.setProductEnrollmentId("14578625");
        CustomerSearchRequest customerRequest = new CustomerSearchRequest();
        customerRequest.setFirstName("test");
        customerRequest.setLastName("test");
        customerRequest.setDateOfBirth("12/01/2019");

    }

    @Test
    void test_createMemo() throws CloakException, CustLookUpException, ActionItpException, MembershipException, ParseException {
        List<MembershipListResponse> membershipList = new ArrayList<>();
        MembershipListResponse membership = new MembershipListResponse();
        membership.setLevelNumber(6);
        membershipList.add(membership);
        memoEntity = new MemoEntity();
        memoEntity.setCreateTs(LocalDateTime
                .parse("2021-09-21T18:55:42", DateTimeFormatter
                        .ofPattern("yyyy-MM-dd'T'HH:mm:ss")));
        memoEntity.setMemoText("Test");
        memoEntity.setProductEnrollmentId("123455677");
        memoEntity.setMemoId(12345678910L);
        when(custLookUpService.customerSearch(any(), any(CustomerSearchRequest.class)))
                .thenReturn(getCustPiiLookUpResponse());
        when(membershipService.fetchMemberships(anyString()))
                .thenReturn(membershipList);
        when(membershipService.determineMembershipFromList(any())).thenReturn(membershipList.get(0));
        when(cloudPropertiesConfiguration.isPublishMemoToAnalytics()).thenReturn(true);
        when(memoRepository.save(any(MemoEntity.class))).thenReturn(memoEntity);
        assertDoesNotThrow(() -> memoService.createMemo(request, "agent1"));
    }

    @Test
    void test_createMemo_itb_product_type_code() throws CloakException, CustLookUpException, ActionItpException, MembershipException, ParseException {
        List<MembershipListResponse> membershipList = new ArrayList<>();
        MembershipListResponse membership = new MembershipListResponse();
        membership.setLevelNumber(8);
        membershipList.add(membership);
        memoEntity = new MemoEntity();
        memoEntity.setCreateTs(LocalDateTime
                .parse("2021-09-21T18:55:42", DateTimeFormatter
                        .ofPattern("yyyy-MM-dd'T'HH:mm:ss")));
        memoEntity.setMemoText("Test");
        memoEntity.setProductEnrollmentId("123455677");
        memoEntity.setMemoId(12345678910L);
        when(custLookUpService.customerSearch(any(), any(CustomerSearchRequest.class)))
                .thenReturn(getCustPiiLookUpResponse());
        when(membershipService.fetchMemberships(anyString()))
                .thenReturn(membershipList);
        when(membershipService.determineMembershipFromList(any())).thenReturn(membershipList.get(0));
        when(cloudPropertiesConfiguration.isPublishMemoToAnalytics()).thenReturn(true);
        when(memoRepository.save(any(MemoEntity.class))).thenReturn(memoEntity);
        assertDoesNotThrow(() -> memoService.createMemo(request, "agent1"));
    }

    @Test
    void test_createMemo_when_publish_flux_disabled() throws CloakException, CustLookUpException, ActionItpException, MembershipException, ParseException {
        List<MembershipListResponse> membershipList = new ArrayList<>();
        MembershipListResponse membership = new MembershipListResponse();
        membership.setLevelNumber(6);
        membershipList.add(membership);
        memoEntity = new MemoEntity();
        memoEntity.setCreateTs(LocalDateTime
                .parse("2021-09-21T18:55:42", DateTimeFormatter
                        .ofPattern("yyyy-MM-dd'T'HH:mm:ss")));
        memoEntity.setMemoText("Test");
        memoEntity.setProductEnrollmentId("123455677");
        memoEntity.setMemoId(12345678910L);
        when(custLookUpService.customerSearch(any(), any(CustomerSearchRequest.class)))
                .thenReturn(getCustPiiLookUpResponse());
        when(membershipService.fetchMemberships(anyString()))
                .thenReturn(membershipList);
        when(membershipService.determineMembershipFromList(any())).thenReturn(membershipList.get(0));
        when(cloudPropertiesConfiguration.isPublishMemoToAnalytics()).thenReturn(false);
        when(memoRepository.save(any(MemoEntity.class))).thenReturn(memoEntity);
        assertDoesNotThrow(() -> memoService.createMemo(request, "agent1"));
        verify(memoPublishService, never()).publishEvent(any(MemoMessage.class));
    }

    @Test
    void test_createMemo_exception() {
        Mockito.doThrow(new DataIntegrityViolationException("Error occurred")).when(memoRepository).save(any());
        assertThrows(MemoException.class, () -> memoService.createMemo(request, "agent1"));
    }

    @Test
    void test_createMemo_flux_exception() throws CloakException, CustLookUpException,
            ActionItpException, MembershipException, ParseException {
        List<MembershipListResponse> membershipList = new ArrayList<>();
        MembershipListResponse membership = new MembershipListResponse();
        membership.setLevelNumber(6);
        membershipList.add(membership);
        memoEntity = new MemoEntity();
        memoEntity.setCreateTs(LocalDateTime
                .parse("2021-09-21T18:55:42", DateTimeFormatter
                        .ofPattern("yyyy-MM-dd'T'HH:mm:ss")));
        memoEntity.setMemoText("Test");
        memoEntity.setProductEnrollmentId("123455677");
        memoEntity.setMemoId(12345678910L);
        when(custLookUpService.customerSearch(any(), any(CustomerSearchRequest.class)))
                .thenReturn(getCustPiiLookUpResponse());
        when(membershipService.fetchMemberships(anyString()))
                .thenReturn(membershipList);
        when(membershipService.determineMembershipFromList(any())).thenReturn(membershipList.get(0));
        when(cloudPropertiesConfiguration.isPublishMemoToAnalytics()).thenReturn(true);
        when(memoRepository.save(any(MemoEntity.class))).thenReturn(memoEntity);
        Mockito.doThrow(new FluxException("Error publishing messaged")).when(memoPublishService)
                .publishEvent(any(MemoMessage.class));
        assertThrows(FluxException.class, () -> memoService.createMemo(request, "agent1"));
    }

    @Test
    void test_createMemo_parseDate_exception() throws CloakException, CustLookUpException,
            ActionItpException, MembershipException, ParseException {
        List<MembershipListResponse> membershipList = new ArrayList<>();
        MembershipListResponse membership = new MembershipListResponse();
        membership.setLevelNumber(6);
        membershipList.add(membership);
        memoEntity = new MemoEntity();
        memoEntity.setCreateTs(LocalDateTime
                .parse("2021-09-21T18:55:42", DateTimeFormatter
                        .ofPattern("yyyy-MM-dd'T'HH:mm:ss")));
        memoEntity.setMemoText("Test");
        memoEntity.setProductEnrollmentId("123455677");
        memoEntity.setMemoId(12345678910L);
        when(custLookUpService.customerSearch(any(), any(CustomerSearchRequest.class)))
                .thenReturn(getCustPiiLookUpResponse());
        when(membershipService.fetchMemberships(anyString()))
                .thenReturn(membershipList);
        when(membershipService.determineMembershipFromList(any())).thenThrow(new ParseException("error", 1));
        when(cloudPropertiesConfiguration.isPublishMemoToAnalytics()).thenReturn(true);
        when(memoRepository.save(any(MemoEntity.class))).thenReturn(memoEntity);
        Mockito.doThrow(new FluxException("Error publishing messaged")).when(memoPublishService)
                .publishEvent(any(MemoMessage.class));
        assertThrows(MembershipException.class, () -> memoService.createMemo(request, "agent1"));
    }

    @Test
    void test_createMemo_when_customer_is_null() throws CloakException, CustLookUpException,
            ActionItpException, MembershipException, ParseException {
        List<MembershipListResponse> membershipList = new ArrayList<>();
        MembershipListResponse membership = new MembershipListResponse();
        membership.setLevelNumber(6);
        membershipList.add(membership);
        memoEntity = new MemoEntity();
        memoEntity.setCreateTs(LocalDateTime
                .parse("2021-09-21T18:55:42", DateTimeFormatter
                        .ofPattern("yyyy-MM-dd'T'HH:mm:ss")));
        memoEntity.setMemoText("Test");
        memoEntity.setProductEnrollmentId("123455677");
        memoEntity.setMemoId(12345678910L);
        when(custLookUpService.customerSearch(any(), any(CustomerSearchRequest.class)))
                .thenReturn(null);
        when(membershipService.fetchMemberships(anyString()))
                .thenReturn(membershipList);
        when(membershipService.determineMembershipFromList(any())).thenReturn(membershipList.get(0));
        when(cloudPropertiesConfiguration.isPublishMemoToAnalytics()).thenReturn(true);
        when(memoRepository.save(any(MemoEntity.class))).thenReturn(memoEntity);
        assertDoesNotThrow(() -> memoService.createMemo(request, "agent1"));
        verify(memoPublishService, never()).publishEvent(any(MemoMessage.class));
    }

    @Test
    void test_createMemo_when_customer_is_not_present() throws CloakException, CustLookUpException, ActionItpException, MembershipException, ParseException {
        List<MembershipListResponse> membershipList = new ArrayList<>();
        MembershipListResponse membership = new MembershipListResponse();
        membership.setLevelNumber(6);
        membershipList.add(membership);
        memoEntity = new MemoEntity();
        memoEntity.setCreateTs(LocalDateTime
                .parse("2021-09-21T18:55:42", DateTimeFormatter
                        .ofPattern("yyyy-MM-dd'T'HH:mm:ss")));
        memoEntity.setMemoText("Test");
        memoEntity.setProductEnrollmentId("123455677");
        memoEntity.setMemoId(12345678910L);
        CustomerSearchResponse customerSearchResponse = getCustPiiLookUpResponse();
        List<CustomerPii> customer = new ArrayList<>();
        customerSearchResponse.setCustomers(customer);
        when(custLookUpService.customerSearch(any(), any(CustomerSearchRequest.class)))
                .thenReturn(customerSearchResponse);
        when(membershipService.fetchMemberships(anyString()))
                .thenReturn(membershipList);
        when(membershipService.determineMembershipFromList(any())).thenReturn(membershipList.get(0));
        when(cloudPropertiesConfiguration.isPublishMemoToAnalytics()).thenReturn(true);
        when(memoRepository.save(any(MemoEntity.class))).thenReturn(memoEntity);
        assertDoesNotThrow(() -> memoService.createMemo(request, "agent1"));
        verify(memoPublishService, never()).publishEvent(any(MemoMessage.class));
    }

    @Test
    void test_fetchMemoWithValidPeid() {
        List<MemoEntity> memoEntityList = new ArrayList<>();
        MemoEntity memoEntity = new MemoEntity();
        memoEntity.setMemoId(1L);
        memoEntity.setProductEnrollmentId("1234");
        memoEntity.setMemoText("Test");
        memoEntity.setCreateAgentId("test");
        memoEntityList.add(memoEntity);
        Mockito.doReturn(memoEntityList).when(memoRepository).findAllByProductEnrollmentIdOrderByCreateTsAsc(any());
        MemoResponse response = assertDoesNotThrow(() -> memoService.fetchMemos("343434343"));
        assertNotNull(response);
    }

    @Test
    void test_fetchMemoWithInvalidPeid() {
        doThrow(new RuntimeException("Memo not found")).when(memoRepository).findAllByProductEnrollmentIdOrderByCreateTsAsc("343434");
        assertThrows(MemoException.class, () -> memoService.fetchMemos("343434"));
    }

    @Test
    void test_fetchMemoWithBlankPeid() {
        doThrow(new RuntimeException("Error occurred")).when(memoRepository).findAllByProductEnrollmentIdOrderByCreateTsAsc("");
        assertThrows(MemoException.class, () -> memoService.fetchMemos(""));
    }

    @Test
    void test_fetchMemoWithNullPeid() {
        doThrow(new RuntimeException("Error occurred")).when(memoRepository).findAllByProductEnrollmentIdOrderByCreateTsAsc(null);
        assertThrows(MemoException.class, () -> memoService.fetchMemos(null));
    }

    private CustomerSearchResponse getCustPiiLookUpResponse() {
        CustomerSearchResponse response = new CustomerSearchResponse();
        CustomerPii customerPii = new CustomerPii();
        customerPii.setFirstName("firstName");
        customerPii.setLastName("lastName");
        customerPii.setPartyId("1234566");
        customerPii.setSsn("3232");

        response.setCustomers(Arrays.asList(customerPii));
        return response;
    }

}
