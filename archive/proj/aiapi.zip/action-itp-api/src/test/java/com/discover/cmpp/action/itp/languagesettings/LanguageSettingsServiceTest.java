package com.discover.cmpp.action.itp.languagesettings;

import com.discover.cmpp.action.itp.accountactivity.AccountActivityException;
import com.discover.cmpp.action.itp.accountactivity.AccountActivityServiceImpl;
import com.discover.cmpp.action.itp.common.ActionItpUtil;
import com.discover.cmpp.action.itp.languagesettings.model.LanguageSettingsEntity;
import com.discover.cmpp.action.itp.languagesettings.model.LanguageSettingsRequest;
import com.discover.cmpp.action.itp.languagesettings.model.LanguageSettingsResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;

import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LanguageSettingsServiceTest {

    @InjectMocks
    LanguageSettingsServiceImpl languageSettingsService;

    @Mock
    AccountActivityServiceImpl accountActivityService;

    @Mock
    LanguageSettingsRepository languageSettingsRepository;

    @Mock
    ActionItpUtil actionItpUtil;

    LanguageSettingsEntity languageSettingsEntity;
    private LanguageSettingsRequest languageSettingsRequest;

    @BeforeEach
    void init() {
        languageSettingsRequest = new LanguageSettingsRequest();
        languageSettingsRequest.setLanguageCode("EN");
        languageSettingsRequest.setProductEnrollmentId("9090123456789012345");
    }

    @ParameterizedTest
    @CsvSource({
            "9090123456789012345,EN",
            "9090123456789012345,SP",
    })
    void test_createLanguageSettingsCreate(String peid, String langPref) throws LanguageSettingsException, AccountActivityException {

        LanguageSettingsRequest languageSettingsRequest = new LanguageSettingsRequest();
        languageSettingsRequest.setLanguageCode(langPref);
        languageSettingsRequest.setProductEnrollmentId(peid);

        Mockito.doNothing().when(accountActivityService).createActivity(any());
        when(languageSettingsRepository.save(any())).thenReturn(languageSettingsEntity);
        languageSettingsService.saveLanguageSettings(languageSettingsRequest, "agent1");

        ArgumentCaptor<LanguageSettingsEntity> captor = ArgumentCaptor.forClass(LanguageSettingsEntity.class);
        Mockito.verify(languageSettingsRepository).save(captor.capture());
        LanguageSettingsEntity enity = captor.getValue();
        assertThat(enity.getProductEnrollmentId()).isEqualTo("9090123456789012345");
        if (langPref.equalsIgnoreCase("EN")) {
            assertThat(enity.getLanguageCode()).isEqualTo("EN");
        } else {
            assertThat(enity.getLanguageCode()).isEqualTo("SP");
        }
    }

    @ParameterizedTest
    @CsvSource({
            "9090123456789012345,SP"
    })
    void test_createLanguageSettingsUpdateDifferentScenarios(String peid, String langPref) throws LanguageSettingsException, AccountActivityException {
        LanguageSettingsEntity languageSettingsEntity = new LanguageSettingsEntity();
        languageSettingsEntity.setProductEnrollmentId(peid);
        languageSettingsEntity.setLanguageCode(langPref);
        when(languageSettingsRepository.findByProductEnrollmentId(peid)).thenReturn(languageSettingsEntity);
        when(languageSettingsRepository.save(any())).thenReturn(languageSettingsEntity);
        languageSettingsService.saveLanguageSettings(languageSettingsRequest, "agent1");

        ArgumentCaptor<LanguageSettingsEntity> captor = ArgumentCaptor.forClass(LanguageSettingsEntity.class);
        Mockito.verify(languageSettingsRepository).save(captor.capture());
        LanguageSettingsEntity languageSettingsEntityVerify = captor.getValue();
        assertThat(languageSettingsEntityVerify.getProductEnrollmentId()).isEqualTo("9090123456789012345");
        assertThat(languageSettingsEntityVerify.getLanguageCode()).isEqualTo("EN");
    }

    @ParameterizedTest
    @CsvSource({"9090123456789012345,EN,SP"})
    void test_updateLanguageSettingsUpdateDifferentScenarios(String peid,
                                                          String dbLangPref,
                                                          String inputLangPref) throws LanguageSettingsException, AccountActivityException {
        LanguageSettingsEntity languageSettingsEntity = new LanguageSettingsEntity();
        languageSettingsEntity.setProductEnrollmentId(peid);
        languageSettingsEntity.setLanguageCode(dbLangPref);

        LanguageSettingsRequest languageSettingsRequest = new LanguageSettingsRequest();
        languageSettingsRequest.setProductEnrollmentId(peid);
        languageSettingsRequest.setLanguageCode(inputLangPref);

        when(languageSettingsRepository.findByProductEnrollmentId(peid)).thenReturn(languageSettingsEntity);
        when(languageSettingsRepository.save(any())).thenReturn(languageSettingsEntity);
        languageSettingsService.saveLanguageSettings(languageSettingsRequest, "agent1");

        ArgumentCaptor<LanguageSettingsEntity> captor = ArgumentCaptor.forClass(LanguageSettingsEntity.class);
        Mockito.verify(languageSettingsRepository).save(captor.capture());
        LanguageSettingsEntity languageSettingsEntityVerify = captor.getValue();
        assertThat(languageSettingsEntityVerify.getProductEnrollmentId()).isEqualTo("9090123456789012345");
    }



    @ParameterizedTest
    @CsvSource(value = {
            "9090123456789012345,null"
    }, nullValues={"null"})
    void test_createLanguageSettingsNullLanguageCodeException(String peid, String langPref) {
        LanguageSettingsRequest languageSettingsRequest = new LanguageSettingsRequest();
        languageSettingsRequest.setProductEnrollmentId(peid);
        languageSettingsRequest.setLanguageCode(langPref);
        assertThrows(LanguageSettingsException.class, () -> languageSettingsService.saveLanguageSettings(languageSettingsRequest, "agentId"));
    }

    @Test
    void test_createLanguageSettingsSameDataNoUpdateException() throws LanguageSettingsException, AccountActivityException {
        LanguageSettingsRequest languageSettingsRequest = new LanguageSettingsRequest();
        languageSettingsRequest.setProductEnrollmentId("9090123456789012345");
        languageSettingsRequest.setLanguageCode("EN");

        LanguageSettingsEntity languageSettingsEntity = new LanguageSettingsEntity();
        languageSettingsEntity.setProductEnrollmentId("9090123456789012345");
        languageSettingsEntity.setLanguageCode("EN");
        when(languageSettingsRepository.findByProductEnrollmentId("9090123456789012345")).thenReturn(languageSettingsEntity);
        assertThrows(LanguageSettingsException.class, () -> languageSettingsService.saveLanguageSettings(languageSettingsRequest, "agentId"));
    }

    @Test
    void test_createLanguageSettings_update() throws LanguageSettingsException {
        LanguageSettingsEntity languageSettings = LanguageSettingsEntity.builder()
                .languageCode("EN")
                .productEnrollmentId("9090123456789012345")
                .createBy("agent1")
                .createTs(LocalDateTime.now())
                .updateBy("agent1")
                .updateTs(LocalDateTime.now()).build();

        when(languageSettingsRepository.findByProductEnrollmentId(any())).thenReturn(languageSettings);
        languageSettingsRequest.setLanguageCode("SP");
        languageSettingsService.saveLanguageSettings(languageSettingsRequest, "agent1");

        ArgumentCaptor<LanguageSettingsEntity> captor = ArgumentCaptor.forClass(LanguageSettingsEntity.class);
        Mockito.verify(languageSettingsRepository).save(captor.capture());
        LanguageSettingsEntity languageSettingsEntity = captor.getValue();
        assertThat(languageSettingsEntity.getProductEnrollmentId()).isEqualTo("9090123456789012345");
        assertThat(languageSettingsEntity.getLanguageCode()).isEqualTo("SP");
    }

    @Test
    void test_createLanguageSettings_createWithNullLanguadeCode() {
        languageSettingsRequest.setLanguageCode("");
        when(languageSettingsRepository.findByProductEnrollmentId(any())).thenReturn(null);

        assertThrows(LanguageSettingsException.class, () -> languageSettingsService.saveLanguageSettings(languageSettingsRequest, "agentId"));
    }

    @Test
    void test_createLanguageSettings_exception() {
        Mockito.doThrow(new DataIntegrityViolationException("Error occurred")).when(languageSettingsRepository).save(any());
        assertThrows(LanguageSettingsException.class, () -> languageSettingsService.saveLanguageSettings(languageSettingsRequest, "agentId"));
    }

    @Test
    void test_fetchLanguageSettingsWithValidPeid() throws LanguageSettingsException {
        LanguageSettingsEntity languageSettings = LanguageSettingsEntity.builder()
                .languageCode("EN")
                .productEnrollmentId("9090123456789012345")
                .createBy("agent1")
                .createTs(LocalDateTime.now())
                .updateBy("agent1")
                .updateTs(LocalDateTime.now()).build();

        Mockito.doReturn(languageSettings)
                .when(languageSettingsRepository).findByProductEnrollmentId(any());
        LanguageSettingsResponse response = languageSettingsService.fetchLanguageSettings("9090123456789012345");
        assertNotNull(response);
    }

    @Test
    void test_fetchLanguageSettingsWithValidPeid_NoLanguageSettings_ThrowsException() {
        Mockito.doReturn(null)
                .when(languageSettingsRepository).findByProductEnrollmentId(any());

        assertThrows(LanguageSettingsException.class, () ->
                languageSettingsService.fetchLanguageSettings("123456"));
    }

    @Test
    void test_fetchLanguageSettingsWithInvalidPeid() {
        assertThrows(LanguageSettingsException.class, () ->
                languageSettingsService.fetchLanguageSettings("invalidPEID"));
    }

    @Test
    void test_fetchLanguageSettingsWithBlankPeid() {
        assertThrows(LanguageSettingsException.class, () ->
                languageSettingsService.fetchLanguageSettings(""));
    }

    @Test
    void test_fetchLanguageSettingsWithNullPeid(){
        assertThrows(LanguageSettingsException.class, () ->
                languageSettingsService.fetchLanguageSettings(null));
    }
}
