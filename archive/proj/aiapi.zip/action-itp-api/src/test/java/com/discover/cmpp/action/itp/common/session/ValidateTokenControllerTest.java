package com.discover.cmpp.action.itp.common.session;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class ValidateTokenControllerTest {

    @Mock
    JwtActionItpUtil jwtActionItpUtil;

    @InjectMocks
    ValidateTokenController validateTokenController;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(validateTokenController)
                .addPlaceholderValue("api.context-path", TestUtils.contextPath).build();
    }

    @Test
    void testValidate_whenTokenIsValidAndReturnsOk() throws Exception {
        ValidateTokenInput validateTokenInput = new ValidateTokenInput();
        validateTokenInput.setJwtToken("validJWT");
        String input = new ObjectMapper().writeValueAsString(validateTokenInput);

        when(jwtActionItpUtil.validateJwtToken("validJWT")).thenReturn(true);
        when(jwtActionItpUtil.getUserNameFromJwtToken("validJWT")).thenReturn("testUserName");

        MvcResult result = mockMvc
                .perform(post(TestUtils.contextPath + ActionItpConstants.JWT_TOKEN_VALIDATE_URL).contentType(MediaType.APPLICATION_JSON)
                        .content(input).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username", Matchers.equalTo("testUserName"))).andReturn();

        verify(jwtActionItpUtil, atLeastOnce()).validateJwtToken("validJWT");
        verify(jwtActionItpUtil, atLeastOnce()).getUserNameFromJwtToken("validJWT");
    }

    @Test
    void testValidate_whenTokenIsUnauthorized() throws Exception {
        ValidateTokenInput validateTokenInput = new ValidateTokenInput();
        validateTokenInput.setJwtToken("INVALID TOKEN");
        String input = new ObjectMapper().writeValueAsString(validateTokenInput);

        when(jwtActionItpUtil.validateJwtToken("INVALID TOKEN")).thenThrow(ActionItpException.class);

        MvcResult result = mockMvc
                .perform(post(TestUtils.contextPath + ActionItpConstants.JWT_TOKEN_VALIDATE_URL).contentType(MediaType.APPLICATION_JSON)
                        .content(input).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isUnauthorized()).andReturn();

        verify(jwtActionItpUtil, atLeastOnce()).validateJwtToken("INVALID TOKEN");
    }
}