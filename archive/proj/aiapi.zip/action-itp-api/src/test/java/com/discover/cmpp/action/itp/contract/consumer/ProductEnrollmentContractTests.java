package com.discover.cmpp.action.itp.contract.consumer;

import com.discover.cmpp.action.itp.membership.ProductEnrollmentClient;
import com.discover.cmpp.action.itp.membership.model.EnrollmentLookupResponse;
import feign.FeignException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@AutoConfigureStubRunner(ids = {
        "com.discover.cmpp:product-enrollment-api:+:stubs:"
})
@TestPropertySource(properties = {
        "productEnrollmentApi.service.baseUrl=http://localhost:${stubrunner.runningstubs.product-enrollment-api.port}/v1" // /enterprise/products/enrollment/v1
})
class ProductEnrollmentContractTests extends AbstractConsumerTest {

    @Autowired
    private ProductEnrollmentClient productEnrollmentClient;

    private Map<String, String> headerMap;

    @BeforeEach
    public void setup() {
        headerMap = mockRestClientCommonHeader();
    }

    @Test
    void productEnrollmentSuccess() {
        ResponseEntity<EnrollmentLookupResponse> response = productEnrollmentClient.getEnrollmentInfo(headerMap, "9090202611429200120");

        assertEquals(200, response.getStatusCode().value());
        assertEquals("PDXZ202611428504080", response.getBody().getSubscriberId());
    }

    @Test
    void productEnrollmentValidator400() {
        final FeignException ex = assertThrows(FeignException.class, () -> productEnrollmentClient.getEnrollmentInfo(headerMap, "invalidProductEnrollmentId"));
        assertEquals(400, ex.status());
    }
}
