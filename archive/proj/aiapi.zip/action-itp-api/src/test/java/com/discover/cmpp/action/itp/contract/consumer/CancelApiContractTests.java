package com.discover.cmpp.action.itp.contract.consumer;

import com.discover.cmpp.action.itp.cancel.CancelException;
import com.discover.cmpp.action.itp.cancel.model.CancelRequest;
import com.discover.cmpp.action.itp.membership.MembershipServiceImpl;
import feign.FeignException;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@AutoConfigureStubRunner(ids = {
        "com.discover.cmpp:product-cancel-api:+:stubs:"
})
@TestPropertySource(properties = {
        "cancelApi.service.baseUrl=http://localhost:${stubrunner.runningstubs.product-cancel-api.port}",
        "cancelApi.service.cancelMembership=/cancellation"
})
class CancelApiContractTests extends AbstractConsumerTest {

    @Autowired
    private MembershipServiceImpl membershipService;

    @Test
    void cancelApiSuccess() throws CancelException {
        ResponseEntity<Void> response = membershipService.cancelMembership(getTestHeaderMap(), 200L, getCancelRequest());
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void cancelApi500() {
        Map<String, String> headers = getTestHeaderMap();
        CancelRequest request = getCancelRequest();
        final FeignException ex = assertThrows(FeignException.class, () -> membershipService.cancelMembership(headers, 500L, request));
        assertEquals(500, ex.status());
    }

    private CancelRequest getCancelRequest() {
        CancelRequest cancelRequest = new CancelRequest();
        cancelRequest.setBusinessOrgCode("EC");
        cancelRequest.setContactChannelCode("ACT");
        cancelRequest.setProcessRequestReasonCode("VTO");
        cancelRequest.setProcessRequestSourceCode("AC");
        cancelRequest.setUserId("tested1");
        return cancelRequest;
    }

    private Map<String, String> getTestHeaderMap() {
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put("token", "json");
        headerMap.put("X-DFSUSER-USER-ID", "tested1");
        return headerMap;
    }
}
