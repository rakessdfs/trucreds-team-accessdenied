package com.discover.cmpp.action.itp.authentication.ldap;

import com.discover.cmpp.action.itp.common.ErrorResponse;
import netscape.ldap.LDAPException;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;

@ExtendWith(MockitoExtension.class)
class AgentAuthExceptionHandlerTest {
    @InjectMocks
    AgentAuthExceptionHandler agentAuthExceptionHandler;
    @Mock
    HttpServletRequest httpRequest;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testHandleLDAPException() {
        LDAPException ex = new LDAPException("LDAP error");
        ResponseEntity<ErrorResponse> reEntity = agentAuthExceptionHandler.handleLdapAndInternalException(ex, httpRequest);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, reEntity.getStatusCode());
    }

    @Test
    void testHandleAgentNotAuthenticatedException() {
        AgentNotAuthenticatedException ex = new AgentNotAuthenticatedException("User not authenticated");
        ResponseEntity<ErrorResponse> reEntity =
                agentAuthExceptionHandler.handleAgentNotAuthenticatedException(ex, httpRequest);
        Assert.assertEquals(HttpStatus.UNAUTHORIZED, reEntity.getStatusCode());
    }

    @Test
    void testHandleAgentAuthInternalErrorException() {
        AgentAuthInternalErrorException ex = new AgentAuthInternalErrorException("Internal Server Error");
        ResponseEntity<ErrorResponse> reEntity = agentAuthExceptionHandler.handleLdapAndInternalException(ex, httpRequest);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, reEntity.getStatusCode());
    }
}
