package com.discover.cmpp.action.itp.custlookup;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.custlookup.model.CustomerInfoResponse;
import com.discover.cmpp.action.itp.custlookup.model.CustomerPii;
import com.discover.cmpp.action.itp.custlookup.model.CustomerSearchRequest;
import com.discover.cmpp.action.itp.custlookup.model.CustomerSearchResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.Address;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import org.junit.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class CustLookUpControllerTest {
    @InjectMocks
    private CustLookUpController custLookUpController;
    @Mock
    CustLookUpService custLookUpService;
    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(custLookUpController)
                .addPlaceholderValue("api.context-path", TestUtils.contextPath).build();
    }

    @Test
    void testCustomerPiiSearch_Success() throws Exception {
        CustomerSearchRequest request = new CustomerSearchRequest();
        request.setFirstName("test");
        request.setLastName("test");
        request.setDateOfBirth("12/01/2019");
        Mockito.when(custLookUpService.customerSearch("testRacf", request)).thenReturn(getCustPiiLookUpResponse());
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(request);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + CustLookUpConstants.CUST_PII_LOOK_UP_URL)
                .contentType("application/json")
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .content(requestJson)).andExpect(status().isOk()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }

    @Test
    void testCustomerPiiSearch_invalidDOB() throws Exception {
        CustomerSearchRequest request = new CustomerSearchRequest();
        request.setFirstName("test");
        request.setLastName("test");
        request.setDateOfBirth("12-01-2019");
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(request);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + CustLookUpConstants.CUST_PII_LOOK_UP_URL)
                .contentType("application/json")
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .content(requestJson)).andExpect(status().isBadRequest()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }

    @Test
    void testCustomerPiiSearch_invalidFirstName() throws Exception {
        CustomerSearchRequest request = new CustomerSearchRequest();
        request.setFirstName("testddvgdsgvsgdfgffbfsg");
        request.setLastName("test");
        request.setDateOfBirth("12/01/2019");
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(request);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + CustLookUpConstants.CUST_PII_LOOK_UP_URL)
                .contentType("application/json")
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .content(requestJson)).andExpect(status().isBadRequest()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }

    @Test
    void testCustomerPiiSearch_invalidLastName() throws Exception {
        CustomerSearchRequest request = new CustomerSearchRequest();
        request.setFirstName("test");
        request.setLastName("testdvdvsdvsbfsbfbfbfdbf");
        request.setDateOfBirth("12/01/2019");
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(request);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + CustLookUpConstants.CUST_PII_LOOK_UP_URL)
                .contentType("application/json").content(requestJson)).andExpect(status().isBadRequest()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }

    @Test
    void testCustomerPiiInfo_Success() throws Exception {
        Mockito.when(custLookUpService.customerInfo(anyString(), anyString())).thenReturn(getCustLookUpResponse());
        MvcResult result = mockMvc.perform(get(TestUtils.contextPath + CustLookUpConstants.CUST_PII_INFO_URL)
                .contentType("application/json")
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .param(CustLookUpConstants.PII_INFO_PARTY_ID, "123456"))
                .andExpect(status().is2xxSuccessful()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }

    private CustomerSearchResponse getCustPiiLookUpResponse() {
        CustomerSearchResponse response = new CustomerSearchResponse();
        CustomerPii customerPii = new CustomerPii();
        customerPii.setFirstName("firstName");
        customerPii.setLastName("lastName");
        customerPii.setPartyId("1234566");
        customerPii.setSsn("3232");

        response.setCustomers(Arrays.asList(customerPii));
        return response;
    }

    private CustomerInfoResponse getCustLookUpResponse() {
        CustomerInfoResponse response = new CustomerInfoResponse();
        response.setAddress(new Address());
        response.setDateOfBirth("01/01/1990");
        response.setEmail("foo@bar.com");
        response.setFirstName("firstName");
        response.setLastName("lastName");
        response.setPrimaryPhone("0987654321");
        response.setSsn("9876");
        return response;
    }
}
