package com.discover.cmpp.action.itp.memo;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@ActiveProfiles("test")
@Sql(scripts = "classpath:cleanup.sql", executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
class MemoRepositoryTest {

    private static final String PRODUCT_ENROLLMENT_ID = "someEnrollId";

    @Autowired
    private MemoRepository memoRepository;

    @Disabled("Disable temporarily so pipeline has fewer sporadic failures")
    @Test
    @DisplayName("Should save memo information")
    void save_whenInvoked_shouldSaveMemoInformation() {
        MemoEntity entity = MemoEntity.builder()
                .productEnrollmentId(PRODUCT_ENROLLMENT_ID)
                .memoText("Enrolled")
                .createTs(LocalDateTime.now())
                .createAgentId("jlowrey")
                .updateTs(null)
                .updateAgentId(null)
                .build();
        assertNotNull(memoRepository.save(entity));
    }
}
