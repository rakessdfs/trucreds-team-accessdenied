package com.discover.cmpp.action.itp.contract.consumer;

import com.discover.cmpp.action.itp.membership.ProductReferralClient;
import com.discover.cmpp.action.itp.membership.model.billing.ReferralEntity;
import feign.FeignException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@AutoConfigureStubRunner(ids = {
        "com.discover.cmpp:product-referral-api:+:stubs:"
}, consumerName = "actionItpApi", stubsPerConsumer = true)
@TestPropertySource(properties = {
        "productReferralApi.service.baseUrl=http://localhost:${stubrunner.runningstubs.product-referral-api.port}",
        "productReferralApi.service.getReferrals=/v1/referrals/peid/{peid}"
})
class ProductReferralContractTests extends AbstractConsumerTest {

    @Autowired
    private ProductReferralClient productReferralClient;

    private Map<String, String> headerMap;

    @BeforeEach
    public void setup() {
        headerMap = mockRestClientCommonHeader();
    }

    @Test
    void productReferralSuccess() {
        ResponseEntity<ReferralEntity> response = productReferralClient.getReferrals(headerMap, "9090355072210935451");
        assertEquals(200, response.getStatusCode().value());
    }

    @Test
    void productReferral400() {
        final FeignException ex = assertThrows(FeignException.class, () -> productReferralClient.getReferrals(headerMap, "bad-referral"));
        assertEquals(400, ex.status());
    }

    @Test
    void productReferral404() {
        final FeignException ex = assertThrows(FeignException.class, () -> productReferralClient.getReferrals(headerMap, "9090202731528400943"));
        assertEquals(404, ex.status());
    }

    @Test
    void productReferral500() {
        final FeignException ex = assertThrows(FeignException.class, () -> productReferralClient.getReferrals(headerMap, "9090202731528400500"));
        assertEquals(500, ex.status());
    }
}
