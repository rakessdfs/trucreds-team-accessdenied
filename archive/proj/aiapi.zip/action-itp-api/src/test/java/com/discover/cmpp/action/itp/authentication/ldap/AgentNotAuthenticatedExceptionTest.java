package com.discover.cmpp.action.itp.authentication.ldap;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AgentNotAuthenticatedExceptionTest {
    AgentNotAuthenticatedException agentNotAuthenticateException;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCardOpsAgentAuthAuthorizationException() {
        Exception exception = new Exception("Not Authenticated");
        agentNotAuthenticateException = new AgentNotAuthenticatedException(exception);
        Assert.assertNotNull(agentNotAuthenticateException);
        agentNotAuthenticateException = new AgentNotAuthenticatedException("Not Authenticated", exception);
        Assert.assertNotNull(agentNotAuthenticateException);
        agentNotAuthenticateException = new AgentNotAuthenticatedException("Not Authenticated");
        Assert.assertNotNull(agentNotAuthenticateException);
    }
}
