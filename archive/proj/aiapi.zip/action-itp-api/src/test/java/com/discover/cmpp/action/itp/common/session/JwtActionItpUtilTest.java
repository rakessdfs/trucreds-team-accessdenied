package com.discover.cmpp.action.itp.common.session;

import com.discover.cmpp.action.itp.common.ActionItpException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Date;

import static org.junit.Assert.assertThrows;

@ExtendWith(MockitoExtension.class)
class JwtActionItpUtilTest {

    private static String userID = "testUserID";

    @InjectMocks
    JwtActionItpUtil jwtActionItpUtil;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(jwtActionItpUtil, "jwtSecret", "test-secret");
        ReflectionTestUtils.setField(jwtActionItpUtil, "jwtTokenExpirationInMilliSeconds", 6000);
    }

    @Test
    void testGenerateJwtToken() {
        String generatedToken = jwtActionItpUtil.generateJwtToken(userID);

        Assert.assertNotNull(generatedToken);
    }

    @Test
    void testGetUserNameFromJwtToken() {
        String jwtToken = jwtActionItpUtil.generateJwtToken(userID);

        Assert.assertEquals(userID, jwtActionItpUtil.getUserNameFromJwtToken(jwtToken));
    }

    @Test
    void testValidateJwtTokenForValidToken() throws ActionItpException {
        String jwtToken = jwtActionItpUtil.generateJwtToken(userID);

        Assert.assertTrue(jwtActionItpUtil.validateJwtToken(jwtToken));
    }

    @Test
    void testValidateJwtTokenForInvalidToken() {
        String invalidToken = "invalidToken";

        assertThrows(ActionItpException.class, () -> jwtActionItpUtil.validateJwtToken(invalidToken));
    }

    @Test
    void testValidateJwtTokenForInvalidUserId() {
        String jwtToken = jwtActionItpUtil.generateJwtToken(null);

        assertThrows(ActionItpException.class, () -> jwtActionItpUtil.validateJwtToken(jwtToken));
    }

    @Test
    void testValidateJwtTokenForExpiredToken() {
        Date expiredDate = new Date(new Date().getTime() - 1000);
        String jwtToken = Jwts.builder()
                .setSubject(userID)
                .setIssuedAt(new Date())
                .setExpiration(expiredDate)
                .signWith(SignatureAlgorithm.HS512, "test-secret")
                .compact();

        assertThrows(ActionItpException.class, () -> jwtActionItpUtil.validateJwtToken(jwtToken));
    }
}
