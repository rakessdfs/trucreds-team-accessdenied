package com.discover.cmpp.action.itp.oob;

import com.discover.cmpp.action.itp.oob.OobMockServiceEndpoint;
import com.discover.internet.service.oob.ao.OOBServiceAOBean;
import com.discover.internet.service.oob.ao.OOBServiceAOBeanService;
import org.apache.cxf.Bus;
import org.apache.cxf.bus.spring.SpringBus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.servlet.CXFServlet;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;

import javax.xml.ws.Endpoint;

@TestConfiguration
public class OobSoapIntegrationTestConfiguration {

    public static final String SERVICE_URL = "/OOBServiceAOBean";

    public OOBServiceAOBean mockOobServiceAoBean() {
        JaxWsProxyFactoryBean jaxWsProxyFactory = new JaxWsProxyFactoryBean();
        jaxWsProxyFactory.setServiceClass(OOBServiceAOBean.class);
        jaxWsProxyFactory.setAddress("http://localhost:8088" + SERVICE_URL);
        return (OOBServiceAOBean) jaxWsProxyFactory.create();
    }

    @Bean
    public ServletRegistrationBean<CXFServlet> cxfServlet() {
        return new ServletRegistrationBean<>(new CXFServlet(), SERVICE_URL + "/*");
    }

    @Bean(name = Bus.DEFAULT_BUS_ID)
    public SpringBus springBus() {
        return new SpringBus();
    }

    @Bean
    public OOBServiceAOBean oobServiceAoBean() {
        return new OobMockServiceEndpoint();
    }

    @Bean
    public Endpoint endpoint() {
        EndpointImpl endpoint = new EndpointImpl(springBus(), mockOobServiceAoBean());
        endpoint.setServiceName(oobService().getServiceName());
        endpoint.setWsdlLocation(oobService().getWSDLDocumentLocation().toString());
        endpoint.publish(SERVICE_URL);
        return endpoint;
    }

    @Bean
    public OOBServiceAOBeanService oobService() {
        return new OOBServiceAOBeanService();
    }
}

