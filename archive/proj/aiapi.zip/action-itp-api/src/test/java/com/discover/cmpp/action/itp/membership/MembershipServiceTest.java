package com.discover.cmpp.action.itp.membership;

import com.dfs.ws.jwt.generator.WSJWTException;
import com.discover.cmpp.action.itp.cancel.CancelClient;
import com.discover.cmpp.action.itp.cancel.CancelException;
import com.discover.cmpp.action.itp.cancel.model.CancelRequest;
import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ActionItpUtil;
import com.discover.cmpp.action.itp.common.CloudPropertiesConfiguration;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.custlookup.CdsService;
import com.discover.cmpp.action.itp.custlookup.model.cdspersonal.CdsPersonalInfoResponse;
import com.discover.cmpp.action.itp.membership.model.*;
import com.discover.cmpp.action.itp.membership.model.billing.AccountKeySequenceNbrResponse;
import com.discover.cmpp.action.itp.membership.model.billing.BillingResponse;
import com.discover.cmpp.action.itp.membership.model.billing.CardCustomerDataResponse;
import com.discover.cmpp.action.itp.membership.model.billing.ReferralEntity;
import com.discover.cmpp.utils.CommonConstants;
import feign.FeignException;
import feign.Request;
import feign.Response;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

@ExtendWith(SpringExtension.class)
class MembershipServiceTest {

    @InjectMocks
    MembershipServiceImpl membershipService;
    @Mock
    CardCustomerService cardCustomerService;
    @Mock
    AccountNumberService accountNumberService;
    @Mock
    ProductService productService;
    @Mock
    CdsService cdsService;
    @Mock
    ActionItpUtil itpUtil;
    @Mock
    CsidSubscriberService csidSubscriberService;
    @Mock
    CancelClient cancelClient;
    @Mock
    MembershipAccessClient membershipAccessClient;
    @Mock
    CloudPropertiesConfiguration cloudPropertiesConfiguration;

    @BeforeEach
    public void init() throws WSJWTException, ActionItpException {
        MockitoAnnotations.openMocks(this);
        Mockito.when(itpUtil.restClientCdsHeader("testRacf")).thenReturn(new HashMap<>());
    }

    @Test
    void testFetchItpMembershipInformationGeneralException() throws ActionItpException {
        assertThrows(ActionItpException.class, () -> membershipService.fetchItpMembershipInformation("testRacf", "123"));
    }

    @Test
    void testFetchItpMembershipInformationActionItpException() throws ActionItpException {
        assertThrows(ActionItpException.class, () -> membershipService.fetchItpMembershipInformation("testRacf", "123"));
    }


    @Test
    void testFetchItpMembershipInformationEnrolled() throws ActionItpException {
        Instant instantFuture = Instant.now().plus(Duration.ofHours(5));

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("1313");
        partyToSourceIdAssociation.setExpiryTimestamp(instantFuture);
        partyToSourceIdAssociation.setRequestSourceCode(MembershipConstants.REQ_SRC_CODE_PD);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);


        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );
        Mockito.when(productService.fetchMemberships(any(), any()))
                .thenReturn(new ResponseEntity<>(getMembershipListInfo(StandingCodeEnum.ENR.toString(), CommonConstants.LEVEL_6), HttpStatus.OK));
        // Set mock for product enrollment lookup with parameter membershipId=123 to return subscriber number abc1122
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("abcd1122"), HttpStatus.OK));

        MembershipResponse response1 = membershipService.fetchItpMembershipInformation("testRacf", "123");
        Assert.assertTrue(response1.getEnrollmentStatus().equalsIgnoreCase(StandingCodeEnum.ENR.getStandingName()));
        // Assert that subscriber number in response is abcd1122
        Assert.assertEquals("abcd1122", response1.getSubscriberNumber());
        Assert.assertEquals("ITP_FF",response1.getCustomerType());
    }

    @Test
    void testFetchItpMembershipInformationPendingEnrollment() throws ActionItpException {
        Instant instantFuture = Instant.now().plus(Duration.ofHours(5));


        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("123213");
        partyToSourceIdAssociation.setExpiryTimestamp(instantFuture);
        partyToSourceIdAssociation.setRequestSourceCode(MembershipConstants.REQ_SRC_CODE_PD);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);


        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );
        Mockito.when(productService.fetchMemberships(any(), any()))
                .thenReturn(new ResponseEntity<>(getMembershipListInfo(StandingCodeEnum.PEN.toString(), CommonConstants.LEVEL_6), HttpStatus.OK));
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("abcd1122"), HttpStatus.OK));

        MembershipResponse response1 = membershipService.fetchItpMembershipInformation("testRacf", "123");
        Assert.assertTrue(response1.getEnrollmentStatus().equalsIgnoreCase(StandingCodeEnum.PEN.getStandingName()));
    }

    @Test
    void testFetchItpMembershipInformationForNullPartyId() throws ActionItpException {
        assertThrows(ActionItpException.class, () -> membershipService.fetchItpMembershipInformation(null, null));
    }

    @Test
    void testFetchItpMembershipInformationForNoSubs() throws MembershipException, ActionItpException {

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId(null);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);

        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );
        assertThrows(ActionItpException.class, () -> membershipService.fetchItpMembershipInformation(null, null));
    }

    @Test
    void testFetchItpMembershipInformationPendingCancellation() throws ActionItpException {

        List<ProcessRequestResponse> requestResponses = new ArrayList<>();
        ProcessRequestResponse requestResponse = new ProcessRequestResponse();
        requestResponse.setContactReasonCode(null);
        requestResponse.setProcessRequestDate(new Date(System.currentTimeMillis()));
        requestResponse.setProcessRequestReasonCode("CLS");
        requestResponses.add(requestResponse);

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("2213");
        partyToSourceIdAssociation.setRequestSourceCode(MembershipConstants.REQ_SRC_CODE_PD);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);

        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );
        Mockito.when(productService.fetchMemberships(any(), any()))
                .thenReturn(new ResponseEntity<>(getMembershipListInfo(StandingCodeEnum.PCN.toString(), CommonConstants.LEVEL_6), HttpStatus.OK));
        Mockito.when(productService.fetchProcessRequests(any(), any()))
                .thenReturn(new ResponseEntity<>(requestResponses, HttpStatus.OK));
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("abcd1122"), HttpStatus.OK));
        MembershipResponse response1 = membershipService.fetchItpMembershipInformation("testRacf", "123");
        Assert.assertTrue(response1.getEnrollmentStatus().equalsIgnoreCase(StandingCodeEnum.PCN.getStandingName()));
    }

    @Test
    void testFetchItpMembershipInformationCancellation() throws ActionItpException {

        List<ProcessRequestResponse> requestResponses = new ArrayList<>();
        ProcessRequestResponse requestResponse = new ProcessRequestResponse();
        requestResponse.setProcessRequestReasonCode("E60");
        requestResponse.setProcessRequestDate(new Date(System.currentTimeMillis()));
        requestResponses.add(requestResponse);

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("1231");
        partyToSourceIdAssociation.setRequestSourceCode(MembershipConstants.REQ_SRC_CODE_PD);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);


        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );
        Mockito.when(productService.fetchMemberships(any(), any()))
                .thenReturn(new ResponseEntity<>(getMembershipListInfo(StandingCodeEnum.CAN.toString(), CommonConstants.LEVEL_6), HttpStatus.OK));
        Mockito.when(productService.fetchProcessRequests(any(), any()))
                .thenReturn(new ResponseEntity<>(requestResponses, HttpStatus.OK));
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("abcd1122"), HttpStatus.OK));
        Mockito.when(itpUtil.isMemberCancelled(any())).thenReturn(true);
        MembershipResponse response1 = membershipService.fetchItpMembershipInformation("testRacf", "123");
        Assert.assertTrue(response1.getEnrollmentStatus().equalsIgnoreCase(StandingCodeEnum.CAN.getStandingName()));
        Assert.assertNotNull(response1.getEnrollmentFailedReason());
        Assert.assertEquals(response1.getEnrollmentFailedReason(), ItpffEnrolledFailedReasonEnum.E60.getItpffEnrolledFailedReason());
        Assert.assertEquals(ActionItpConstants.BLANK_STRING, response1.getCancellationCode());
    }

    @Test
    void testFetchItpMembershipInformation_CustomerType_ITP_BM() throws ActionItpException {
        Instant instantFuture = Instant.now().plus(Duration.ofHours(5));

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("1313");
        partyToSourceIdAssociation.setExpiryTimestamp(instantFuture);
        partyToSourceIdAssociation.setRequestSourceCode(MembershipConstants.REQ_SRC_CODE_PD);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);


        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );
        Mockito.when(productService.fetchMemberships(any(), any()))
                .thenReturn(new ResponseEntity<>(getMembershipListInfo(StandingCodeEnum.ENR.toString(), CommonConstants.LEVEL_9), HttpStatus.OK));
        // Set mock for product enrollment lookup with parameter membershipId=123 to return subscriber number abc1122
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("abcd1122"), HttpStatus.OK));

        MembershipResponse response1 = membershipService.fetchItpMembershipInformation("testRacf", "123");
        Assert.assertTrue(response1.getEnrollmentStatus().equalsIgnoreCase(StandingCodeEnum.ENR.getStandingName()));
        // Assert that subscriber number in response is abcd1122
        Assert.assertEquals("abcd1122", response1.getSubscriberNumber());
        Assert.assertEquals("ITP_BM", response1.getCustomerType());
    }

    @Test
    void testFetchItpMembershipInformation_WithMultipleMemberships_ActiveAndCancelled() throws ActionItpException {
        Instant instantFuture = Instant.now().plus(Duration.ofHours(5));

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("1313");
        partyToSourceIdAssociation.setExpiryTimestamp(instantFuture);
        partyToSourceIdAssociation.setRequestSourceCode(MembershipConstants.REQ_SRC_CODE_PD);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);

        List<MembershipListResponse> membershipList = new ArrayList<>();
        MembershipListResponse member1 = createMembershipListInfo("ENR", CommonConstants.LEVEL_9);
        MembershipListResponse member2 = createMembershipListInfo("CAN", CommonConstants.LEVEL_6);
        membershipList.add(member1);
        membershipList.add(member2);

        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );
        Mockito.when(productService.fetchMemberships(any(), any()))
                .thenReturn(new ResponseEntity<>(membershipList, HttpStatus.OK));

        // Set mock for product enrollment lookup with parameter membershipId=123 to return subscriber number abc1122
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("abcd1122"), HttpStatus.OK));
        Mockito.when(itpUtil.isMemberCancelled(any())).thenCallRealMethod();
        MembershipResponse response1 = membershipService.fetchItpMembershipInformation("testRacf", "123");
        Assert.assertTrue(response1.getEnrollmentStatus().equalsIgnoreCase(StandingCodeEnum.ENR.getStandingName()));
        // Assert that subscriber number in response is abcd1122
        Assert.assertEquals("abcd1122", response1.getSubscriberNumber());
        Assert.assertEquals("ITP_BM", response1.getCustomerType());
    }

    @Test
    void testFetchItpMembershipInformation_WithMultipleMemberships_CancelledAndCancelled() throws ActionItpException {
        Instant instantFuture = Instant.now().plus(Duration.ofHours(5));

        List<ProcessRequestResponse> requestResponses = new ArrayList<>();
        ProcessRequestResponse requestResponse = new ProcessRequestResponse();
        requestResponse.setProcessRequestReasonCode("E60");
        requestResponse.setProcessRequestDate(new Date(System.currentTimeMillis()));
        requestResponses.add(requestResponse);

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("1313");
        partyToSourceIdAssociation.setExpiryTimestamp(instantFuture);
        partyToSourceIdAssociation.setRequestSourceCode(MembershipConstants.REQ_SRC_CODE_PD);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);

        List<MembershipListResponse> membershipList = new ArrayList<>();
        MembershipListResponse member1 = createMembershipListInfo("CAN", CommonConstants.LEVEL_9);
        MembershipListResponse member2 = createMembershipListInfo("CAN", CommonConstants.LEVEL_6);
        membershipList.add(member1);
        membershipList.add(member2);

        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );
        Mockito.when(productService.fetchMemberships(any(), any()))
                .thenReturn(new ResponseEntity<>(membershipList, HttpStatus.OK));
        Mockito.when(productService.fetchProcessRequests(any(), any()))
                .thenReturn(new ResponseEntity<>(requestResponses, HttpStatus.OK));
        // Set mock for product enrollment lookup with parameter membershipId=123 to return subscriber number abc1122
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("abcd1122"), HttpStatus.OK));
        Mockito.when(itpUtil.isMemberCancelled(any())).thenCallRealMethod();
        MembershipResponse response1 = membershipService.fetchItpMembershipInformation("testRacf", "123");
        Assert.assertTrue(response1.getEnrollmentStatus().equalsIgnoreCase(StandingCodeEnum.CAN.getStandingName()));
        // Assert that subscriber number in response is abcd1122
        Assert.assertEquals("abcd1122", response1.getSubscriberNumber());
        Assert.assertEquals("ITP_FF", response1.getCustomerType());
    }

    @Test
    void testFetchItpMembershipInformation_WithMultipleMemberships_ActiveAndActive() throws ActionItpException {
        Instant instantFuture = Instant.now().plus(Duration.ofHours(5));

        List<ProcessRequestResponse> requestResponses = new ArrayList<>();
        ProcessRequestResponse requestResponse = new ProcessRequestResponse();
        requestResponse.setProcessRequestReasonCode("E60");
        requestResponse.setProcessRequestDate(new Date(System.currentTimeMillis()));
        requestResponses.add(requestResponse);

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("1313");
        partyToSourceIdAssociation.setExpiryTimestamp(instantFuture);
        partyToSourceIdAssociation.setRequestSourceCode(MembershipConstants.REQ_SRC_CODE_PD);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);

        List<MembershipListResponse> membershipList = new ArrayList<>();
        MembershipListResponse member1 = createMembershipListInfo("ENR", CommonConstants.LEVEL_9);
        MembershipListResponse member2 = createMembershipListInfo("ENR", CommonConstants.LEVEL_6);
        member1.setLastBillDate("2021-09-27");
        member2.setLastBillDate("2021-07-13");
        membershipList.add(member1);
        membershipList.add(member2);

        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );
        Mockito.when(productService.fetchMemberships(any(), any()))
                .thenReturn(new ResponseEntity<>(membershipList, HttpStatus.OK));
        Mockito.when(productService.fetchProcessRequests(any(), any()))
                .thenReturn(new ResponseEntity<>(requestResponses, HttpStatus.OK));
        // Set mock for product enrollment lookup with parameter membershipId=123 to return subscriber number abc1122
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("abcd1122"), HttpStatus.OK));
        Mockito.when(itpUtil.isMemberCancelled(any())).thenCallRealMethod();
        MembershipResponse response1 = membershipService.fetchItpMembershipInformation("testRacf", "123");
        Assert.assertTrue(response1.getEnrollmentStatus().equalsIgnoreCase(StandingCodeEnum.ENR.getStandingName()));
        // Assert that subscriber number in response is abcd1122
        Assert.assertEquals("abcd1122", response1.getSubscriberNumber());
        Assert.assertEquals("ITP_BM", response1.getCustomerType());
    }

    @Test
    void testFetchItpMembershipInformationCancellation_InvalidReasonCode() throws ActionItpException {

        List<ProcessRequestResponse> requestResponses = new ArrayList<>();
        ProcessRequestResponse requestResponse = new ProcessRequestResponse();
        requestResponse.setProcessRequestReasonCode("XPR");
        requestResponse.setProcessRequestDate(new Date(System.currentTimeMillis()));
        requestResponses.add(requestResponse);

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("1231");
        partyToSourceIdAssociation.setRequestSourceCode(MembershipConstants.REQ_SRC_CODE_PD);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);


        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );
        Mockito.when(productService.fetchMemberships(any(), any()))
                .thenReturn(new ResponseEntity<>(getMembershipListInfo(StandingCodeEnum.CAN.toString(), CommonConstants.LEVEL_6), HttpStatus.OK));
        Mockito.when(productService.fetchProcessRequests(any(), any()))
                .thenReturn(new ResponseEntity<>(requestResponses, HttpStatus.OK));
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("abcd1122"), HttpStatus.OK));
        MembershipResponse response1 = membershipService.fetchItpMembershipInformation("testRacf", "123");
        Assert.assertTrue(response1.getEnrollmentStatus().equalsIgnoreCase(StandingCodeEnum.CAN.getStandingName()));
        Assert.assertNotNull(response1.getEnrollmentFailedReason());
        Assert.assertNull(response1.getCancellationReason());
        Assert.assertEquals(ActionItpConstants.BLANK_STRING, response1.getCancellationCode());
    }

    @Test
    void testFetchSubscriberNumber() throws ActionItpException {

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("124325345");
        partyToSourceIdAssociation.setRequestSourceCode(MembershipConstants.REQ_SRC_CODE_PD);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);


        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );
        Mockito.when(productService.fetchMemberships(any(), any()))
                .thenReturn(new ResponseEntity<>(getMembershipListInfo(StandingCodeEnum.ENR.toString(), CommonConstants.LEVEL_6), HttpStatus.OK));
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("abcd1234"), HttpStatus.OK));
        MembershipResponse response1 = membershipService.fetchItpMembershipInformation("testRacf", "123");
        Assert.assertTrue(response1.getSubscriberNumber().equalsIgnoreCase("abcd1234"));
    }

    @Test
    void test_getProductEnrollmentID_whenPeidExpired() throws MembershipException, ActionItpException {
        Instant date = LocalDate.now().plusDays(10).atStartOfDay().toInstant(ZoneOffset.UTC);

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("324234");
        partyToSourceIdAssociation.setExpiryTimestamp(Instant.EPOCH);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation2 =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation2.setAlternatePartyId("BBC123");
        partyToSourceIdAssociation2.setExpiryTimestamp(date);
        partyToSourceIdAssociation.setRequestSourceCode("test");
        partyToSourceIdAssociation2.setRequestSourceCode(MembershipConstants.REQ_SRC_CODE_PD);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[2];
        array[0] = partyToSourceIdAssociation;
        array[1] = partyToSourceIdAssociation2;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);


        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );

        assertEquals("BBC123", membershipService.getProductEnrollmentId("testRacf", "123abc"));
    }

    @Test
    void testFetchItpMembershipInformationInvalidSubscriberNumber() throws ActionItpException {

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("12313");
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);

        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );
        assertThrows(ActionItpException.class, () -> membershipService.fetchItpMembershipInformation("testRacf", "123"));
    }

    @Test
    void test_getProductEnrollmentID_whenCdsResponseNull() throws MembershipException, ActionItpException {
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(null, HttpStatus.OK)
        );
        assertThrows(MembershipException.class, () -> membershipService.getProductEnrollmentId("testRacf", "123abc"));
    }

    @Test
    void fetchItpBillingInformation_returnsValidBillingResponse_ForFnfCustomer() throws MembershipException, ActionItpException {
        BillingResponse expectedBillingResponse = getBillingResponse();
        CardCustomerDataResponse cardCustomerDataResponse = getCardCustomerDataResponse();
        AccountKeySequenceNbrResponse accountKeySequenceNbrResponse = getAccountKeySequenceNbrResponse();
        ReferralEntity referralEntity = getReferralEntity();

        Mockito.when(productService.getReferrals(any(), any())).thenReturn(new ResponseEntity<>(referralEntity, HttpStatus.OK));
        Mockito.when(cardCustomerService.fetchCardCustomerData(any(), any())).thenReturn(new ResponseEntity<>(cardCustomerDataResponse, HttpStatus.OK));
        Mockito.when(accountNumberService.fetchAccountNumber(any(), any())).thenReturn(new ResponseEntity<>(accountKeySequenceNbrResponse, HttpStatus.OK));

        BillingResponse billingResponse = membershipService.fetchItpBillingInformation("ITP_FF", "12345", new BigDecimal("11111"), "PDCD203432229473040");
        Assert.assertEquals(expectedBillingResponse, billingResponse);
    }

    @Test
    void fetchItpBillingInformation_returnsValidBillingResponse_ForBmCustomer() throws MembershipException, ActionItpException {
        BillingResponse expectedBillingResponse = getBillingDateResponse();
        CsidApiResponse csidApiResponse = getCsidApiResponse();

        Mockito.when(csidSubscriberService.getBillingStatus(any(), any())).thenReturn(new ResponseEntity<>(csidApiResponse, HttpStatus.OK));
        Mockito.when(productService.getMembershipByPartyId(any(), any(), any()))
                .thenReturn(new ResponseEntity<>(getMembershipInfo(StandingCodeEnum.PEN.toString(), CommonConstants.LEVEL_9), HttpStatus.OK));

        BillingResponse billingResponse = membershipService.fetchItpBillingInformation("ITP_BM", "12345", new BigDecimal("11111"), "PDCD203432229473040");
        Assert.assertEquals(expectedBillingResponse, billingResponse);
    }

    @Test
    void fetchItpBillingInformation_throwsError_ForBmCustomer_whenCsidCallFails() throws MembershipException {

        Mockito.when(csidSubscriberService.getBillingStatus(any(), any())).thenThrow(new MembershipException(MembershipConstants.BILLING_ERROR));
        Mockito.when(productService.getMembershipByPartyId(any(), any(), any()))
                .thenReturn(new ResponseEntity<>(getMembershipInfo(StandingCodeEnum.PEN.toString(), CommonConstants.LEVEL_9), HttpStatus.OK));

        assertThrows(MembershipException.class, () -> membershipService.fetchItpBillingInformation("ITP_BM", "12345", new BigDecimal("11111"), "PDCD203432229473040"));
    }

    @Test
    void fetchItpBillingInformation_returnsNullValueWithInvalidSubscriberId() throws ActionItpException, MembershipException {
        Mockito.when(productService.getMembershipByPartyId(any(), any(), any()))
                .thenReturn(new ResponseEntity<>(getMembershipInfo(StandingCodeEnum.CAN.toString(), CommonConstants.LEVEL_6), HttpStatus.OK));

        BillingResponse billingResponse = membershipService.fetchItpBillingInformation("ITP_BM", "12345", new BigDecimal("11111"), "PD12");
        assertNull(billingResponse.getNextBillingDate());
    }

    @Test
    void fetchItpBillingInformationForFnf_throwsMembershipExceptionWithBillingErrorMessage_whenCallToCardCustomerDataFails() {
        ReferralEntity referralEntity = getReferralEntity();
        Mockito.when(productService.getReferrals(any(), any())).thenReturn(new ResponseEntity<>(referralEntity, HttpStatus.OK));
        ResponseEntity<CardCustomerDataResponse> cardCustomerDataResponseResponseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        Mockito.when(cardCustomerService.fetchCardCustomerData(any(), any())).thenReturn(cardCustomerDataResponseResponseEntity);
        MembershipException exception = assertThrows(MembershipException.class, () -> membershipService.fetchItpBillingInformation("ITP_FF", "12345", new BigDecimal("11111"), "PD12"));
        assertTrue(exception.getMessage().contains(MembershipConstants.BILLING_ERROR));
    }

    @Test
    void fetchItpBillingInformation_throwsMembershipExceptionWithPeidNotFoundErrorMessage_whenCallToProductReferralsReturns404WithEmptyBody() {
        Mockito.when(productService.getReferrals(any(), eq("11111")))
                .thenThrow(FeignException.errorStatus(
                        "referral",
                        Response.builder()
                                .status(404)
                                .headers(new HashMap<>())
                                .request(Request.create(Request.HttpMethod.GET, "", Collections.emptyMap(), Request.Body.empty(), null))
                                .build()));

        MembershipException exception = assertThrows(MembershipException.class, () -> membershipService.fetchItpBillingInformation("ITP_FF", "12345", new BigDecimal("11111"), "PD12"));
        assertTrue(exception.getMessage().contains(ValidationConstants.PEID_NOT_FOUND_EC));
    }

    @Test
    void fetchItpBillingInformation_throwsMembershipExceptionWithInvalidPeidException_whenCallToProductReferralsReturns400() {
        Mockito.when(productService.getReferrals(any(), eq("11111")))
                .thenThrow(FeignException.errorStatus(
                        "referral",
                        Response.builder()
                                .status(400)
                                .headers(new HashMap<>())
                                .request(Request.create(Request.HttpMethod.GET, "", Collections.emptyMap(), Request.Body.empty(), null))
                                .build()));

        MembershipException exception = assertThrows(MembershipException.class, () -> membershipService.fetchItpBillingInformation("ITP_FF", "12345", new BigDecimal("11111"), "PD12"));
        System.out.println(exception.getMessage());
        assertTrue(exception.getMessage().contains(ValidationConstants.PEID_INVALID_LENGTH_EC));
    }

    @Test
    void testFetchItpMembershipInformationBMCancellation_Cancel_Rsn_Code() throws ActionItpException, ParseException {

        List<ProcessRequestResponse> requestResponses = new ArrayList<>();
        ProcessRequestResponse requestResponse = new ProcessRequestResponse();
        requestResponse.setProcessRequestReasonCode("AAF");
        requestResponse.setProcessRequestDate(new Date(System.currentTimeMillis()));
        requestResponses.add(requestResponse);

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("1231");
        partyToSourceIdAssociation.setRequestSourceCode(MembershipConstants.REQ_SRC_CODE_PD);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);


        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );

        Mockito.when(productService.fetchProcessRequests(any(), any()))
                .thenReturn(new ResponseEntity<>(requestResponses, HttpStatus.OK));
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("abcd1122"), HttpStatus.OK));
        Mockito.when(productService.fetchMemberships(any(), any()))
                .thenReturn(new ResponseEntity<>(getMembershipListInfo(StandingCodeEnum.CAN.toString(), CommonConstants.LEVEL_9), HttpStatus.OK));
        Mockito.when(itpUtil.isMemberCancelled(any())).thenReturn(true);
        MembershipResponse response1 = membershipService.fetchItpMembershipInformation("testRacf", "123");
        Assert.assertTrue(response1.getEnrollmentStatus().equalsIgnoreCase(StandingCodeEnum.CAN.getStandingName()));
        Assert.assertNotNull(response1.getCancellationReason());
        Assert.assertNotNull(BmCancellationReasonList.Bm_Enrol_fail_Rsn_list.contains("AAF"));
        Assert.assertEquals("AAF", response1.getCancellationCode());
        Assert.assertEquals(response1.getCancellationReason(), BmCancellationReasonList.Bm_Cancel_Rsn_map.get("AAF"));
    }

    @Test
    void testFetchItpMembershipInformationBMCancellation_InvalidCode() throws ActionItpException {

        List<ProcessRequestResponse> requestResponses = new ArrayList<>();
        ProcessRequestResponse requestResponse = new ProcessRequestResponse();
        requestResponse.setProcessRequestReasonCode("XYZ");
        requestResponse.setProcessRequestDate(new Date(System.currentTimeMillis()));
        requestResponses.add(requestResponse);

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("1231");
        partyToSourceIdAssociation.setRequestSourceCode(MembershipConstants.REQ_SRC_CODE_PD);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);


        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );
        Mockito.when(productService.fetchMemberships(any(), any()))
                .thenReturn(new ResponseEntity<>(getMembershipListInfo(StandingCodeEnum.CAN.toString(), CommonConstants.LEVEL_9), HttpStatus.OK));
        Mockito.when(productService.fetchProcessRequests(any(), any()))
                .thenReturn(new ResponseEntity<>(requestResponses, HttpStatus.OK));
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("abcd1122"), HttpStatus.OK));
        Mockito.when(itpUtil.isMemberCancelled(any())).thenReturn(true);
        MembershipResponse response1 = membershipService.fetchItpMembershipInformation("testRacf", "123");
        Assert.assertTrue(response1.getEnrollmentStatus().equalsIgnoreCase(StandingCodeEnum.CAN.getStandingName()));
        Assert.assertFalse(BmCancellationReasonList.Bm_Enrol_fail_Rsn_list.contains("XYZ"));
        Assert.assertNull(BmCancellationReasonList.Bm_Cancel_Rsn_map.get("XYZ"));
        Assert.assertEquals("XYZ", response1.getCancellationReason());

    }

    @Test
    void testFetchItpMembershipInformationBMCancellation_Enrl_Failed_Rsn_Code() throws ActionItpException {

        List<ProcessRequestResponse> requestResponses = new ArrayList<>();
        ProcessRequestResponse requestResponse = new ProcessRequestResponse();
        requestResponse.setProcessRequestReasonCode("DSC");
        requestResponse.setProcessRequestDate(new Date(System.currentTimeMillis()));
        requestResponses.add(requestResponse);

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("1231");
        partyToSourceIdAssociation.setRequestSourceCode(MembershipConstants.REQ_SRC_CODE_PD);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);


        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );
        Mockito.when(productService.fetchMemberships(any(), any()))
                .thenReturn(new ResponseEntity<>(getMembershipListInfo(StandingCodeEnum.CAN.toString(), CommonConstants.LEVEL_9), HttpStatus.OK));
        Mockito.when(productService.fetchProcessRequests(any(), any()))
                .thenReturn(new ResponseEntity<>(requestResponses, HttpStatus.OK));
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("abcd1122"), HttpStatus.OK));
        Mockito.when(itpUtil.isMemberCancelled(any())).thenReturn(true);
        MembershipResponse response1 = membershipService.fetchItpMembershipInformation("testRacf", "123");
        Assert.assertTrue(response1.getEnrollmentStatus().equalsIgnoreCase(StandingCodeEnum.CAN.getStandingName()));
        Assert.assertTrue(BmCancellationReasonList.Bm_Enrol_fail_Rsn_list.contains("DSC"));
        Assert.assertNotNull(BmCancellationReasonList.Bm_Cancel_Rsn_map.get("DSC"));
        Assert.assertEquals(response1.getEnrollmentFailedReason(), BmCancellationReasonList.Bm_Cancel_Rsn_map.get("DSC"));
    }

    @Test
    void test_fetchItpMembershipInformation_BMCustomer() throws ActionItpException {
        Instant instantFuture = Instant.now().plus(Duration.ofHours(5));

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("1313");
        partyToSourceIdAssociation.setExpiryTimestamp(instantFuture);
        partyToSourceIdAssociation.setRequestSourceCode(MembershipConstants.REQ_SRC_CODE_PD);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);


        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );
        Mockito.when(productService.fetchMemberships(any(), any()))
                .thenReturn(new ResponseEntity<>(getMembershipListInfo(StandingCodeEnum.ENR.toString(), CommonConstants.LEVEL_9), HttpStatus.OK));
        // Set mock for product enrollment lookup with parameter membershipId=123 to return subscriber number abc1122
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("abcd1122"), HttpStatus.OK));

        MembershipResponse response1 = membershipService.fetchItpMembershipInformation("testRacf", "123");
        Assert.assertTrue(response1.getEnrollmentStatus().equalsIgnoreCase(StandingCodeEnum.ENR.getStandingName()));
        // Assert that subscriber number in response is abcd1122
        Assert.assertEquals("abcd1122", response1.getSubscriberNumber());
        Assert.assertEquals("ITP_BM", response1.getCustomerType());
    }

    @Test
    void test_fetchItpMembershipInformation_NotItpFForBMCustomer() throws ActionItpException {
        Instant instantFuture = Instant.now().plus(Duration.ofHours(5));

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("1313");
        partyToSourceIdAssociation.setExpiryTimestamp(instantFuture);
        partyToSourceIdAssociation.setRequestSourceCode(MembershipConstants.REQ_SRC_CODE_PD);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);


        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );
        Mockito.when(productService.fetchMemberships(any(), any()))
                .thenReturn(new ResponseEntity<>(HttpStatus.OK));
        // Set mock for product enrollment lookup with parameter membershipId=123 to return subscriber number abc1122
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("abcd1122"), HttpStatus.OK));

        assertThrows(ActionItpException.class, () -> membershipService.fetchItpMembershipInformation("testRacf", "123"));
    }

    @Test
    void test_fetchItpMembershipInformation_Non200ResponseCode() throws ActionItpException {
        Instant instantFuture = Instant.now().plus(Duration.ofHours(5));

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("1313");
        partyToSourceIdAssociation.setExpiryTimestamp(instantFuture);
        partyToSourceIdAssociation.setRequestSourceCode(MembershipConstants.REQ_SRC_CODE_PD);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);


        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );
        Mockito.when(productService.fetchMemberships(any(), any()))
                .thenReturn(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
        // Set mock for product enrollment lookup with parameter membershipId=123 to return subscriber number abc1122
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("abcd1122"), HttpStatus.OK));

        assertThrows(ActionItpException.class, () -> membershipService.fetchItpMembershipInformation("testRacf", "123"));
    }

    @Test
    void testFetchItpMembershipInformation_CustomerType_ITP_BM_FREE() throws ActionItpException {
        Instant instantFuture = Instant.now().plus(Duration.ofHours(5));

        CdsPersonalInfoResponse response = new CdsPersonalInfoResponse();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfos = new ArrayList<>();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation =
                new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        partyToSourceIdAssociation.setAlternatePartyId("1313");
        partyToSourceIdAssociation.setExpiryTimestamp(instantFuture);
        partyToSourceIdAssociation.setRequestSourceCode(MembershipConstants.REQ_SRC_CODE_PD);
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] array = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[1];
        array[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(array);
        personalInfos.add(personalInfo);
        response.setPersonalInfo(personalInfos);


        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(
                new ResponseEntity<>(response, HttpStatus.OK)
        );
        Mockito.when(productService.fetchMemberships(any(), any()))
                .thenReturn(new ResponseEntity<>(getMembershipListInfo(StandingCodeEnum.ENR.toString(), CommonConstants.LEVEL_8), HttpStatus.OK));
        // Set mock for product enrollment lookup with parameter membershipId=123 to return subscriber number abc1122
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("abcd1122"), HttpStatus.OK));

        MembershipResponse response1 = membershipService.fetchItpMembershipInformation("testRacf", "123");
        Assert.assertTrue(response1.getEnrollmentStatus().equalsIgnoreCase(StandingCodeEnum.ENR.getStandingName()));
        // Assert that subscriber number in response is abcd1122
        Assert.assertEquals("abcd1122", response1.getSubscriberNumber());
        Assert.assertEquals("ITP_BM_FREE", response1.getCustomerType());
    }

    @Test
    void testFetchRequestReasons() throws RequestReasonsException, ActionItpException {
        List<RequestReasonResponseEntity> requestReasonList = getRequestReasonResponseEntities();

        Mockito.when(productService.getRequestReasonCodes(any(), any()))
                .thenReturn(new ResponseEntity<>(getRequestReasonResponseEntities(), HttpStatus.OK));

        RequestReasonResponse response = membershipService.fetchRequestReasons("testRacf", "ITP_BM");
        Assert.assertNotNull(response.getRequestReasons());
        Assert.assertEquals("CODE", response.getRequestReasons().get(0).getCode());
        Assert.assertEquals("DESC", response.getRequestReasons().get(0).getDescription());
    }

    @Test
    void testFetchRequestReasons_throwRequestReasonsNotFound() {
        ResponseEntity<List<RequestReasonResponseEntity>> responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        Mockito.when(productService.getRequestReasonCodes(any(), any())).thenReturn(responseEntity);
        RequestReasonsException exception = assertThrows(RequestReasonsException.class, () -> membershipService.fetchRequestReasons("12345", "ITP_BM"));
        assertTrue(exception.getMessage().contains(MembershipConstants.REQUEST_REASONS_NOT_FOUND));
    }

    @Test
    void testCancelMembership_oldCancelEndpoint() throws CancelException {
        Mockito.when(cloudPropertiesConfiguration.isNewCancelApiEnabled()).thenReturn(false);

        membershipService.cancelMembership(new HashMap<>(), 123L, new CancelRequest());
        verify(membershipAccessClient).cancelMembership(any(), any(), any());
    }

    @Test
    void testCancelMembership_newCancelEndpoint() throws CancelException {
        Mockito.when(cloudPropertiesConfiguration.isNewCancelApiEnabled()).thenReturn(true);

        membershipService.cancelMembership(new HashMap<>(), 123L, new CancelRequest());
        verify(cancelClient).cancelMembership(any(), any(), any(), any());
    }

    private List<RequestReasonResponseEntity> getRequestReasonResponseEntities() {
        List<RequestReasonResponseEntity> requestReasonList = new ArrayList<>();
        RequestReasonResponseEntity entity = RequestReasonResponseEntity.builder()
                .processRequestSourceCode("A")
                .productLevelNumber(1)
                .productProcessCode("C")
                .productTypeCode("D")
                .requestReasonCode("CODE")
                .requestReasonName("DESC")
                .build();
        requestReasonList.add(entity);
        return requestReasonList;
    }

    private MembershipInfo getMembershipInfo(String standingCode, Integer levelNumber) {
        MembershipInfo info = new MembershipInfo();
        MembershipEntity entity = new MembershipEntity();
        MembershipPK membershipPK = new MembershipPK();
        membershipPK.setMembershipId(new BigDecimal(123));
        membershipPK.setTablePartNumber("06");
        entity.setCancelCompletionDate("2021-05-24");
        entity.setCancelRequestDate("2021-01-01");
        entity.setMembershipPK(membershipPK);
        entity.setMembershipRequestDate("2021-05-24");
        entity.setStandingCode(standingCode);
        entity.setLevelNumber(levelNumber);
        info.setLevelName("test-level");
        info.setMembershipEntity(entity);
        info.setPricingStructureName("test");
        info.setProductName("ITF");
        info.setStandingName("test");
        return info;
    }

    private List<MembershipListResponse> getMembershipListInfo(String standingCode, Integer levelNumber) {
        List<MembershipListResponse> membershipList = new ArrayList<>();
        MembershipListResponse member = new MembershipListResponse();
        member.setLevelNumber(levelNumber);
        member.setStandingCode(standingCode);
        member.setStandingName("test");
        member.setPricingStructureName("test");
        member.setCancelCompletionDate("2021-05-24");
        member.setCancelRequestDate("2021-01-01");
        member.setMembershipId(123);
        member.setMembershipRequestDate("2021-01-01");
        membershipList.add(member);
        return membershipList;
    }

    private MembershipListResponse createMembershipListInfo(String standingCode, Integer levelNumber) {
        MembershipListResponse member = new MembershipListResponse();
        member.setLevelNumber(levelNumber);
        member.setStandingCode(standingCode);
        member.setStandingName("test");
        member.setPricingStructureName("test");
        member.setCancelCompletionDate("2021-05-24");
        member.setCancelRequestDate("2021-01-01");
        member.setMembershipId(123);
        member.setMembershipRequestDate("2021-01-01");
        return member;
    }

    private EnrollmentLookupResponse getEnrollmentInfo(String subscriberNumber) {
        EnrollmentLookupResponse response = new EnrollmentLookupResponse();
        response.setSubscriberId(subscriberNumber);
        return response;
    }

    private BillingResponse getBillingResponse() {
        BillingResponse expectedBillingResponse = new BillingResponse();
        expectedBillingResponse.setPcmFirstName("Scottie");
        expectedBillingResponse.setPcmLastName("Pippen");
        expectedBillingResponse.setPcmAccountNumber("555555555");
        expectedBillingResponse.setPresenceOfSecondary("No");
        return expectedBillingResponse;
    }

    private BillingResponse getBillingDateResponse() {
        BillingResponse expectedBillingResponse = new BillingResponse();
        expectedBillingResponse.setNextBillingDate("20210222");
        return expectedBillingResponse;
    }

    private CardCustomerDataResponse getCardCustomerDataResponse() {
        CardCustomerDataResponse cardCustomerDataResponse = new CardCustomerDataResponse();
        cardCustomerDataResponse.setFirstName("Scottie");
        cardCustomerDataResponse.setLastName("Pippen");
        cardCustomerDataResponse.setPresenceOfSecondary("No");
        return cardCustomerDataResponse;
    }

    private AccountKeySequenceNbrResponse getAccountKeySequenceNbrResponse() {
        AccountKeySequenceNbrResponse accountKeySequenceNbrResponse = new AccountKeySequenceNbrResponse();
        accountKeySequenceNbrResponse.setAcctNbr("555555555");
        return accountKeySequenceNbrResponse;
    }

    private ReferralEntity getReferralEntity() {
        ReferralEntity referralEntity = new ReferralEntity();
        referralEntity.setCmAccountKey(12345678);
        return referralEntity;
    }

    private CsidApiResponse getCsidApiResponse() {
        CsidApiResponse csidApiResponse = new CsidApiResponse();
        CsidApiResponse.ResponseObject responseObject = CsidApiResponse.ResponseObject.builder().build();
        CsidApiResponse.Response response = CsidApiResponse.Response.builder().build();
        CsidApiResponse.SubscriberData subscriberData = CsidApiResponse.SubscriberData.builder().build();
        subscriberData.setNextBillDate("20210222");
        response.setSubscriberData(subscriberData);
        responseObject.setResponse(response);
        csidApiResponse.setResponseObject(responseObject);
        return csidApiResponse;
    }
}
