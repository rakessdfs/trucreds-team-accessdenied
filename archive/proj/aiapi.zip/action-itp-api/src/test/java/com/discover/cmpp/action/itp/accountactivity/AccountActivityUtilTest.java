package com.discover.cmpp.action.itp.accountactivity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;

import static org.junit.Assert.assertTrue;

@ExtendWith(MockitoExtension.class)
class AccountActivityUtilTest {

    @BeforeEach
    public void init() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testConvertAccountActivityEntityToAccountActivityDto() {
        AccountActivityCodeEntity codeEntity = AccountActivityCodeEntity.builder()
                .activityCode("activity-util")
                .activityDesc("desc")
                .category("category")
                .createTs(LocalDateTime.now())
                .updateTs(null)
                .build();

        AccountActivityEntity entity = AccountActivityEntity.builder()
                .productEnrollmentId("123456")
                .activityCode(codeEntity)
                .previousData("previous")
                .newData("new")
                .operator("operator")
                .requestDate(LocalDateTime.now())
                .createTs(LocalDateTime.now())
                .updateTs(null)
                .build();

        AccountActivityDto dto = AccountActivityUtil.convertAccountActivityEntityToAccountActivityDto(entity);
        assertTrue(dto.getProductEnrollmentId().equalsIgnoreCase("123456"));
        assertTrue(dto.getActivityDesc().equalsIgnoreCase("desc"));
    }
}
