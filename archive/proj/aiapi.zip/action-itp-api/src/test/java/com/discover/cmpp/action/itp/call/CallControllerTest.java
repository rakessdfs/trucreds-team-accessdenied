package com.discover.cmpp.action.itp.call;

import com.discover.cmpp.action.itp.call.model.RecordCallRequest;
import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.util.NestedServletException;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class CallControllerTest {

    @InjectMocks
    CallController callController;
    @Mock
    CallService callService;

    private MockMvc mockMvc;
    private RecordCallRequest request;

    @BeforeEach
    void setUp() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(callController)
                .addPlaceholderValue("api.context-path", TestUtils.contextPath).build();
        request = RecordCallRequest.builder().productEnrollmentId("14578625").customerType("ITP_BM").tagType("servicing").build();
    }

    @Test
    void test_recordCall_success() throws Exception {
        Mockito.doNothing().when(callService).recordCall(any(), any());
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(request);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + CallConstants.RECORD_CALL_URL)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .contentType("application/json")
                .content(requestJson))
                .andExpect(status().isOk()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }

    @Test
    void test_recordCall_badRequest() throws Exception {
        request.setProductEnrollmentId("1");

        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(request);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + CallConstants.RECORD_CALL_URL)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .contentType("application/json")
                .content(requestJson))
                .andExpect(status().isBadRequest()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }

    @Test
    void test_recordCall_internalServerError() throws Exception {
        Mockito.doThrow(new CallException("Server error")).when(callService).recordCall(any(), any());

        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(request);
        assertThrows(NestedServletException.class, () ->
                mockMvc.perform(post(TestUtils.contextPath + CallConstants.RECORD_CALL_URL)
                .header(ActionItpConstants.AGENT_ID, "testRacf")
                .contentType("application/json")
                .content(requestJson))
                .andExpect(status().isInternalServerError()));
    }
}
