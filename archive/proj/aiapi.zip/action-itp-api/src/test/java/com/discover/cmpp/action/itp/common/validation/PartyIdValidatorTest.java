package com.discover.cmpp.action.itp.common.validation;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.validation.ConstraintValidatorContext;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class PartyIdValidatorTest {
    @Mock
    private PartyId partyId;
    private ConstraintValidatorContext cxt;
    private PartyIdValidator validator;

    @BeforeEach
    public void setup() {
        validator = new PartyIdValidator();
        validator.initialize(partyId);

        when(partyId.nullable()).thenReturn(false);
        when(partyId.empty()).thenReturn(false);
    }

    @Test
    void testPartyId_valid() {
        assertTrue(validator.isValid("123456789", cxt));
    }

    @Test
    void testPartyId_invalid_nonNumeric() {
        assertFalse(validator.isValid("ABCD1234", cxt));
    }

    @Test
    void testPartyId_invalid_WhenNull() {
        assertFalse(validator.isValid(null, cxt));

        when(partyId.nullable()).thenReturn(true);
        assertTrue(validator.isValid(null, cxt));
    }

    @Test
    void testPartyId_invalid_WhenBlankOrWhitespace() {
        assertFalse(validator.isValid("", cxt));
        assertFalse(validator.isValid(" ", cxt));

        when(partyId.empty()).thenReturn(true);
        assertTrue(validator.isValid("", cxt));
        assertTrue(validator.isValid(" ", cxt));
    }
}
