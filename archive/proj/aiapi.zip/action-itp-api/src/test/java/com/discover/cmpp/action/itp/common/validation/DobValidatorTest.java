package com.discover.cmpp.action.itp.common.validation;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import javax.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


class DobValidatorTest {
    private ConstraintValidatorContext cxt;
    private DobValidator validator;

    @BeforeEach
    public void setUp() throws Exception {
        validator = new DobValidator();
    }

    @Test
    void testDob_valid() {
        assertTrue(validator.isValid("09/08/1995", cxt));
    }

    @Test
    void testDob_inValidFormat() {
        assertFalse(validator.isValid("1995-09-08", cxt));
    }

    @Test
    void testDob_inValidMonth() {
        assertFalse(validator.isValid("13/08/1995", cxt));
    }

    @Test
    void testDob_inValidDay() {
        assertFalse(validator.isValid("12/32/1995", cxt));
    }
}
