package com.discover.cmpp.action.itp.memo;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@ExtendWith(MockitoExtension.class)
class MemoUtilTest {

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testErrorLogHeaderConversion() {
        MemoEntity memoEntity = new MemoEntity();
        memoEntity.setMemoId(1L);
        memoEntity.setProductEnrollmentId("1234");
        memoEntity.setMemoText("Test");
        memoEntity.setCreateAgentId("test");
        MemoDto memoDto = MemoUtil.convertMemoEnityToMemoDto(memoEntity);
        assertTrue(memoDto.getProductEnrollmentId().equalsIgnoreCase("1234"));
    }

    @Test
    void testErrorLogHeaderConversionFailure() {
        MemoEntity memoEntity = new MemoEntity();
        memoEntity.setMemoId(1L);
        memoEntity.setProductEnrollmentId("1234");
        memoEntity.setMemoText("Test");
        memoEntity.setCreateAgentId("test");
        MemoDto memoDto = MemoUtil.convertMemoEnityToMemoDto(memoEntity);
        assertFalse(memoDto.getProductEnrollmentId().equalsIgnoreCase("3454545"));
    }
}
