package com.discover.cmpp.action.itp.contract;

import com.discover.cmpp.action.itp.cancel.CancelController;
import com.discover.cmpp.action.itp.cancel.CancelException;
import com.discover.cmpp.action.itp.cancel.CancelService;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ActionItpExceptionHandler;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import io.restassured.module.mockmvc.RestAssuredMockMvc;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.setup.StandaloneMockMvcBuilder;

@ExtendWith(SpringExtension.class)
public abstract class CancelBase {

    @InjectMocks
    private CancelController controller;

    @Mock
    private CancelService cancelService;

    @BeforeEach
    public void setup() throws CancelException, ActionItpException {
        MockitoAnnotations.openMocks(this);

        Mockito.doThrow(new CancelException(ValidationConstants.BAD_REQUEST))
                .when(cancelService).cancelRequest("testRACF", "9090210762045412346", "XYZ");
        Mockito.doThrow(new CancelException("500"))
                .when(cancelService).cancelRequest("testRACF","9090210762045412347","DNW");

        StandaloneMockMvcBuilder standaloneMockMvcBuilder = MockMvcBuilders.standaloneSetup(controller)
                .addPlaceholderValue("api.context-path", TestUtils.contextPath)
                .setControllerAdvice(new ActionItpExceptionHandler());
        RestAssuredMockMvc.standaloneSetup(standaloneMockMvcBuilder);
    }
}
