package com.discover.cmpp.action.itp.oob;

import com.discover.cmpp.action.itp.common.CloudPropertiesConfiguration;
import com.discover.cmpp.action.itp.oob.model.GetStatusResponse;
import com.discover.cmpp.action.itp.oob.model.SendCodeRequest;
import com.discover.cmpp.action.itp.oob.model.ValidateCodeRequest;
import com.discover.cmpp.action.itp.oob.model.OobServiceAoResponse;
import com.discover.cmpp.action.itp.oob.model.UnlockUserRequest;
import com.discover.internet.service.oob.ao.OOBServiceException_Exception;
import com.discover.internet.service.oob.vo.GetStatusOutputVO;
import com.discover.internet.service.oob.vo.ReturnStatusVO;
import com.discover.internet.service.oob.vo.SendCodeOutputVO;
import com.discover.internet.service.oob.vo.UserVO;
import com.discover.internet.service.oob.vo.ValidateCodeOutputVO;
import com.discover.internet.service.oob.vo.UnlockUserInputVO;
import com.discover.internet.service.oob.vo.UnlockUserOutputVO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.discover.internet.service.oob.ao.OOBServiceAOBean;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.dao.DataIntegrityViolationException;

import static com.discover.cmpp.action.itp.common.validation.ValidationConstants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class OobServiceTest {

    @Mock
    OOBServiceAOBean oobServiceAoBean;

    @Mock
    CloudPropertiesConfiguration cloudPropertiesConfiguration;

    @InjectMocks
    private OobServiceImpl oobService;

    private SendCodeOutputVO sendCodeOutputVO;

    private ValidateCodeOutputVO validateCodeOutputVO;

    private UnlockUserOutputVO unlockUserOutputVO;

    @BeforeEach
    public void init() {
        MockitoAnnotations.openMocks(this);
        sendCodeOutputVO = new SendCodeOutputVO();
        validateCodeOutputVO = new ValidateCodeOutputVO();
        unlockUserOutputVO = new UnlockUserOutputVO();
    }

    // Send code success
    @Test
    void test_sendCode_success() throws OobSoapException, OOBServiceException_Exception {
        ReturnStatusVO returnStatusVO = new ReturnStatusVO();
        returnStatusVO.setCode(5);
        sendCodeOutputVO.setReturnStatus(returnStatusVO);
        SendCodeRequest request = new SendCodeRequest();
        request.setCustomerFirstName("Firstname");
        request.setCustomerLastName("Lastname");
        request.setChannelCode("EM");
        request.setChannelValue("oobtest@test.com");
        request.setCustUserKey("987654321");
        when(oobServiceAoBean.sendCode(any())).thenReturn(sendCodeOutputVO);

        OobServiceAoResponse response =  oobService.sendCode(request, "testAgent");
        assertEquals(5, response.getReturnStatus().getCode());
    }


    // Send code failure - sending message to oob service fails general exception
    @Test
    void test_sendCode_oobexception() throws OOBServiceException_Exception {
        SendCodeRequest request = new SendCodeRequest();
        Mockito.doThrow(new OOBServiceException_Exception("OOB Send Code Request failed")).when(oobServiceAoBean).sendCode(any());
        assertThrows(OobSoapException.class, () -> oobService.sendCode(request, "agent1"));
    }

    @Test
    void test_sendCode_exception() throws OOBServiceException_Exception {
        SendCodeRequest request = new SendCodeRequest();
        Mockito.doThrow(new DataIntegrityViolationException("OOB Send Code Request failed")).when(oobServiceAoBean).sendCode(any());

        assertThrows(OobSoapException.class, () -> oobService.sendCode(request, "agent1"));
    }

    @Test
    void test_sendCode_oobException_Invalid_Subscriber() throws OOBServiceException_Exception {
        SendCodeRequest request = new SendCodeRequest();
        Mockito.doThrow(new OOBServiceException_Exception(INVALID_SUBSCRIBER_ID_EM)).when(oobServiceAoBean).sendCode(any());
        assertThrows(OobSoapException.class, () -> oobService.sendCode(request, "agent1"), INVALID_SUBSCRIBER_ID_EM);
    }

    @Test
    void test_sendCode_oobException_Member_Not_Found() throws OOBServiceException_Exception {
        SendCodeRequest request = new SendCodeRequest();
        Mockito.doThrow(new OOBServiceException_Exception(MEMBER_NOT_FOUND_EM)).when(oobServiceAoBean).sendCode(any());
        assertThrows(OobSoapException.class, () -> oobService.sendCode(request, "agent1"), MEMBER_NOT_FOUND_EM);
    }

    @Test
    void test_sendCode_oobException_Invalid_Peid_Subscriber_Id() throws OOBServiceException_Exception {
        SendCodeRequest request = new SendCodeRequest();
        Mockito.doThrow(new OOBServiceException_Exception(INVALID_PEID_OR_SUBSCRIBER_EM)).when(oobServiceAoBean).sendCode(any());
        assertThrows(OobSoapException.class, () -> oobService.sendCode(request, "agent1"), INVALID_PEID_OR_SUBSCRIBER_EM);
    }

    @Test
    void test_sendCode_oobException_Arg_Not_Valid() throws OOBServiceException_Exception {
        SendCodeRequest request = new SendCodeRequest();
        Mockito.doThrow(new OOBServiceException_Exception(ARG_NOT_VALID_EM)).when(oobServiceAoBean).sendCode(any());
        assertThrows(OobSoapException.class, () -> oobService.sendCode(request, "agent1"), ARG_NOT_VALID_EM);
    }

    @Test
    void test_sendCode_oobException_Product_Enrollment_Api_Issue() throws OOBServiceException_Exception {
        SendCodeRequest request = new SendCodeRequest();
        Mockito.doThrow(new OOBServiceException_Exception(ERROR_MSG_PRODUCT_ENROLLMENT_EM)).when(oobServiceAoBean).sendCode(any());
        assertThrows(OobSoapException.class, () -> oobService.sendCode(request, "agent1"), ERROR_MSG_PRODUCT_ENROLLMENT_EM);
    }

    @Test
    void test_sendCode_oobException_CDS_Api_Issue() throws OOBServiceException_Exception {
        SendCodeRequest request = new SendCodeRequest();
        Mockito.doThrow(new OOBServiceException_Exception(CDS_API_ISSUE_EM)).when(oobServiceAoBean).sendCode(any());
        assertThrows(OobSoapException.class, () -> oobService.sendCode(request, "agent1"), CDS_API_ISSUE_EM);
    }

    @Test
    void test_sendCode_oobException_Invalid_Channel_Code() throws OOBServiceException_Exception {
        SendCodeRequest request = new SendCodeRequest();
        Mockito.doThrow(new OOBServiceException_Exception(CHANNEL_CODE_INVALID_EM)).when(oobServiceAoBean).sendCode(any());
        assertThrows(OobSoapException.class, () -> oobService.sendCode(request, "agent1"), CHANNEL_CODE_INVALID_EM);
    }

    @Test
    void test_sendCode_oobException_Invalid_Channel_Value() throws OOBServiceException_Exception {
        SendCodeRequest request = new SendCodeRequest();
        Mockito.doThrow(new OOBServiceException_Exception(CHANNEL_VALUE_INVALID_EM)).when(oobServiceAoBean).sendCode(any());
        assertThrows(OobSoapException.class, () -> oobService.sendCode(request, "agent1"), CHANNEL_VALUE_INVALID_EM);
    }

    @Test
    void test_sendCode_oobException_Code_Generation_Error() throws OOBServiceException_Exception {
        SendCodeRequest request = new SendCodeRequest();
        Mockito.doThrow(new OOBServiceException_Exception(CODE_GENERATION_ERROR_EM)).when(oobServiceAoBean).sendCode(any());
        assertThrows(OobSoapException.class, () -> oobService.sendCode(request, "agent1"), CODE_GENERATION_ERROR_EM);
    }

    // Send code failure - sending message to oob service fails OOB exception
    @Test
    void test_sendCode_codeInvalid() throws OOBServiceException_Exception {
        ReturnStatusVO returnStatusVO = new ReturnStatusVO();
        returnStatusVO.setCode(-1);
        sendCodeOutputVO.setReturnStatus(returnStatusVO);
        SendCodeRequest request = new SendCodeRequest();
        when(oobServiceAoBean.sendCode(any())).thenReturn(sendCodeOutputVO);
        assertThrows(OobSoapException.class, () -> oobService.sendCode(request, "agent1"));
    }

    // Get Status success
    @Test
    void test_getStatus_success() throws OobSoapException, OOBServiceException_Exception {
        GetStatusOutputVO getStatusOutputVO = new GetStatusOutputVO();
        ReturnStatusVO returnStatus = new ReturnStatusVO();
        returnStatus.setCode(0);
        getStatusOutputVO.setReturnStatus(returnStatus);
        UserVO userInfo = new UserVO();
        userInfo.setUserStatusCode("OK");
        userInfo.setUserStatusCodeDesc("User OK, in good standing");
        getStatusOutputVO.setUserInfo(userInfo);

        when(oobServiceAoBean.getStatus(any())).thenReturn(getStatusOutputVO);
        GetStatusResponse response = oobService.getStatus("123456789");
        assertEquals("OK", response.getUserStatusCode());
        assertEquals("User OK, in good standing", response.getUserStatusCodeDesc());
    }

    // Get Status success, user not enrolled
    @Test
    void test_getStatus_user_not_enrolled() throws OobSoapException, OOBServiceException_Exception {
        GetStatusOutputVO getStatusOutputVO = new GetStatusOutputVO();
        ReturnStatusVO returnStatus = new ReturnStatusVO();
        returnStatus.setCode(1);
        returnStatus.setDescription("Success, user not enrolled");
        getStatusOutputVO.setReturnStatus(returnStatus);

        when(oobServiceAoBean.getStatus(any())).thenReturn(getStatusOutputVO);
        assertThrows(OobSoapException.class, () -> oobService.getStatus("123456789"));
    }

    @Test
    void test_getStatus_oob_exception() throws OOBServiceException_Exception {
        Mockito.doThrow(new OOBServiceException_Exception("OOB Get Status Request failed")).when(oobServiceAoBean).getStatus(any());
        assertThrows(OobSoapException.class, () -> oobService.getStatus("12345678"));
    }

    @Test
    void test_getStatus_exception() throws OOBServiceException_Exception {
        Mockito.doThrow(new DataIntegrityViolationException("OOB Get Status Request failed")).when(oobServiceAoBean).getStatus(any());
        assertThrows(OobSoapException.class, () -> oobService.getStatus("12345678"));
    }

    @Test
    void test_validateCode_success() throws OobSoapException, OOBServiceException_Exception {
        ReturnStatusVO returnStatusVO = new ReturnStatusVO();
        returnStatusVO.setCode(5);
        validateCodeOutputVO.setReturnStatus(returnStatusVO);
        ValidateCodeRequest request = new ValidateCodeRequest();
        request.setCustUserKey("987654321");
        request.setInputCode("12345");
        request.setLockCustomer(false);

        when(oobServiceAoBean.validateCode(any())).thenReturn(validateCodeOutputVO);
        OobServiceAoResponse response = oobService.validateOobCode(request);

        verify(oobServiceAoBean, times(1)).validateCode(any());
        assertEquals(5, response.getReturnStatus().getCode());
    }

    @Test
    void test_validateCode_lockUser_success() throws OobSoapException, OOBServiceException_Exception {
        UserVO userInfo = new UserVO();
        userInfo.setUserStatusCode("LK");
        userInfo.setUserStatusCodeDesc("User Locked");

        ReturnStatusVO returnStatusVO = new ReturnStatusVO();
        returnStatusVO.setCode(-3);
        validateCodeOutputVO.setReturnStatus(returnStatusVO);
        validateCodeOutputVO.setUserInfo(userInfo);
        ValidateCodeRequest request = new ValidateCodeRequest();
        request.setCustUserKey("987654321");
        request.setInputCode("12345");
        request.setLockCustomer(true);

        when(cloudPropertiesConfiguration.getOobLockNumberOfCalls()).thenReturn(4);
        when(oobServiceAoBean.validateCode(any())).thenReturn(validateCodeOutputVO);
        OobServiceAoResponse response = oobService.validateOobCode(request);

        verify(oobServiceAoBean, times(4)).validateCode(any());
        assertEquals(-3, response.getReturnStatus().getCode());
    }

    @Test
    void test_validateCode_lockUser_failure() throws OOBServiceException_Exception {
        UserVO userInfo = new UserVO();
        userInfo.setUserStatusCode("OK");
        userInfo.setUserStatusCodeDesc("User OK, in good standing");

        ReturnStatusVO returnStatusVO = new ReturnStatusVO();
        returnStatusVO.setCode(0);
        validateCodeOutputVO.setReturnStatus(returnStatusVO);
        validateCodeOutputVO.setUserInfo(userInfo);
        ValidateCodeRequest request = new ValidateCodeRequest();
        request.setCustUserKey("987654321");
        request.setInputCode("12345");
        request.setLockCustomer(true);

        when(cloudPropertiesConfiguration.getOobLockNumberOfCalls()).thenReturn(4);
        when(oobServiceAoBean.validateCode(any())).thenReturn(validateCodeOutputVO);

        assertThrows(OobSoapException.class, () -> oobService.validateOobCode(request));
    }

    @Test
    void test_validateCode_oobexception() throws OOBServiceException_Exception {
        ValidateCodeRequest request = new ValidateCodeRequest();
        Mockito.doThrow(new OOBServiceException_Exception("OOB Validate Code Request failed")).when(oobServiceAoBean)
                .validateCode(any());
        assertThrows(OobSoapException.class, () -> oobService.validateOobCode(request));
    }

    @Test
    void test_validateCode_codeInvalid() throws OOBServiceException_Exception {
        ReturnStatusVO returnStatusVO = new ReturnStatusVO();
        returnStatusVO.setCode(-1);
        validateCodeOutputVO.setReturnStatus(returnStatusVO);
        ValidateCodeRequest request = new ValidateCodeRequest();
        when(oobServiceAoBean.validateCode(any())).thenReturn(validateCodeOutputVO);
        assertThrows(OobSoapException.class, () -> oobService.validateOobCode(request));
    }
    @Test
    void test_unlockUser_success() throws OobSoapException, OOBServiceException_Exception {
        ReturnStatusVO returnStatusVO = new ReturnStatusVO();
        returnStatusVO.setCode(1);
        unlockUserOutputVO.setReturnStatus(returnStatusVO);
        UnlockUserRequest request = new UnlockUserRequest();
        request.setCustUserKey("987654321");
        when(oobServiceAoBean.unlockUser(any())).thenReturn(unlockUserOutputVO);
        oobService.unlockUser(request, "testAgent");
        verify(oobServiceAoBean, times(1)).unlockUser(any(UnlockUserInputVO.class));
        assertTrue(true);
    }

    @Test
    void test_unlockUser_custKeyInvalid() throws OOBServiceException_Exception {
        ReturnStatusVO returnStatusVO = new ReturnStatusVO();
        returnStatusVO.setCode(-1);
        unlockUserOutputVO.setReturnStatus(returnStatusVO);
        UnlockUserRequest request = new UnlockUserRequest();
        request.setCustUserKey("xxx");
        when(oobServiceAoBean.unlockUser(any())).thenReturn(unlockUserOutputVO);
        assertThrows(OobSoapException.class, () -> oobService.unlockUser(request, "agent1"));
    }

    @Test
    void test_unlockUser_custKeyInvalidEmpty() throws OOBServiceException_Exception {
        ReturnStatusVO returnStatusVO = new ReturnStatusVO();
        returnStatusVO.setCode(-1);
        unlockUserOutputVO.setReturnStatus(returnStatusVO);
        UnlockUserRequest request = new UnlockUserRequest();
        when(oobServiceAoBean.unlockUser(any())).thenReturn(unlockUserOutputVO);
        assertThrows(OobSoapException.class, () -> oobService.unlockUser(request, "agent1"));
    }

    @Test
    void test_unlockUser_exception() throws OOBServiceException_Exception {
        UnlockUserRequest request = new UnlockUserRequest();
        Mockito.doThrow(new DataIntegrityViolationException("OOB Unlock User Request failed")).when(oobServiceAoBean).unlockUser(any());
        assertThrows(OobSoapException.class, () -> oobService.unlockUser(request, "agent1"));
    }
}
