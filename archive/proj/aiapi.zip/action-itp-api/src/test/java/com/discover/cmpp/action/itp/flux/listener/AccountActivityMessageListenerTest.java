package com.discover.cmpp.action.itp.flux.listener;

import com.discover.cmpp.action.itp.accountactivity.AccountActivityException;
import com.discover.cmpp.action.itp.accountactivity.AccountActivityService;
import com.discover.cmpp.action.itp.flux.ActivityPayloadConstants;
import com.discover.cmpp.action.itp.flux.FluxException;
import com.discover.cmpp.action.itp.flux.schema.AccountActivityPayload;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.reflect.ReflectData;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.internal.verification.VerificationModeFactory.times;

@ExtendWith(MockitoExtension.class)
class AccountActivityMessageListenerTest {
    AccountActivityPayload ACTIVITY_PAYLOAD = new AccountActivityPayload();
    private GenericRecord avroRecord;

    @InjectMocks
    @Spy
    private AccountActivityMessageListener accountActivityMessageListener;

    @Mock
    AccountActivityService accountActivityService;

    @BeforeEach
    public void init() {

        MockitoAnnotations.openMocks(this);
        ACTIVITY_PAYLOAD.setActivityCode("500");
        ACTIVITY_PAYLOAD.setOperator("ONLINE");
        ACTIVITY_PAYLOAD.setProductEnrollmentId("457821487");
        ACTIVITY_PAYLOAD.setRequestDate("2021-02-16 20:34:59");
        ACTIVITY_PAYLOAD.setNewData("");
        ACTIVITY_PAYLOAD.setPreviousData("");

        final Schema schema = ReflectData.get().getSchema(ACTIVITY_PAYLOAD.getClass());
        avroRecord = new GenericData.Record(schema);
        avroRecord.put(ActivityPayloadConstants.ACTIVITY_CODE, ACTIVITY_PAYLOAD.getActivityCode());
        avroRecord.put(ActivityPayloadConstants.PRODUCT_ENROLLMENT_ID, ACTIVITY_PAYLOAD.getProductEnrollmentId());
        avroRecord.put(ActivityPayloadConstants.PREVIOUS_DATA, ACTIVITY_PAYLOAD.getPreviousData());
        avroRecord.put(ActivityPayloadConstants.NEW_DATA, ACTIVITY_PAYLOAD.getNewData());
        avroRecord.put(ActivityPayloadConstants.OPERATOR, ACTIVITY_PAYLOAD.getOperator());
        avroRecord.put(ActivityPayloadConstants.REQUEST_DATE, ACTIVITY_PAYLOAD.getRequestDate());
    }


    @Test
    void testOnMessage() throws AccountActivityException {
        ConsumerRecord<String, GenericRecord> activityRecord =
                new ConsumerRecord<>("TestTopic", 0, 10, null, avroRecord);
        accountActivityMessageListener.onMessage(activityRecord, "TestTopic");
        verify(accountActivityMessageListener, times(1)).onMessage(activityRecord, "TestTopic");
    }

    @Test
    void testOnMessageFluxException() throws FluxException, AccountActivityException {
        ConsumerRecord<String, GenericRecord> activityRecord =
                new ConsumerRecord<>("TestTopic", 0, 10, null, avroRecord);
        doThrow(FluxException.class).when(accountActivityMessageListener).onMessage(activityRecord, "TestTopic");
        assertThrows(FluxException.class, () -> accountActivityMessageListener.onMessage(activityRecord, "TestTopic"));
        verify(accountActivityMessageListener, times(1)).onMessage(activityRecord, "TestTopic");
    }

    @Test
    void testOnMessage_NullFields() throws FluxException, AccountActivityException {
        avroRecord.put(ActivityPayloadConstants.PRODUCT_ENROLLMENT_ID, null);
        avroRecord.put(ActivityPayloadConstants.PREVIOUS_DATA, null);
        avroRecord.put(ActivityPayloadConstants.NEW_DATA, null);
        avroRecord.put(ActivityPayloadConstants.OPERATOR, null);
        ConsumerRecord<String, GenericRecord> activityRecord =
                new ConsumerRecord<>("TestTopic", 0, 10, null, avroRecord);
        accountActivityMessageListener.onMessage(activityRecord, "TestTopic");
        verify(accountActivityMessageListener, times(1)).onMessage(activityRecord, "TestTopic");
    }

    @Test
    void testOnMessage_NullActivityCode_Exception() throws FluxException, AccountActivityException {
        avroRecord.put(ActivityPayloadConstants.ACTIVITY_CODE, null);
        ConsumerRecord<String, GenericRecord> activityRecord =
                new ConsumerRecord<>("TestTopic", 0, 10, null, avroRecord);
        assertThrows(FluxException.class, () -> accountActivityMessageListener.onMessage(activityRecord, "TestTopic"));
        verify(accountActivityMessageListener, times(1)).onMessage(activityRecord, "TestTopic");
    }
}
