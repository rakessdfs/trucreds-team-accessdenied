package com.discover.cmpp.action.itp.contract;

import com.discover.cmpp.action.itp.cloak.CloakException;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ActionItpExceptionHandler;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.custlookup.CustLookUpException;
import com.discover.cmpp.action.itp.membership.MembershipException;
import com.discover.cmpp.action.itp.memo.CreateMemoRequest;
import com.discover.cmpp.action.itp.memo.MemoController;
import com.discover.cmpp.action.itp.memo.MemoDto;
import com.discover.cmpp.action.itp.memo.MemoException;
import com.discover.cmpp.action.itp.memo.MemoResponse;
import com.discover.cmpp.action.itp.memo.MemoService;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import io.restassured.module.mockmvc.RestAssuredMockMvc;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.setup.StandaloneMockMvcBuilder;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
abstract class MemosBase {

    @InjectMocks
    private MemoController controller;

    @Mock
    private MemoService memoService;

    @BeforeEach
    void setup() throws MemoException, ActionItpException, CloakException, MembershipException, CustLookUpException {
        MockitoAnnotations.openMocks(this);
        when(memoService.fetchMemos("1")).thenReturn(getMemoResponse());
        when(memoService.fetchMemos("2")).thenThrow(new MemoException(ValidationConstants.PEID_INVALID_EC));
        when(memoService.fetchMemos("4")).thenThrow(new NullPointerException());

        CreateMemoRequest createMemoRequest = new CreateMemoRequest();
        createMemoRequest.setMemoText("Enrolled into ITP F&F");
        createMemoRequest.setProductEnrollmentId("23456789");
        Mockito.doThrow(new MemoException(ValidationConstants.AGENT_ID_INVALID_EC))
                .when(memoService).createMemo(createMemoRequest, "invalidID");
        Mockito.doThrow(new NullPointerException()).when(memoService)
                .createMemo(createMemoRequest, "testRACF500");

        MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter = new
                MappingJackson2HttpMessageConverter();
        mappingJackson2HttpMessageConverter.setObjectMapper(new ObjectMapper()
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
                .registerModule(new JavaTimeModule()));

        StandaloneMockMvcBuilder standaloneMockMvcBuilder = MockMvcBuilders.standaloneSetup(controller)
                .addPlaceholderValue("api.context-path", TestUtils.contextPath)
                .setControllerAdvice(new ActionItpExceptionHandler());
        RestAssuredMockMvc
                .standaloneSetup(standaloneMockMvcBuilder.setMessageConverters(mappingJackson2HttpMessageConverter));
    }

    private MemoResponse getMemoResponse() {
        MemoResponse memoResponse = new MemoResponse();
        List<MemoDto> memoDtoList = new ArrayList<>();
        MemoDto memoDto = new MemoDto();
        memoDto.setCreateAgentId("Peter");
        LocalDateTime localDateTime = LocalDateTime.of(2020, 8, 31, 20, 28, 57);
        System.out.println("date = " +localDateTime);
        memoDto.setCreateTs(localDateTime);
        memoDto.setMemoId((long) 12);
        memoDto.setMemoText("Enrolled into ITP F&F");
        memoDto.setProductEnrollmentId("1");
        memoDto.setUpdateAgentId(null);
        memoDto.setUpdateTs(null);
        memoDtoList.add(memoDto);
        MemoDto memoDto2 = new MemoDto();
        memoDto.setCreateAgentId("Peter");
        LocalDateTime localDateTime2 = LocalDateTime.of(2020, 8, 31, 20, 29, 57);
        System.out.println("date = " +localDateTime);
        memoDto2.setCreateTs(localDateTime);
        memoDto2.setMemoId((long) 13);
        memoDto2.setMemoText("Cancelled enrollment");
        memoDto2.setProductEnrollmentId("1");
        memoDto2.setUpdateAgentId("Peter2");
        memoDto2.setUpdateTs(localDateTime2);
        memoDtoList.add(memoDto2);
        memoResponse.setMemosList(memoDtoList);
        return memoResponse;
    }
}
