package com.discover.cmpp.action.itp.common;

import com.discover.cmpp.action.itp.common.session.JwtActionItpUtil;
import com.discover.cmpp.jwt.ExcludeEndpointFilter;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.http.HttpHeaders;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import static com.discover.cmpp.jwt.utils.JwtIntegrationTestHelper.*;
import static com.github.tomakehurst.wiremock.client.WireMock.resetAllRequests;
import static org.springframework.test.context.jdbc.Sql.ExecutionPhase.AFTER_TEST_METHOD;

@AutoConfigureMockMvc
@DirtiesContext
@AutoConfigureWireMock(port = 9002)
@SpringBootTest
@ActiveProfiles("test")
@ExtendWith(SpringExtension.class)
@Sql(scripts = "classpath:cleanup.sql", executionPhase = AFTER_TEST_METHOD)
public abstract class AbstractIntegrationTest {

    @Autowired
    public FilterRegistrationBean<ExcludeEndpointFilter> jwtAuthenticationFilterBean;
    @Autowired
    public FilterRegistrationBean<ExcludeEndpointFilter> applicationScopeAuthFilterBean;
    @Autowired
    public JwtActionItpUtil jwtActionItpUtil;
    @Autowired
    public ObjectMapper objectMapper;
    @Autowired
    public MockMvc mockMvc;

    public HttpHeaders httpHeaders;

    @BeforeEach
    void setUp() throws Exception {
        setupAuthenticationFilterForTest(jwtAuthenticationFilterBean);
        setupAuthorizationFilterForTest(applicationScopeAuthFilterBean);
        stubCallsToJWTEndpoint();
        httpHeaders = httpAuthHeaders("Ent_productsActionItp_v1");
    }

    @AfterEach
    void reset() {
        resetAllRequests();
    }
}