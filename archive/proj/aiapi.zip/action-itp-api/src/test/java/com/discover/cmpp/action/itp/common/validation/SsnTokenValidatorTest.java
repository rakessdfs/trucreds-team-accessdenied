package com.discover.cmpp.action.itp.common.validation;

import static org.junit.Assert.*;
import static org.mockito.Mockito.lenient;
import javax.validation.ConstraintValidatorContext;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class SsnTokenValidatorTest {
    @Mock
    private SsnToken ssnToken;
    private ConstraintValidatorContext cxt;
    private SsnTokenValidator validator;

    @BeforeEach
    public void setUp() throws Exception {
        lenient().when(ssnToken.nullable()).thenReturn(false);
        lenient().when(ssnToken.empty()).thenReturn(false);
        validator = new SsnTokenValidator();
        validator.initialize(ssnToken);
    }

    @Test
    void testSsnToken_valid() {
        assertTrue(validator.isValid("827819839", cxt));
    }

    @Test
    void testSsnToken_inValid_whenNonNumeric() {
        assertFalse(validator.isValid("tqrwyuaio", cxt));
    }

    @Test
    void testSsnToken_inValid_whenLengthNotEqualto9() {
        assertFalse(validator.isValid("8278198", cxt));
        assertFalse(validator.isValid("8278198397862", cxt));
    }

    @Test
    void testSsnToken_inValid_whenNULL() {
        assertFalse(validator.isValid(null, cxt));
    }

    @Test
    void testSsnToken_inValid_WhenBlankOrSpace() {
        assertFalse(validator.isValid("", cxt));
        assertFalse(validator.isValid(" ", cxt));
    }

    @Test
    void testSsnToken_WhenNullableAndEmptyIsTrue() {
        Mockito.when(ssnToken.empty()).thenReturn(true);
        Mockito.when(ssnToken.nullable()).thenReturn(true);
        validator.initialize(ssnToken);
        assertTrue(validator.isValid("", cxt));
        assertTrue(validator.isValid(null, cxt));
        assertFalse(validator.isValid("72378192389832874", cxt));
    }
}
