package com.discover.cmpp.action.itp.contract.consumer;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.cloud.contract.stubrunner.spring.StubRunnerProperties;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.cloud.openfeign.FeignClientsConfiguration;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;

import java.util.HashMap;
import java.util.Map;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@AutoConfigureWireMock(port = 0)
@SpringBootTest(properties = {
        "jwt.authenticator.filter.certsUrl=http://localhost:${wiremock.server.port}/certs",
        "jwt.authenticator.filter.certs2ndUrl=http://localhost:${wiremock.server.port}/certs",
        "jwt.client.tokenEndpointURL=http://localhost:${wiremock.server.port}/fake-auth/token"
})
@ActiveProfiles("test")
@Import(FeignClientsConfiguration.class)
@DirtiesContext
public abstract class AbstractConsumerTest {

    @BeforeEach
    void setUp() {
        stubCallsToJwtEndpoint();
    }

    public static void stubCallsToJwtEndpoint() {
        stubFor(get(urlEqualTo("/fake-auth/token"))
                .willReturn(aResponse()
                        .withStatus(HttpStatus.OK.value())
                        .withHeader("Content-Type", APPLICATION_JSON_VALUE)
                        .withBody(//language=json
                                "{\n" +
                                        "  \"token\": \"t0kent0ken\"\n" +
                                        "}")));
    }

    protected Map<String, String> mockRestClientCommonHeader() {
        Map<String, String> map = new HashMap<>();
        map.put(ActionItpConstants.HTTP_AUTH_TOKEN, "JWTv2token");
        map.put(ActionItpConstants.CONTENT_TYPE, ActionItpConstants.CONTENT_TYPE_APP_JSON);
        map.put(ActionItpConstants.ACCEPT, ActionItpConstants.CONTENT_TYPE_APP_JSON);
        return map;
    }
}

