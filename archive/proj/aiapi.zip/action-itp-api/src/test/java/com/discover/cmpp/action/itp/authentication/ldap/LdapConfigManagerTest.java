package com.discover.cmpp.action.itp.authentication.ldap;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LdapConfigManagerTest {
    LdapConfigManager ldapConfigMgr;

    @BeforeEach
    public void setup() {
        ldapConfigMgr = new LdapConfigManager(10, 50, 1523, 1103, "XE", "bindid", "binddn", "bindpwd", true, "bindgroup");
    }

    @Test
    void testLDAPConfigTest() {
        assertEquals("binddn", ldapConfigMgr.getBinddn());
        assertEquals("bindid", ldapConfigMgr.getBindid());
        assertEquals("bindpwd", ldapConfigMgr.getBindpwd());
        assertEquals(50, ldapConfigMgr.getMaxpoolsize());
        assertEquals(10, ldapConfigMgr.getMinpoolsize());
        assertEquals(1523, ldapConfigMgr.getPortnumber());
        assertEquals(1103, ldapConfigMgr.getProtocolversion());
        assertTrue(ldapConfigMgr.isPwdEncrypted());
        assertEquals("XE", ldapConfigMgr.getServer());
        assertEquals("bindgroup", ldapConfigMgr.getBindgroup());
    }
}