package com.discover.cmpp.action.itp.accountactivity;

import com.dfs.ws.jwt.generator.WSJWTException;
import com.discover.cmpp.action.itp.common.ActionItpException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
public class CsidReportingServiceTest {
    @Mock
    private CsidReportingClient csidReportingClient;

    @InjectMocks
    CsidReportingServiceImpl csidReportingService;

    @BeforeEach
    public void init() throws ActionItpException {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void test_getItpAlertsSuccess() throws AccountActivityException {
        List<ItpCsidAlertData> dataList = new ArrayList<>();
        ItpCsidAlertData data = new  ItpCsidAlertData();
        data.setCreateDate(Timestamp.valueOf("2021-02-01 00:00:00.0"));
        data.setEnrollmentId("123456789");
        dataList.add(data);
        ResponseEntity<List<ItpCsidAlertData>> clientResponse = new ResponseEntity(dataList, HttpStatus.OK);
        Mockito.when(csidReportingClient.getItpAlerts(any(), any())).thenReturn(clientResponse);
        List<ItpCsidAlertData> result = csidReportingService.getItpAlerts(new HashMap<String, String>(), "123456789");
        Assert.assertEquals(1, result.size());
        Assert.assertEquals("123456789", result.get(0).getEnrollmentId());
    }
}
