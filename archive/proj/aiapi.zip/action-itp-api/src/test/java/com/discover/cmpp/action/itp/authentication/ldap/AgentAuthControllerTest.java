package com.discover.cmpp.action.itp.authentication.ldap;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.session.JwtActionItpUtil;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import netscape.ldap.LDAPException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.mockito.ArgumentMatchers.anyString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class AgentAuthControllerTest {

    @InjectMocks
    AgentAuthController agentAuthController;

    @Mock
    AgentAuthService agentAuthService;

    @Mock
    JwtActionItpUtil jwtActionItpUtil;

    private MockMvc mockMvc;
    private AgentAuthInputVO agentAuthInputVO;
    private AgentAuthOutputVO agentAuthOutputVO;

    @BeforeEach
    public void setUp() throws Exception {
        AgentAuthExceptionHandler agentAuthExceptionHandler = new AgentAuthExceptionHandler();
        this.mockMvc = MockMvcBuilders.standaloneSetup(agentAuthController)
                .addPlaceholderValue("api.context-path", TestUtils.contextPath)
                .setControllerAdvice(agentAuthExceptionHandler).build();

        agentAuthInputVO = new AgentAuthInputVO();
        agentAuthInputVO.setRacf("testuser");
        agentAuthInputVO.setPsswd("1234");

        agentAuthOutputVO = new AgentAuthOutputVO();
        agentAuthOutputVO = new AgentAuthOutputVO();
        agentAuthOutputVO.setEmail("foo@bar.com");
        agentAuthOutputVO.setFullName("fullName");
        agentAuthOutputVO.setUserName("testuser");
    }

    @Test
    void testAuthenticateOk() throws Exception {
        Mockito.when(jwtActionItpUtil.generateJwtToken(anyString())).thenReturn("dummyToken");
        Mockito.when(agentAuthService.authenticate(agentAuthInputVO)).thenReturn(agentAuthOutputVO);

        MvcResult result = mockMvc
                .perform(post(TestUtils.contextPath + AgentAuthConstants.AGENT_AUTH_URL).contentType(MediaType.APPLICATION_JSON)
                        .content("{ \"racf\": \"testuser\", \"psswd\": \"1234\"}").accept(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.userName").value("testuser"))
                .andExpect(status().isOk())
                .andExpect(header().exists(ActionItpConstants.JWT_SESSION_TOKEN))
                .andReturn();
    }

    @Test
    void testAuthenticateBadRequest() throws Exception {
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + AgentAuthConstants.AGENT_AUTH_URL)
                .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
                .content("{ \"racf\": \"failagent\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(header().doesNotExist(ActionItpConstants.JWT_SESSION_TOKEN))
                .andReturn();
    }

    @Test
    void testAuthenticateUnauthorizedUser() throws Exception {
        agentAuthInputVO.setRacf("failagent");

        Mockito.when(agentAuthService.authenticate(agentAuthInputVO))
                .thenThrow(new AgentNotAuthenticatedException(AgentAuthConstants.USER_NOT_AUTHENTICATED));

        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + AgentAuthConstants.AGENT_AUTH_URL)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{ \"racf\": \"failagent\", \"psswd\": \"1234\"}")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.errors.1009").value("User not authenticated"))
                .andExpect(header().doesNotExist(ActionItpConstants.JWT_SESSION_TOKEN))
                .andReturn();
    }

    @Test
    void testAuthenticate_When_LDAPException_Is_Thrown() throws Exception {
        agentAuthInputVO.setRacf("testAgent");

        Mockito.when(agentAuthService.authenticate(agentAuthInputVO))
                .thenThrow(new LDAPException("Error: Authentication failed"));

        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + AgentAuthConstants.AGENT_AUTH_URL)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{ \"racf\": \"testAgent\", \"psswd\": \"1234\"}")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.errors.5005").value("LDAP Issues"))
                .andExpect(header().doesNotExist(ActionItpConstants.JWT_SESSION_TOKEN))
                .andReturn();
    }
}
