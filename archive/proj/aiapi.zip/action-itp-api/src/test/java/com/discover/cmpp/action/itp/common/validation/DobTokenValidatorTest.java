package com.discover.cmpp.action.itp.common.validation;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import javax.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DobTokenValidatorTest {
    private ConstraintValidatorContext cxt;
    private DobTokenValidator validator;

    @BeforeEach
    public void setUp() throws Exception {
        validator = new DobTokenValidator();
    }

    @Test
    void testDobToken_vaildDate() {
        assertTrue(validator.isValid("1995-09-08", cxt));
    }

    @Test
    void testDobToken_inVaildMonth() {
        assertFalse(validator.isValid("1995-13-08", cxt));
    }

    @Test
    void testDobToken_inVaildDay() {
        assertFalse(validator.isValid("1995-12-32", cxt));
    }

    @Test
    void testDobToken_inVaildFormat() {
        assertFalse(validator.isValid("1995/09/08", cxt));
    }
}
