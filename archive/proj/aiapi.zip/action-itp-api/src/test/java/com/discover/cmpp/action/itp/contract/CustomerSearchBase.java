package com.discover.cmpp.action.itp.contract;

import com.discover.cmpp.action.itp.cloak.CloakException;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ActionItpExceptionHandler;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.custlookup.CustLookUpController;
import com.discover.cmpp.action.itp.custlookup.CustLookUpException;
import com.discover.cmpp.action.itp.custlookup.CustLookUpService;
import com.discover.cmpp.action.itp.custlookup.model.CustomerPii;
import com.discover.cmpp.action.itp.custlookup.model.CustomerSearchRequest;
import com.discover.cmpp.action.itp.custlookup.model.CustomerSearchResponse;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import io.restassured.module.mockmvc.RestAssuredMockMvc;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.setup.StandaloneMockMvcBuilder;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
abstract class CustomerSearchBase {
    @InjectMocks
    private CustLookUpController controller;

    @Mock
    private CustLookUpService custLookUpService;

    @BeforeEach
    void setup() throws ActionItpException, CloakException, CustLookUpException {
        MockitoAnnotations.openMocks(this);

        when(custLookUpService.customerSearch("testRACF", getCustomerSearchRequest())).thenReturn(getCustomerSearchResponse());
        when(custLookUpService.customerSearch("testRACF", getCustomerSearchRequestWithPeiid())).thenReturn(getCustomerSearchResponse());
        when(custLookUpService.customerSearch("nullAgentID", getCustomerSearchRequest())).thenThrow(new ActionItpException(ValidationConstants.AGENT_ID_INVALID_EC));
        when(custLookUpService.customerSearch("testRACF500", getCustomerSearchRequest())).thenThrow(new NullPointerException());
        when(custLookUpService.customerSearch("invalidReq", getCustomerSearchRequestEmpty())).thenThrow(new CustLookUpException(ValidationConstants.ARG_NOT_VALID_EC));

        StandaloneMockMvcBuilder standaloneMockMvcBuilder = MockMvcBuilders.standaloneSetup(controller)
                .addPlaceholderValue("api.context-path", TestUtils.contextPath)
                .setControllerAdvice(new ActionItpExceptionHandler());
        RestAssuredMockMvc.standaloneSetup(standaloneMockMvcBuilder);
    }

    private CustomerSearchRequest getCustomerSearchRequest() {
        CustomerSearchRequest customerSearchRequest = new CustomerSearchRequest();
        customerSearchRequest.setDateOfBirth("05/04/2019");
        customerSearchRequest.setFirstName("ACTION");
        customerSearchRequest.setLastName("ITP");
        customerSearchRequest.setPeidOrSubscriberId(null);
        return customerSearchRequest;
    }

    private CustomerSearchRequest getCustomerSearchRequestEmpty() {
        CustomerSearchRequest customerSearchRequest = new CustomerSearchRequest();
        customerSearchRequest.setDateOfBirth("");
        customerSearchRequest.setFirstName("");
        customerSearchRequest.setLastName("");
        customerSearchRequest.setPeidOrSubscriberId(null);
        return customerSearchRequest;
    }

    private CustomerSearchRequest getCustomerSearchRequestWithPeiid() {
        CustomerSearchRequest customerSearchRequest = new CustomerSearchRequest();
        customerSearchRequest.setDateOfBirth("");
        customerSearchRequest.setFirstName("");
        customerSearchRequest.setLastName("");
        customerSearchRequest.setPeidOrSubscriberId("9090203091733124810");
        return customerSearchRequest;
    }

    private CustomerSearchResponse getCustomerSearchResponse() {
        CustomerSearchResponse customerSearchResponse = new CustomerSearchResponse();
        CustomerPii customerPii = new CustomerPii();
        customerPii.setFirstName("ACTION");
        customerPii.setLastName("ITP");
        customerPii.setPartyId("123456");
        customerPii.setSsn("1234");
        List<CustomerPii> customerPiiList = new ArrayList<>();
        customerPiiList.add(customerPii);
        customerSearchResponse.setCustomers(customerPiiList);
        return customerSearchResponse;
    }
}
