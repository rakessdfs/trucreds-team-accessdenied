package com.discover.cmpp.action.itp.accountcenter.model;

import com.discover.cmpp.action.itp.accountcenter.customer.profile.CustomerProfileConstants;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class UpdatePiiRequestTest {

    @Test
    @DisplayName("Validate phonetype field is equal cellphone")
    void updatePiiRequest_phoneTypeShouldBeCellphone() {
        UpdatePiiRequest updatePiiRequest = new UpdatePiiRequest();
        updatePiiRequest.setPhoneType(CustomerProfileConstants.CELLPHONE);
        assertThat(updatePiiRequest.getPhoneType()).isEqualTo(CustomerProfileConstants.CELLPHONE);
    }
}

