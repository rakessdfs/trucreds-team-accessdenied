package com.discover.cmpp.action.itp.contract;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

import com.discover.cmpp.action.itp.common.session.JwtActionItpUtil;
import org.hamcrest.beans.HasPropertyWithValue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.hamcrest.MockitoHamcrest;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.setup.StandaloneMockMvcBuilder;
import com.discover.cmpp.action.itp.authentication.ldap.AgentAuthConstants;
import com.discover.cmpp.action.itp.authentication.ldap.AgentAuthController;
import com.discover.cmpp.action.itp.authentication.ldap.AgentAuthExceptionHandler;
import com.discover.cmpp.action.itp.authentication.ldap.AgentAuthOutputVO;
import com.discover.cmpp.action.itp.authentication.ldap.AgentAuthService;
import com.discover.cmpp.action.itp.authentication.ldap.AgentNotAuthenticatedException;
import com.discover.cmpp.action.itp.test.utils.TestUtils;

import io.restassured.module.mockmvc.RestAssuredMockMvc;
import netscape.ldap.LDAPException;

@ExtendWith(SpringExtension.class)
public abstract class AuthenticationBase {

    @InjectMocks
    private AgentAuthController authController;

    @Mock
    private JwtActionItpUtil jwtActionItpUtil;

    @Mock
    private AgentAuthService authService;

    @BeforeEach
    public void setup() throws LDAPException, AgentNotAuthenticatedException {

        MockitoAnnotations.openMocks(this);
        lenient().when(jwtActionItpUtil.generateJwtToken(anyString())).thenReturn("dummyToken");

        lenient().when(authService.authenticate(
                MockitoHamcrest.argThat(
                        HasPropertyWithValue.hasProperty("racf", equalTo("testagent")))))
                .thenReturn(getAuthOutput());

        lenient().when(authService.authenticate(
                MockitoHamcrest.argThat(
                        HasPropertyWithValue.hasProperty("racf", equalTo("failagent")))))
                .thenThrow(new AgentNotAuthenticatedException(AgentAuthConstants.USER_NOT_AUTHENTICATED));

        lenient().when(authService.authenticate(
                MockitoHamcrest.argThat(
                        HasPropertyWithValue.hasProperty("racf", equalTo("erroragent")))))
                .thenThrow(new LDAPException());

        StandaloneMockMvcBuilder standaloneMockMvcBuilder =
                MockMvcBuilders.standaloneSetup(authController)
                        .addPlaceholderValue("api.context-path", TestUtils.contextPath)
                        .setControllerAdvice(new AgentAuthExceptionHandler());

        RestAssuredMockMvc.standaloneSetup(standaloneMockMvcBuilder);
    }

    private AgentAuthOutputVO getAuthOutput() {
        AgentAuthOutputVO response = new AgentAuthOutputVO();
        response.setEmail("testagent@test.com");
        response.setFullName("Test Agent");
        response.setUserName("testagent");
        return response;
    }
}
