package com.discover.cmpp.action.itp.config;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import springfox.documentation.spring.web.plugins.Docket;

import static org.junit.Assert.assertNotNull;

@ExtendWith(MockitoExtension.class)
class SwaggerConfigTest {
    @InjectMocks
    SwaggerConfig swaggerConfig;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void apiDocumentation() {
        Docket docket = swaggerConfig.itpServicingApiDocket();
        assertNotNull(docket);
    }
}
