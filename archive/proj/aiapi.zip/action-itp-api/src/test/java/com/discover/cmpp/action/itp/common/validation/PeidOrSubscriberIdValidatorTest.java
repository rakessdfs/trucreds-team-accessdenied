package com.discover.cmpp.action.itp.common.validation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import javax.validation.ConstraintValidatorContext;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@ExtendWith(MockitoExtension.class)
class PeidOrSubscriberIdValidatorTest {
    @Mock
    private PeidOrSubscriberId peidOrSubscriberId;
    private ConstraintValidatorContext cxt;
    private PeidOrSubscriberIdValidator validator;

    @BeforeEach
    public void setUp() throws Exception {
        validator = new PeidOrSubscriberIdValidator();
        validator.initialize(peidOrSubscriberId);
    }

    @Test
    void testPeid_Valid() {
        assertTrue(validator.isValid("9090203091733124810", cxt));
    }

    @Test
    void testSubscriberId_Valid() {
        assertTrue(validator.isValid("PDDB203091733124810", cxt));
    }

    @Test
    void testPeid_InValid() {
        assertFalse(validator.isValid("9191203091733124810", cxt));
        assertFalse(validator.isValid("90902030917", cxt));
        assertFalse(validator.isValid("9090ABC12334", cxt));
    }

    @Test
    void testSubscriberId_InValid() {
        assertFalse(validator.isValid("ABCD203091733124810", cxt));
        assertFalse(validator.isValid("PDDB203091", cxt));
        assertFalse(validator.isValid("7172203091733124810", cxt));
    }

    @Test
    void testFPeidOrSubscriberId_WhenNullableAndEmptyIsTrue() {
        Mockito.when(peidOrSubscriberId.empty()).thenReturn(true);
        Mockito.when(peidOrSubscriberId.nullable()).thenReturn(true);
        validator.initialize(peidOrSubscriberId);
        assertTrue(validator.isValid("", cxt));
        assertTrue(validator.isValid(null, cxt));
    }
}
