package com.discover.cmpp.action.itp.accountactivity;

import com.discover.cmpp.action.itp.common.AbstractIntegrationTest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import java.time.LocalDateTime;
import static org.junit.jupiter.api.Assertions.assertNotNull;


class AccountActivityRepositoryTest extends AbstractIntegrationTest {

    @Autowired
    private AccountActivityRepository accountActivityRepository;

    @Autowired
    private AccountActivityCodeRepository accountActivityCodeRepository;

    @Test
    @DisplayName("Should save account activity information")
    void save_whenInvoked_shouldSaveAccountActivityInformation() {
        AccountActivityCodeEntity codeEntity = AccountActivityCodeEntity.builder()
                .activityCode("account-act-repo")
                .activityDesc("desc")
                .category("category")
                .createTs(LocalDateTime.now())
                .updateTs(null)
                .build();
        assertNotNull(accountActivityCodeRepository.save(codeEntity));

        AccountActivityEntity entity = AccountActivityEntity.builder()
                .productEnrollmentId("someEnrollId")
                .activityCode(codeEntity)
                .previousData("previous")
                .newData("new")
                .operator("operator")
                .requestDate(LocalDateTime.now())
                .createTs(LocalDateTime.now())
                .updateTs(null)
                .build();
        assertNotNull(accountActivityRepository.save(entity));
    }

}
