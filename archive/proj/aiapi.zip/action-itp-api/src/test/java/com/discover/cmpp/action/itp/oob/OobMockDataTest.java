package com.discover.cmpp.action.itp.oob;

import com.discover.cmpp.action.itp.oob.oobmock.OobMockData;
import com.discover.internet.service.oob.vo.GetStatusInputVO;
import com.discover.internet.service.oob.vo.GetStatusOutputVO;
import com.discover.internet.service.oob.vo.GetUserHistoryInputVO;
import com.discover.internet.service.oob.vo.GetUserHistoryOutputVO;
import com.discover.internet.service.oob.vo.HeartBeatInputVO;
import com.discover.internet.service.oob.vo.HeartBeatOutputVO;
import com.discover.internet.service.oob.vo.SendCodeInputVO;
import com.discover.internet.service.oob.vo.SendCodeOutputVO;
import com.discover.internet.service.oob.vo.SetImpressionInputVO;
import com.discover.internet.service.oob.vo.SetImpressionOutputVO;
import com.discover.internet.service.oob.vo.UnlockUserInputVO;
import com.discover.internet.service.oob.vo.UnlockUserOutputVO;
import com.discover.internet.service.oob.vo.UserCancelInputVO;
import com.discover.internet.service.oob.vo.UserCancelOutputVO;
import com.discover.internet.service.oob.vo.ValidateCodeInputVO;
import com.discover.internet.service.oob.vo.ValidateCodeOutputVO;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.powermock.api.mockito.PowerMockito.mock;

@ExtendWith(SpringExtension.class)
class OobMockDataTest {
    
    @InjectMocks
    OobMockData mockData;

    @Test
    @DisplayName("Should return Send Code Output")
    void oobMockData_shouldReturnSendCodeOutput(){
        SendCodeInputVO inputVO = mock(SendCodeInputVO.class);
        SendCodeOutputVO expected = mockData.sendCode(inputVO);

        assertEquals(1, expected.getReturnStatus().getCode());
    }

    @Test
    @DisplayName("Should return Get Status Output")
    void oobMockData_shouldReturnGetStatusOutput(){
        GetStatusInputVO inputVO = mock(GetStatusInputVO.class);
        GetStatusOutputVO expected = mockData.getStatus(inputVO);

        assertEquals("activeCodeChannel", expected.getActiveCodeChannel());
        assertEquals("activeCodeChannelValue", expected.getActiveCodeChannelValue());
    }

    @Test
    @DisplayName("Should return Validate Code Output")
    void oobMockData_shouldReturnValidateCodeOutput(){
        ValidateCodeInputVO inputVO = mock(ValidateCodeInputVO.class);
        ValidateCodeOutputVO expected = mockData.validateCode(inputVO);

        assertEquals(1, expected.getReturnStatus().getCode());
    }

    @Test
    @DisplayName("Should return Unlock User Output")
    void oobMockData_shouldReturnUnlockUserOutput(){
        UnlockUserInputVO inputVO = mock(UnlockUserInputVO.class);
        UnlockUserOutputVO expected = mockData.unlockUser(inputVO);

        assertEquals(1, expected.getReturnStatus().getCode());
        assertEquals(1, expected.getReturnStatus().getCode());
        assertEquals(0, expected.getUserInfo().getFailedSubmissionCount());
        assertEquals(0, expected.getUserInfo().getGenerationCount());
        assertEquals("OK", expected.getUserInfo().getUserStatusCode());
    }

    @Test
    @DisplayName("Should return null")
    void oobMockData_getUserHistory_shouldReturnNull(){
        GetUserHistoryInputVO inputVO = mock(GetUserHistoryInputVO.class);
        GetUserHistoryOutputVO expected = mockData.getUserHistory(inputVO);
        assertNull(expected);
    }

    @Test
    @DisplayName("Should return null")
    void oobMockData_heartBeat_shouldReturnNull(){
        HeartBeatInputVO inputVO = mock(HeartBeatInputVO.class);
        HeartBeatOutputVO expected = mockData.heartBeat(inputVO);
        assertNull(expected);
    }

    @Test
    @DisplayName("Should return null")
    void oobMockData_setImpression_shouldReturnNull(){
        SetImpressionInputVO inputVO = mock(SetImpressionInputVO.class);
        SetImpressionOutputVO expected = mockData.setImpression(inputVO);
        assertNull(expected);
    }

    @Test
    @DisplayName("Should return null")
    void oobMockData_userCancel_shouldReturnNull(){
        UserCancelInputVO inputVO = mock(UserCancelInputVO.class);
        UserCancelOutputVO expected = mockData.userCancel(inputVO);
        assertNull(expected);
    }
}
