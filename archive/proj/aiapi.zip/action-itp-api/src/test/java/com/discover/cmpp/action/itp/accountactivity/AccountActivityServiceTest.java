package com.discover.cmpp.action.itp.accountactivity;

import com.discover.cmpp.action.itp.accountactivity.model.AccountActivityCodeRequest;
import com.discover.cmpp.action.itp.accountactivity.model.AccountActivityResponse;
import com.discover.cmpp.action.itp.accountactivity.model.ActivityToAnalyticsRequest;
import com.discover.cmpp.action.itp.accountactivity.model.ActivityToAnalyticsResponse;
import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ActionItpUtil;
import com.discover.cmpp.action.itp.custlookup.CdsService;
import com.discover.cmpp.action.itp.custlookup.CustLookUpException;
import com.discover.cmpp.action.itp.custlookup.model.cdstranslation.CdsTranslationAlternateIdResponse;
import com.discover.cmpp.action.itp.flux.publish.accountactivity.AccountActivityPublishServiceImpl;
import com.discover.cmpp.action.itp.flux.schema.AccountActivityPayload;
import com.discover.cmpp.action.itp.membership.ProductService;
import com.discover.cmpp.action.itp.membership.model.EnrollmentLookupResponse;
import com.discover.cmpp.action.itp.membership.model.MembershipEntity;
import com.discover.cmpp.action.itp.membership.model.MembershipInfo;
import com.discover.cmpp.action.itp.membership.model.MembershipPK;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.discover.cmpp.action.itp.accountactivity.AccountActivityConstants.ACTIVITY_CODE_CACHE_NAME;
import static com.discover.cmpp.action.itp.common.validation.ValidationConstants.FAILED_TO_GET_CODE_ENTITIES_EC;
import static com.discover.cmpp.action.itp.common.validation.ValidationConstants.NO_CODE_ENTITIES_EC;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AccountActivityServiceTest {

    @Mock
    AccountActivityRepository accountActivityRepository;

    @InjectMocks
    AccountActivityServiceImpl accountActivityService;

    @Mock
    AccountActivityPublishServiceImpl activityPublishService;

    @Mock
    CreateAccountActivityRepository createAccountActivityRepository;

    @Mock
    AccountActivityCodeRepository accountActivityCodeRepository;

    @Mock
    CacheManager cacheManager;

    @Mock
    CdsService cdsService;

    @Mock
    ProductService productService;

    @Mock
    ActionItpUtil itpUtil;

    @Mock
    CreateAccountActivityEntity createAccountActivityEntity;

    @Mock
    AccountActivityCodeEntity accountActivityCodeEntity;

    @Mock
    CsidReportingServiceImpl csidReportingService;

    private AccountActivityPayload accountActivityPayload;
    private AccountActivityCodeRequest accountActivityCodeRequest;

    @BeforeEach
    void init() {
        accountActivityPayload = new AccountActivityPayload();
        accountActivityPayload.setProductEnrollmentId("14578625");
        accountActivityPayload.setOperator("Test");
        accountActivityPayload.setRequestDate("2021-09-11 20:11:34");
        accountActivityPayload.setActivityCode("EUR");

        accountActivityCodeRequest = new AccountActivityCodeRequest();
        accountActivityCodeRequest.setActivityCode("AUR");
        accountActivityCodeRequest.setActivityDesc("CUSTMR ADDR CHGND VIA (PHONE/INTERNET)");
        accountActivityCodeRequest.setCategory("ITP Account Center");
    }

    @Test
    void test_createAccountActivity() throws AccountActivityException {
        when(createAccountActivityRepository.save(any())).thenReturn(createAccountActivityEntity);
        accountActivityService.createActivity(accountActivityPayload);

        ArgumentCaptor<CreateAccountActivityEntity> captor = ArgumentCaptor.forClass(CreateAccountActivityEntity.class);
        Mockito.verify(createAccountActivityRepository).save(captor.capture());
        CreateAccountActivityEntity createAccountActivityEntity = captor.getValue();
        assertThat(createAccountActivityEntity.getProductEnrollmentId()).isEqualTo("14578625");
        assertThat(createAccountActivityEntity.getOperator()).isEqualTo("Test");
        assertThat(createAccountActivityEntity.getRequestDate()).isEqualTo("2021-09-11T20:11:34");
        assertThat(createAccountActivityEntity.getActivityCode()).isEqualTo("EUR");
    }

    @Test
    void test_create_exception() {
        Mockito.doThrow(new DataIntegrityViolationException("Error occurred")).when(createAccountActivityRepository).save(any());
        assertThrows(AccountActivityException.class, () -> accountActivityService.createActivity(accountActivityPayload));
    }

    @Test
    void test_createAccountActivityCode() throws AccountActivityException {
        when(accountActivityCodeRepository.save(any())).thenReturn(accountActivityCodeEntity);
        when(cacheManager.getCache(any())).thenReturn(new ConcurrentMapCache(ACTIVITY_CODE_CACHE_NAME));
        accountActivityService.createAccountActivityCode(accountActivityCodeRequest);

        ArgumentCaptor<AccountActivityCodeEntity> captor = ArgumentCaptor.forClass(AccountActivityCodeEntity.class);
        Mockito.verify(accountActivityCodeRepository).save(captor.capture());
        AccountActivityCodeEntity accountActivityCodeEntity = captor.getValue();
        assertThat(accountActivityCodeEntity.getActivityCode()).isEqualTo("AUR");
        assertThat(accountActivityCodeEntity.getActivityDesc()).isEqualTo("CUSTMR ADDR CHGND VIA (PHONE/INTERNET)");
        assertThat(accountActivityCodeEntity.getCategory()).isEqualTo("ITP Account Center");
    }

    @Test
    void test_createAccountActivityCode_DbException() {
        Mockito.doThrow(new DataIntegrityViolationException("Error occurred"))
                .when(accountActivityCodeRepository).save(any());
        assertThrows(AccountActivityException.class, () ->
                accountActivityService.createAccountActivityCode(accountActivityCodeRequest));
    }

    @Test
    void test_createAccountActivityCode_CacheException() {
        when(accountActivityCodeRepository.save(any())).thenReturn(accountActivityCodeEntity);
        assertThrows(AccountActivityException.class, () ->
                accountActivityService.createAccountActivityCode(accountActivityCodeRequest));
    }

    @Test
    void test_create_DateParsingException() {
        accountActivityPayload.setRequestDate("2021-09-11");
        assertThrows(AccountActivityException.class, () -> accountActivityService.createActivity(accountActivityPayload));
    }

    @Test
    void test_fetchAccountActivityWithValidPeid() throws AccountActivityException {
        AccountActivityCodeEntity codeEntity = AccountActivityCodeEntity.builder()
                .activityCode("activity-service")
                .activityDesc("desc")
                .category("category")
                .createTs(LocalDateTime.now())
                .updateTs(null)
                .build();

        AccountActivityEntity activity = AccountActivityEntity.builder()
                .productEnrollmentId("123456")
                .activityCode(codeEntity)
                .previousData("previous")
                .newData("new")
                .operator("operator")
                .requestDate(LocalDateTime.now())
                .createTs(LocalDateTime.now())
                .updateTs(null)
                .build();

        List<AccountActivityEntity> activityList = new ArrayList<>();
        activityList.add(activity);

        Mockito.doReturn(activityList)
                .when(accountActivityRepository).findAllByProductEnrollmentIdOrderByRequestDateDesc(any());

        EnrollmentLookupResponse responseData = new EnrollmentLookupResponse();
        responseData.setProductEnrollmentId("123456789");
        responseData.setSubscriberId("123456789");
        ResponseEntity<EnrollmentLookupResponse> enrollmentLookupRsponse = new ResponseEntity<>(responseData, HttpStatus.OK);
        Mockito.doReturn(enrollmentLookupRsponse)
                .when(productService).getEnrollmentInfo(any(), any());

        List<ItpCsidAlertData> alertsList = new ArrayList<>();
        Mockito.doReturn(alertsList)
                .when(csidReportingService).getItpAlerts(any(), any());

        AccountActivityResponse response = accountActivityService.fetchAccountActivityByPeid("123456");
        assertNotNull(response);
    }

    @Test
    void test_fetchAccountActivityWithValidPeid_GetEnrollmentInfoFails_ThrowsException() {
        List<AccountActivityEntity> activityList = new ArrayList<>();

        Mockito.doReturn(activityList)
                .when(accountActivityRepository).findAllByProductEnrollmentIdOrderByRequestDateDesc(any());

        ResponseEntity<EnrollmentLookupResponse> enrollmentLookupRsponse = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        Mockito.doReturn(enrollmentLookupRsponse)
                .when(productService).getEnrollmentInfo(any(), any());

        assertThrows(AccountActivityException.class, () ->
                accountActivityService.fetchAccountActivityByPeid("123456"));
    }

    @Test
    void test_fetchAccountActivityWithValidPeid_NoItpAlerts_ThrowsException() {
        List<AccountActivityEntity> activityList = new ArrayList<>();

        Mockito.doReturn(activityList)
                .when(accountActivityRepository).findAllByProductEnrollmentIdOrderByRequestDateDesc(any());

        EnrollmentLookupResponse responseData = new EnrollmentLookupResponse();
        responseData.setProductEnrollmentId("123456789");
        responseData.setSubscriberId("123456789");
        ResponseEntity<EnrollmentLookupResponse> enrollmentLookupRsponse = new ResponseEntity<>(responseData, HttpStatus.OK);
        Mockito.doReturn(enrollmentLookupRsponse)
                .when(productService).getEnrollmentInfo(any(), any());

        List<ItpCsidAlertData> alertsList = new ArrayList<>();
        Mockito.doReturn(alertsList)
                .when(csidReportingService).getItpAlerts(any(), any());

        assertThrows(AccountActivityException.class, () ->
                accountActivityService.fetchAccountActivityByPeid("123456"));
    }

    @ParameterizedTest
    @NullSource    // pass a null value for one of the test runs
    @ValueSource(strings = {"invalidPEID", " "})
    void test_fetchAccountActivityWithInvalidPeid_blankPeid_nullPeid(String peid) {
        Mockito.doReturn(new ResponseEntity<EnrollmentLookupResponse>(HttpStatus.INTERNAL_SERVER_ERROR))
                .when(productService).getEnrollmentInfo(any(), any());

        assertThrows(AccountActivityException.class, () ->
                accountActivityService.fetchAccountActivityByPeid(peid));
    }

    @Test
    void test_fetchAccountActivityAndAlertsWithValidPeid() throws AccountActivityException {
        AccountActivityCodeEntity codeEntity = AccountActivityCodeEntity.builder()
                .activityCode("activity-service")
                .activityDesc("desc")
                .category("category")
                .createTs(LocalDateTime.now())
                .updateTs(null)
                .build();

        AccountActivityEntity activity = AccountActivityEntity.builder()
                .productEnrollmentId("123456")
                .activityCode(codeEntity)
                .previousData("previous")
                .newData("new")
                .operator("operator")
                .requestDate(LocalDateTime.now())
                .createTs(LocalDateTime.now())
                .updateTs(null)
                .build();

        List<AccountActivityEntity> activityList = new ArrayList<>();
        activityList.add(activity);

        Mockito.doReturn(activityList)
                .when(accountActivityRepository).findAllByProductEnrollmentIdOrderByRequestDateDesc(any());

        EnrollmentLookupResponse responseData = new EnrollmentLookupResponse();
        responseData.setProductEnrollmentId("123456789");
        responseData.setSubscriberId("123456789");
        ResponseEntity<EnrollmentLookupResponse> enrollmentLookupRsponse = new ResponseEntity<>(responseData, HttpStatus.OK);
        Mockito.doReturn(enrollmentLookupRsponse)
                .when(productService).getEnrollmentInfo(any(), any());

        List<ItpCsidAlertData> alertsList = new ArrayList<>();
        ItpCsidAlertData data = new ItpCsidAlertData();
        data.setCreateDate(Timestamp.valueOf("2021-02-01 00:00:00.0"));
        data.setEnrollmentId("1234567777");
        data.setEventSubject("Subj");
        alertsList.add(data);
        ItpCsidAlertData data1 = new ItpCsidAlertData();
        data1.setCreateDate(Timestamp.valueOf("2021-03-01 00:00:00.0"));
        data1.setEnrollmentId("1234567888");
        data1.setEventSubject("Subj");
        alertsList.add(data1);
        Mockito.doReturn(alertsList)
                .when(csidReportingService).getItpAlerts(any(), any());

        AccountActivityResponse response = accountActivityService.fetchAccountActivityByPeid("123456");
        assertNotNull(response);
        assertEquals("123456", response.getAccountActivityList().get(0).getProductEnrollmentId());
        assertEquals("1234567888", response.getAccountActivityList().get(1).getProductEnrollmentId());
        assertEquals("1234567777", response.getAccountActivityList().get(2).getProductEnrollmentId());
    }

    @Test
    void test_fetchAlertWithNullDesc_OnlyReturnsIfCreditSummary() throws AccountActivityException {
        List<AccountActivityEntity> activityList = new ArrayList<>();

        Mockito.doReturn(activityList)
                .when(accountActivityRepository).findAllByProductEnrollmentIdOrderByRequestDateDesc(any());

        EnrollmentLookupResponse responseData = new EnrollmentLookupResponse();
        responseData.setProductEnrollmentId("123456789");
        responseData.setSubscriberId("123456789");
        ResponseEntity<EnrollmentLookupResponse> enrollmentLookupRsponse = new ResponseEntity<>(responseData, HttpStatus.OK);
        Mockito.doReturn(enrollmentLookupRsponse)
                .when(productService).getEnrollmentInfo(any(), any());

        List<ItpCsidAlertData> alertsList = new ArrayList<>();
        ItpCsidAlertData data = new ItpCsidAlertData();
        data.setCreateDate(Timestamp.valueOf("2021-02-01 00:00:00.0"));
        data.setEnrollmentId("123456");
        data.setEventSubject(null);
        data.setFormCode("BTITPBACREDSUM");
        alertsList.add(data);
        ItpCsidAlertData nonCreditSumData = new ItpCsidAlertData();
        nonCreditSumData.setCreateDate(Timestamp.valueOf("2021-02-02 00:00:00.0"));
        nonCreditSumData.setEnrollmentId("123456");
        nonCreditSumData.setEventSubject(null);
        nonCreditSumData.setFormCode("NotCredSummary");
        alertsList.add(nonCreditSumData);
        Mockito.doReturn(alertsList)
                .when(csidReportingService).getItpAlerts(any(), any());

        AccountActivityResponse response = accountActivityService.fetchAccountActivityByPeid("123456");
        assertNotNull(response);
        // Check that for the alert with a null event desc, if the formcode confirms it's a credit summary,
        // then returns Monthly Credit Summary
        assertEquals("123456", response.getAccountActivityList().get(0).getProductEnrollmentId());
        assertEquals("Monthly Credit Summary", response.getAccountActivityList().get(0).getActivityDesc());
        // In edge case of null desc and not credit summary, exclude alert
        assertEquals(1, response.getAccountActivityList().size());
    }

    @Test
    void test_publishOldActivitiesValidCode() throws AccountActivityException, CustLookUpException, ActionItpException {
        ActivityToAnalyticsRequest request = ActivityToAnalyticsRequest.builder()
                .activityCodes("activity-service")
                .build();
        Mockito.when(activityPublishService.publishEvent(any())).thenReturn(true);
        List<AccountActivityCodeEntity> entityList = new ArrayList<>();
        AccountActivityCodeEntity activityCodeEntity = new AccountActivityCodeEntity();
        activityCodeEntity.setActivityCode("activity-service");
        activityCodeEntity.setActivityDesc("activity description");
        entityList.add(activityCodeEntity);
        Mockito.when(accountActivityCodeRepository.findAllByActivityCode(any())).thenReturn(entityList);
        List<AccountActivityEntity> activityEntityList = new ArrayList<>();
        AccountActivityEntity activityEntity = new AccountActivityEntity();
        activityEntity.setActivityCode(activityCodeEntity);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        activityEntity.setRequestDate(LocalDateTime.parse("2021-12-02 00:00", formatter));
        activityEntity.setOperator("Test");
        activityEntity.setNewData("new data");
        activityEntity.setPreviousData("previous data");
        activityEntityList.add(activityEntity);
        Mockito.when(accountActivityRepository.findAllByActivityCodeOrderByRequestDateDesc(any())).thenReturn(activityEntityList);
        List<CdsTranslationAlternateIdResponse> cdsTranslationList = new ArrayList<>();
        CdsTranslationAlternateIdResponse cdsResponse = new CdsTranslationAlternateIdResponse();
        cdsResponse.setPartyId("99987654321");
        cdsTranslationList.add(cdsResponse);
        ResponseEntity<List<CdsTranslationAlternateIdResponse>> listResponseEntity =
                new ResponseEntity<>(cdsTranslationList, HttpStatus.OK);
        Mockito.when(cdsService.getPartyId(any(), any())).thenReturn(listResponseEntity);
        MembershipInfo membershipInfo = new MembershipInfo();
        MembershipPK membershipPk = new MembershipPK();
        membershipPk.setMembershipId(BigDecimal.valueOf(123456789));
        MembershipEntity membershipEntity = new MembershipEntity();
        membershipEntity.setLevelNumber(9);
        membershipEntity.setProductTypeCode("ITF");
        membershipEntity.setMembershipPK(membershipPk);
        membershipInfo.setMembershipEntity(membershipEntity);
        ResponseEntity<MembershipInfo> membershipInfoResponseEntity = new ResponseEntity<>(membershipInfo, HttpStatus.OK);
        Mockito.when(productService
                .getMembershipByPartyId(any(), any(), any())).thenReturn(membershipInfoResponseEntity);
        Map<String, String> headerMap = new HashMap<>();
        Mockito.when(itpUtil.restClientCdsHeader(any())).thenReturn(headerMap);

        ActivityToAnalyticsResponse response = accountActivityService.publishActivitiesToAnalytics(request);
        Assert.assertEquals(1, response.getDatabaseActivitiesCount());
        Assert.assertEquals(1, response.getPublishedActivitiesCount());
        // Validate that activityPublishService.publishEvent is called
        Mockito.verify(activityPublishService, Mockito.times(1)).publishEvent(Mockito.any());
    }

    @Test
    void test_publishOldActivitiesValidCodeITB() throws AccountActivityException, CustLookUpException, ActionItpException {
        ActivityToAnalyticsRequest request = ActivityToAnalyticsRequest.builder()
                .activityCodes("activity-service")
                .build();
        Mockito.when(activityPublishService.publishEvent(any())).thenReturn(true);
        List<AccountActivityCodeEntity> entityList = new ArrayList<>();
        AccountActivityCodeEntity activityCodeEntity = new AccountActivityCodeEntity();
        activityCodeEntity.setActivityCode("activity-service");
        activityCodeEntity.setActivityDesc("activity description");
        entityList.add(activityCodeEntity);
        Mockito.when(accountActivityCodeRepository.findAllByActivityCode(any())).thenReturn(entityList);
        List<AccountActivityEntity> activityEntityList = new ArrayList<>();
        AccountActivityEntity activityEntity = new AccountActivityEntity();
        activityEntity.setActivityCode(activityCodeEntity);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        activityEntity.setRequestDate(LocalDateTime.parse("2021-12-02 00:00", formatter));
        activityEntity.setOperator("Test");
        activityEntity.setNewData("new data");
        activityEntity.setPreviousData("previous data");
        activityEntityList.add(activityEntity);
        Mockito.when(accountActivityRepository.findAllByActivityCodeOrderByRequestDateDesc(any())).thenReturn(activityEntityList);
        List<CdsTranslationAlternateIdResponse> cdsTranslationList = new ArrayList<>();
        CdsTranslationAlternateIdResponse cdsResponse = new CdsTranslationAlternateIdResponse();
        cdsResponse.setPartyId("99987654321");
        cdsTranslationList.add(cdsResponse);
        ResponseEntity<List<CdsTranslationAlternateIdResponse>> listResponseEntity =
                new ResponseEntity<>(cdsTranslationList, HttpStatus.OK);
        Mockito.when(cdsService.getPartyId(any(), any())).thenReturn(listResponseEntity);
        MembershipInfo membershipInfo = new MembershipInfo();
        MembershipPK membershipPk = new MembershipPK();
        membershipPk.setMembershipId(BigDecimal.valueOf(123456789));
        MembershipEntity membershipEntity = new MembershipEntity();
        membershipEntity.setLevelNumber(9);
        membershipEntity.setProductTypeCode("ITF");
        membershipEntity.setMembershipPK(membershipPk);
        membershipInfo.setMembershipEntity(membershipEntity);
        ResponseEntity<MembershipInfo> membershipInfoResponseEntity = new ResponseEntity<>(membershipInfo, HttpStatus.OK);
        Mockito.when(productService
                .getMembershipByPartyId(any(), any(), Mockito.eq(ActionItpConstants.ITF_PRODUCT_TYPE_CODE))).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        Mockito.when(productService
                .getMembershipByPartyId(any(), any(), Mockito.eq(ActionItpConstants.ITB_PRODUCT_TYPE_CODE))).thenReturn(membershipInfoResponseEntity);
        Map<String, String> headerMap = new HashMap<>();
        Mockito.when(itpUtil.restClientCdsHeader(any())).thenReturn(headerMap);

        ActivityToAnalyticsResponse response = accountActivityService.publishActivitiesToAnalytics(request);
        Assert.assertEquals(1, response.getDatabaseActivitiesCount());
        Assert.assertEquals(1, response.getPublishedActivitiesCount());
        // Validate that activityPublishService.publishEvent is called
        Mockito.verify(activityPublishService, Mockito.times(1)).publishEvent(Mockito.any());
    }

    @Test
    void test_publishOldActivitiesValidCodeNoMembershipInfo() throws AccountActivityException, CustLookUpException, ActionItpException {
        ActivityToAnalyticsRequest request = ActivityToAnalyticsRequest.builder()
                .activityCodes("activity-service")
                .build();

        List<AccountActivityCodeEntity> entityList = new ArrayList<>();
        AccountActivityCodeEntity activityCodeEntity = new AccountActivityCodeEntity();
        activityCodeEntity.setActivityCode("activity-service");
        activityCodeEntity.setActivityDesc("activity description");
        entityList.add(activityCodeEntity);
        Mockito.when(accountActivityCodeRepository.findAllByActivityCode(any())).thenReturn(entityList);
        List<AccountActivityEntity> activityEntityList = new ArrayList<>();
        AccountActivityEntity activityEntity = new AccountActivityEntity();
        activityEntity.setActivityCode(activityCodeEntity);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        activityEntity.setRequestDate(LocalDateTime.parse("2021-12-02 00:00", formatter));
        activityEntity.setOperator("Test");
        activityEntity.setNewData("new data");
        activityEntity.setPreviousData("previous data");
        activityEntityList.add(activityEntity);
        Mockito.when(accountActivityRepository.findAllByActivityCodeOrderByRequestDateDesc(any())).thenReturn(activityEntityList);
        List<CdsTranslationAlternateIdResponse> cdsTranslationList = new ArrayList<>();
        CdsTranslationAlternateIdResponse cdsResponse = new CdsTranslationAlternateIdResponse();
        cdsResponse.setPartyId("99987654321");
        cdsTranslationList.add(cdsResponse);
        ResponseEntity<List<CdsTranslationAlternateIdResponse>> listResponseEntity =
                new ResponseEntity<>(cdsTranslationList, HttpStatus.OK);
        Mockito.when(cdsService.getPartyId(any(), any())).thenReturn(listResponseEntity);
        MembershipInfo membershipInfo = new MembershipInfo();
        MembershipPK membershipPk = new MembershipPK();
        membershipPk.setMembershipId(BigDecimal.valueOf(123456789));
        MembershipEntity membershipEntity = new MembershipEntity();
        membershipEntity.setLevelNumber(9);
        membershipEntity.setProductTypeCode("ITF");
        membershipEntity.setMembershipPK(membershipPk);
        membershipInfo.setMembershipEntity(membershipEntity);
        ResponseEntity<MembershipInfo> membershipInfoResponseEntity = new ResponseEntity<>(membershipInfo, HttpStatus.OK);
        Mockito.when(productService
                .getMembershipByPartyId(any(), any(), Mockito.eq(ActionItpConstants.ITF_PRODUCT_TYPE_CODE))).thenReturn(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));

        ActivityToAnalyticsResponse response = accountActivityService.publishActivitiesToAnalytics(request);
        Assert.assertEquals(1, response.getDatabaseActivitiesCount());
        Assert.assertEquals(0, response.getPublishedActivitiesCount());
        // Validate that activityPublishService.publishEvent is not called
        Mockito.verify(activityPublishService, Mockito.times(0)).publishEvent(Mockito.any());
    }

    @Test
    void test_publishOldActivitiesValidCodeNoPartyId() throws AccountActivityException, CustLookUpException, ActionItpException {
        ActivityToAnalyticsRequest request = ActivityToAnalyticsRequest.builder()
                .activityCodes("activity-service")
                .build();
        List<AccountActivityCodeEntity> entityList = new ArrayList<>();
        AccountActivityCodeEntity activityCodeEntity = new AccountActivityCodeEntity();
        activityCodeEntity.setActivityCode("activity-service");
        activityCodeEntity.setActivityDesc("activity description");
        entityList.add(activityCodeEntity);
        Mockito.when(accountActivityCodeRepository.findAllByActivityCode(any())).thenReturn(entityList);
        List<AccountActivityEntity> activityEntityList = new ArrayList<>();
        AccountActivityEntity activityEntity = new AccountActivityEntity();
        activityEntity.setActivityCode(activityCodeEntity);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        activityEntity.setRequestDate(LocalDateTime.parse("2021-12-02 00:00", formatter));
        activityEntity.setOperator("Test");
        activityEntity.setNewData("new data");
        activityEntity.setPreviousData("previous data");
        activityEntityList.add(activityEntity);
        Mockito.when(accountActivityRepository.findAllByActivityCodeOrderByRequestDateDesc(any())).thenReturn(activityEntityList);
        ResponseEntity<List<CdsTranslationAlternateIdResponse>> listResponseEntity =
                new ResponseEntity<>(HttpStatus.OK);
        Mockito.when(cdsService.getPartyId(any(), any())).thenReturn(listResponseEntity);
        Map<String, String> headerMap = new HashMap<>();
        Mockito.when(itpUtil.restClientCdsHeader(any())).thenReturn(headerMap);

        ActivityToAnalyticsResponse response = accountActivityService.publishActivitiesToAnalytics(request);
        Assert.assertEquals(1, response.getDatabaseActivitiesCount());
        Assert.assertEquals(0, response.getPublishedActivitiesCount());
        // Validate that activityPublishService.publishEvent is not called
        Mockito.verify(activityPublishService, Mockito.times(0)).publishEvent(Mockito.any());
    }

    @Test
    void test_publishOldActivitiesValidCodeNoActivities() throws AccountActivityException, CustLookUpException, ActionItpException {
        ActivityToAnalyticsRequest request = ActivityToAnalyticsRequest.builder()
                .activityCodes("activity-service")
                .build();
        List<AccountActivityCodeEntity> entityList = new ArrayList<>();
        AccountActivityCodeEntity activityCodeEntity = new AccountActivityCodeEntity();
        activityCodeEntity.setActivityCode("activity-service");
        activityCodeEntity.setActivityDesc("activity description");
        entityList.add(activityCodeEntity);
        Mockito.when(accountActivityCodeRepository.findAllByActivityCode(any())).thenReturn(entityList);
        List<AccountActivityEntity> activityEntityList = new ArrayList<>();
        Mockito.when(accountActivityRepository.findAllByActivityCodeOrderByRequestDateDesc(any())).thenReturn(activityEntityList);

        assertThrows(AccountActivityException.class, () ->
                accountActivityService.publishActivitiesToAnalytics(request));
    }

    @Test
    void test_publishOldActivitiesMultipleValidCodes() throws AccountActivityException, CustLookUpException, ActionItpException {
        ActivityToAnalyticsRequest request = ActivityToAnalyticsRequest.builder()
                .activityCodes("activity-service,activity-code")
                .build();
        Mockito.when(activityPublishService.publishEvent(any())).thenReturn(true);
        List<AccountActivityCodeEntity> entityList = new ArrayList<>();
        AccountActivityCodeEntity activityCodeEntity = new AccountActivityCodeEntity();
        activityCodeEntity.setActivityCode("activity-service");
        activityCodeEntity.setActivityDesc("activity description");
        entityList.add(activityCodeEntity);
        Mockito.when(accountActivityCodeRepository.findAllByActivityCode(any())).thenReturn(entityList);
        List<AccountActivityEntity> activityEntityList = new ArrayList<>();
        AccountActivityEntity activityEntity = new AccountActivityEntity();
        activityEntity.setActivityCode(activityCodeEntity);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        activityEntity.setRequestDate(LocalDateTime.parse("2021-12-02 00:00:00", formatter));
        activityEntity.setOperator("Test");
        activityEntity.setNewData("new data");
        activityEntity.setPreviousData("previous data");
        activityEntityList.add(activityEntity);
        Mockito.when(accountActivityRepository.findAllByActivityCodeOrderByRequestDateDesc(any())).thenReturn(activityEntityList);
        List<CdsTranslationAlternateIdResponse> cdsTranslationList = new ArrayList<>();
        CdsTranslationAlternateIdResponse cdsResponse = new CdsTranslationAlternateIdResponse();
        cdsResponse.setPartyId("99987654321");
        cdsTranslationList.add(cdsResponse);
        ResponseEntity<List<CdsTranslationAlternateIdResponse>> listResponseEntity =
                new ResponseEntity<>(cdsTranslationList, HttpStatus.OK);
        Mockito.when(cdsService.getPartyId(any(), any())).thenReturn(listResponseEntity);
        MembershipInfo membershipInfo = new MembershipInfo();
        MembershipPK membershipPk = new MembershipPK();
        membershipPk.setMembershipId(BigDecimal.valueOf(123456789));
        MembershipEntity membershipEntity = new MembershipEntity();
        membershipEntity.setLevelNumber(9);
        membershipEntity.setProductTypeCode("ITF");
        membershipEntity.setMembershipPK(membershipPk);
        membershipInfo.setMembershipEntity(membershipEntity);
        ResponseEntity<MembershipInfo> membershipInfoResponseEntity = new ResponseEntity<>(membershipInfo, HttpStatus.OK);
        Mockito.when(productService
                .getMembershipByPartyId(any(), any(), any())).thenReturn(membershipInfoResponseEntity);
        Map<String, String> headerMap = new HashMap<>();
        Mockito.when(itpUtil.restClientCdsHeader(any())).thenReturn(headerMap);

        ActivityToAnalyticsResponse response = accountActivityService.publishActivitiesToAnalytics(request);
        Assert.assertEquals(2, response.getDatabaseActivitiesCount());
        Assert.assertEquals(2, response.getPublishedActivitiesCount());
        // Validate that activityPublishService.publishEvent is called
        Mockito.verify(activityPublishService, Mockito.times(2)).publishEvent(Mockito.any());
    }

    @Test
    void test_publishOldActivitiesInvalidCode() throws AccountActivityException {
        ActivityToAnalyticsRequest request = ActivityToAnalyticsRequest.builder()
                .activityCodes("invalidcode")
                .build();
        List<AccountActivityCodeEntity> entityList = new ArrayList<>();
        Mockito.when(accountActivityCodeRepository.findAllByActivityCode(any())).thenReturn(entityList);
        assertThrows(AccountActivityException.class, () ->
                accountActivityService.publishActivitiesToAnalytics(request));
    }

    @Test
    void test_publishOldActivitiesNoCode() throws AccountActivityException {
        ActivityToAnalyticsRequest request = ActivityToAnalyticsRequest.builder()
                .activityCodes("")
                .build();

        assertThrows(AccountActivityException.class, () ->
                accountActivityService.publishActivitiesToAnalytics(request));
    }

    @Test
    void test_publishOldActivitiesInvalidStartDate() throws AccountActivityException {
        ActivityToAnalyticsRequest request = ActivityToAnalyticsRequest.builder()
                .activityCodes("TST")
                .startDate("2021-10-19")
                .endDate("2021-11-19")
                .build();
        List<AccountActivityCodeEntity> entityList = new ArrayList<>();
        AccountActivityCodeEntity activityCodeEntity = new AccountActivityCodeEntity();
        activityCodeEntity.setActivityCode("activity-service");
        activityCodeEntity.setActivityDesc("activity description");
        entityList.add(activityCodeEntity);
        Mockito.when(accountActivityCodeRepository.findAllByActivityCode(any())).thenReturn(entityList);
        assertThrows(AccountActivityException.class, () ->
                accountActivityService.publishActivitiesToAnalytics(request));
    }

    @Test
    void test_publishOldActivitiesValidCodeAndDate() throws AccountActivityException, CustLookUpException, ActionItpException {
        ActivityToAnalyticsRequest request = ActivityToAnalyticsRequest.builder()
                .activityCodes("activity-service")
                .startDate("2021-11-02 00:00:00")
                .endDate("2021-12-02 00:00:00")
                .build();
        Mockito.when(activityPublishService.publishEvent(any())).thenReturn(true);
        List<AccountActivityCodeEntity> entityList = new ArrayList<>();
        AccountActivityCodeEntity activityCodeEntity = new AccountActivityCodeEntity();
        activityCodeEntity.setActivityCode("activity-service");
        activityCodeEntity.setActivityDesc("activity description");
        entityList.add(activityCodeEntity);
        Mockito.when(accountActivityCodeRepository.findAllByActivityCode(any())).thenReturn(entityList);
        List<AccountActivityEntity> activityEntityList = new ArrayList<>();
        AccountActivityEntity activityEntity = new AccountActivityEntity();
        activityEntity.setActivityCode(activityCodeEntity);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        activityEntity.setRequestDate(LocalDateTime.parse("2021-12-02 00:00:00", formatter));
        activityEntity.setOperator("Test");
        activityEntity.setNewData("new data");
        activityEntity.setPreviousData("previous data");
        activityEntityList.add(activityEntity);
        Mockito.when(accountActivityRepository.findAllByActivityCodeAndRequestDateBetweenOrderByRequestDateDesc(any(), any(), any())).thenReturn(activityEntityList);
        List<CdsTranslationAlternateIdResponse> cdsTranslationList = new ArrayList<>();
        CdsTranslationAlternateIdResponse cdsResponse = new CdsTranslationAlternateIdResponse();
        cdsResponse.setPartyId("99987654321");
        cdsTranslationList.add(cdsResponse);
        ResponseEntity<List<CdsTranslationAlternateIdResponse>> listResponseEntity =
                new ResponseEntity<>(cdsTranslationList, HttpStatus.OK);
        Mockito.when(cdsService.getPartyId(any(), any())).thenReturn(listResponseEntity);
        MembershipInfo membershipInfo = new MembershipInfo();
        MembershipPK membershipPk = new MembershipPK();
        membershipPk.setMembershipId(BigDecimal.valueOf(123456789));
        MembershipEntity membershipEntity = new MembershipEntity();
        membershipEntity.setLevelNumber(9);
        membershipEntity.setProductTypeCode("ITF");
        membershipEntity.setMembershipPK(membershipPk);
        membershipInfo.setMembershipEntity(membershipEntity);
        ResponseEntity<MembershipInfo> membershipInfoResponseEntity = new ResponseEntity<>(membershipInfo, HttpStatus.OK);
        Mockito.when(productService
                .getMembershipByPartyId(any(), any(), any())).thenReturn(membershipInfoResponseEntity);
        Map<String, String> headerMap = new HashMap<>();
        Mockito.when(itpUtil.restClientCdsHeader(any())).thenReturn(headerMap);

        ActivityToAnalyticsResponse response = accountActivityService.publishActivitiesToAnalytics(request);
        Assert.assertEquals(1, response.getDatabaseActivitiesCount());
        Assert.assertEquals(1, response.getPublishedActivitiesCount());
        // Validate that activityPublishService.publishEvent is called
        Mockito.verify(activityPublishService, Mockito.times(1)).publishEvent(Mockito.any());
    }

    @Test
    void test_publishOldActivitiesValidCodeAndDateNoAcitivities() throws AccountActivityException, CustLookUpException, ActionItpException {
        ActivityToAnalyticsRequest request = ActivityToAnalyticsRequest.builder()
                .activityCodes("activity-service")
                .startDate("2021-11-02 00:00:00")
                .endDate("2021-12-02 00:00:00")
                .build();
        List<AccountActivityCodeEntity> entityList = new ArrayList<>();
        AccountActivityCodeEntity activityCodeEntity = new AccountActivityCodeEntity();
        activityCodeEntity.setActivityCode("activity-service");
        activityCodeEntity.setActivityDesc("activity description");
        entityList.add(activityCodeEntity);
        Mockito.when(accountActivityCodeRepository.findAllByActivityCode(any())).thenReturn(entityList);
        List<AccountActivityEntity> activityEntityList = new ArrayList<>();
        Mockito.when(accountActivityRepository.findAllByActivityCodeAndRequestDateBetweenOrderByRequestDateDesc(any(), any(), any())).thenReturn(activityEntityList);

        assertThrows(AccountActivityException.class, () ->
                accountActivityService.publishActivitiesToAnalytics(request));
    }

    @Test
    void test_publishOldActivitiesValidCodePublishFails() throws AccountActivityException, CustLookUpException, ActionItpException {
        ActivityToAnalyticsRequest request = ActivityToAnalyticsRequest.builder()
                .activityCodes("activity-service")
                .build();
        Mockito.when(activityPublishService.publishEvent(any())).thenReturn(false);
        List<AccountActivityCodeEntity> entityList = new ArrayList<>();
        AccountActivityCodeEntity activityCodeEntity = new AccountActivityCodeEntity();
        activityCodeEntity.setActivityCode("activity-service");
        activityCodeEntity.setActivityDesc("activity description");
        entityList.add(activityCodeEntity);
        Mockito.when(accountActivityCodeRepository.findAllByActivityCode(any())).thenReturn(entityList);
        List<AccountActivityEntity> activityEntityList = new ArrayList<>();
        AccountActivityEntity activityEntity = new AccountActivityEntity();
        activityEntity.setActivityCode(activityCodeEntity);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        activityEntity.setRequestDate(LocalDateTime.parse("2021-12-02 00:00", formatter));
        activityEntity.setOperator("Test");
        activityEntity.setNewData("new data");
        activityEntity.setPreviousData("previous data");
        activityEntityList.add(activityEntity);
        Mockito.when(accountActivityRepository.findAllByActivityCodeOrderByRequestDateDesc(any())).thenReturn(activityEntityList);
        List<CdsTranslationAlternateIdResponse> cdsTranslationList = new ArrayList<>();
        CdsTranslationAlternateIdResponse cdsResponse = new CdsTranslationAlternateIdResponse();
        cdsResponse.setPartyId("99987654321");
        cdsTranslationList.add(cdsResponse);
        ResponseEntity<List<CdsTranslationAlternateIdResponse>> listResponseEntity =
                new ResponseEntity<>(cdsTranslationList, HttpStatus.OK);
        Mockito.when(cdsService.getPartyId(any(), any())).thenReturn(listResponseEntity);
        MembershipInfo membershipInfo = new MembershipInfo();
        MembershipPK membershipPk = new MembershipPK();
        membershipPk.setMembershipId(BigDecimal.valueOf(123456789));
        MembershipEntity membershipEntity = new MembershipEntity();
        membershipEntity.setLevelNumber(9);
        membershipEntity.setProductTypeCode("ITF");
        membershipEntity.setMembershipPK(membershipPk);
        membershipInfo.setMembershipEntity(membershipEntity);
        ResponseEntity<MembershipInfo> membershipInfoResponseEntity = new ResponseEntity<>(membershipInfo, HttpStatus.OK);
        Mockito.when(productService
                .getMembershipByPartyId(any(), any(), any())).thenReturn(membershipInfoResponseEntity);
        Map<String, String> headerMap = new HashMap<>();
        Mockito.when(itpUtil.restClientCdsHeader(any())).thenReturn(headerMap);

        ActivityToAnalyticsResponse response = accountActivityService.publishActivitiesToAnalytics(request);
        Assert.assertEquals(1, response.getDatabaseActivitiesCount());
        Assert.assertEquals(0, response.getPublishedActivitiesCount());
        // Validate that activityPublishService.publishEvent is called
        Mockito.verify(activityPublishService, Mockito.times(1)).publishEvent(Mockito.any());
    }

    @Test
    void test_fetchAccountActivity_byCode_success() throws AccountActivityException, ActionItpException {
        List<AccountActivityCodeEntity> entityList = new ArrayList<>();
        AccountActivityCodeEntity activityCodeEntity = new AccountActivityCodeEntity();
        activityCodeEntity.setActivityCode("code");
        String expectedDesc = "activity description";
        activityCodeEntity.setActivityDesc(expectedDesc);
        entityList.add(activityCodeEntity);
        Mockito.when(accountActivityCodeRepository.findAllByActivityCode(any())).thenReturn(entityList);

        List<AccountActivityCodeEntity> response = accountActivityService.fetchAccountActivityCodes("code",
                null);
        Assert.assertEquals(1, response.size());
        Assert.assertEquals(expectedDesc, response.get(0).getActivityDesc());
    }

    @Test
    void test_fetchAccountActivity_byCategory_success() throws AccountActivityException, ActionItpException {
        List<AccountActivityCodeEntity> entityList = new ArrayList<>();
        AccountActivityCodeEntity activityCodeEntity = new AccountActivityCodeEntity();
        activityCodeEntity.setActivityCode("c1");
        activityCodeEntity.setCategory("testCat");
        activityCodeEntity.setActivityDesc("desc1");
        AccountActivityCodeEntity activityCodeEntity2 = new AccountActivityCodeEntity();
        activityCodeEntity2.setActivityCode("c2");
        activityCodeEntity2.setCategory("testCat");
        activityCodeEntity2.setActivityDesc("desc2");
        entityList.add(activityCodeEntity);
        entityList.add(activityCodeEntity2);
        Mockito.when(accountActivityCodeRepository.findAllByCategory(any())).thenReturn(entityList);

        List<AccountActivityCodeEntity> response = accountActivityService.fetchAccountActivityCodes(null,
                "testCat");
        Assert.assertEquals(2, response.size());
    }

    @Test
    void test_fetchAccountActivity_noParameters_success() throws AccountActivityException, ActionItpException {
        List<AccountActivityCodeEntity> entityList = new ArrayList<>();
        AccountActivityCodeEntity activityCodeEntity = new AccountActivityCodeEntity();
        activityCodeEntity.setActivityCode("c1");
        activityCodeEntity.setCategory("cat1");
        activityCodeEntity.setActivityDesc("desc1");
        AccountActivityCodeEntity activityCodeEntity2 = new AccountActivityCodeEntity();
        activityCodeEntity2.setActivityCode("c2");
        activityCodeEntity2.setCategory("cat2");
        activityCodeEntity2.setActivityDesc("desc2");
        entityList.add(activityCodeEntity);
        entityList.add(activityCodeEntity2);
        Mockito.when(accountActivityCodeRepository.findAll()).thenReturn(entityList);

        List<AccountActivityCodeEntity> response = accountActivityService.fetchAccountActivityCodes(null,
                null);
        Assert.assertEquals(2, response.size());
    }

    @Test
    void test_fetchAccountActivity_codePrioritizedOverCategory_success() throws AccountActivityException, ActionItpException {
        List<AccountActivityCodeEntity> entityList = new ArrayList<>();
        AccountActivityCodeEntity activityCodeEntity = new AccountActivityCodeEntity();
        activityCodeEntity.setActivityCode("c1");
        activityCodeEntity.setCategory("testCat");
        activityCodeEntity.setActivityDesc("desc1");
        entityList.add(activityCodeEntity);
        Mockito.when(accountActivityCodeRepository.findAllByActivityCode(any())).thenReturn(entityList);

        List<AccountActivityCodeEntity> response = accountActivityService.fetchAccountActivityCodes("c1",
                "testCat");
        Assert.assertEquals(1, response.size());
    }

    @Test
    void test_fetchAccountActivity_byCode_exception() throws ActionItpException {
        List<AccountActivityCodeEntity> entityList = new ArrayList<>();
        Mockito.when(accountActivityCodeRepository.findAllByActivityCode(any())).thenReturn(entityList);

        AccountActivityException ex = assertThrows(AccountActivityException.class, () -> accountActivityService
                .fetchAccountActivityCodes("notInDb", null));
        assertTrue(ex.getMessage().contains(NO_CODE_ENTITIES_EC));
    }

    @Test
    void test_fetchAccountActivity_byCategory_emptyResult_exception() throws ActionItpException {
        List<AccountActivityCodeEntity> entityList = new ArrayList<>();
        when(accountActivityCodeRepository.findAllByCategory(any())).thenReturn(entityList);

        AccountActivityException ex = assertThrows(AccountActivityException.class, () -> accountActivityService
                .fetchAccountActivityCodes(null, "notInDb"));
        assertTrue(ex.getMessage().contains(NO_CODE_ENTITIES_EC));
    }

    @Test
    void test_fetchAccountActivity_byCategory_databaseError_exception() throws ActionItpException {
        when(accountActivityCodeRepository.findAllByCategory(any())).thenThrow(RuntimeException.class);

        AccountActivityException ex = assertThrows(AccountActivityException.class, () -> accountActivityService
                .fetchAccountActivityCodes(null, "notInDb"));
        assertTrue(ex.getMessage().contains(FAILED_TO_GET_CODE_ENTITIES_EC));
    }
}
