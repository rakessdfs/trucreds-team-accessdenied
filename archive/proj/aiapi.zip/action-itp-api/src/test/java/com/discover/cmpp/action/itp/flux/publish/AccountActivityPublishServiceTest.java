package com.discover.cmpp.action.itp.flux.publish;

import com.discover.cmpp.action.itp.common.ActionItpUtil;
import com.discover.cmpp.action.itp.flux.FluxException;
import com.discover.cmpp.action.itp.flux.publish.accountactivity.AccountActivityPublishServiceImpl;
import com.discover.cmpp.action.itp.flux.schema.AnalyticsActivityMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.discover.cmpp.action.itp.common.ActionItpConstants.ITP_PRODUCT_TYPE_CODE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class AccountActivityPublishServiceTest {
    
    @Mock
    ActionItpUtil actionItpUtil;
    
    @Mock
    FluxPublishFeignClient fluxPublishFeignClient;
    
    @InjectMocks
    private AccountActivityPublishServiceImpl activityPublishService;
    
    private FluxPublishResponse fluxPublishResponse;
    
    private AnalyticsActivityMessage message;
    
    @BeforeEach
    public void init(){
        fluxPublishResponse = mock(FluxPublishResponse.class);
        message = AnalyticsActivityMessage.builder()
                .activityCode(ITP_PRODUCT_TYPE_CODE)
                .activityDescription("")
                .productEnrollmentId("9090343434343434")
                .customerType("Test")
                .customerLevel(9)
                .membershipNumber("9090343434343434")
                .newData("")
                .operator("agent1")
                .previousData("")
                .productType("")
                .requestDate("")
                .build();
    }
    
    @Test
    void test_PublishEvent_Successful(){
        when(fluxPublishFeignClient.publishAnalyticsActivityEvent(anyMap(),any())).thenReturn(fluxPublishResponse);
        activityPublishService.publishEvent(message);
        ArgumentCaptor<AnalyticsActivityMessage> captor = ArgumentCaptor.forClass(AnalyticsActivityMessage.class);
        Mockito.verify(fluxPublishFeignClient).publishAnalyticsActivityEvent(anyMap(), captor.capture());
        AnalyticsActivityMessage actualRequest = captor.getValue();
        assertThat(actualRequest.getProductEnrollmentId()).isEqualTo(message.getProductEnrollmentId());
        assertThat(actualRequest.getOperator()).isEqualTo(message.getOperator());
        assertThat(actualRequest.getCustomerLevel()).isEqualTo(message.getCustomerLevel());
        assertThat(actualRequest.getCustomerType()).isEqualTo(message.getCustomerType());
        assertThat(actualRequest.getProductType()).isEqualTo(message.getProductType());
    }

    @Test
    void test_PublishEvent_Throws_Exception(){
        Mockito.doThrow(new FluxException("Error publishing message"))
                .when(fluxPublishFeignClient).publishAnalyticsActivityEvent(anyMap(), any());
        activityPublishService.publishEvent(message);
        Mockito.verify(fluxPublishFeignClient, Mockito.times(1)).publishAnalyticsActivityEvent(Mockito.any(), any());
    }
}
