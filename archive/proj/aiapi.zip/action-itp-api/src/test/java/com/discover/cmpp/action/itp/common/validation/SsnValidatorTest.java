package com.discover.cmpp.action.itp.common.validation;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.lenient;

import javax.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class SsnValidatorTest {
    @Mock
    private Ssn ssn;
    private ConstraintValidatorContext cxt;
    private SsnValidator validator;

    @BeforeEach
    public void setUp() throws Exception {
        lenient().when(ssn.nullable()).thenReturn(false);
        lenient().when(ssn.empty()).thenReturn(false);
        validator = new SsnValidator();
        validator.initialize(ssn);
    }

    @Test
    void testSsn_valid() {
        assertTrue(validator.isValid("827-81-9839", cxt));
    }

    @Test
    void testSsnToken_inValid_whenNonNumeric() {
        assertFalse(validator.isValid("abc-de-rgfg", cxt));
        assertFalse(validator.isValid("123-34-523A", cxt));
    }

    @Test
    void testSsnToken_inValid_whenLengthNotEqualto11() {
        assertFalse(validator.isValid("827819867", cxt));
        assertFalse(validator.isValid("8278198397862", cxt));
        assertFalse(validator.isValid("827-81-98397862", cxt));
    }

    @Test
    void testSsnToken_inValid_whenNULL() {
        assertFalse(validator.isValid(null, cxt));
    }

    @Test
    void testSsnToken_inValid_WhenBlankOrSpace() {
        assertFalse(validator.isValid("", cxt));
        assertFalse(validator.isValid(" ", cxt));
    }

    @Test
    void testSsnToken_inValid_WhenAllSameNumber() {
        assertFalse(validator.isValid("111-11-1111", cxt));
        assertFalse(validator.isValid("222-22-2222", cxt));
        assertFalse(validator.isValid("333-33-3333", cxt));
        assertFalse(validator.isValid("444-44-4444", cxt));
        assertFalse(validator.isValid("555-55-5555", cxt));
        assertFalse(validator.isValid("666-66-6666", cxt));
        assertFalse(validator.isValid("777-77-7777", cxt));
        assertFalse(validator.isValid("888-88-8888", cxt));
        assertFalse(validator.isValid("999-99-9999", cxt));
    }

    @Test
    void testSsnToken_inValid_WhenNumericSequence() {
        assertFalse(validator.isValid("123-45-6789", cxt));
        assertFalse(validator.isValid("987-65-4321", cxt));
    }

    @Test
    void testSsnToken_inValid_WhenStartsWith955() {
        assertFalse(validator.isValid("955-55-5555", cxt));
    }

    @Test
    void testSsnToken_inValid_WhenStartsWith666() {
        assertFalse(validator.isValid("666-55-5555", cxt));
    }

    @Test
    void testSsnToken_inValid_WhenStartsWith000() {
        assertFalse(validator.isValid("000-55-5555", cxt));
    }

    @Test
    void testSsnToken_inValid_When000InMiddle() {
        assertFalse(validator.isValid("555-00-5555", cxt));
    }

    @Test
    void testSsnToken_inValid_WhenEndsWith000() {
        assertFalse(validator.isValid("555-55-0000", cxt));
    }

    @Test
    void testSsnToken_inValid_WithWrongFormat() {
        assertFalse(validator.isValid("82781983978", cxt));
    }

    @Test
    void testSsnToken_WhenNullableAndEmptyIsTrue() {
        Mockito.when(ssn.empty()).thenReturn(true);
        Mockito.when(ssn.nullable()).thenReturn(true);
        validator.initialize(ssn);
        assertTrue(validator.isValid("", cxt));
        assertTrue(validator.isValid(null, cxt));
        assertFalse(validator.isValid("72378192389832874", cxt));
    }
}
