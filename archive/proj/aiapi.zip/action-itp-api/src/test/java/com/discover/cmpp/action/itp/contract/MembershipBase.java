package com.discover.cmpp.action.itp.contract;

import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ActionItpExceptionHandler;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.membership.MembershipController;
import com.discover.cmpp.action.itp.membership.MembershipException;
import com.discover.cmpp.action.itp.membership.MembershipService;
import com.discover.cmpp.action.itp.membership.model.MembershipResponse;
import com.discover.cmpp.action.itp.membership.model.billing.BillingResponse;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import io.restassured.module.mockmvc.RestAssuredMockMvc;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.setup.StandaloneMockMvcBuilder;

import java.math.BigDecimal;

import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
abstract class MembershipBase {
    @InjectMocks
    private MembershipController controller;

    @Mock
    private MembershipService membershipService;

    @BeforeEach
    void setup() throws MembershipException, ActionItpException {
        MockitoAnnotations.openMocks(this);
        when(membershipService.fetchItpMembershipInformation("testRACF", "1111")).thenReturn(getMembershipResponse("ITP_FF", "1111"));
        when(membershipService.fetchItpMembershipInformation("testRACF", "1112")).thenReturn(getMembershipResponse("ITP_BM", "1112"));
        when(membershipService.fetchItpMembershipInformation("testRACF", "1212")).thenThrow(new MembershipException(ValidationConstants.AGENT_ID_INVALID_EC));
        when(membershipService.fetchItpBillingInformation("ITP_FF", "12345", new BigDecimal(1), "2")).thenReturn(getBillingResponse());
        when(membershipService.fetchItpBillingInformation("ITP_BM", "12345", new BigDecimal(1), "2")).thenReturn(getBillingDateResponse());
        when(membershipService.fetchItpBillingInformation("ITP_BM", "12345", new BigDecimal(2), "2")).thenThrow(new MembershipException(ValidationConstants.PEID_INVALID_EC));

        StandaloneMockMvcBuilder standaloneMockMvcBuilder = MockMvcBuilders.standaloneSetup(controller)
                .addPlaceholderValue("api.context-path", TestUtils.contextPath)
                .setControllerAdvice(new ActionItpExceptionHandler());
        RestAssuredMockMvc.standaloneSetup(standaloneMockMvcBuilder);
    }

    private MembershipResponse getMembershipResponse(String customerType, String partyId) {
        MembershipResponse membershipResponse = new MembershipResponse();
        membershipResponse.setCancellationDate("0");
        membershipResponse.setCancellationRequestDate("0");
        membershipResponse.setEnrollmentDate("123456789");
        membershipResponse.setEnrollmentStatus("Enrolled");
        membershipResponse.setEnrollmentFailedReason("");
        membershipResponse.setSubscriberNumber("11");
        membershipResponse.setProductEnrollmentId("1");
        membershipResponse.setCancellationReason("");
        membershipResponse.setCustomerType(customerType);
        membershipResponse.setPartyId(partyId);
        return membershipResponse;
    }

    private BillingResponse getBillingResponse() {
        BillingResponse billingResponse = new BillingResponse();
        billingResponse.setPcmFirstName("Jamal");
        billingResponse.setPcmLastName("Murray");
        billingResponse.setPcmAccountNumber("123456789");
        billingResponse.setPresenceOfSecondary("No");
        return billingResponse;
    }

    private BillingResponse getBillingDateResponse() {
        BillingResponse billingResponse = new BillingResponse();
        billingResponse.setNextBillingDate("20210222");
        return billingResponse;
    }
}
