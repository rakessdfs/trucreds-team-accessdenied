package com.discover.cmpp.action.itp.common.validation;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.lenient;
import javax.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class LastNameValidatorTest {
    @Mock
    private LastName lname;
    private ConstraintValidatorContext cxt;
    private LastNameValidator validator;

    @BeforeEach
    public void setUp() throws Exception {
        validator = new LastNameValidator();
        lenient().when(lname.nullable()).thenReturn(false);
        lenient().when(lname.empty()).thenReturn(false);
        validator.initialize(lname);
    }

    @Test
    void testLastName_valid() {
        assertTrue(validator.isValid("testuyo3uixwnnx", cxt));
        assertTrue(validator.isValid("test", cxt));
        assertTrue(validator.isValid("12313", cxt));
    }

    @Test
    void testLastName_inValid_greaterThanMaxLength() {
        assertFalse(validator.isValid("testuyonuixwnnxhgdguw", cxt));
    }

    @Test
    void testLastName_inValid_WhenNull() {
        assertFalse(validator.isValid(null, cxt));
    }

    @Test
    void testLastName_inValid_WhenBlankOrSpace() {
        assertFalse(validator.isValid("", cxt));
        assertFalse(validator.isValid(" ", cxt));
    }

    @Test
    void testLastName_WhenNullableAndEmptyIsTrue() {
        Mockito.when(lname.empty()).thenReturn(true);
        Mockito.when(lname.nullable()).thenReturn(true);
        validator.initialize(lname);
        assertTrue(validator.isValid("", cxt));
        assertTrue(validator.isValid(null, cxt));
        assertFalse(validator.isValid("testuyonuixwnnxhgdguw", cxt));
    }
}
