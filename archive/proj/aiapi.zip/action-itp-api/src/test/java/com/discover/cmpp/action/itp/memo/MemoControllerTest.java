package com.discover.cmpp.action.itp.memo;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.util.NestedServletException;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class MemoControllerTest {

    @InjectMocks
    private MemoController memoController;
    @Mock
    MemoService memoService;
    private MockMvc mockMvc;
    private CreateMemoRequest request;

    @BeforeEach
    void setUp() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(memoController)
                .addPlaceholderValue("api.context-path", TestUtils.contextPath).build();
        request = new CreateMemoRequest();
        request.setMemoText("Enrolled");
        request.setProductEnrollmentId("14578625");
    }

    @Test
    void test_createMemo() throws Exception {
        Mockito.doNothing().when(memoService).createMemo(any(), any());
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(request);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + MemoConstants.CREATE_MEMO_URL)
                .header(ActionItpConstants.AGENT_ID, "agent1")
                .contentType("application/json").content(requestJson)).andExpect(status().isCreated()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }

    @Test
    void test_createMemo_badRequest() throws Exception {
        CreateMemoRequest requestClone = request;
        requestClone.setMemoText("");
        requestClone.setProductEnrollmentId(null);
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(requestClone);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + MemoConstants.CREATE_MEMO_URL)
                .header(ActionItpConstants.AGENT_ID, "")
                .contentType("application/json").content(requestJson)).andExpect(status().isBadRequest()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }

    @Test
    void test_createMemo_internalServerError() throws Exception {
        Mockito.doThrow(new MemoException("Error occured")).when(memoService).createMemo(any(), any());
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(request);
        assertThrows(NestedServletException.class, () ->
                mockMvc.perform(post(TestUtils.contextPath + MemoConstants.CREATE_MEMO_URL)
                .header(ActionItpConstants.AGENT_ID, "")
                .contentType("application/json").content(requestJson)).andExpect(status().is5xxServerError()));
    }

    @Test
    void test_fetchMemo() throws Exception {
        Mockito.when(memoService.fetchMemos(any())).thenReturn(new MemoResponse());

        MvcResult result = mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_MEMO_PATH + "457821487"))
                .andExpect(status().isOk()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }
}
