package com.discover.cmpp.action.itp.oob;


import com.discover.cmpp.action.itp.common.validation.ChannelCode;
import com.discover.cmpp.action.itp.common.validation.ChannelCodeValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.validation.ConstraintValidatorContext;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class ChannelCodeValidatorTest {
    @Mock
    private ChannelCode channelCode;
    private ConstraintValidatorContext cxt;
    private ChannelCodeValidator validator;

    @BeforeEach
    public void setup() {
        validator = new ChannelCodeValidator();
        validator.initialize(channelCode);
    }

    @Test
    void testChannelCode_valid() {
        assertTrue(validator.isValid("EM", cxt));
        assertTrue(validator.isValid("TXT", cxt));
        assertTrue(validator.isValid("AM", cxt));
    }

    @Test
    void testChannelCode_invalid_numeric() {
        assertFalse(validator.isValid("1234", cxt));
    }

    @Test
    void testChannelCode_invalid_WhenNull() { assertFalse(validator.isValid(null, cxt)); }

    @Test
    void testChannelCode_invalid_WhenBlankOrWhitespace() {
        assertFalse(validator.isValid("", cxt));
        assertFalse(validator.isValid(" ", cxt));
    }
}
