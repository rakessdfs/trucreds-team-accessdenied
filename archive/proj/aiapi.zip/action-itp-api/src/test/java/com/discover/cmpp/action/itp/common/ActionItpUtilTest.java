package com.discover.cmpp.action.itp.common;

import com.dfs.ws.jwt.generator.WSJWTException;
import com.dfs.ws.jwt.generator.WSJWTGenerator;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.custlookup.CdsServiceImpl;
import com.discover.cmpp.action.itp.custlookup.CustLookUpException;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.Name;
import com.discover.cmpp.action.itp.custlookup.model.cdspersonal.CdsPersonalInfoResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class ActionItpUtilTest {
    @InjectMocks
    ActionItpUtil itpUtil;
    @Mock
    WSJWTGenerator jwtGenerator;

    @Mock
    CdsServiceImpl cdsService;

    Map<String, String> headerMap;
    private static final String AGENT_ID="testRacf";

    @BeforeEach
    void init() throws ActionItpException {

        MockitoAnnotations.openMocks(this);
        headerMap = itpUtil.restClientHeader();
    }

    @Test
    void testRestClientHeader() throws WSJWTException, ActionItpException {
        Mockito.when(jwtGenerator.getJWTToken()).thenReturn("test");
        headerMap = itpUtil.restClientHeader();
        assertNotNull(headerMap);
    }

    @Test
    void testGetRestClientHeader_WSJWTException() throws WSJWTException {
        Mockito.when(jwtGenerator.getJWTToken()).thenThrow(new WSJWTException());
        assertThrows(ActionItpException.class, () -> itpUtil.restClientHeader());
    }

    @Test
    void testGetRestClientCdsHeader_EmptyId() {
        assertThrows(ActionItpException.class, () -> itpUtil.restClientCdsHeader(""));
    }

    @Test
    void testConvertDateFormat() throws CustLookUpException {
        assertNotNull(
                itpUtil.convertDateFormat("12/15/2019", ValidationConstants.DOB_PATTERN,
                        ValidationConstants.TOKENIZED_DOB_PATTERN));
    }

    @Test
    void testConvertDateFormat_CustLookUpException() {
        assertThrows(CustLookUpException.class, () ->
                itpUtil.convertDateFormat("12/15/2019", ValidationConstants.TOKENIZED_DOB_PATTERN,
                        ValidationConstants.DOB_PATTERN));
    }

    @Test
    void testProductEnrollmentId_Valid() throws CustLookUpException {
        Map<String, String> map = headerMap;
        map.put(ActionItpConstants.X_USER_ID, ActionItpConstants.X_USER_ID_VALUE);
        map.put(ActionItpConstants.X_REQUEST_ID, AGENT_ID);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseFullData(), HttpStatus.OK);
        Mockito.lenient().when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(cdsPersonalInfoResponseEntity);
        assertNotNull(
                itpUtil.getProductEnrollmentId(map,"1234545"));
    }

    private CdsPersonalInfoResponse getCdsPersonalInfoResponseFullData() {
        CdsPersonalInfoResponse cdsPersonalInfoResponse = new CdsPersonalInfoResponse();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfoArr = new ArrayList<>();
        Name name = new Name();
        name.setFirstName("fewd");
        name.setLastName("wdvv");
        personalInfo.setName(name);
        personalInfo.setSsnToken("382906055");
        personalInfo.setDobToken("482906055");
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation = new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] partyToSourceIdAssociationList = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[]{partyToSourceIdAssociation};
        partyToSourceIdAssociation.setAlternatePartyId("PDAB345454656343456");
        partyToSourceIdAssociation.setExpiryTimestamp(null);
        partyToSourceIdAssociation.setRequestSourceCode("PD");
        partyToSourceIdAssociationList[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(partyToSourceIdAssociationList);
        personalInfoArr.add(personalInfo);
        cdsPersonalInfoResponse.setPersonalInfo(personalInfoArr);
        return cdsPersonalInfoResponse;
    }

}
