package com.discover.cmpp.action.itp.contract.consumer;

import com.discover.cmpp.action.itp.membership.MembershipAccessClient;
import com.discover.cmpp.action.itp.membership.model.ProcessRequestResponse;
import com.discover.cmpp.action.itp.membership.model.ProcessRequestSearchCriteria;
import feign.FeignException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@AutoConfigureStubRunner(ids = {
        "com.discover.cmpp:products-api:+:stubs:"
})
@TestPropertySource(properties = {
        "productsApi.service.baseUrl=http://localhost:${stubrunner.runningstubs.products-api.port}" // /cardissuer/products/v1
})
class ProcessRequestContractTests extends AbstractConsumerTest {

    @Autowired
    private MembershipAccessClient membershipAccessClient;

    private Map<String, String> headerMap;

    @BeforeEach
    public void setup() {
        headerMap = mockRestClientCommonHeader();
    }

    @Test
    void processRequestValidatorSuccess() {
        ProcessRequestSearchCriteria processRequestSearchCriteria = getProcessRequestSearchCriteria("111111111", null);
        ResponseEntity<List<ProcessRequestResponse>> response = membershipAccessClient.fetchProcessRequests(headerMap, processRequestSearchCriteria);

        assertEquals(200, response.getStatusCode().value());
    }

    @Test
    void processRequestValidatorWithPartyIdSuccess() {
        ProcessRequestSearchCriteria processRequestSearchCriteria = getProcessRequestSearchCriteria("111111111", "12345");
        ResponseEntity<List<ProcessRequestResponse>> response = membershipAccessClient.fetchProcessRequests(headerMap, processRequestSearchCriteria);

        assertEquals(200, response.getStatusCode().value());
    }

    @Test
    void processRequestValidator400() {
        ProcessRequestSearchCriteria processRequestSearchCriteria = getProcessRequestSearchCriteria("BAD_REQUEST", null);

        final FeignException ex = assertThrows(FeignException.class, () -> membershipAccessClient.fetchProcessRequests(headerMap, processRequestSearchCriteria));
        assertEquals(400, ex.status());
    }

    @Test
    void processRequestValidator500() {
        ProcessRequestSearchCriteria processRequestSearchCriteria = getProcessRequestSearchCriteria("000000", null);
        final FeignException ex = assertThrows(FeignException.class, () -> membershipAccessClient.fetchProcessRequests(headerMap, processRequestSearchCriteria));
        assertEquals(500, ex.status());
    }

    private ProcessRequestSearchCriteria getProcessRequestSearchCriteria(String membershipId, String partyId) {
        ProcessRequestSearchCriteria processRequestSearchCriteria = new ProcessRequestSearchCriteria();
        processRequestSearchCriteria.setMembershipId(membershipId);
        processRequestSearchCriteria.setProcessRequestCode("CAN");
        processRequestSearchCriteria.setProcessStatusCodes(Arrays.asList("CMP", "INP"));
        processRequestSearchCriteria.setProductTypeCode("ITF");
        processRequestSearchCriteria.setRequestorPartyId(partyId);
        return processRequestSearchCriteria;
    }
}
