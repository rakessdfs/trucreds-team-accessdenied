package com.discover.cmpp.action.itp.cancel;

import com.discover.cmpp.action.itp.cancel.model.CancelRequest;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ActionItpUtil;
import com.discover.cmpp.action.itp.common.CloudPropertiesConfiguration;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.custlookup.CustLookUpException;
import com.discover.cmpp.action.itp.membership.MembershipException;
import com.discover.cmpp.action.itp.membership.MembershipService;
import com.discover.cmpp.action.itp.membership.ProductService;
import com.discover.cmpp.action.itp.membership.model.EnrollmentLookupResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class CancelServiceTest {

    @InjectMocks
    private CancelServiceImpl cancelService;

    @Mock
    ActionItpUtil itpUtil;

    @Mock
    ProductService productService;

    @Mock
    MembershipService membershipService;

    CancelRequest cancelRequest;

    @Mock
    CloudPropertiesConfiguration cloudPropertiesConfiguration;

    @BeforeEach
    public void init() {
        MockitoAnnotations.openMocks(this);

        cancelRequest = new CancelRequest();
        cancelRequest.setBusinessOrgCode("EC");
        cancelRequest.setContactChannelCode("ACT");
        cancelRequest.setProcessRequestReasonCode("DNW");
        cancelRequest.setUserId("testRacf");
        cancelRequest.setProcessRequestSourceCode("ACT");
    }

    @Test
    void testCancelCustomer_oldCancelApi_Success() throws CancelException, ActionItpException, CustLookUpException,
            MembershipException {
        Mockito.when(cloudPropertiesConfiguration.isNewCancelApiEnabled()).thenReturn(false);
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("63737373"), HttpStatus.OK));
        Mockito.when(membershipService.cancelMembership(any(), any(), any()))
                .thenReturn(new ResponseEntity<>(HttpStatus.OK));
        cancelService.cancelRequest("testRacf", "1234", "DNW");

        verify(productService).getEnrollmentInfo(any(), any());
        verify(membershipService).cancelMembership(any(), any(), any());
    }

    @Test
    void testCancelCustomer_newCancelApi_Success() throws CancelException, ActionItpException, CustLookUpException,
            MembershipException {
        Mockito.when(cloudPropertiesConfiguration.isNewCancelApiEnabled()).thenReturn(true);
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("63737373"), HttpStatus.OK));
        Mockito.when(membershipService.cancelMembership(any(), any(), any()))
                .thenReturn(new ResponseEntity<>(HttpStatus.OK));
        cancelService.cancelRequest("testRacf", "1234", "DNW");

        verify(productService).getEnrollmentInfo(any(), any());
        verify(membershipService).cancelMembership(any(), any(), any());
    }

    @Test
    void testCancelCustomer_ErrorUpdatingStatus() throws CancelException, CustLookUpException, ActionItpException, MembershipException {
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo("63737373"), HttpStatus.OK));

        Mockito.doThrow(new CancelException(CancelConstants.CANCEL_MEMBERSHIP_ERROR))
                .when(membershipService).cancelMembership(any(), any(), any());
        assertThatThrownBy(() -> cancelService.cancelRequest("testRacf", "1234", "XYZ"))
                .isInstanceOf(CancelException.class)
                .hasMessage(CancelConstants.CANCEL_MEMBERSHIP_ERROR);
    }

    @Test
    void testCancelCustomer_ErrorUpdatingStatus_MembershipIdInvalid() throws CancelException, CustLookUpException, ActionItpException, MembershipException {
        Mockito.when(productService.getEnrollmentInfo(any(), any()))
                .thenReturn(new ResponseEntity<>(getEnrollmentInfo(""), HttpStatus.BAD_REQUEST));
        lenient().when(membershipService.cancelMembership(any(), any(), any())).thenThrow(new CancelException(ValidationConstants.MEMBERSHIP_ID_NOT_FOUND_EC));
        assertThatThrownBy(() -> cancelService.cancelRequest("testRacf", "1234", "XYZ"))
                .isInstanceOf(CancelException.class)
                .hasMessage(ValidationConstants.MEMBERSHIP_ID_NOT_FOUND_EC);
    }

    private EnrollmentLookupResponse getEnrollmentInfo(String membershipId) {
        EnrollmentLookupResponse response = new EnrollmentLookupResponse();
        response.setMembershipId(membershipId);
        return response;
    }
}
