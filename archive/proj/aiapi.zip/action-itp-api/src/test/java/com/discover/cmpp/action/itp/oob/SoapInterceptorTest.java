package com.discover.cmpp.action.itp.oob;

import com.dfs.ws.jwt.generator.WSJWTException;
import com.dfs.ws.jwt.generator.WSJWTGenerator;
import org.apache.cxf.binding.soap.SoapMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.reflect.Whitebox;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

class SoapInterceptorTest {

    @InjectMocks
    SoapInterceptor soapInterceptor;

    @Mock
    SoapMessage message;

    @Mock
    WSJWTGenerator jwtGenerator;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testHandleMessage() {
        soapInterceptor.handleMessage(message);
        assertDoesNotThrow(() ->soapInterceptor.handleMessage(message));
    }

    @Test
    void testGetJWTtokenSuccess() throws Exception {
        Mockito.when(jwtGenerator.getJWTToken()).thenReturn("fg73465789235jhdyft37956ukghf7i");
        String actual = Whitebox.invokeMethod(soapInterceptor, "getJwtToken");
        assertEquals("fg73465789235jhdyft37956ukghf7i", actual);
    }

    @Test
    void testGetJWTtokenFailure() throws Exception {
        Mockito.when(jwtGenerator.getJWTToken()).thenThrow(WSJWTException.class);
        assertThrows(OobSoapException.class, () -> Whitebox.invokeMethod(soapInterceptor, "getJwtToken"));
    }
}
