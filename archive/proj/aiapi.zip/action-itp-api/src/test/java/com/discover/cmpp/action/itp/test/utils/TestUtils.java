package com.discover.cmpp.action.itp.test.utils;

import com.discover.cmpp.action.itp.common.ApiStatus;
import com.github.tomakehurst.wiremock.client.WireMock;
import lombok.NoArgsConstructor;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import java.io.IOException;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.badRequest;
import static com.github.tomakehurst.wiremock.client.WireMock.equalToJson;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.notFound;
import static com.github.tomakehurst.wiremock.client.WireMock.ok;
import static com.github.tomakehurst.wiremock.client.WireMock.okJson;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.put;
import static com.github.tomakehurst.wiremock.client.WireMock.serverError;
import static com.github.tomakehurst.wiremock.client.WireMock.status;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static java.nio.charset.StandardCharsets.UTF_8;
import static lombok.AccessLevel.PRIVATE;

@Component
@NoArgsConstructor(access = PRIVATE)
public class TestUtils {

	public static final String FETCH_MEMO_PATH = "/memo/";

	public static final String FETCH_MEMBERSHIP_PATH = "/membership";

	public static final String FETCH_ACCOUNT_ACTIVITY_PATH = "/accountActivity/";

	public static final String LANGUAGE_PATH = "/language";

    public static String contextPath = "/enterprise/products/action/itp/v1";

	public static String FETCH_BILLING_PATH = "/membership/billing";

	public static String FETCH_STATUS_PATH = "/getStatus/";

	private static Resource validCloakSsnTokenResponse;

	@Value("classpath:data/valid-cloak-ssn-tokenkize-response.json")
	public void setValidCloakSsnTokenResponse(Resource resource) {
		TestUtils.validCloakSsnTokenResponse = resource;
	}

	private static Resource validCloakDobTokenResponse;

	@Value("classpath:data/valid-cloak-dob-tokenkize-response.json")
	public void setValidCloakDobTokenResponse(Resource resource) {
		TestUtils.validCloakDobTokenResponse = resource;
	}

	private static Resource validCloakDobTokenResponse1;

	@Value("classpath:data/valid-cloak-dob-tokenkize-response1.json")
	public void setValidCloakDobTokenResponse1(Resource resource) {
		TestUtils.validCloakDobTokenResponse1 = resource;
	}

	private static Resource validCustSearchRequest;

	@Value("classpath:data/valid-cust-search-request.json")
	public void setValidCustSearchRequest(Resource resource) {
		TestUtils.validCustSearchRequest = resource;
	}

	private static Resource invalidCustSearchRequest;

	@Value("classpath:data/invalid-cust-search-request.json")
	public void setInalidCustSearchRequest(Resource resource) {
		TestUtils.invalidCustSearchRequest = resource;
	}

	private static Resource validCustSearchResponse;

	@Value("classpath:data/valid-cust-search-response.json")
	public void setValidCustSearchResponse(Resource resource) {
		TestUtils.validCustSearchResponse = resource;
	}

	private static Resource validCloakSsnDeTokenResponse;

	@Value("classpath:data/valid-cloak-ssn-detokenkize-response.json")
	public void setValidCloakSsnDeTokenResponse(Resource resource) {
		TestUtils.validCloakSsnDeTokenResponse = resource;
	}

	private static Resource validCloakDobDeTokenResponse;

	@Value("classpath:data/valid-cloak-dob-detokenkize-response.json")
	public void setValidCloakDobDeTokenResponse(Resource resource) {
		TestUtils.validCloakDobDeTokenResponse = resource;
	}

	private static Resource validCustLocationInfoResponse;

	@Value("classpath:data/valid-cust-location-info-response.json")
	public void setValidCustLocationInfoResponse(Resource resource) {
		TestUtils.validCustLocationInfoResponse = resource;
	}

	private static Resource validCustLocationInfoResponseMultiplePiis;

	@Value("classpath:data/valid-cust-location-info-response-multiple-piis.json")
	public void setValidCustLocationInfoResponseMultiplePiis(Resource resource) {
		TestUtils.validCustLocationInfoResponseMultiplePiis = resource;
	}
	
	private static Resource validCustLocationInfoResponseNullUserIdentifier;

	@Value("classpath:data/valid-cust-location-info-response-multiple-piis_null_user-identifier.json")
	public void setValidCustLocationInfoResponseNullUserIdentifier(Resource resource) {
		TestUtils.validCustLocationInfoResponseNullUserIdentifier = resource;
	}

	private static Resource validCustLocationInfoResponseSingleNullUserIdentifier;

	@Value("classpath:data/valid-cust-location-info-response-multiple-piis_single-null_user-identifier.json")
	public void setValidCustLocationInfoResponseSingleNullUserIdentifier(Resource resource) {
		TestUtils.validCustLocationInfoResponseSingleNullUserIdentifier = resource;
	}
	
	private static Resource validCustPersonalInfoResponse;

	@Value("classpath:data/valid-cust-personal-info-response.json")
	public void setValidCustPersonalInfoResponse(Resource resource) {
		TestUtils.validCustPersonalInfoResponse = resource;
	}

	private static Resource validMembershipInfoResponseBMCanPcn;

	@Value("classpath:data/valid-membership-info-response-bm-CAN.json")
	public void setValidMembershipInfoResponseBMCanPcn(Resource resource) {
		TestUtils.validMembershipInfoResponseBMCanPcn = resource;
	}

	private static Resource validMembershipInfoResponseCancelRsnBM;

	@Value("classpath:data/valid-membership-info-response-cancel-rsn-bm.json")
	public void setValidMembershipInfoResponseCancelRsnBM(Resource resource) {
		TestUtils.validMembershipInfoResponseCancelRsnBM = resource;
	}

	private static Resource validMembershipInfoListResponseFF;

	@Value("classpath:data/valid-membership-info-response-list-ff.json")
	public void setValidMembershipInfoListResponseFF(Resource resource) {
		TestUtils.validMembershipInfoListResponseFF = resource;
	}

	private static Resource validMembershipInfoListRequestFF;

	@Value("classpath:data/valid-membership-info-request-list-ff.json")
	public void setValidMembershipInfoListRequestFF(Resource resource) {
		TestUtils.validMembershipInfoListRequestFF = resource;
	}

	private static Resource validMembershipInfoListResponseBM;

	@Value("classpath:data/valid-membership-info-response-list-bm.json")
	public void setValidMembershipInfoListResponseBM(Resource resource) {
		TestUtils.validMembershipInfoListResponseBM = resource;
	}

	private static Resource validMembershipInfoListRequestBM;

	@Value("classpath:data/valid-membership-info-request-list-bm.json")
	public void setValidMembershipInfoListRequestBM(Resource resource) {
		TestUtils.validMembershipInfoListRequestBM = resource;
	}

	private static Resource validMembershipInfoListResponseRsnBM;

	@Value("classpath:data/valid-membership-info-response-list-rsn-bm.json")
	public void setValidMembershipInfoListResponseRsnBM(Resource resource) {
		TestUtils.validMembershipInfoListResponseRsnBM = resource;
	}

	private static Resource validMembershipInfoListRequestRsnBM;

	@Value("classpath:data/valid-membership-info-request-list-rsn-bm.json")
	public void setValidMembershipInfoListRequestRsnBM(Resource resource) {
		TestUtils.validMembershipInfoListRequestRsnBM = resource;
	}

	private static Resource validMembershipInfoListResponseEnr;

	@Value("classpath:data/valid-membership-info-response-list-enr.json")
	public void setValidMembershipInfoListResponseEnr(Resource resource) {
		TestUtils.validMembershipInfoListResponseEnr = resource;
	}

	private static Resource validMembershipInfoListRequestEnr;

	@Value("classpath:data/valid-membership-info-request-list-enr.json")
	public void setValidMembershipInfoListRequestEnr(Resource resource) {
		TestUtils.validMembershipInfoListRequestEnr = resource;
	}

	private static Resource validMembershipInfoListResponseCanFF;

	@Value("classpath:data/valid-membership-info-response-list-ff-can.json")
	public void setValidMembershipInfoListResponseCanFF(Resource resource) {
		TestUtils.validMembershipInfoListResponseCanFF = resource;
	}

	private static Resource validMembershipInfoListRequestCanFF;

	@Value("classpath:data/valid-membership-info-request-list-ff-can.json")
	public void setValidMembershipInfoListRequestCanFF(Resource resource) {
		TestUtils.validMembershipInfoListRequestCanFF = resource;
	}

	private static Resource validMembershipInfoListRequestCanFFNullUserIdentifier;

	@Value("classpath:data/valid-membership-info-request-list-ff-can-null-user-identifier.json")
	public void setValidMembershipInfoListRequestCanFFNullUserIdentifier(Resource resource) {
		TestUtils.validMembershipInfoListRequestCanFFNullUserIdentifier = resource;
	}

	private static Resource validMembershipInfoListRequestCanFFSingleNullUserIdentifier;

	@Value("classpath:data/valid-membership-info-request-list-ff-can-single-null-user-identifier.json")
	public void setValidMembershipInfoListRequestCanFFSingleNullUserIdentifier(Resource resource) {
		TestUtils.validMembershipInfoListRequestCanFFSingleNullUserIdentifier = resource;
	}

	private static Resource validMembershipInfoListRequestMemoFF;

	@Value("classpath:data/valid-membership-info-request-list-ff-memo.json")
	public void setValidMembershipInfoListRequestMemoFF(Resource resource) {
		TestUtils.validMembershipInfoListRequestMemoFF = resource;
	}

	private static Resource validProcessDetailsResponse;

	@Value("classpath:data/valid-process-details-response.json")
	public void setValidProcessDetailsResponse(Resource resource) {
		TestUtils.validProcessDetailsResponse = resource;
	}

	private static Resource validProcessDetailsResponseCancelRsnBM;

	@Value("classpath:data/valid-process-details-response-cancel-rsn-bm.json")
	public void setValidProcessDetailsResponseCancelRsnBM(Resource resource) {
		TestUtils.validProcessDetailsResponseCancelRsnBM = resource;
	}

	private static Resource validProcessRequestSearchCriteria;

	@Value("classpath:data/valid-process-request-search-criteria.json")
	public void setValidProcessRequestSearchCriteria(Resource resource) {
		TestUtils.validProcessRequestSearchCriteria = resource;
	}

	private static Resource validProcessRequestSearchCriteriaCancelRsnBM;

	@Value("classpath:data/valid-process-request-search-criteria-cancel-rsn-bm.json")
	public void setValidProcessRequestSearchCriteriaCancelRsnBM(Resource resource) {
		TestUtils.validProcessRequestSearchCriteriaCancelRsnBM = resource;
	}

	private static Resource validProcessRequestSearchCriteriaEnrRsnBM;

    @Value("classpath:data/valid-process-request-search-criteria-ENR-rsn-bm.json")
    public void setValidProcessRequestSearchCriteriaEnrRsnBM(Resource resource) {
        TestUtils.validProcessRequestSearchCriteriaEnrRsnBM = resource;
    }

	private static Resource validEnrollmentLookupResponse;

	@Value("classpath:data/valid-enrollment-lookup-response.json")
	public void setValidEnrollmentLookupResponse(Resource resource) {
		TestUtils.validEnrollmentLookupResponse = resource;
	}

	private static Resource validEnrollmentLookupSubscriberIdResponse;

	@Value("classpath:data/valid-enrollment-lookup-subscriberId-response.json")
	public void setValidEnrollmentLookupSubscriberIdResponse(Resource resource) {
		TestUtils.validEnrollmentLookupSubscriberIdResponse = resource;
	}


	private static Resource validCardCustomerDataResponse;

	@Value("classpath:data/valid-card-customer-data-response.json")
	public void setValidCardCustomerDataResponse(Resource resource) {
		TestUtils.validCardCustomerDataResponse = resource;
	}

	private static Resource validAccountNumberResponse;

	@Value("classpath:data/valid-account-number-response.json")
	public void setValidAccountNumberResponse(Resource resource) {
		TestUtils.validAccountNumberResponse = resource;
	}

	private static Resource validCustPiiLookUpSearchResponse;

	@Value("classpath:data/valid-cust-pii-info-response.json")
	public void setValidCustPiiLookUpSearchResponse(Resource resource) {
		TestUtils.validCustPiiLookUpSearchResponse = resource;
	}

	private static Resource validProductReferralResponse;

	@Value("classpath:data/valid-product-referral-response.json")
    public void setValidProductReferralResponse(Resource resource) {
        TestUtils.validProductReferralResponse = resource;
    }

	private static Resource validCustLocReqManyReq;

    @Value("classpath:data/valid-cust-location-info-request-many-records.json")
    public void setValidCustLocReqManyReq(Resource resource) {
        TestUtils.validCustLocReqManyReq = resource;
    }


	private static Resource validCustLocReqNullUserIdentifier;

	@Value("classpath:data/valid-cust-location-info-request-null_user-identifier.json")
	public void setValidCustLocReqNullUserIdentifier(Resource resource) {
		TestUtils.validCustLocReqNullUserIdentifier = resource;
	}

	private static Resource validCustLocReqSingleNullUserIdentifier;

	@Value("classpath:data/valid-cust-location-info-request-single-null_user-identifier.json")
	public void setValidCustLocReqSingleNullUserIdentifier(Resource resource) {
		TestUtils.validCustLocReqSingleNullUserIdentifier = resource;
	}
 
	private static Resource validCustSearchRequestPeid;

	@Value("classpath:data/valid-cust-search-request-peid.json")
	public void setValidCustSearchRequestPeid(Resource resource) {
		TestUtils.validCustSearchRequestPeid = resource;
	}

	private static Resource validCdsTranslationResponse;

	@Value("classpath:data/valid-cds-translation-response.json")
	public void setValidCdsTranslationResponse(Resource resource) {
		TestUtils.validCdsTranslationResponse = resource;
	}

	private static Resource validCdsTranslationReqSrcCodeResponse;

	@Value("classpath:data/valid-cds-translation-req-src-code-response.json")
	public void setValidCdsTranslationReqSrcCodeResponse(Resource resource) {
		TestUtils.validCdsTranslationReqSrcCodeResponse = resource;
	}

	private static Resource invalidCdsTranslationReqSrcCodeResponse;

	@Value("classpath:data/invalid-cds-translation-req-src-code-response.json")
	public void setInvalidCdsTranslationReqSrcCodeResponse(Resource resource) {
		TestUtils.invalidCdsTranslationReqSrcCodeResponse = resource;
	}

	private static Resource validCsidSubscriberGetBillingStatusResponse;

	@Value("classpath:data/valid-get-billing-status-response.json")
	public void setValidCsidSubscriberGetBillingStatusResponse(Resource resource) {
		TestUtils.validCsidSubscriberGetBillingStatusResponse = resource;
	}

	private static Resource invalidVerintTagCallRequest;

	@Value("classpath:data/invalid-tag-call-request.json")
	public void setInvalidVerintTagCallRequest(Resource resource) {
		TestUtils.invalidVerintTagCallRequest = resource;
	}

	private static Resource validVerintTagCallResponse;

	@Value("classpath:data/valid-tag-call-response.json")
	public void setValidVerintTagCallResponse(Resource resource) {
		TestUtils.validVerintTagCallResponse = resource;
	}

	private static Resource validGetExtensionResponse;

	@Value("classpath:data/valid-get-extension-response.json")
	public void setValidGetExtensionResponse(Resource resource) {
		TestUtils.validGetExtensionResponse = resource;
	}

	private static Resource validCdsPersonalInfoCancelMembershipRequest;

	@Value("classpath:data/valid-cust-personal-info-request-cancel-membership.json")
	public void setValidCdsPersonalInfoCancelMembershipRequest(Resource resource) {
		TestUtils.validCdsPersonalInfoCancelMembershipRequest = resource;
	}

	private static Resource validCdsPersonalInfoCancelMembershipResponse;

	@Value("classpath:data/valid-cust-personal-info-response-canel-membership.json")
	public void setValidCdsPersonalInfoCancelMembershipResponse(Resource resource) {
		TestUtils.validCdsPersonalInfoCancelMembershipResponse = resource;
	}

	private static Resource validProductsEnrollmnetLookupCancelMembershipResponse;

	@Value("classpath:data/valid-enrollment-lookup-response-cancel-membership.json")
	public void setValidProductsEnrollmnetLookupCancelMembershipResponse(Resource resource) {
		TestUtils.validProductsEnrollmnetLookupCancelMembershipResponse = resource;
	}

	private static Resource validCdsPersonalInfoCancelMembershipRequest500;

	@Value("classpath:data/valid-cust-personal-info-request-cancel-membership-500.json")
	public void setValidCdsPersonalInfoCancelMembershipRequest500(Resource resource) {
		TestUtils.validCdsPersonalInfoCancelMembershipRequest500 = resource;
  }

	private static Resource noActiveCallGetExtensionResponse;

	@Value("classpath:data/no-active-call-get-extension-response.json")
	public void setNoActiveCallGetExtensionResponse(Resource resource) {
		TestUtils.noActiveCallGetExtensionResponse = resource;
	}

	private static Resource contactFailsGetExtensionResponse;

	@Value("classpath:data/contact-fails-get-extension-response.json")
	public void setContactFailsGetExtensionResponse(Resource resource) {
		TestUtils.contactFailsGetExtensionResponse = resource;
	}

	private static Resource validUpdateCustomerProfileInfoResponse;

	@Value("classpath:data/valid-update-customer-profile-info-response.json")
	public void setValidUpdateCustomerProfileInfoResponseResponse(Resource resource) {
		TestUtils.validUpdateCustomerProfileInfoResponse = resource;
	}


	public static String getStringContent(Resource resource) throws IOException {
		return IOUtils.toString(resource.getInputStream(), UTF_8);
	}

	private static Resource memoFluxValidRequest;
	@Value("classpath:data/memo-flux-valid-request.json")
	public void setMemoFluxValidRequest(Resource resource) {
		TestUtils.memoFluxValidRequest = resource;
	}

	private static Resource memoFluxInvalidRequest;

	@Value("classpath:data/memo-flux-invalid-request.json")
	public void setMemoFluxInvalidRequest(Resource resource) {
		TestUtils.memoFluxInvalidRequest = resource;
	}

	private static Resource memoFluxValidResponse;

	@Value("classpath:data/memo-flux-success-response.json")
	public void setMemoFluxSuccessResponse(Resource resource) {
		TestUtils.memoFluxValidResponse = resource;
	}

	private static Resource validUpdateCustomerProfileInfoRequest;
	
	@Value("classpath:data/valid-update-customer-profile-info-request.json")
	public void setValidUpdateCustomerProfileInfoRequest(Resource resource) {
		TestUtils.validUpdateCustomerProfileInfoRequest = resource;
	}

	private static Resource invalidCustomerProfileInfoRequestNoData;
	@Value("classpath:data/invalid-update-customer-profile-info-request-no-data.json")
	public void setInvalidCustomerProfileInfoRequestNoData(Resource resource) {
		TestUtils.invalidCustomerProfileInfoRequestNoData = resource;
	}

	private static Resource validCustomerProfileInfoRequestReturns500;
	@Value("classpath:data/valid-update-customer-profile-info-request-returns-500.json")
	public void setValidCustomerProfileInfoRequestReturns500(Resource resource) {
		TestUtils.validCustomerProfileInfoRequestReturns500 = resource;
	}
	
	public static void setWiremockCloakService() throws Exception {
		stubFor(post(WireMock.urlPathMatching("/CloakService/enterprise/security/cloak/v1/data/tokenization"))
				.withRequestBody(equalToJson("{\"input\": \"346226414\"}", false, true))
				.willReturn(okJson(getStringContent(validCloakSsnTokenResponse))));

		stubFor(post(WireMock.urlPathMatching("/CloakService/enterprise/security/cloak/v1/data/tokenization"))
				.withRequestBody(equalToJson("{\"input\": \"1970-01-01\"}", false, true))
				.willReturn(okJson(getStringContent(validCloakDobTokenResponse))));

		stubFor(post(WireMock.urlPathMatching("/CloakService/enterprise/security/cloak/v1/data/tokenization"))
				.withRequestBody(equalToJson("{\"input\": \"1870-01-01\"}", false, true))
				.willReturn(okJson(getStringContent(validCloakDobTokenResponse1))));

		stubFor(post(WireMock.urlPathMatching("/CloakService/enterprise/security/cloak/v1/data/detokenization"))
				.withRequestBody(equalToJson("{\"input\": \"382906055\"}", false, true))
				.willReturn(okJson(getStringContent(validCloakSsnDeTokenResponse))));

		stubFor(post(WireMock.urlPathMatching("/CloakService/enterprise/security/cloak/v1/data/detokenization"))
				.withRequestBody(equalToJson("{\"input\": \"0955-08-06\"}", false, true))
				.willReturn(okJson(getStringContent(validCloakDobDeTokenResponse))));

	}

	public static void setWiremockCdsService() throws Exception {

		stubFor(post(urlPathMatching("/enterprise/customer/search/v1/pii/query"))
				.withRequestBody(equalToJson(getStringContent(validCustSearchRequest)))
				.willReturn(okJson(getStringContent(validCustSearchResponse))));

		stubFor(post(urlPathMatching("/enterprise/customer/search/v1/pii/query"))
				.withRequestBody(equalToJson(getStringContent(invalidCustSearchRequest)))
				.willReturn(okJson("{\n" + "    \"customers\": [\n" + "    ]\n" + "}")));

		stubFor(post(urlPathMatching("/enterprise/customer/access/v1/location/query"))
                .withRequestBody(equalToJson(getStringContent(validCustLocReqManyReq)))
                .willReturn(okJson(getStringContent(validCustLocationInfoResponseMultiplePiis))));

		stubFor(post(urlPathMatching("/enterprise/customer/access/v1/location/query"))
				.withRequestBody(equalToJson(getStringContent(validCustLocReqNullUserIdentifier)))
				.willReturn(okJson(getStringContent(validCustLocationInfoResponseNullUserIdentifier))));

		stubFor(post(urlPathMatching("/enterprise/customer/access/v1/location/query"))
				.withRequestBody(equalToJson(getStringContent(validCustLocReqSingleNullUserIdentifier)))
				.willReturn(okJson(getStringContent(validCustLocationInfoResponseSingleNullUserIdentifier))));
		
		stubFor(post(urlPathMatching("/enterprise/customer/access/v1/location/query"))
		        .withRequestBody(equalToJson("{ \"retrieveExpired\": false  }", true, true))
				.willReturn(okJson(getStringContent(validCustLocationInfoResponse))));

		stubFor(post(urlPathMatching("/enterprise/customer/access/v1/personalinfo/query"))
				.willReturn(okJson(getStringContent(validCustPersonalInfoResponse))));

		stubFor(post(urlPathMatching("/enterprise/products/action/itp/v1/customer/search"))
				.willReturn(okJson(getStringContent(validCustSearchResponse))));

		stubFor(post(urlPathMatching("/enterprise/products/action/itp/v1/customer/pii"))
				.willReturn(okJson(getStringContent(validCustPiiLookUpSearchResponse))));

		stubFor(post(urlPathMatching("/enterprise/customer/search/v1/pii/query"))
				.withRequestBody(equalToJson(getStringContent(invalidCustSearchRequest)))
				.willReturn(okJson("{\n" + "    \"customers\": [\n" + "    ]\n" + "}")));

		stubFor(post(urlPathMatching("/enterprise/products/action/itp/v1/customer/search"))
				.withRequestBody(equalToJson(getStringContent(validCustSearchRequestPeid)))
				.willReturn(okJson("{\n" + "    \"customers\": [\n" + "    ]\n" + "}")));

		stubFor(post(urlPathMatching("/enterprise/customer/access/v1/personalinfo/query"))
				.withRequestBody(equalToJson(getStringContent(validCdsPersonalInfoCancelMembershipRequest)))
				.willReturn(okJson(getStringContent(validCdsPersonalInfoCancelMembershipResponse))));

		stubFor(post(urlPathMatching("/enterprise/customer/access/v1/personalinfo/query"))
				.withRequestBody(equalToJson(getStringContent(validCdsPersonalInfoCancelMembershipRequest500)))
				.willReturn(aResponse().withStatus(500)));

	}

	public static void setWiremockProductsApiService() throws Exception {
		stubFor(post(urlPathMatching("/v3/membership/list/query"))
				.withRequestBody(equalToJson(getStringContent(validMembershipInfoListRequestCanFF)))
				.willReturn(okJson(getStringContent(validMembershipInfoListResponseCanFF))));
		
		stubFor(post(urlPathMatching("/v3/membership/list/query"))
				.withRequestBody(equalToJson(getStringContent(validMembershipInfoListRequestCanFFNullUserIdentifier)))
				.willReturn(okJson(getStringContent(validMembershipInfoListResponseCanFF))));
		
		stubFor(post(urlPathMatching("/v3/membership/list/query"))
				.withRequestBody(equalToJson(getStringContent(validMembershipInfoListRequestCanFFSingleNullUserIdentifier)))
				.willReturn(okJson(getStringContent(validMembershipInfoListResponseCanFF))));
		
		stubFor(post(urlPathMatching("/v3/membership/list/query"))
				.withRequestBody(equalToJson(getStringContent(validMembershipInfoListRequestFF)))
				.willReturn(okJson(getStringContent(validMembershipInfoListResponseFF))));

		stubFor(post(urlPathMatching("/v3/membership/list/query"))
				.withRequestBody(equalToJson(getStringContent(validMembershipInfoListRequestBM)))
				.willReturn(okJson(getStringContent(validMembershipInfoListResponseBM))));

		stubFor(post(urlPathMatching("/v3/membership/list/query"))
				.withRequestBody(equalToJson(getStringContent(validMembershipInfoListRequestRsnBM)))
				.willReturn(okJson(getStringContent(validMembershipInfoListResponseRsnBM))));

		stubFor(post(urlPathMatching("/v3/membership/list/query"))
				.withRequestBody(equalToJson(getStringContent(validMembershipInfoListRequestEnr)))
				.willReturn(okJson(getStringContent(validMembershipInfoListResponseEnr))));

		stubFor(post(urlPathMatching("/v3/membership/list/query"))
				.withRequestBody(equalToJson(getStringContent(validMembershipInfoListRequestMemoFF)))
				.willReturn(okJson(getStringContent(validMembershipInfoListResponseFF))));

		stubFor(post(urlPathMatching("/v1/processrequest/query"))
				.withRequestBody(equalToJson(getStringContent(validProcessRequestSearchCriteria)))
				.willReturn(okJson(getStringContent(validProcessDetailsResponse))));

		stubFor(post(urlPathMatching("/v1/processrequest/query"))
                .withRequestBody(equalToJson(getStringContent(validProcessRequestSearchCriteriaEnrRsnBM)))
                .willReturn(okJson(getStringContent(validProcessDetailsResponse))));

		stubFor(post(urlPathMatching("/v1/processrequest/query"))
				.withRequestBody(equalToJson(getStringContent(validProcessRequestSearchCriteriaCancelRsnBM)))
				.willReturn(okJson(getStringContent(validProcessDetailsResponseCancelRsnBM))));

		stubFor(get(urlPathMatching("/v1/membership/partyid/5555"))
				.willReturn(serverError()));

		stubFor(get(urlPathMatching("/v1/membership/partyid/4444/productcode/ITB"))
				.willReturn(okJson(getStringContent(validMembershipInfoResponseBMCanPcn))));

		stubFor(get(urlPathMatching("/v1/membership/partyid/3333/productcode/ITB"))
				.willReturn(okJson(getStringContent(validMembershipInfoResponseCancelRsnBM))));

		stubFor(put(urlPathMatching("/v1/membership/partyid/5555/productcode/ITF"))
				.willReturn(aResponse().withStatus(500)));
	}

	public static void setWiremockProductEnrollmentApiService() throws Exception {

		stubFor(get(urlPathMatching("/enterprise/products/enrollment/v1/lookup"))
				.willReturn(okJson(getStringContent(validEnrollmentLookupResponse))));

		stubFor(get(urlPathMatching("/enterprise/products/enrollment/v1/lookup"))
				.willReturn(okJson(getStringContent(validEnrollmentLookupSubscriberIdResponse))));

		stubFor(get(urlPathMatching("/enterprise/products/enrollment/v1/lookup"))
				.willReturn(okJson(getStringContent(validProductsEnrollmnetLookupCancelMembershipResponse))));
	}

	public static void setWiremockCdsTranslationService() throws Exception {

		stubFor(get(urlPathMatching("/enterprise/customer/translation/v2/alternatepartyid/9090203091733124810"))
				.willReturn(okJson(getStringContent(validCdsTranslationResponse))));
		stubFor(get(urlPathMatching("/enterprise/customer/translation/v2/alternatepartyid/9090512345812345678"))
				.willReturn(okJson(getStringContent(validCdsTranslationResponse))));
		stubFor(get(urlPathMatching("/enterprise/customer/translation/v2/alternatepartyid/457821487"))
				.willReturn(okJson(getStringContent(validCdsTranslationResponse))));
		stubFor(get(urlPathMatching("/enterprise/customer/translation/v2/prty/96863612/srcsyscustids"))
				.willReturn(okJson(getStringContent(validCdsTranslationReqSrcCodeResponse))));

		stubFor(get(urlPathMatching("/enterprise/customer/translation/v2/prty/96863614/srcsyscustids"))
				.willReturn(okJson(getStringContent(validCdsTranslationReqSrcCodeResponse))));

		stubFor(get(urlPathMatching("/enterprise/customer/translation/v2/prty/96863615/srcsyscustids"))
				.willReturn(okJson(getStringContent(validCdsTranslationReqSrcCodeResponse))));

		stubFor(get(urlPathMatching("/enterprise/customer/translation/v2/prty/96863616/srcsyscustids"))
				.willReturn(okJson(getStringContent(invalidCdsTranslationReqSrcCodeResponse))));

		stubFor(get(urlPathMatching("/enterprise/customer/translation/v2/prty/96863617/srcsyscustids"))
				.willReturn(okJson("{\n" + "}")));

		stubFor(get(urlPathMatching("/enterprise/customer/translation/v2/alternatepartyid/1111"))
				.willReturn(okJson(getStringContent(validCdsTranslationResponse))));
	}

	public static void setWiremockCardCustomerDataApi() throws Exception {

		stubFor(post(urlPathMatching("/cardissuer/cardcustomerdata/v1/cardcustomerdata/query"))
		.willReturn(okJson(getStringContent(validCardCustomerDataResponse))));
	}

	public static void setWiremockAccountNumberApi() throws Exception {
		stubFor(post(urlPathMatching("/cardissuer/acctnbr/v1/acctnbr/query"))
		.willReturn(okJson(getStringContent(validAccountNumberResponse))));
	}

	public static void setWiremockProductReferralApi() throws Exception {
		stubFor(get(urlPathMatching("/enterprise/products/referral/v1/referrals/peid/54321"))
				.willReturn(okJson(getStringContent(validProductReferralResponse))));

		stubFor(get(urlPathMatching("/enterprise/products/referral/v1/referrals/peid/1"))
				.willReturn(badRequest()));

		stubFor(get(urlPathMatching("/enterprise/products/referral/v1/referrals/peid/2"))
		.willReturn(notFound()));

		stubFor(get(urlPathMatching("/enterprise/products/referral/v1/referrals/peid/4"))
				.willReturn(serverError()));
	}

	public static void setWiremockCsidSubscriberApi() throws Exception {
		stubFor(post(urlPathMatching("/cardissuer/itp/csid/subscriber/v1/subscriber/subscribernumber/PDCD203432229473040/billingstatus"))
				.willReturn(okJson(getStringContent(validCsidSubscriberGetBillingStatusResponse))));
	}

	public static void setWiremockCiscoRestApi() throws Exception {
		stubFor(get(urlEqualTo("/v1/getAgent?racf=testRacf&sys=ucce&match=exact"))
				.willReturn(okJson(getStringContent(validGetExtensionResponse))));
		stubFor(get(urlEqualTo("/v1/getAgent?racf=extensionFails&sys=ucce&match=exact"))
				.willReturn(badRequest()));
		stubFor(get(urlEqualTo("/v1/getAgent?racf=noCallActive&sys=ucce&match=exact"))
				.willReturn(okJson(getStringContent(noActiveCallGetExtensionResponse))));
		stubFor(get(urlEqualTo("/v1/getAgent?racf=invalidContact&sys=ucce&match=exact"))
				.willReturn(okJson(getStringContent(contactFailsGetExtensionResponse))));
	}

	public static void setWiremockVerintRestApi() throws Exception {
		stubFor(post(urlPathMatching("/dfs/verintrest/v1/tagcall"))
				.willReturn(okJson(getStringContent(validVerintTagCallResponse))));
		stubFor(post(urlPathMatching("/dfs/verintrest/v1/tagcall"))
				.withRequestBody(equalToJson(getStringContent(invalidVerintTagCallRequest)))
				.willReturn(badRequest()));

		stubFor(get(urlPathMatching("/dfs/verintrest/v1/getContact/11311009008"))
				.willReturn(ok()));
		stubFor(get(urlPathMatching("/dfs/verintrest/v1/getContact/500"))
				.willReturn(serverError()));
		stubFor(get(urlPathMatching("/dfs/verintrest/v1/getContact/202"))
				.willReturn(status(202)));
	}

	public static void setWiremockCancelApi() {
		stubFor(post(urlEqualTo("/cancellation?identifierType=MEMBERSHIPID&identifier=4434354546565"))
				.willReturn(ok()));
	}

	public static void setWiremockMemoFluxService() throws IOException {
		stubFor(post(
				urlPathMatching("/enterprise/flux/publish/v1/events/business.direct-banking.credit-cards.entr-prdct.agnt-memo-acct-actvy.create"))
				.withRequestBody(equalToJson(getStringContent(memoFluxValidRequest)))
				.willReturn(okJson(getStringContent(memoFluxValidResponse)).withStatus(200)));

		stubFor(post(
				urlPathMatching("/enterprise/flux/publish/v1/events/business.direct-banking.credit-cards.entr-prdct.agnt-memo-acct-actvy.create"))
				.withRequestBody(equalToJson(getStringContent(memoFluxInvalidRequest)))
				.willReturn(aResponse().withStatus(500)));
	}

	public static void setWiremockCsidReportingService() throws IOException {
		stubFor(get(urlPathMatching("/cardissuer/itp/csid/reporting/v1/itp/alert/PDDB203091733124810"))
				.willReturn(okJson("[\n" + "]")));

	}

	public static void setWiremockAccountCenterService() throws IOException {
		stubFor(post(
				urlPathMatching("/enterprise/products/itp/account/v1/customer/profile"))
				.withRequestBody(equalToJson(getStringContent(validUpdateCustomerProfileInfoRequest)))
				.willReturn(okJson(getStringContent(validUpdateCustomerProfileInfoResponse)).withStatus(200)));

		stubFor(post(
				urlPathMatching("/enterprise/products/itp/account/v1/customer/profile"))
				.withRequestBody(equalToJson(getStringContent(invalidCustomerProfileInfoRequestNoData)))
				.willReturn(aResponse().withStatus(204)));

		stubFor(post(
				urlPathMatching("/enterprise/products/itp/account/v1/customer/profile"))
				.withRequestBody(equalToJson(getStringContent(validCustomerProfileInfoRequestReturns500)))
				.willReturn(aResponse().withStatus(500)));
	}
	
	public static ApiStatus successfulApiStatus(String url) {
		return ApiStatus.builder()
				.url(url)
				.status("UP")
				.build();
	}

	public static ApiStatus unsuccessfulApiStatus(String url) {
		return ApiStatus.builder()
				.url(url)
				.status("DOWN")
				.build();
	}
}
