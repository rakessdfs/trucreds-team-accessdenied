package com.discover.cmpp.action.itp.languagesettings;

import com.discover.cmpp.action.itp.common.AbstractIntegrationTest;
import com.discover.cmpp.action.itp.languagesettings.model.LanguageSettingsEntity;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertNotNull;

class LanguageSettingsRepositoryTest extends AbstractIntegrationTest {

    @Autowired
    private LanguageSettingsRepository languageSettingsRepository;

    @Test
    @DisplayName("Should save Language Settings information")
    void save_whenInvoked_shouldSaveLanguageSettingsInformation() {

        LanguageSettingsEntity languageSettingsEntity = LanguageSettingsEntity.builder()
                .languageCode("EN")
                .productEnrollmentId("9090123456789012345")
                .createBy("agent1")
                .createTs(LocalDateTime.now())
                .updateBy("agent1")
                .updateTs(LocalDateTime.now()).build();

        assertNotNull(languageSettingsRepository.save(languageSettingsEntity));
    }
}
