package com.discover.cmpp.action.itp.common;

import com.discover.cmpp.action.itp.accountactivity.AccountActivityException;
import com.discover.cmpp.action.itp.accountcenter.ItpAccountCenterException;
import com.discover.cmpp.action.itp.accountcenter.customer.profile.CustomerProfileConstants;
import com.discover.cmpp.action.itp.call.CallException;
import com.discover.cmpp.action.itp.cancel.CancelException;
import com.discover.cmpp.action.itp.cloak.CloakException;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.custlookup.CustLookUpConstants;
import com.discover.cmpp.action.itp.custlookup.CustLookUpException;
import com.discover.cmpp.action.itp.custlookup.model.CustomerSearchRequest;
import com.discover.cmpp.action.itp.flux.FluxException;
import com.discover.cmpp.action.itp.membership.MembershipConstants;
import com.discover.cmpp.action.itp.membership.MembershipException;
import com.discover.cmpp.action.itp.membership.RequestReasonsException;
import com.discover.cmpp.action.itp.memo.MemoException;
import com.discover.cmpp.action.itp.languagesettings.LanguageSettingsConstants;
import com.discover.cmpp.action.itp.languagesettings.LanguageSettingsException;
import com.discover.cmpp.action.itp.oob.OobSoapException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import static org.junit.Assert.assertTrue;

@ExtendWith(MockitoExtension.class)
class ActionItpExceptionHandlerTest {
    @InjectMocks
    private ActionItpExceptionHandler exceptionHandler;
    @Mock
    HttpServletRequest httpRequest;

    private static ValidatorFactory validatorFactory;
    private static Validator validator;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testHandleConstraintValidations() {
        CustomerSearchRequest test = new CustomerSearchRequest();
        test.setDateOfBirth("dfs");
        validatorFactory = Validation.buildDefaultValidatorFactory();
        validator = validatorFactory.getValidator();
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleConstraintValidations(new ConstraintViolationException(validator.validate(test)));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testHandleCustLookUpException() {
        ResponseEntity<ErrorResponse> response =
                exceptionHandler.handleCustLookUpException(new CustLookUpException("Internal Server error"));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testHandleCustLookUpException_custNotFound() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleCustLookUpException(new CustLookUpException(CustLookUpConstants.ERROR_MSG_CDS_CUST_NOT_FOUND));
        assertTrue(response.getStatusCode().is2xxSuccessful());
    }

    @Test
    void testHandleCustLookUpException_invalidPeidOrSubscriberId() {
       ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleCustLookUpException(new CustLookUpException(ValidationConstants.INVALID_PEID_OR_SUBSCRIBER_EC));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testHandleActionItpApiException() {
        ResponseEntity<ErrorResponse> response =
                exceptionHandler.handleActionItpApiException(new ActionItpException("Internal server error"));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testHandleCloakException() {
        ResponseEntity<ErrorResponse> response = exceptionHandler.handleCloakException(new CloakException("Error"));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testHandleGlobalException() {
        ResponseEntity<ErrorResponse> response = exceptionHandler.handleGlobalException(new Exception("Error"));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testHandleMemoException_peidBlank() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleMemoException(new MemoException(ValidationConstants.PEID_INVALID_EC));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testHandleMemoException_peidNotFound() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleMemoException(new MemoException(ValidationConstants.PEID_NO_CONTENT_EC));
        assertTrue(response.getStatusCode().is2xxSuccessful());
    }

    @Test
    void testHandleMemoException_peidInternalServerError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleMemoException(new MemoException(ValidationConstants.INTERNAL_SERVER_ISSUE_EC));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testHandleMemoException() {
        ResponseEntity<ErrorResponse> response = exceptionHandler.handleMemoException(new MemoException("Error"));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testHandleAccountActivityException_peidBlank() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleAccountActivityException(new AccountActivityException(ValidationConstants.PEID_INVALID_EC));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testHandleAccountActivityException_peidNotFound() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleAccountActivityException(new AccountActivityException(ValidationConstants.PEID_NO_CONTENT_EC));
        assertTrue(response.getStatusCode().is2xxSuccessful());
    }

    @Test
    void testHandleAccountActivityException_peidInternalServerError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleAccountActivityException(
                        new AccountActivityException(ValidationConstants.INTERNAL_SERVER_ISSUE_EC));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testHandleAccountActivityException_codeEntities_InternalServerError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleAccountActivityException(
                        new AccountActivityException(ValidationConstants.FAILED_TO_GET_CODE_ENTITIES_EC));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testHandleAccountActivityException_InvalidOperator() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleAccountActivityException(new AccountActivityException(ValidationConstants.INVALID_OPERATOR_EC));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testHandleAccountActivityException_InvalidRequestDate() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleAccountActivityException(new AccountActivityException(ValidationConstants.INVALID_REQUEST_DATE_EC));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testHandleAccountActivityException() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleAccountActivityException(new AccountActivityException("Error"));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testHandleAccountActivityException_No_Content() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleAccountActivityException(new AccountActivityException(ValidationConstants.ACCOUNT_ACTIVITY_NO_CONTENT_EC));
        assertTrue(response.getStatusCode().is2xxSuccessful());
    }

    @Test
    void testHandleAccountActivityException_No_Code_Entities_No_Content() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleAccountActivityException(new AccountActivityException(ValidationConstants.NO_CODE_ENTITIES_EC));
        assertTrue(response.getStatusCode().is2xxSuccessful());
    }

    @Test
    void testHandleMembershipExceptionMembershipNotFound() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleMembershipException(new MembershipException(MembershipConstants.MEMBERSHIP_NOT_FOUND));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testHandleMembershipExceptionInternalServerError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleMembershipException(new MembershipException(ValidationConstants.INTERNAL_SERVER_ISSUE_EC));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testHandleCallException_invalidPeid() {
        ResponseEntity<ErrorResponse> response = exceptionHandler.handleCallException(
                new CallException(ValidationConstants.PEID_INVALID_EC));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testHandleCalltException_invalidCustomerType() {
        ResponseEntity<ErrorResponse> response = exceptionHandler.handleCallException(
                new CallException(ValidationConstants.INVALID_CUST_TYPE_EC));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testHandleCallException_invalidAgentId() {
        ResponseEntity<ErrorResponse> response = exceptionHandler.handleCallException(
                new CallException(ValidationConstants.AGENT_ID_INVALID_EC));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testHandleCallException_internalServerError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler.handleCallException(
                        new CallException(ValidationConstants.INTERNAL_SERVER_ISSUE_EC));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testHandleCallException() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleCallException(new CallException("Error"));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testHandleCancelException_invalidMembershipId() {
        ResponseEntity<ErrorResponse> response = exceptionHandler.handleCancelException(
                new CancelException(ValidationConstants.MEMBERSHIP_ID_NOT_FOUND_EC));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testHandleCancelException_BadRequest() {
        ResponseEntity<ErrorResponse> response = exceptionHandler.handleCancelException(
                new CancelException(ValidationConstants.BAD_REQUEST));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testHandleCancelException() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleCancelException(new CancelException("Error"));
               assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testHandleCallException_inactiveCall() {
        ResponseEntity<ErrorResponse> response = exceptionHandler.handleCallException(
                new CallException(ValidationConstants.CALL_NOT_ACTIVE_EC));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testHandleCallException_verifyCall() {
        ResponseEntity<ErrorResponse> response = exceptionHandler.handleCallException(
                new CallException(ValidationConstants.ERROR_VERIFYING_CALL_EC));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testHandleRequestReasonsNotFound() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleRequestReasonsException(new RequestReasonsException(MembershipConstants.REQUEST_REASONS_NOT_FOUND));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void estHandleRequestReasons_invalidAgentId() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleRequestReasonsException(new RequestReasonsException(ValidationConstants.AGENT_ID_INVALID_EC));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testHandleRequestReasonsServerError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleRequestReasonsException(new RequestReasonsException(MembershipConstants.REQUEST_REASONS_ERROR));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testFluxExceptionServerError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleFluxException(new FluxException(ValidationConstants.ERROR_FLUX_PAYLOAD_EC));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testPublishingFluxExceptionServerError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleFluxException(new FluxException(ActionItpConstants.FLUX_PUBLISH_ERROR));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testOobSoapExceptionServerError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleOobSoapException(new OobSoapException(ValidationConstants.ERROR_OOB_SERVICE_EC));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testCustKeyNullEmptyServerError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleOobSoapException(new OobSoapException(ValidationConstants.ERROR_OOB_SERVICE_CUST_KEY_EMPTY_EM));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testUserNotExistServerError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleOobSoapException(new OobSoapException(ValidationConstants.ERROR_OOB_SERVICE_USER_NOT_FOUND_EM));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testUserKeyTooLongError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleOobSoapException(new OobSoapException(ValidationConstants.ERROR_OOB_SERVICE_CUST_KEY_LONG_EM));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testPasscodeInvalidError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleOobSoapException(new OobSoapException(ValidationConstants.ERROR_OOB_SERVICE_PASSCODE_INVALID_EM));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testUserLockedError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleOobSoapException(new OobSoapException(ValidationConstants.ERROR_OOB_SERVICE_USER_LOCKED_EM));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testOobFailedToLock() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleOobSoapException(new OobSoapException(ValidationConstants.ERROR_OOB_SERVICE_FAILED_TO_LOCK_EM));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testLanguageSettingsNoContentPeidException() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleLanguageSettingsException(new LanguageSettingsException(ValidationConstants.PEID_NO_CONTENT_EC));
        assertTrue(response.getStatusCode().is2xxSuccessful());
    }

    @Test
    void testLanguageSettingsInvalidPeidError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleLanguageSettingsException(new LanguageSettingsException(ValidationConstants.PEID_INVALID_EC));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testLanguageSettingsInvalidLanguageCodeError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleLanguageSettingsException(new LanguageSettingsException(ValidationConstants.ERROR_LANGUAGE_CODE_EC));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testLanguageSettingsDbSavingError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleLanguageSettingsException(new LanguageSettingsException(LanguageSettingsConstants.SAVE_LANGUAGE_EXCEPTION));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testLanguageSettingsNoDataUpdate() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleLanguageSettingsException(new LanguageSettingsException(ValidationConstants.LANGUAGE_NO_DATA_UPDATE_EM));
        assertTrue(response.getStatusCode().is2xxSuccessful());
    }

    @Test
    void testLanguageSettingsGeneralInternalServerError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleLanguageSettingsException(new LanguageSettingsException("Error Occured"));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testGlobalParsingError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleGlobalException(new Exception(ValidationConstants.JSON_PARSING_ERROR));
        assertTrue(response.getStatusCode().is4xxClientError());
    }

    @Test
    void testGlobalGeneralError() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleGlobalException(new Exception("Error Occured"));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testHandleItpAccountCenterException() {
        ResponseEntity<ErrorResponse> response =
                exceptionHandler.handleItpAccountCenterException(new ItpAccountCenterException("Internal Server error"));
        assertTrue(response.getStatusCode().is5xxServerError());
    }

    @Test
    void testHandleItpAccountCenter_custNotFound() {
        ResponseEntity<ErrorResponse> response = exceptionHandler
                .handleItpAccountCenterException(
                        new ItpAccountCenterException(CustomerProfileConstants.API_CUST_PROFILE_NOT_FOUND_ERROR));
        assertTrue(response.getStatusCode().is2xxSuccessful());
    }
}
