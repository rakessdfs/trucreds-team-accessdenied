package com.discover.cmpp.action.itp.accountactivity;

import com.discover.cmpp.action.itp.accountactivity.model.AccountActivityResponse;
import com.discover.cmpp.action.itp.accountactivity.model.AccountActivityCodeRequest;
import com.discover.cmpp.action.itp.flux.schema.AccountActivityPayload;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.util.NestedServletException;

import java.util.ArrayList;

import static com.discover.cmpp.action.itp.accountactivity.AccountActivityConstants.FETCH_ACCOUNT_ACTIVITY_CODES_URL;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class AccountActivityControllerTest {

    @InjectMocks
    AccountActivityController accountActivityController;
    @Mock
    AccountActivityService accountActivityService;
    private MockMvc mockMvc;
    private AccountActivityPayload request;
    private AccountActivityCodeRequest codeRequest;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(accountActivityController)
                .addPlaceholderValue("api.context-path", TestUtils.contextPath).build();
        request = new AccountActivityPayload();
        request.setOperator("Test");
        request.setProductEnrollmentId("14578625");
        request.setRequestDate("2021-09-11");
        request.setActivityCode("EUR");

        codeRequest = new AccountActivityCodeRequest();
        codeRequest.setActivityCode("AUR");
        codeRequest.setActivityDesc("CUSTMR ADDR CHGND VIA (PHONE/INTERNET)");
        codeRequest.setCategory("ITP Account Center");
    }

    @Test
    void test_createActivity() throws Exception {
        Mockito.doNothing().when(accountActivityService).createActivity(any());
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(request);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + AccountActivityConstants.CREATE_ACTIVITY_URL)
                .contentType("application/json").content(requestJson)).andExpect(status().isCreated()).andReturn();
        String resultResponse = result.getResponse().getContentAsString();
        assertNotNull(resultResponse);
    }

    @Test
    void test_createActivity_badRequest() throws Exception {
        request.setOperator("");
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(request);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + AccountActivityConstants.CREATE_ACTIVITY_URL)
                .contentType("application/json").content(requestJson)).andExpect(status().isBadRequest()).andReturn();
        String resultResponse = result.getResponse().getContentAsString();
        assertNotNull(resultResponse);
    }

    @Test
    void test_createActivity_internalServerError() throws Exception {
        Mockito.doThrow(new AccountActivityException("Error")).when(accountActivityService).createActivity(any());
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(request);
        assertThrows(NestedServletException.class, () -> mockMvc.perform(post(
                TestUtils.contextPath + AccountActivityConstants.CREATE_ACTIVITY_URL)
                .contentType("application/json").content(requestJson)));

    }

    @Test
    void test_fetchAccountActivity_internalServerError() throws Exception {
        Mockito.doThrow(new AccountActivityException("Error occurred"))
                .when(accountActivityService).fetchAccountActivityByPeid(any());
        assertThrows(NestedServletException.class, () -> mockMvc.perform(get(
                TestUtils.contextPath + TestUtils.FETCH_ACCOUNT_ACTIVITY_PATH + "12345")));
    }

    @Test
    void test_fetchAccountActivityByPeid() throws Exception {
        Mockito.when(accountActivityService.fetchAccountActivityByPeid(any())).thenReturn(new AccountActivityResponse());

        MvcResult result = mockMvc.perform(
                get(TestUtils.contextPath + TestUtils.FETCH_ACCOUNT_ACTIVITY_PATH + "12345"))
                .andExpect(status().isOk()).andReturn();
        String resultResponse = result.getResponse().getContentAsString();
        assertNotNull(resultResponse);
    }

    @Test
    void test_createAccountActivityCode() throws Exception {
        Mockito.doNothing().when(accountActivityService).createAccountActivityCode(any());
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(codeRequest);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + AccountActivityConstants.CREATE_ACCOUNT_ACTIVITY_CODE_URL)
                .contentType("application/json").content(requestJson)).andExpect(status().isCreated()).andReturn();
        String resultResponse = result.getResponse().getContentAsString();
        assertNotNull(resultResponse);
    }

    @Test
    void test_createAccountActivityCode_badRequest() throws Exception {
        codeRequest.setCategory("");
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(codeRequest);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + AccountActivityConstants.CREATE_ACCOUNT_ACTIVITY_CODE_URL)
                .contentType("application/json").content(requestJson)).andExpect(status().isBadRequest()).andReturn();
        String resultResponse = result.getResponse().getContentAsString();
        assertNotNull(resultResponse);
    }

    @Test
    void test_createAccountActivityCode_internalServerError() throws Exception {
        Mockito.doThrow(new AccountActivityException("Error")).when(accountActivityService).createAccountActivityCode(any());
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(codeRequest);
        assertThrows(NestedServletException.class, () -> mockMvc.perform(post(
                TestUtils.contextPath + AccountActivityConstants.CREATE_ACCOUNT_ACTIVITY_CODE_URL)
                .contentType("application/json").content(requestJson)));

    }

    @Test
    void test_fetchAccountActivityConstants() throws Exception {
        Mockito.when(accountActivityService.fetchAccountActivityCodes(any(), any()))
                .thenReturn(new ArrayList<>());

        MvcResult result = mockMvc.perform(
                get(TestUtils.contextPath + FETCH_ACCOUNT_ACTIVITY_CODES_URL))
                .andExpect(status().isOk()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }
}
