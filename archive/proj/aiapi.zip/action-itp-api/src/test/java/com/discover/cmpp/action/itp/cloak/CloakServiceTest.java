package com.discover.cmpp.action.itp.cloak;

import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ActionItpUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.executable.ExecutableValidator;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CloakServiceTest {
    @InjectMocks
    private CloakService cloakService = new CloakServiceImpl();
    @Mock
    CloakClient client;
    @Mock
    ActionItpUtil itpUtil;
    Map<String, String> headerMap = new HashMap<>();
    private Set<ConstraintViolation<CloakService>> constraintViolations;

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }

    // tokenizeSsn
    @Test
    void testtokenizeSsn() throws CloakException, ActionItpException {
        CloakTokenizeResponse response = new CloakTokenizeResponse();
        response.setToken("115566778");
        when(client.tokenize(any(), any()))
                .thenReturn(new ResponseEntity<>(response, HttpStatus.OK));
        assertTrue(cloakService.tokenizeSsn(headerMap, "123456789").equalsIgnoreCase(response.getToken()));
    }

    @ParameterizedTest
    @CsvSource({
            "tokenizeSsn,765456789",
            "tokenizeDob,1975-01-01",
            "detokenizeSsn,054150854",
            "detokenizeDob,1565-12-21"
    })
    void testValidTokenizeAndDetokenize(String name, String param) throws NoSuchMethodException {
        Method method = CloakService.class.getDeclaredMethod(name, new Class[] { Map.class, String.class });
        ExecutableValidator executableValidator =
                Validation.buildDefaultValidatorFactory().getValidator().forExecutables();
        constraintViolations =
                executableValidator.validateParameters(cloakService, method, new Object[] { param });
        assertTrue(constraintViolations.isEmpty());
    }

    @Test
    void testtokenizeSsnNullResponse() {
        when(client.tokenize(any(), any())).thenReturn(new ResponseEntity<>(null, HttpStatus.FORBIDDEN));
        assertThrows(CloakException.class, () -> cloakService.tokenizeSsn(headerMap, "115566778"));
    }

    @Test
    void testtokenizeSsnHttpStatusNot2XX() {
        when(client.tokenize(any(), any())).thenReturn(new ResponseEntity<>(null, HttpStatus.BAD_REQUEST));
        assertThrows(CloakException.class, () -> cloakService.tokenizeSsn(headerMap, "115566778"));
    }

    @Test
    void testtokenizeSsnTokenGenerationError() {
        when(client.tokenize(any(), any())).thenReturn(new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR));
        assertThrows(CloakException.class, () -> cloakService.tokenizeSsn(headerMap, "115566778"));
    }

    // tokenizeDob
    @Test
    void testtokenizeDob() throws CloakException, ActionItpException {
        CloakTokenizeResponse response = new CloakTokenizeResponse();
        response.setToken("1234-12-12");
        when(client.tokenize(any(), any()))
                .thenReturn(new ResponseEntity<>(response, HttpStatus.OK));
        assertTrue(cloakService.tokenizeDob(headerMap, "2012-12-12").equalsIgnoreCase(response.getToken()));
    }

    @Test
    void testtokenizeDobNullResponse() {
        when(client.tokenize(any(), any())).thenReturn(new ResponseEntity<>(null, HttpStatus.FORBIDDEN));
        assertThrows(CloakException.class, () -> cloakService.tokenizeDob(headerMap, "2012-12-12"));
    }

    @Test
    void testtokenizeDobHttpStatusNot2XX() {
        when(client.tokenize(any(), any())).thenReturn(new ResponseEntity<>(null, HttpStatus.BAD_REQUEST));
        assertThrows(CloakException.class, () -> cloakService.tokenizeDob(headerMap, "2012-12-12"));
    }

    @Test
    void testtokenizeDobTokenGenerationError() {
        when(client.tokenize(any(), any())).thenReturn(new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR));
        assertThrows(CloakException.class, () -> cloakService.tokenizeDob(headerMap, "2012-12-12"));
    }

    // detokenizeSsn
    @Test
    void testDetokenizeSsn() throws CloakException, ActionItpException {
        CloakDetokenizeResponse response = new CloakDetokenizeResponse();
        response.setValue("123456789");
        when(client.detokenize(any(), any()))
                .thenReturn(new ResponseEntity<>(response, HttpStatus.OK));
        assertTrue(cloakService.detokenizeSsn(headerMap, "115566778").equalsIgnoreCase(response.getValue()));
    }

    @Test
    void testDetokenizeSsnNullResponse() {
        when(client.detokenize(any(), any())).thenReturn(new ResponseEntity<>(null, HttpStatus.FORBIDDEN));
        assertThrows(CloakException.class, () -> cloakService.detokenizeSsn(headerMap, "115566778"));
    }

    @Test
    void testDetokenizeSsnHttpStatusNot2XX() {
        when(client.tokenize(any(), any())).thenReturn(new ResponseEntity<>(null, HttpStatus.BAD_REQUEST));
        assertThrows(CloakException.class, () -> cloakService.tokenizeSsn(headerMap, "115566778"));
    }

    @Test
    void testDetokenizeSsnTokenGenerationError() {
        when(client.detokenize(any(), any())).thenReturn(new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR));
        assertThrows(CloakException.class, () -> cloakService.detokenizeSsn(headerMap, "115566778"));
    }

    // detokenizeDob
    @Test
    void testDetokenizeDob() throws CloakException, ActionItpException {
        CloakDetokenizeResponse response = new CloakDetokenizeResponse();
        response.setValue("1975-01-01");
        when(client.detokenize(any(), any()))
                .thenReturn(new ResponseEntity<>(response, HttpStatus.OK));
        assertTrue(cloakService.detokenizeSsn(headerMap, "1565-12-21").equalsIgnoreCase(response.getValue()));
    }

    @Test
    void testDetokenizeDobNullResponse() {
        when(client.detokenize(any(), any())).thenReturn(new ResponseEntity<>(null, HttpStatus.FORBIDDEN));
        assertThrows(CloakException.class, () -> cloakService.detokenizeDob(headerMap, "1582-05-23"));
    }

    @Test
    void testDetokenizeDobHttpStatusNot2XX() {
        when(client.detokenize(any(), any())).thenReturn(new ResponseEntity<>(null, HttpStatus.BAD_REQUEST));
        assertThrows(CloakException.class, () -> cloakService.detokenizeDob(headerMap, "1582-05-23"));
    }

    @Test
    void testDetokenizeDobTokenGenerationError() {
        when(client.detokenize(any(), any())).thenReturn(new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR));
        assertThrows(CloakException.class, () -> cloakService.detokenizeDob(headerMap, "1582-05-23"));
    }
}
