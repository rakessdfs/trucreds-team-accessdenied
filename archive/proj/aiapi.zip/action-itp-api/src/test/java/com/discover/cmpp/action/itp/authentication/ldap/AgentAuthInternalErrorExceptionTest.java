package com.discover.cmpp.action.itp.authentication.ldap;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AgentAuthInternalErrorExceptionTest {
    AgentAuthInternalErrorException agentAuthDataParsingException;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCardOpsAgentAuthAuthorizationException() {
        Exception exception = new Exception("Message");
        agentAuthDataParsingException = new AgentAuthInternalErrorException(exception);
        Assert.assertNotNull(agentAuthDataParsingException);
        agentAuthDataParsingException = new AgentAuthInternalErrorException("Message", exception);
        Assert.assertNotNull(agentAuthDataParsingException);
        agentAuthDataParsingException = new AgentAuthInternalErrorException("Message");
        Assert.assertNotNull(agentAuthDataParsingException);
    }
}
