package com.discover.cmpp.action.itp.authentication.ldap;

import com.novusnet.ldap.dsutil.UserEntry;
import netscape.ldap.LDAPException;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import java.util.Vector;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

class AgentAuthServiceTest {
    @InjectMocks
    AgentAuthService agentAuthService = new AgentAuthServiceImpl();
    @Mock
    LdapUtil ldapUtil;
    @Mock
    UserEntry userEntry;
    @Mock
    LdapConfigManager ldapConfigManager;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAuthenticate()
            throws LDAPException, AgentNotAuthenticatedException {
        AgentAuthInputVO inputVO = new AgentAuthInputVO();
        inputVO.setRacf("racf");
        inputVO.setPsswd("psswd");
        AgentAuthOutputVO outputVO = new AgentAuthOutputVO();
        outputVO.setEmail("foo@bar.com");
        outputVO.setFullName("fullName");
        outputVO.setUserName("userName");
        Vector testGroup = new Vector();
        testGroup.add("Action_ITP_DPS-Only");
        when(ldapUtil.authenticate(Mockito.anyString(), Mockito.anyString())).thenReturn(true);
        when(ldapUtil.getUserEntry(Mockito.anyString())).thenReturn(userEntry);
        when(userEntry.getGroupNames()).thenReturn(testGroup);
        when(ldapUtil.getLdapConfigManager()).thenReturn(ldapConfigManager);
        when(ldapUtil.getLdapConfigManager().getBindgroup()).thenReturn("Action_ITP_DPS-Only");
        outputVO = agentAuthService.authenticate(inputVO);
        Assert.assertNotNull(outputVO);
    }

    @Test
    void testAuthenticateLdapException()
            throws LDAPException, AgentNotAuthenticatedException {
        AgentAuthInputVO inputVO = new AgentAuthInputVO();
        inputVO.setRacf("racf");
        inputVO.setPsswd("psswd");
        when(ldapUtil.authenticate(Mockito.anyString(), Mockito.anyString()))
                .thenThrow(new LDAPException("ldapExpection"));
        assertThrows(LDAPException.class, () -> agentAuthService.authenticate(inputVO));
    }

    @Test
    void testAuthenticateAgentNotAuthenticatedException()
            throws LDAPException, AgentNotAuthenticatedException {
        AgentAuthInputVO inputVO = new AgentAuthInputVO();
        inputVO.setRacf("racf");
        inputVO.setPsswd("psswd");
        when(ldapUtil.authenticate(Mockito.anyString(), Mockito.anyString())).thenReturn(false);
        assertThrows(AgentNotAuthenticatedException.class, () -> agentAuthService.authenticate(inputVO));
    }
}