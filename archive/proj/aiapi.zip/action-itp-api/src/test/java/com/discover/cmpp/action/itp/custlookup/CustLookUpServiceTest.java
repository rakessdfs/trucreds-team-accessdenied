package com.discover.cmpp.action.itp.custlookup;

import com.discover.cmpp.action.itp.cloak.CloakException;
import com.discover.cmpp.action.itp.cloak.CloakService;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ActionItpUtil;
import com.discover.cmpp.action.itp.custlookup.model.CustPiiSearchResponse;
import com.discover.cmpp.action.itp.custlookup.model.Customer;
import com.discover.cmpp.action.itp.custlookup.model.CustomerInfoResponse;
import com.discover.cmpp.action.itp.custlookup.model.CustomerSearchRequest;
import com.discover.cmpp.action.itp.custlookup.model.CustomerSearchResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.Address;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.AddressRelationship;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.CdsLocationResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.EmailRelationship;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.Name;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.PhoneRelationship;
import com.discover.cmpp.action.itp.custlookup.model.cdspersonal.CdsPersonalInfoResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdstranslation.CdsTranslationAlternateIdResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdstranslation.CdsTranslationReqSrcCodeResponse;
import com.discover.cmpp.action.itp.membership.MembershipException;
import com.discover.cmpp.action.itp.membership.MembershipService;
import com.discover.cmpp.action.itp.membership.ProductService;
import com.discover.cmpp.action.itp.membership.model.EnrollmentLookupResponse;
import com.discover.cmpp.action.itp.membership.model.MembershipListResponse;
import feign.FeignException;
import feign.Request;
import feign.Response;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.text.ParseException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;

@ExtendWith(MockitoExtension.class)
class CustLookUpServiceTest {

    @InjectMocks
    private CustLookUpService custLookUpService = new CustLookUpServiceImpl();
    @Mock
    CloakService cloakService;
    @Mock
    ActionItpUtil itpUtil;
    @Mock
    CdsService cdsService;
    @Mock
    CdsCustTranslationAccessClient cdsCustomerTranslationalClient;

    Map<String, String> header;
    String partyId;
    @Mock
    ProductService productService;
    @Mock
    MembershipService membershipService;

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCustomerPiiSearch_Success() throws CloakException, ActionItpException, CustLookUpException {
        CustomerSearchRequest customerSearchRequest = getCustPiiLookUpRequestData("01/01/1990", "sdsd", "sdsdsd", null);
        CustPiiSearchResponse custPiiSearchResponse = getCustPiiSearchResponseData();
        Customer customer = new Customer();
        customer.setPartyId("1122222");
        customer.setDobToken("2405-08-05");
        customer.setFirstName("test");
        customer.setLastName("test1");
        List<Customer> customerList = new ArrayList<>();
        customerList.add(customer);
        custPiiSearchResponse.setCustomers(customerList);
        ResponseEntity<CustPiiSearchResponse> custPiiSearchResponseEntity =
                new ResponseEntity<>(custPiiSearchResponse, HttpStatus.OK);
        Mockito.when(cdsService.searchCustomerPii(any(), any())).thenReturn(custPiiSearchResponseEntity);
        CustomerSearchResponse result = custLookUpService.customerSearch("testRacf", customerSearchRequest);
        assertNotNull(result);
    }

    @Test
    void testCustomerPiiSearch_NullPeid() throws CloakException, ActionItpException, CustLookUpException {
        CustomerSearchRequest customerSearchRequest = getCustPiiLookUpRequestData("01/01/1990", "sdsd", "sdsdsd", null);
        CustPiiSearchResponse custPiiSearchResponse = getCustPiiSearchResponseData();
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseIncorrectDataData(), HttpStatus.OK);
        ResponseEntity<CustPiiSearchResponse> custPiiSearchResponseEntity =
                new ResponseEntity<>(custPiiSearchResponse, HttpStatus.OK);
        Mockito.when(cdsService.searchCustomerPii(any(), any())).thenReturn(custPiiSearchResponseEntity);
        CustomerSearchResponse result = custLookUpService.customerSearch("testRacf", customerSearchRequest);
        assertNotNull(result);
    }

    @Test
    void testCustomerPiiSearch_NonOk_status() {
        CustomerSearchRequest customerSearchRequest = getCustPiiLookUpRequestData("01/01/1990", "sdsd", "sdsdsd", null);
        ResponseEntity<CustPiiSearchResponse> custPiiSearchResponseEntity =
                new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        Mockito.when(cdsService.searchCustomerPii(any(), any())).thenReturn(custPiiSearchResponseEntity);
        assertThrows(CustLookUpException.class, () ->
                custLookUpService.customerSearch("testRacf", customerSearchRequest));
    }

    @Test
    void testCustomerPiiSearch_EmptyResponse() throws CloakException, ActionItpException, CustLookUpException {
        CustomerSearchRequest customerSearchRequest = getCustPiiLookUpRequestData("01/01/1990", "sdsd", "sdsdsd", null);
        CustPiiSearchResponse custPiiSearchResponse = getCustPiiSearchResponseDataEmpty();
        ResponseEntity<List<CdsTranslationReqSrcCodeResponse>> cdsTranslationReqSrcCodeResponseEntity =
                new ResponseEntity<>(getCdsTranslationReqSrcCodeResponse("9090123456789012345", "FN"), HttpStatus.OK);
        ResponseEntity<CustPiiSearchResponse> custPiiSearchResponseEntity =
                new ResponseEntity<>(custPiiSearchResponse, HttpStatus.OK);
        Mockito.when(cdsService.searchCustomerPii(any(), any())).thenReturn(custPiiSearchResponseEntity);
        CustomerSearchResponse result = custLookUpService.customerSearch("testRacf", customerSearchRequest);
        assertEquals(0, result.getCustomers().size());
        assertEquals("FN", cdsTranslationReqSrcCodeResponseEntity.getBody().get(0).getAplnDataSrcCde());
    }

    @Test
    void testGetPartyIdFromPeid_Success() throws CloakException, CustLookUpException, ActionItpException {

        CustomerSearchRequest customerSearchRequest = getCustPiiLookUpRequestData(null, null, null, "9090203091733124810");
        List<CdsTranslationAlternateIdResponse> cdsLocationResponseEntity = new ArrayList<>();
        cdsLocationResponseEntity.add(new CdsTranslationAlternateIdResponse("34354555",
                false, "df"));

        ResponseEntity<List<CdsTranslationAlternateIdResponse>> listResponseEntity =
                new ResponseEntity<>(cdsLocationResponseEntity, HttpStatus.OK);

        Mockito.when(cdsService.getPartyId(any(), any())).thenReturn(listResponseEntity);

        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(cdsPersonalInfoResponseEntity);

        CustomerSearchResponse result = custLookUpService.customerSearch("testRacf", customerSearchRequest);
        assertNotNull(result);
        assertNotNull(listResponseEntity.getBody().get(0).getPartyId());
    }

    @Test
    void testGetPartyIdFromSubscriberId_Success() throws CloakException, CustLookUpException, ActionItpException {

        CustomerSearchRequest customerSearchRequest = getCustPiiLookUpRequestData(null, null, null, "PDDB203091733124810");
        List<CdsTranslationAlternateIdResponse> cdsLocationResponseEntity = new ArrayList<>();
        cdsLocationResponseEntity.add(new CdsTranslationAlternateIdResponse("34354555",
                false, "df"));

        ResponseEntity<List<CdsTranslationAlternateIdResponse>> listResponseEntity =
                new ResponseEntity<>(cdsLocationResponseEntity, HttpStatus.OK);

        Mockito.when(cdsService.getPartyId(any(), any())).thenReturn(listResponseEntity);

        EnrollmentLookupResponse enrollmentLookupResponse = new EnrollmentLookupResponse();
        enrollmentLookupResponse.setProductEnrollmentId("9090203091733124810");

        ResponseEntity<EnrollmentLookupResponse> getPeidResponseEntity =
               new ResponseEntity<>(enrollmentLookupResponse, HttpStatus.OK);

        Mockito.when(productService.getPeid(any(), any())).thenReturn(getPeidResponseEntity);

        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(cdsPersonalInfoResponseEntity);

        CustomerSearchResponse result = custLookUpService.customerSearch("testRacf", customerSearchRequest);
        assertNotNull(result);
        assertNotNull(listResponseEntity.getBody().get(0).getPartyId());
    }


    @Test
    void testGetPartyIdFromSubscriberId_Exception() {
        CustomerSearchRequest customerSearchRequest = getCustPiiLookUpRequestData(null, null, null, "PDDB203091733124810");
        List<CdsTranslationAlternateIdResponse> cdsLocationResponseEntity = new ArrayList<>();
        cdsLocationResponseEntity.add(new CdsTranslationAlternateIdResponse("34354555",
                false, "df"));
        ResponseEntity<List<CdsTranslationAlternateIdResponse>> listResponseEntity =
                new ResponseEntity<>(cdsLocationResponseEntity, HttpStatus.OK);
        ResponseEntity<EnrollmentLookupResponse> getPeidResponseEntity =
                new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        Mockito.when(productService.getPeid(any(), any())).thenReturn(getPeidResponseEntity);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        assertThrows(CustLookUpException.class, () ->
                custLookUpService.customerSearch("testRacf", customerSearchRequest));
    }

    @Test
    void testGetPartyIdFromSubscriberId_FeignClient_BadRequest_Exception() {
        CustomerSearchRequest customerSearchRequest = getCustPiiLookUpRequestData(null, null, null, "PDDB203091733124810");
        List<CdsTranslationAlternateIdResponse> cdsLocationResponseEntity = new ArrayList<>();
        cdsLocationResponseEntity.add(new CdsTranslationAlternateIdResponse("34354555",
                false, "df"));
        ResponseEntity<List<CdsTranslationAlternateIdResponse>> listResponseEntity =
                new ResponseEntity<>(cdsLocationResponseEntity, HttpStatus.OK);
        Mockito.when(productService.getPeid(any(), any())).thenThrow(FeignException.errorStatus(
                "referral",
                Response.builder()
                        .status(400)
                        .headers(new HashMap<>())
                        .request(Request.create(Request.HttpMethod.GET, "", Collections.emptyMap(), Request.Body.empty(),null))
                        .build()));
        assertThrows(CustLookUpException.class, () ->
                custLookUpService.customerSearch("testRacf", customerSearchRequest));
    }

    @Test
    void testGetPartyIdFromPeid_PartyIdNotFound_CDSAPIIssue_Exception() {
        CustomerSearchRequest customerSearchRequest = getCustPiiLookUpRequestData(null, null, null, "9090203091733124810");
        List<CdsTranslationAlternateIdResponse> cdsLocationResponseEntity = new ArrayList<>();
        cdsLocationResponseEntity.add(new CdsTranslationAlternateIdResponse(null,
                false, null));
        Mockito.when(cdsService.getPartyId(any(), any()))
                .thenThrow(FeignException.errorStatus(
                        "referral",
                        Response.builder()
                                .status(400)
                                .headers(new HashMap<>())
                                .request(Request.create(Request.HttpMethod.GET, "", Collections.emptyMap(), Request.Body.empty(),null))
                                .build()));
        assertThrows(CustLookUpException.class, () ->
                custLookUpService.customerSearch("testRacf", customerSearchRequest));
     }

    @Test
    void testGetPartyIdFromPeid_InvalidPeidSubscriberId_Exception() throws CloakException, CustLookUpException, ActionItpException {

        CustomerSearchRequest customerSearchRequest = getCustPiiLookUpRequestData(null, null, null, "9090203091733124810");

        Mockito.when(cdsService.getPartyId(any(), any()))
                .thenThrow(FeignException.errorStatus(
                        "referral",
                        Response.builder()
                                .status(404)
                                .headers(new HashMap<>())
                                .request(Request.create(Request.HttpMethod.GET, "", Collections.emptyMap(), Request.Body.empty(),null))
                                .build()));

        CustomerSearchResponse result = custLookUpService.customerSearch("testRacf", customerSearchRequest);
        assertTrue(result.getCustomers().isEmpty());
    }

    @Test
    void testCustomerPiiInfo_Success()
            throws CloakException, ActionItpException, CustLookUpException, MembershipException {

        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity =
                new ResponseEntity<>(getCdsLocationResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(cdsPersonalInfoResponseEntity);
        Mockito.when(membershipService.fetchMemberships(any())).thenReturn(getCancelMemberResponse("ENR"));
        CustomerInfoResponse result = custLookUpService.customerInfo("testRacf", "123456");
        assertEquals(cdsLocationResponseEntity.getBody().getAddresses().get(0).getAddress(), result.getAddress());
        assertEquals(cdsLocationResponseEntity.getBody().getEmails().get(0).getEmailAddress(), result.getEmail());
        assertEquals(cdsLocationResponseEntity.getBody().getPhones().get(0).getPhoneNbr(), result.getPrimaryPhone());
    }

    @Test
    void testCustomerPiiInfo_Success_User_Identifier_Null()
            throws CloakException, ActionItpException, CustLookUpException, MembershipException {
        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity =
                new ResponseEntity<>(getCdsLocationResponseDataWithNullUserIdentifier(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(cdsPersonalInfoResponseEntity);
        Mockito.when(membershipService.fetchMemberships(any())).thenReturn(getCancelMemberResponse("ENR"));
        CustomerInfoResponse result = custLookUpService.customerInfo("testRacf", "123456");
        assertEquals(cdsLocationResponseEntity.getBody().getAddresses().get(1).getAddress(), result.getAddress());
        assertEquals(cdsLocationResponseEntity.getBody().getEmails().get(0).getEmailAddress(), result.getEmail());
        assertEquals(cdsLocationResponseEntity.getBody().getPhones().get(0).getPhoneNbr(), result.getPrimaryPhone());
    }

    @Test
    void testCustomerPiiInfo_SuccessWithEmptyData()
            throws CloakException, ActionItpException, CustLookUpException, MembershipException {
        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity =
                new ResponseEntity<>(getCdsLocationResponseDataEmpty(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(cdsPersonalInfoResponseEntity);
        Mockito.when(membershipService.fetchMemberships(any())).thenReturn(getCancelMemberResponse("ENR"));
        CustomerInfoResponse result = custLookUpService.customerInfo("testRacf", "123456");
        assertNull(result.getAddress());
        assertEquals("", result.getPrimaryPhone());
        assertEquals("", result.getEmail());
    }



    @Test
    void testCustomerPiiInfo_CloakApiIssue() throws CloakException, ActionItpException {
        Mockito.lenient().when(cloakService.tokenizeSsn(any(), any())).thenThrow(new CloakException("Invalid dob"));
        assertThrows(CustLookUpException.class, () ->
                custLookUpService.customerInfo("testRacf", "123456"));
    }

    @Test
    void testCustomerPiiInfo_CdsLocationException() throws ActionItpException, MembershipException {
        CdsLocationResponse locResponse = getCdsLocationResponseData();
        locResponse.getAddresses().set(0, null);
        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity =
                new ResponseEntity<>(locResponse, HttpStatus.OK);
        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);
        Mockito.when(membershipService.fetchMemberships(any())).thenReturn(getCancelMemberResponse("ENR"));
        assertThrows(CustLookUpException.class, () ->
                custLookUpService.customerInfo("testRacf", "123456"));
    }

    @Test
    void testCustomerPiiInfo_CdsPersonalInfoException() {
        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity =
                new ResponseEntity<>(getCdsLocationResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);

        CdsPersonalInfoResponse response = getCdsPersonalInfoResponseData();
        response.getPersonalInfo().get(0).setDobToken(null);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(response, HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(cdsPersonalInfoResponseEntity);
        assertThrows(CustLookUpException.class, () ->
                custLookUpService.customerInfo("testRacf", "123456"));
    }

    @Test
    void testCustomerPiiInfo_CancelMember_WhenLocationDataContainsOnePhoneAddressEmail()
            throws CloakException, ActionItpException, CustLookUpException, MembershipException, ParseException {
        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity =
                new ResponseEntity<>(getCdsLocationResponse_withExpiredData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any()))
                .thenReturn(cdsPersonalInfoResponseEntity);
        Mockito.when(membershipService.fetchMemberships(any())).thenReturn(getCancelMemberResponse("CAN"));
        Mockito.when(membershipService.determineMembershipFromList(any())).thenReturn(getCancelMemberResponse("CAN").get(0));
        Mockito.when(itpUtil.isMemberCancelled(any())).thenReturn(true);
        CustomerInfoResponse result = custLookUpService.customerInfo("testRacf", "123456");
        assertNotNull(result.getAddress());
        assertNotNull(result.getPrimaryPhone());
        assertNotNull(result.getEmail());
    }

    @Test
    void testCustomerPiiInfo_CancelMember_WhenLocationDataContainsMoreThenOnePhone()
            throws CloakException, ActionItpException, CustLookUpException, MembershipException, ParseException {
        CdsLocationResponse response = getCdsLocationResponse_withExpiredData();
        response.getPhones().add(getPhoneRelationship_Expired());
        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity =
                new ResponseEntity<>(response, HttpStatus.OK);
        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any()))
                .thenReturn(cdsPersonalInfoResponseEntity);
        Mockito.when(membershipService.fetchMemberships(any())).thenReturn(getCancelMemberResponse("CAN"));
        Mockito.when(membershipService.determineMembershipFromList(any())).thenReturn(getCancelMemberResponse("CAN").get(0));
        Mockito.when(itpUtil.isMemberCancelled(any())).thenReturn(true);
        CustomerInfoResponse result = custLookUpService.customerInfo("testRacf", "123456");
        assertNotNull(result.getAddress());
        assertTrue(StringUtils.isBlank(result.getPrimaryPhone()));
        assertNotNull(result.getEmail());
    }

    @Test
    void testCustomerPiiInfo_CancelMember_WhenLocationDataContainsMoreThenOneEmail()
            throws CloakException, ActionItpException, CustLookUpException, MembershipException, ParseException {
        CdsLocationResponse response = getCdsLocationResponse_withExpiredData();
        response.getEmails().add(getEmailRelationship_Expried());
        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity =
                new ResponseEntity<>(response, HttpStatus.OK);
        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any()))
                .thenReturn(cdsPersonalInfoResponseEntity);
        Mockito.when(membershipService.fetchMemberships(any())).thenReturn(getCancelMemberResponse("CAN"));
        Mockito.when(membershipService.determineMembershipFromList(any())).thenReturn(getCancelMemberResponse("CAN").get(0));
        Mockito.when(itpUtil.isMemberCancelled(any())).thenReturn(true);
        CustomerInfoResponse result = custLookUpService.customerInfo("testRacf", "123456");
        assertNotNull(result.getAddress());
        assertNotNull(result.getPrimaryPhone());
        assertTrue(StringUtils.isBlank(result.getEmail()));
    }

    @Test
    void testCustomerPiiInfo_CancelMember_WhenLocationDataContainsMoreThenOneAddress()
            throws CloakException, ActionItpException, CustLookUpException, MembershipException {
        CdsLocationResponse response = getCdsLocationResponse_withExpiredData();
        response.getAddresses().add(getAddressRelationship_Expried());
        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity =
                new ResponseEntity<>(response, HttpStatus.OK);
        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any()))
                .thenReturn(cdsPersonalInfoResponseEntity);
        Mockito.when(membershipService.fetchMemberships(any())).thenReturn(getCancelMemberResponse("CAN"));
        CustomerInfoResponse result = custLookUpService.customerInfo("testRacf", "123456");
        assertNull(result.getAddress());
        assertNotNull(result.getPrimaryPhone());
        assertNotNull(result.getEmail());
    }

    @Test
    void testCustomerPiiInfo_CancelMember_WhenLocationDataContainsMoreThenOneAddressEmailPhone()
            throws CloakException, ActionItpException, CustLookUpException, MembershipException {
        CdsLocationResponse response = getCdsLocationResponse_withExpiredData();
        response.getAddresses().add(getAddressRelationship_Expried());
        response.getEmails().add(getEmailRelationship_Expried());
        response.getPhones().add(getPhoneRelationship_Expired());
        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity =
                new ResponseEntity<>(response, HttpStatus.OK);
        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any()))
                .thenReturn(cdsPersonalInfoResponseEntity);
        Mockito.when(membershipService.fetchMemberships(any())).thenReturn(getCancelMemberResponse("CAN"));
        CustomerInfoResponse result = custLookUpService.customerInfo("testRacf", "123456");
        assertNull(result.getAddress());
        assertTrue(StringUtils.isBlank(result.getPrimaryPhone()));
        assertTrue(StringUtils.isBlank(result.getEmail()));
    }

    @Test
    void testCustomerPiiInfo_CancelMember_WhenLocationDataContainsActiveExpiredAddressEmailPhone()
            throws CloakException, ActionItpException, CustLookUpException, MembershipException {
        CdsLocationResponse response = getCdsLocationResponseData();
        response.getAddresses().add(getAddressRelationship_Expried());
        response.getEmails().add(getEmailRelationship_Expried());
        response.getPhones().add(getPhoneRelationship_Expired());
        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity =
                new ResponseEntity<>(response, HttpStatus.OK);
        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any()))
                .thenReturn(cdsPersonalInfoResponseEntity);
        Mockito.when(membershipService.fetchMemberships(any())).thenReturn(getCancelMemberResponse("CAN"));
        CustomerInfoResponse result = custLookUpService.customerInfo("testRacf", "123456");
        assertNotNull(result.getAddress());
        assertEquals("line1", result.getAddress().getAddressLine1());
        assertNotNull(result.getPrimaryPhone());
        assertEquals("5642371223", result.getPrimaryPhone());
        assertNotNull(result.getEmail());
        assertEquals("user@test.com", result.getEmail());
    }

    @Test
    void testCustomerPiiInfo_CancelMember_WhenLocationDataContainsOnlyActiveHomeAddressEmailPhone()
            throws CloakException, ActionItpException, CustLookUpException, MembershipException, ParseException {
        CdsLocationResponse response = getCdsLocationResponseData();
        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity =
                new ResponseEntity<>(response, HttpStatus.OK);
        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any()))
                .thenReturn(cdsPersonalInfoResponseEntity);
        Mockito.when(membershipService.fetchMemberships(any())).thenReturn(getCancelMemberResponse("PCN"));
        Mockito.when(membershipService.determineMembershipFromList(any())).thenReturn(getCancelMemberResponse("PCN").get(0));
        Mockito.when(itpUtil.isMemberCancelled(any())).thenReturn(true);
        CustomerInfoResponse result = custLookUpService.customerInfo("testRacf", "123456");
        assertNotNull(result.getAddress());
        assertEquals("line1", result.getAddress().getAddressLine1());
        assertNotNull(result.getPrimaryPhone());
        assertEquals("5642371223", result.getPrimaryPhone());
        assertNotNull(result.getEmail());
        assertEquals("user@test.com", result.getEmail());
    }

    @Test
    void testCustomerPiiInfo_CancelMember_WhenLocationDataContainsOnlyNonHomeActiveAddressEmailPhone()
            throws CloakException, ActionItpException, CustLookUpException, MembershipException, ParseException {
        CdsLocationResponse response = getCdsLocationResponseData();
        response.getAddresses().get(0).setDesignationCode("002");
        response.getPhones().get(0).setDesignationCode("002");
        response.getEmails().get(0).setDesignationCode("002");
        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity =
                new ResponseEntity<>(response, HttpStatus.OK);
        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any()))
                .thenReturn(cdsPersonalInfoResponseEntity);
        Mockito.when(membershipService.fetchMemberships(any())).thenReturn(getCancelMemberResponse("PCN"));
        Mockito.when(membershipService.determineMembershipFromList(any())).thenReturn(getCancelMemberResponse("PCN").get(0));
        Mockito.when(itpUtil.isMemberCancelled(any())).thenReturn(true);
        CustomerInfoResponse result = custLookUpService.customerInfo("testRacf", "123456");
        assertNotNull(result.getAddress());
        assertEquals("line1", result.getAddress().getAddressLine1());
        assertNotNull(result.getPrimaryPhone());
        assertEquals("5642371223", result.getPrimaryPhone());
        assertNotNull(result.getEmail());
        assertEquals("user@test.com", result.getEmail());
    }

    @Test
    void testCustomerPiiInfo_CancelMember_WhenEmptyLocationData()
            throws CloakException, ActionItpException, CustLookUpException {
        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity =
                new ResponseEntity<>(new CdsLocationResponse(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any()))
                .thenReturn(cdsPersonalInfoResponseEntity);
        CustomerInfoResponse result = custLookUpService.customerInfo("testRacf", "123456");
        assertNull(result.getAddress());
        assertTrue(StringUtils.isBlank(result.getPrimaryPhone()));
        assertTrue(StringUtils.isBlank(result.getEmail()));
    }

    @Test
    void testCustomerPiiInfo_CancelMember_fetchMembershipsApiIssue() throws ActionItpException, MembershipException {
        Mockito.when(membershipService.fetchMemberships(any())).thenThrow(new MembershipException("Membership Error"));
        assertThrows(ActionItpException.class, () ->
                custLookUpService.customerInfo("testRacf", "123456"));
    }

    @Test
    void testCustomerPiiInfo_CancelMember_membershipInfoNotFound() throws ActionItpException, MembershipException {
        Mockito.when(membershipService.fetchMemberships(any())).thenReturn(null);
        assertThrows(ActionItpException.class, () ->
                custLookUpService.customerInfo("testRacf", "123456"));
    }

    @Test
    void testCustomerPiiInfo_CancelMember_locationInfoApiIssue() {
        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity =
                new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);
        assertThrows(CustLookUpException.class, () ->
                custLookUpService.customerInfo("testRacf", "123456"));
    }

    @Test
    void testCustomerPiiInfo_whenItpAddressFirst_ReturnsItpAddress() throws CloakException, ActionItpException, CustLookUpException, MembershipException {
        List<AddressRelationship> addresses = new ArrayList<>();
        addresses.add(createAddressRelationship("ITP", "ITPAddress"));
        addresses.add(createAddressRelationship("BOMIUSER", "BOMIAddress"));

        CdsLocationResponse location = getCdsLocationResponseData();
        location.setAddresses(addresses);
        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity = new ResponseEntity<>(location, HttpStatus.OK);

        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(cdsPersonalInfoResponseEntity);
        Mockito.when(membershipService.fetchMemberships(any())).thenReturn(getCancelMemberResponse("ENR"));
        CustomerInfoResponse result = custLookUpService.customerInfo("testRacf", "123456");
        assertEquals("ITPAddress", result.getAddress().getAddressLine1());
    }

    @Test
    void testCustomerPiiInfo_whenBomiAddressFirst_ReturnsItpAddress() throws CloakException, ActionItpException, CustLookUpException, MembershipException {
        List<AddressRelationship> addresses = new ArrayList<>();
        addresses.add(createAddressRelationship("BOMIUSER", "BOMIAddress"));
        addresses.add(createAddressRelationship("ITP", "ITPAddress"));

        CdsLocationResponse location = getCdsLocationResponseData();
        location.setAddresses(addresses);
        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity = new ResponseEntity<>(location, HttpStatus.OK);

        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(cdsPersonalInfoResponseEntity);
        Mockito.when(membershipService.fetchMemberships(any())).thenReturn(getCancelMemberResponse("ENR"));
        CustomerInfoResponse result = custLookUpService.customerInfo("testRacf", "123456");
        assertEquals("ITPAddress", result.getAddress().getAddressLine1());
    }

    @Test
    void testCustomerPiiInfo_whenNoItpAddress_responseHasNoAddress() throws CloakException, ActionItpException, CustLookUpException, MembershipException {
        List<AddressRelationship> addresses = new ArrayList<>();
        addresses.add(createAddressRelationship("BOMIUSER", "BOMIAddress"));

        CdsLocationResponse location = getCdsLocationResponseData();
        location.setAddresses(addresses);
        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity = new ResponseEntity<>(location, HttpStatus.OK);

        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(cdsPersonalInfoResponseEntity);
        Mockito.when(membershipService.fetchMemberships(any())).thenReturn(getCancelMemberResponse("ENR"));
        CustomerInfoResponse result = custLookUpService.customerInfo("testRacf", "123456");
        assertNull(result.getAddress());
    }

    @Test
    void testCustomerPiiInfo_whenNoNullIdentifier_responseHasNoAddress() throws CloakException, ActionItpException, CustLookUpException, MembershipException {
        List<AddressRelationship> addresses = new ArrayList<>();
        addresses.add(createAddressRelationship(null, "NullAddress"));

        CdsLocationResponse location = getCdsLocationResponseData();
        location.setAddresses(addresses);
        ResponseEntity<CdsLocationResponse> cdsLocationResponseEntity = new ResponseEntity<>(location, HttpStatus.OK);

        Mockito.when(cdsService.getCustomerLocationInfo(any(), any())).thenReturn(cdsLocationResponseEntity);
        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(cdsPersonalInfoResponseEntity);
        Mockito.when(membershipService.fetchMemberships(any())).thenReturn(getCancelMemberResponse("ENR"));
        CustomerInfoResponse result = custLookUpService.customerInfo("testRacf", "123456");
        assertNull(result.getAddress());
    }

    @Test
    void testGetCdsPersonalSearchData_Success() throws CloakException, CustLookUpException, ActionItpException {
        CustomerSearchRequest customerSearchRequest = getCustPiiLookUpRequestData("","","","PD12345678900987654");
        CdsTranslationAlternateIdResponse body = new CdsTranslationAlternateIdResponse(
                "123",true, "PD");
        List<CdsTranslationAlternateIdResponse> list = new ArrayList<>();
        list.add(body);
        ResponseEntity<List<CdsTranslationAlternateIdResponse>> response = new ResponseEntity<>(list, HttpStatus.OK);
        Mockito.when(cdsService.getPartyId(anyMap(), any())).thenReturn(response);

        ResponseEntity<CdsPersonalInfoResponse> cdsPersonalInfoResponseEntity =
                new ResponseEntity<>(getCdsPersonalInfoResponseData(), HttpStatus.OK);
        Mockito.when(cdsService.getCustomerPersonalInfo(any(), any())).thenReturn(cdsPersonalInfoResponseEntity);

        EnrollmentLookupResponse enrollmentLookupResponse = new EnrollmentLookupResponse();
        enrollmentLookupResponse.setProductEnrollmentId("9090203091733124810");

        ResponseEntity<EnrollmentLookupResponse> getPeidResponseEntity =
                new ResponseEntity<>(enrollmentLookupResponse, HttpStatus.OK);

        Mockito.when(productService.getPeid(any(), any())).thenReturn(getPeidResponseEntity);
        CustomerSearchResponse result = custLookUpService.customerSearch("testRacf", customerSearchRequest);
        assertNotNull(result);
    }

    private CustomerSearchRequest getCustPiiLookUpRequestData(String dob, String fName, String lName, String peidOrSubscriberId) {
        CustomerSearchRequest customerSearchRequest = new CustomerSearchRequest();
        customerSearchRequest.setDateOfBirth(dob);
        customerSearchRequest.setFirstName(fName);
        customerSearchRequest.setLastName(lName);
        customerSearchRequest.setPeidOrSubscriberId(peidOrSubscriberId);
        return customerSearchRequest;
    }

    private CustPiiSearchResponse getCustPiiSearchResponseData() {
        CustPiiSearchResponse custPiiSearchResponse = new CustPiiSearchResponse();
        List<Customer> customers = new ArrayList<>();
        Customer customerQuery = new Customer();
        customerQuery.setDobToken("2504-01-22");
        customerQuery.setFirstName("TWANEY");
        customerQuery.setLastName("AZARIYA");
        customerQuery.setPartyId("123456");
        customerQuery.setSsnToken("9876543");
        customers.add(customerQuery);
        custPiiSearchResponse.setCustomers(customers);
        return custPiiSearchResponse;
    }

    private CustPiiSearchResponse getCustPiiSearchResponseDataEmpty() {
        CustPiiSearchResponse custPiiSearchResponse = new CustPiiSearchResponse();
        List<Customer> customers = new ArrayList<>();
        custPiiSearchResponse.setCustomers(customers);
        return custPiiSearchResponse;
    }

    private CdsLocationResponse getCdsLocationResponseData() {
        CdsLocationResponse cdsLocationResponse = new CdsLocationResponse();
        List<AddressRelationship> addresses = new ArrayList<>();
        AddressRelationship addressRelationship = new AddressRelationship();
        Address address = new Address();
        address.setAddressLine1("line1");
        address.setAddressLine2("line2");
        address.setCityName("cityname");
        address.setCountryCode("ccode");
        address.setPostalCode("12345");
        address.setStateOrSectionCode("scode");
        addressRelationship.setAddress(address);
        addressRelationship.setDesignationCode("001");
        addressRelationship.setUpdateUserIdentifier("ITP");
        addresses.add(addressRelationship);
        cdsLocationResponse.setAddresses(addresses);
        List<PhoneRelationship> phones = new ArrayList<>();
        PhoneRelationship phoneRelationship = new PhoneRelationship();
        phoneRelationship.setPhoneNbr("5642371223");
        phoneRelationship.setDesignationCode("001");
        phones.add(phoneRelationship);
        cdsLocationResponse.setPhones(phones);
        List<EmailRelationship> emails = new ArrayList<>();
        EmailRelationship emailRelationship = new EmailRelationship();
        emailRelationship.setEmailAddress("user@test.com");
        emailRelationship.setDesignationCode("001");
        emails.add(emailRelationship);
        cdsLocationResponse.setEmails(emails);
        return cdsLocationResponse;
    }

    private CdsLocationResponse getCdsLocationResponseDataWithNullUserIdentifier() {
        CdsLocationResponse cdsLocationResponse = new CdsLocationResponse();
        List<AddressRelationship> addresses = new ArrayList<>();
        AddressRelationship addressRelationship = new AddressRelationship();
        Address address1 = new Address();
        address1.setAddressLine1("line1");
        address1.setAddressLine2("line2");
        address1.setCityName("cityname");
        address1.setCountryCode("ccode");
        address1.setPostalCode("12345");
        address1.setStateOrSectionCode("scode");
        addressRelationship.setAddress(address1);
        addressRelationship.setDesignationCode("001");
        addressRelationship.setUpdateUserIdentifier(null);
        addressRelationship.setEffectiveTimestamp("1635193804");
        AddressRelationship addressRelationship2 = new AddressRelationship();
        addressRelationship2.setAddress(address1);
        addressRelationship2.setDesignationCode("001");
        addressRelationship2.setUpdateUserIdentifier("BOMIUSER");
        addressRelationship2.setEffectiveTimestamp("1635193790");
        addresses.add(addressRelationship);
        addresses.add(addressRelationship2);
        cdsLocationResponse.setAddresses(addresses);
        List<PhoneRelationship> phones = new ArrayList<>();
        PhoneRelationship phoneRelationship = new PhoneRelationship();
        phoneRelationship.setPhoneNbr("5642371223");
        phoneRelationship.setDesignationCode("001");
        phones.add(phoneRelationship);
        cdsLocationResponse.setPhones(phones);
        List<EmailRelationship> emails = new ArrayList<>();
        EmailRelationship emailRelationship = new EmailRelationship();
        emailRelationship.setEmailAddress("user@test.com");
        emailRelationship.setDesignationCode("001");
        emails.add(emailRelationship);
        cdsLocationResponse.setEmails(emails);
        return cdsLocationResponse;
    }

    private CdsLocationResponse getCdsLocationResponse_withExpiredData() {
        CdsLocationResponse cdsLocationResponse = new CdsLocationResponse();
        List<AddressRelationship> addresses = new ArrayList<>();
        addresses.add(getAddressRelationship_Expried());
        cdsLocationResponse.setAddresses(addresses);
        List<PhoneRelationship> phones = new ArrayList<>();
        phones.add(getPhoneRelationship_Expired());
        cdsLocationResponse.setPhones(phones);
        List<EmailRelationship> emails = new ArrayList<>();
        emails.add(getEmailRelationship_Expried());
        cdsLocationResponse.setEmails(emails);
        return cdsLocationResponse;
    }

    private AddressRelationship getAddressRelationship_Expried(){

        AddressRelationship addressRelationship = new AddressRelationship();
        Address address = new Address();
        address.setAddressLine1("line1Expired");
        address.setAddressLine2("line2Expired");
        address.setCityName("citynameExpired");
        address.setCountryCode("ccodeExpired");
        address.setPostalCode("12345");
        address.setStateOrSectionCode("scode");
        addressRelationship.setAddress(address);
        return addressRelationship;
    }

    private AddressRelationship createAddressRelationship(String updateIdentifier, String line1) {
        AddressRelationship addressRelationship = new AddressRelationship();
        Address address = new Address();
        address.setAddressLine1(line1);
        address.setAddressLine2("line2");
        address.setCityName("cityname");
        address.setCountryCode("ccode");
        address.setPostalCode("12345");
        address.setStateOrSectionCode("scode");
        addressRelationship.setAddress(address);
        addressRelationship.setDesignationCode("001");
        addressRelationship.setUpdateUserIdentifier(updateIdentifier);
        return addressRelationship;
    }

    private PhoneRelationship getPhoneRelationship_Expired(){
        PhoneRelationship phoneRelationship = new PhoneRelationship();
        phoneRelationship.setPhoneNbr("2458755214");
        return phoneRelationship;
    }

    private EmailRelationship getEmailRelationship_Expried(){
        EmailRelationship emailRelationship = new EmailRelationship();
        emailRelationship.setEmailAddress("userExpired@test.com");
        return emailRelationship;
    }

    private CdsLocationResponse getCdsLocationResponseDataEmpty() {
        CdsLocationResponse cdsLocationResponse = new CdsLocationResponse();
        cdsLocationResponse.setAddresses(new ArrayList<>());
        cdsLocationResponse.setPhones(new ArrayList<>());
        cdsLocationResponse.setEmails(new ArrayList<>());
        return cdsLocationResponse;
    }

    private CdsPersonalInfoResponse getCdsPersonalInfoResponseData() {
        CdsPersonalInfoResponse cdsPersonalInfoResponse = new CdsPersonalInfoResponse();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfoArr = new ArrayList<>();
        Name name = new Name();
        name.setFirstName("fewd");
        name.setLastName("wdvv");
        personalInfo.setName(name);
        personalInfo.setSsnToken("382906055");
        personalInfo.setDobToken("482906055");
        personalInfoArr.add(personalInfo);
        cdsPersonalInfoResponse.setPersonalInfo(personalInfoArr);
        return cdsPersonalInfoResponse;
    }

    private CdsPersonalInfoResponse getCdsPersonalInfoResponseFullData() {
        CdsPersonalInfoResponse cdsPersonalInfoResponse = new CdsPersonalInfoResponse();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfoArr = new ArrayList<>();
        Name name = new Name();
        name.setFirstName("fewd");
        name.setLastName("wdvv");
        personalInfo.setName(name);
        personalInfo.setSsnToken("382906055");
        personalInfo.setDobToken("482906055");
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation = new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] partyToSourceIdAssociationList = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[]{partyToSourceIdAssociation};
        partyToSourceIdAssociation.setAlternatePartyId("PDAB345454656343456");
        partyToSourceIdAssociation.setExpiryTimestamp(null);
        partyToSourceIdAssociation.setRequestSourceCode("PD");
        partyToSourceIdAssociationList[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(partyToSourceIdAssociationList);
        personalInfoArr.add(personalInfo);
        cdsPersonalInfoResponse.setPersonalInfo(personalInfoArr);
        return cdsPersonalInfoResponse;
    }

    private CdsPersonalInfoResponse getCdsPersonalInfoResponseIncorrectDataData() {
        CdsPersonalInfoResponse cdsPersonalInfoResponse = new CdsPersonalInfoResponse();
        CdsPersonalInfoResponse.PersonalInfo personalInfo = new CdsPersonalInfoResponse.PersonalInfo();
        List<CdsPersonalInfoResponse.PersonalInfo> personalInfoArr = new ArrayList<>();
        Name name = new Name();
        name.setFirstName("fewd");
        name.setLastName("wdvv");
        personalInfo.setName(name);
        personalInfo.setSsnToken("382906055");
        personalInfo.setDobToken("482906055");
        CdsPersonalInfoResponse.PartyToSourceIdAssociation partyToSourceIdAssociation = new CdsPersonalInfoResponse.PartyToSourceIdAssociation();
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] partyToSourceIdAssociationList = new CdsPersonalInfoResponse.PartyToSourceIdAssociation[]{partyToSourceIdAssociation};
        partyToSourceIdAssociation.setAlternatePartyId("PDAB345454656343457");
        partyToSourceIdAssociation.setExpiryTimestamp(Instant.now());
        partyToSourceIdAssociation.setRequestSourceCode("FN");
        partyToSourceIdAssociationList[0] = partyToSourceIdAssociation;
        personalInfo.setPartyToSourceIdAssociation(partyToSourceIdAssociationList);
        personalInfoArr.add(personalInfo);
        cdsPersonalInfoResponse.setPersonalInfo(personalInfoArr);
        return cdsPersonalInfoResponse;
    }

    private List<CdsTranslationReqSrcCodeResponse> getCdsTranslationReqSrcCodeResponse(String peid, String reqSrcCode) {
        List<CdsTranslationReqSrcCodeResponse> cdsTranslationReqSrcCodeResponseList = new ArrayList<>();
        cdsTranslationReqSrcCodeResponseList.add(new CdsTranslationReqSrcCodeResponse(peid, reqSrcCode));
        return cdsTranslationReqSrcCodeResponseList;
    }

    private List<MembershipListResponse> getCancelMemberResponse(String standingCode) {
        List<MembershipListResponse> membershipList = new ArrayList<>();
        MembershipListResponse membership = new MembershipListResponse();
        membership.setStandingCode(standingCode);
        membershipList.add(membership);
        return membershipList;
    }
}
