package com.discover.cmpp.action.itp.common.health;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.ApiStatus;
import com.discover.cmpp.action.itp.common.CloudPropertiesConfiguration;
import com.discover.cmpp.action.itp.common.health.HealthCheckController;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class HealthCheckControllerTest {
    
    @InjectMocks
    private HealthCheckController healthCheckController;
    private String contextPath = "/products/action/itp/v1";
    private MockMvc mockMvc;

    @Mock
    private HealthCheckService healthCheckService;

    @BeforeEach
    void setUp() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(healthCheckController)
                .addPlaceholderValue("api.context-path", contextPath).build();
    }

    @Test
    void testHealthCheck() throws Exception {
        HealthCheckResponseOutput healthCheckResponseOutput = HealthCheckResponseOutput.builder().buildNumber("0.0.0")
                .configServerStatus(new ApiStatus())
                .featureToggles(new CloudPropertiesConfiguration())
                .status("UP").build();

        when(healthCheckService.performHealthCheck())
                .thenReturn(healthCheckResponseOutput);
        mockMvc.perform(MockMvcRequestBuilders.get(contextPath + ActionItpConstants.HEALTH_CHECK_URL).contentType("application/json"))
                .andExpect(status().isOk());
    }
}
