package com.discover.cmpp.action.itp.oob;

import com.discover.cmpp.action.itp.oob.oobmock.OobMockConfiguration;
import com.discover.internet.service.oob.ao.OOBServiceAOBean;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.xml.ws.Endpoint;

import static org.junit.Assert.assertNotNull;

@ExtendWith(SpringExtension.class)
class OobMockConfigurationTest {
    
    @InjectMocks
    private OobMockConfiguration configMock;
    
    @Test
    @DisplayName("return endpoint")
    void ulrMockConfiguration_endpointShouldReturnEndpointData(){
        Endpoint endPoint = configMock.endpoint();
        assertNotNull(endPoint.getBinding());
        assertNotNull(endPoint.getImplementor());
    }

    @Test
    @DisplayName("return oobServiceAoBean")
    void ulrMockConfiguration_ulrServiceAoBeanShouldReturnEndpointData(){
        OOBServiceAOBean oobService = configMock.oobServiceAoBean();
        assertNotNull(oobService);
    }
}
