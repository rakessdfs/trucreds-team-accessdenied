package com.discover.cmpp.action.itp.contract.consumer;

import com.discover.cmpp.action.itp.custlookup.CdsCustSearchClient;
import com.discover.cmpp.action.itp.custlookup.model.CustPiiSearchRequest;
import com.discover.cmpp.action.itp.custlookup.model.CustPiiSearchResponse;
import feign.FeignException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

// This has a different config because cds apis still don't appear to have
// stubs in the maven-internal-test repo of nexus 3
@AutoConfigureStubRunner(repositoryRoot = "https://nexus2.discoverfinancial.com/repository/maven-internal-prod")
@TestPropertySource(properties = {
        "stubrunner.ids=com.discoverfinancial.cds:custsearch:+:stubs:${stubrunner.runningstubs.custsearch.port}",
        "cdsCustSearch.service.baseUrl=http://localhost:${stubrunner.runningstubs.custsearch.port}/enterprise/customer/search/v1",
})
class CdsCustSearchContractTests extends AbstractConsumerTest {

    @Autowired
    private CdsCustSearchClient cdsCustSearchClient;

    private Map<String, String> headerMap;

    @BeforeEach
    public void setup() {
        headerMap = mockRestClientCommonHeader();
    }

    @Test
    void cdsCustSearchSuccess() {

        CustPiiSearchRequest custPiiSearchRequest = new CustPiiSearchRequest("BOB", "JONES", "2684-01-06");

        headerMap.put("X-USER-ID", "ITP");
        headerMap.put("X-REQUEST-ID", "testRACF");
        ResponseEntity<CustPiiSearchResponse> response = cdsCustSearchClient.customerPiiQuery(headerMap, custPiiSearchRequest);

        assertEquals(200, response.getStatusCode().value());
        assertEquals("BOB", response.getBody().getCustomers().get(0).getFirstName());
        assertEquals("JONES", response.getBody().getCustomers().get(0).getLastName());
        assertEquals("2020-10-10", response.getBody().getCustomers().get(0).getDobToken());
        assertEquals("12345678", response.getBody().getCustomers().get(0).getPartyId());
        assertEquals("123456789", response.getBody().getCustomers().get(0).getSsnToken());
    }

    @Test
    void cdsCustSearch400() {
        CustPiiSearchRequest custPiiSearchRequest = new CustPiiSearchRequest("BOB1234", "JONES", "2684-01-06");

        headerMap.put("X-USER-ID", "ITP");
        headerMap.put("X-REQUEST-ID", "testRACF");
        final FeignException ex = assertThrows(FeignException.class, () -> cdsCustSearchClient.customerPiiQuery(headerMap, custPiiSearchRequest));
        assertEquals(400, ex.status());
    }
}
