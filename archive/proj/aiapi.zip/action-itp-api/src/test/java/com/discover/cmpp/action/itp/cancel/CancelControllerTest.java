package com.discover.cmpp.action.itp.cancel;

import com.discover.cmpp.action.itp.cancel.model.CancelRequest;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class CancelControllerTest {

    @InjectMocks
    CancelController cancelController;

    @Mock
    CancelService cancelService;

    private MockMvc mockMvc;
    private CancelRequest request;

    @BeforeEach
    public void setUp() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(cancelController)
                .addPlaceholderValue("api.context-path", TestUtils.contextPath).build();

        request = CancelRequest.builder()
                .processRequestReasonCode("DNW")
                .processRequestSourceCode("ACT")
                .userId("testRacf")
                .businessOrgCode("EC")
                .contactChannelCode("ACT")
                .build();
    }

    @Test
    void test_cancelCustomer_success() throws Exception {
        Mockito.doNothing().when(cancelService).cancelRequest(any(), any(), any());
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(request);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + CancelConstants.CANCEL_REQUEST_API_URL)
                .header("X-DFSUSER-USER-ID", "testRacf")
                .param(CancelConstants.PRODUCT_ENROLLMENT_ID, "1234")
                .param(CancelConstants.CANCEL_RSN_CDE, "DNW")
                .contentType("application/json")
                .content(requestJson))
                .andExpect(status().isOk()).andReturn();
        String resultResponse = result.getResponse().getContentAsString();
        assertNotNull(resultResponse);
    }
}
