package com.discover.cmpp.action.itp.flux.publish;

import com.discover.cmpp.action.itp.common.ActionItpUtil;
import com.discover.cmpp.action.itp.flux.FluxException;
import com.discover.cmpp.action.itp.flux.publish.FluxPublishFeignClient;
import com.discover.cmpp.action.itp.flux.publish.FluxPublishResponse;
import com.discover.cmpp.action.itp.flux.publish.memo.MemoPublishService;
import com.discover.cmpp.action.itp.flux.publish.memo.MemoPublishServiceImpl;
import com.discover.cmpp.action.itp.flux.schema.MemoMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.discover.cmpp.action.itp.common.ActionItpConstants.ITP_PRODUCT_TYPE_CODE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.eq;

@ExtendWith(SpringExtension.class)
class MemoPublishServiceTest {
    
    @Mock
    ActionItpUtil actionItpUtil;
    
    @Mock
    FluxPublishFeignClient fluxPublishFeignClient;
    
    @InjectMocks
    private MemoPublishServiceImpl memoPublishService;
    
    private FluxPublishResponse fluxPublishResponse;
    
    private MemoMessage memoMessage;
    
    @BeforeEach
    public void init(){
        fluxPublishResponse = mock(FluxPublishResponse.class);
        memoMessage = new MemoMessage(ITP_PRODUCT_TYPE_CODE,
                "9090343434343434",
                "9090343434343434",
                "Test",
                "agent1",
                "2021-05-20 15:00:00",
                "ITP_FF",
                6);
    }
    
    @Test
    void test_PublishEvent_Successful(){
        when(fluxPublishFeignClient.publishMemoEvent(anyMap(),any())).thenReturn(fluxPublishResponse);
        memoPublishService.publishEvent(memoMessage);
        ArgumentCaptor<MemoMessage> captor = ArgumentCaptor.forClass(MemoMessage.class);
        Mockito.verify(fluxPublishFeignClient).publishMemoEvent(anyMap(), captor.capture());
        MemoMessage actualRequest = captor.getValue();
        assertThat(actualRequest.getProductEnrollmentId()).isEqualTo(memoMessage.getProductEnrollmentId());
        assertThat(actualRequest.getCreateAgentId()).isEqualTo(memoMessage.getCreateAgentId());
        assertThat(actualRequest.getCreateTimestamp()).isEqualTo(memoMessage.getCreateTimestamp());
        assertThat(actualRequest.getCustomerType()).isEqualTo(memoMessage.getCustomerType());
        assertThat(actualRequest.getProductType()).isEqualTo(memoMessage.getProductType());
        assertThat(actualRequest.getMemoText()).isEqualTo(memoMessage.getMemoText());
    }

    @Test
    void test_PublishEvent_Throws_Exception(){
        Mockito.doThrow(new FluxException("Error publishing message"))
                .when(fluxPublishFeignClient).publishMemoEvent(anyMap(), any());
       assertThatThrownBy(() -> memoPublishService.publishEvent(memoMessage))
                        .isInstanceOf(FluxException.class)
                        .hasMessage("Error publishing message");
    }
}
