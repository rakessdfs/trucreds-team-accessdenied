package com.discover.cmpp.action.itp.common.health;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.function.Supplier;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class ExternalSystemQueryTaskTest {

    @Mock
    private Supplier<String> mockStatusSupplier;

    private ExternalSystemQueryTask subject;
    private ExternalSystemStatus externalSystemStatus;

    @BeforeEach
    void setUp() {
        when(mockStatusSupplier.get()).thenReturn("UP");

        subject = new ExternalSystemQueryTask( mockStatusSupplier, "someService");
        externalSystemStatus = ExternalSystemStatus.builder()
                .status("UP")
                .serviceName("someService")
                .build();
    }

    @Test
    @DisplayName("Should return status from status supplier")
    void call_whenNoExceptionIsThrown_thenReturnStatusFromSupplier() {
        assertThat(subject.call()).isEqualTo(externalSystemStatus);

        verify(mockStatusSupplier).get();
    }

    @Test
    @DisplayName("Should return DOWN when exception is thrown")
    void call_whenExceptionIsThrown_thenReturnDown() {
        when(mockStatusSupplier.get()).thenThrow(new RuntimeException("oh no!"));

        externalSystemStatus.setStatus("DOWN");
        assertThat(subject.call()).isEqualTo(externalSystemStatus);

        verify(mockStatusSupplier).get();
    }
}
