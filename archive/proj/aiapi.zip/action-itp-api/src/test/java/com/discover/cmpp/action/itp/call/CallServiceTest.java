package com.discover.cmpp.action.itp.call;

import com.discover.cmpp.action.itp.call.model.CiscoRestApiResponse;
import com.discover.cmpp.action.itp.call.model.RecordCallRequest;
import com.discover.cmpp.action.itp.call.model.TagCallRequest;
import com.discover.cmpp.action.itp.call.model.TagCallResponse;
import com.discover.cmpp.action.itp.cloak.CloakException;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ActionItpUtil;
import com.discover.cmpp.action.itp.config.TaggingProperties;
import com.discover.cmpp.action.itp.custlookup.CustLookUpException;
import com.discover.cmpp.action.itp.membership.MembershipException;
import com.discover.cmpp.action.itp.memo.MemoException;
import com.discover.cmpp.action.itp.memo.MemoService;
import feign.FeignException;
import feign.Request;
import feign.Response;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CallServiceTest {

    @InjectMocks
    CallServiceImpl callService;

    @Mock
    VerintRestService verintService;

    @Mock
    ActionItpUtil itpUtil;

    @Mock
    MemoService memoService;

    @Mock
    CiscoRestService ciscoRestService;

    @Mock
    private TaggingProperties taggingProperties;


    private RecordCallRequest request;
    private CiscoRestApiResponse ciscoRestApiResponse;
    private TagCallResponse tagCallResponse;
    private String agentId;

    @BeforeEach
    void init() {
        request = RecordCallRequest.builder().productEnrollmentId("123456789").customerType("ITP_BM").build();
        agentId = "testRacf";

        ciscoRestApiResponse = new CiscoRestApiResponse();
        tagCallResponse = new TagCallResponse();
        CiscoRestApiResponse.UcceObj ucceObj = CiscoRestApiResponse.UcceObj.builder().build();
        CiscoRestApiResponse.Obj obj = CiscoRestApiResponse.Obj.builder().build();
        CiscoRestApiResponse.DnsObject dnsObject = CiscoRestApiResponse.DnsObject.builder().build();
        ucceObj.setObj(obj);
        obj.setDns(dnsObject);
        dnsObject.setExt("0123456789");
        ciscoRestApiResponse.setUcce(ucceObj);
        tagCallResponse.setHttpStatus(HttpStatus.OK.toString());
        tagCallResponse.setContactId("1234567890");
        tagCallResponse.setExt("0123456789");
        tagCallResponse.setSuccess("tag success");
        HashMap<String, Map<String, String>> tagMap = new HashMap<>();
        Map<String, String> broadmarketMap = new HashMap<>();
        broadmarketMap.put("servicing","ITP_SRV");
        broadmarketMap.put("cancel","ITP_BM_CNCL");
        Map<String, String> ff = new HashMap<>();
        ff.put("servicing","ITP_SRV");
        ff.put("cancel","ITP_FF_CNCL");
        tagMap.put("ITP_BM",broadmarketMap);
        tagMap.put("ITP_FF",ff);
        tagMap.put("ITP_BM_FREE", broadmarketMap);
        lenient().when(taggingProperties.getItp()).thenReturn(tagMap);
    }

    @Test
    void test_recordCall_bmCustomer_success() throws ActionItpException, CallException, MemoException,
            CloakException, CustLookUpException, MembershipException {
        when(verintService.tagCall(any(), any())).thenReturn(new ResponseEntity<>(tagCallResponse, HttpStatus.OK));
        when(verintService.contact(any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        when(ciscoRestService.getAgentPhoneExtension(any(), any(), any())).thenReturn(
                new ResponseEntity<>(ciscoRestApiResponse, HttpStatus.OK));
        doNothing().when(memoService).createMemo(any(), any());

        request.setTagType("cancel");
        callService.recordCall(request, agentId);
        verify(itpUtil).restClientHeader();
        verify(verintService).contact(any(), eq("0123456789"));

        ArgumentCaptor<TagCallRequest> captor = ArgumentCaptor.forClass(TagCallRequest.class);
        verify(verintService).tagCall(any(), captor.capture());
        assertEquals("ITP_BM_CNCL", captor.getValue().getTags().getSalesType());
    }

    @Test
    void test_recordCall_bmFreeCustomer_success() throws ActionItpException, CallException, MemoException,
            CloakException, CustLookUpException, MembershipException {
        request.setCustomerType("ITP_BM_FREE");
        when(verintService.tagCall(any(), any())).thenReturn(new ResponseEntity<>(tagCallResponse, HttpStatus.OK));
        when(verintService.contact(any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        when(ciscoRestService.getAgentPhoneExtension(any(), any(), any())).thenReturn(
                new ResponseEntity<>(ciscoRestApiResponse, HttpStatus.OK));
        doNothing().when(memoService).createMemo(any(), any());
        request.setTagType("cancel");
        callService.recordCall(request, agentId);

        verify(itpUtil).restClientHeader();
        verify(verintService).contact(any(), eq("0123456789"));

        ArgumentCaptor<TagCallRequest> captor = ArgumentCaptor.forClass(TagCallRequest.class);
        verify(verintService).tagCall(any(), captor.capture());
        assertEquals("ITP_BM_CNCL", captor.getValue().getTags().getSalesType());
    }

    @Test
    void test_recordCall_ffCustomer_success() throws CallException, MemoException,
            ActionItpException, CloakException, MembershipException, CustLookUpException {
        request.setCustomerType("ITP_FF");
        request.setTagType("cancel");
        when(verintService.tagCall(any(), any())).thenReturn(new ResponseEntity<>(tagCallResponse, HttpStatus.OK));
        when(verintService.contact(any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        when(ciscoRestService.getAgentPhoneExtension(any(), any(), any())).thenReturn(
                new ResponseEntity<>(ciscoRestApiResponse, HttpStatus.OK));
        doNothing().when(memoService).createMemo(any(), any());
        callService.recordCall(request, agentId);

        verify(verintService).contact(any(), eq("0123456789"));

        ArgumentCaptor<TagCallRequest> captor = ArgumentCaptor.forClass(TagCallRequest.class);
        verify(verintService).tagCall(any(), captor.capture());
        assertEquals("ITP_FF_CNCL", captor.getValue().getTags().getSalesType());
    }

    @Test
    void test_recordCall_throwsException_whenTaggingError() throws CallException {
        when(ciscoRestService.getAgentPhoneExtension(any(), any(), any())).thenReturn(
                new ResponseEntity<>(ciscoRestApiResponse, HttpStatus.OK));
        when(verintService.contact(any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        when(verintService.tagCall(any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
        request.setTagType("servicing");
        assertThrows(CallException.class, () -> callService.recordCall(request, agentId));
    }

    @Test
    void test_validateCustomerType_throwsException_whenInvalid() {
        request.setCustomerType("invalid");
        assertThrows(CallException.class, () -> callService.recordCall(request, agentId));
    }

    @Test
    void fetchPhoneExtension_returnsValidExtension_ForAgent() throws CallException {
        when(ciscoRestService.getAgentPhoneExtension(any(), any(), any())).thenReturn(
                new ResponseEntity<>(ciscoRestApiResponse, HttpStatus.OK));

        String ext = callService.getAgentPhoneExtension("mheerma");
        Assert.assertNotNull(ext);
    }

    @Test
    void fetchPhoneExtension_returnsNull_ForAgent_ThrowsException() throws CallException {
        CiscoRestApiResponse.UcceObj ucceObj = CiscoRestApiResponse.UcceObj.builder().build();
        ucceObj.setObj(null);
        ciscoRestApiResponse.setUcce(ucceObj);

        when(ciscoRestService.getAgentPhoneExtension(any(), any(), any())).thenReturn(
                new ResponseEntity<>(ciscoRestApiResponse, HttpStatus.OK));

        assertThrows(CallException.class, () -> callService.getAgentPhoneExtension("mheerma"));
    }

    @Test
    void fetchPhoneExtension_agentNumberNotFound() throws CallException {
        Mockito.lenient().when(ciscoRestService.getAgentPhoneExtension(any(), any(), any())).thenThrow(FeignException.errorStatus(
                "ciscoRest",
                Response.builder()
                        .status(500)
                        .headers(new HashMap<>())
                        .request(Request.create(Request.HttpMethod.GET, "", Collections.emptyMap(), Request.Body.empty(),null))
                        .build()));
        assertThrows(CallException.class, () -> callService.getAgentPhoneExtension("mheerma"));
    }

    @Test
    void contact_throwsException_whenNotInCall() throws CallException {
        when(verintService.contact(any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.ACCEPTED));

        assertFalse(callService.verifyCall(any(), eq("0123456789")));
        verify(verintService).contact(any(), any());
    }

    @Test
    void contact_throwsException_whenServerError() throws CallException {
        when(verintService.contact(any(), any())).thenThrow(new CallException("Error"));

        assertThrows(CallException.class, () -> callService.verifyCall(any(), eq("0123456789")));
    }

    @Test
    void test_recordCall_bmCustomer_success_memofailure() throws ActionItpException, CallException, MemoException,
            CloakException, CustLookUpException, MembershipException {
        request.setTagType("cancel");
        when(verintService.tagCall(any(), any())).thenReturn(new ResponseEntity<>(tagCallResponse, HttpStatus.OK));
        when(ciscoRestService.getAgentPhoneExtension(any(), any(), any())).thenReturn(
                new ResponseEntity<>(ciscoRestApiResponse, HttpStatus.OK));
        when(verintService.contact(any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        doThrow(new MemoException("error")).when(memoService).createMemo(any(), any());
        callService.recordCall(request, agentId);
        verify(itpUtil).restClientHeader();
        ArgumentCaptor<TagCallRequest> captor = ArgumentCaptor.forClass(TagCallRequest.class);
        verify(verintService).tagCall(any(), captor.capture());
        assertEquals("ITP_BM_CNCL", captor.getValue().getTags().getSalesType());
    }

    @Test
    void test_recordCall_bmCustomer_error_memofailure() throws ActionItpException, CallException, MemoException, 
            CloakException, CustLookUpException, MembershipException {
        when(verintService.tagCall(any(), any())).thenThrow(new CallException("er"));
        when(ciscoRestService.getAgentPhoneExtension(any(), any(), any())).thenReturn(
                new ResponseEntity<>(ciscoRestApiResponse, HttpStatus.OK));
        when(verintService.contact(any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        doThrow(new MemoException("error")).when(memoService).createMemo(any(), any());
        request.setTagType("servicing");
        assertThrows(CallException.class, () -> callService.recordCall(request, agentId));
        verify(itpUtil).restClientHeader();
        ArgumentCaptor<TagCallRequest> captor = ArgumentCaptor.forClass(TagCallRequest.class);
        verify(verintService).tagCall(any(), captor.capture());
    }

    @Test
    void test_recordCall_bmCustomer_error_memoSuccess() throws ActionItpException, CallException, MemoException,
            CloakException, CustLookUpException, MembershipException {
        when(verintService.tagCall(any(), any())).thenThrow(new CallException("er"));
        when(ciscoRestService.getAgentPhoneExtension(any(), any(), any())).thenReturn(
                new ResponseEntity<>(ciscoRestApiResponse, HttpStatus.OK));
        when(verintService.contact(any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        doNothing().when(memoService).createMemo(any(), any());
        request.setTagType("servicing");
        assertThrows(CallException.class, () -> callService.recordCall(request, agentId));
        verify(itpUtil).restClientHeader();
        ArgumentCaptor<TagCallRequest> captor = ArgumentCaptor.forClass(TagCallRequest.class);
        verify(verintService).tagCall(any(), captor.capture());
    }


    @Test
    void test_recordCall_bmCustomer_null_memoSuccess() throws ActionItpException, CallException, MemoException,
            CloakException, CustLookUpException, MembershipException {
        when(verintService.tagCall(any(), any())).thenReturn(null);
        when(ciscoRestService.getAgentPhoneExtension(any(), any(), any())).thenReturn(
                new ResponseEntity<>(ciscoRestApiResponse, HttpStatus.OK));
        when(verintService.contact(any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        doNothing().when(memoService).createMemo(any(), any());
        request.setTagType("servicing");
        assertThrows(CallException.class, () -> callService.recordCall(request, agentId));
        verify(itpUtil).restClientHeader();
        ArgumentCaptor<TagCallRequest> captor = ArgumentCaptor.forClass(TagCallRequest.class);
        verify(verintService).tagCall(any(), captor.capture());
    }

    @Test
    void testInvalidSalesType() {
        request.setTagType("xyz");
        assertThrows(CallException.class, () -> callService.recordCall(request, agentId));
    }
}
