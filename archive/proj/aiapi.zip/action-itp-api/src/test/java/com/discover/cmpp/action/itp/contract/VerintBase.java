package com.discover.cmpp.action.itp.contract;

import com.discover.cmpp.action.itp.call.CallController;
import com.discover.cmpp.action.itp.call.CallException;
import com.discover.cmpp.action.itp.call.CallService;
import com.discover.cmpp.action.itp.call.model.RecordCallRequest;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ActionItpExceptionHandler;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import io.restassured.module.mockmvc.RestAssuredMockMvc;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.setup.StandaloneMockMvcBuilder;

import static org.mockito.Mockito.doThrow;

@ExtendWith(SpringExtension.class)
public abstract class VerintBase {

    @InjectMocks
    private CallController callController;

    @Mock
    private CallService callService;

    @BeforeEach
    public void setup() throws CallException, ActionItpException {
        MockitoAnnotations.openMocks(this);

        doThrow(new CallException("Exception: Internal Server Error"))
                .when(callService).recordCall(
                        RecordCallRequest.builder().productEnrollmentId("500").customerType("ITP_BM").tagType("servicing").build(),
                "testRACF");

        StandaloneMockMvcBuilder standaloneMockMvcBuilder =
                MockMvcBuilders.standaloneSetup(callController)
                        .addPlaceholderValue("api.context-path", TestUtils.contextPath)
                        .setControllerAdvice(new ActionItpExceptionHandler());
        RestAssuredMockMvc.standaloneSetup(standaloneMockMvcBuilder);
    }
}
