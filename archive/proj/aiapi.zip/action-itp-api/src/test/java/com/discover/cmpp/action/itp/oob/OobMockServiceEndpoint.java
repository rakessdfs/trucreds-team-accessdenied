package com.discover.cmpp.action.itp.oob;

import com.discover.internet.service.oob.ao.OOBServiceAOBean;
import com.discover.internet.service.oob.vo.GetStatusInputVO;
import com.discover.internet.service.oob.vo.GetStatusOutputVO;
import com.discover.internet.service.oob.vo.GetUserHistoryInputVO;
import com.discover.internet.service.oob.vo.GetUserHistoryOutputVO;
import com.discover.internet.service.oob.vo.HeartBeatInputVO;
import com.discover.internet.service.oob.vo.HeartBeatOutputVO;
import com.discover.internet.service.oob.vo.ReturnStatusVO;
import com.discover.internet.service.oob.vo.SendCodeInputVO;
import com.discover.internet.service.oob.vo.SendCodeOutputVO;
import com.discover.internet.service.oob.vo.SetImpressionInputVO;
import com.discover.internet.service.oob.vo.SetImpressionOutputVO;
import com.discover.internet.service.oob.vo.UnlockUserInputVO;
import com.discover.internet.service.oob.vo.UnlockUserOutputVO;
import com.discover.internet.service.oob.vo.UserCancelInputVO;
import com.discover.internet.service.oob.vo.UserCancelOutputVO;
import com.discover.internet.service.oob.vo.UserVO;
import com.discover.internet.service.oob.vo.ValidateCodeInputVO;
import com.discover.internet.service.oob.vo.ValidateCodeOutputVO;
import org.junit.platform.commons.util.StringUtils;

public class OobMockServiceEndpoint implements OOBServiceAOBean {

    @Override
    public SendCodeOutputVO sendCode(SendCodeInputVO sendCodeInputVO) {
        if (sendCodeInputVO.getCustUserKey().equals("9090211931657114339")) {
            return successSendCode();
        } else if (sendCodeInputVO.getCustUserKey().equals("9090211931657114338")) {
            return errorSendCode();
        } else {
            return null;
        }
    }

    private SendCodeOutputVO successSendCode() {
        SendCodeOutputVO output = new SendCodeOutputVO();
        output.setReturnStatus(buildReturnStatus(0, "SUCCESS, passcode sent"));
        output.setUserInfo(buildUserInfo("OK", "User OK, in good standing", 0));
        return output;
    }

    private SendCodeOutputVO errorSendCode() {
        SendCodeOutputVO output = new SendCodeOutputVO();
        output.setReturnStatus(buildReturnStatus(-2, "USER LOCKED"));
        output.setUserInfo(buildUserInfo("LOCKED", "User locked", 0));
        return output;
    }

    @Override
    public GetStatusOutputVO getStatus(GetStatusInputVO getStatusInputVO) {
        if (getStatusInputVO.getCustUserKey().equals("123456789")) {
            return successGetStatus();
        } else if (getStatusInputVO.getCustUserKey().equals("999999999")) {
            return errorGetStatus();
        } else {
            return null;
        }
    }

    private GetStatusOutputVO successGetStatus() {
        GetStatusOutputVO output = new GetStatusOutputVO();
        output.setActiveCodeChannel("activeCodeChannel");
        output.setActiveCodeChannelValue("activeCodeChannelValue");
        output.setEmailChannelActive(true);
        output.setSmsChannelActive(false);
        output.setVoiceChannelActive(false);
        output.setReturnStatus(buildReturnStatus(0, "success"));
        output.setUserInfo(buildUserInfo("success", "success", 0));
        return output;
    }

    private GetStatusOutputVO errorGetStatus() {
        GetStatusOutputVO output = new GetStatusOutputVO();
        output.setActiveCodeChannel("activeCodeChannel");
        output.setActiveCodeChannelValue("activeCodeChannelValue");
        output.setEmailChannelActive(false);
        output.setSmsChannelActive(false);
        output.setVoiceChannelActive(false);
        output.setReturnStatus(buildReturnStatus(-1, "Not Enrolled"));
        output.setUserInfo(buildUserInfo("Not Enrolled", "Not Enrolled", 0));
        return output;
    }

    @Override
    public ValidateCodeOutputVO validateCode(ValidateCodeInputVO validateCodeInputVO) {
        if (validateCodeInputVO.getCode().equals("123456")) {
            return successValidateCode();
        } else if (validateCodeInputVO.getCode().equals("222222")) {
            return errorValidateCode();
        } else if (validateCodeInputVO.isForceFailure()) {
            return lockUserSuccessValidateCode();
        } else {
            return null;
        }
    }

    private ValidateCodeOutputVO successValidateCode() {
        ValidateCodeOutputVO output = new ValidateCodeOutputVO();
        output.setReturnStatus(buildReturnStatus(0, "SUCCESS, passcode validated"));
        output.setUserInfo(buildUserInfo("OK", "User OK, in good standing", 0));
        return output;
    }

    private ValidateCodeOutputVO errorValidateCode() {
        ValidateCodeOutputVO output = new ValidateCodeOutputVO();
        output.setReturnStatus(buildReturnStatus(-2, "USER LOCKED"));
        output.setUserInfo(buildUserInfo("LOCKED", "User locked", 0));
        return output;
    }

    private ValidateCodeOutputVO lockUserSuccessValidateCode() {
        ValidateCodeOutputVO output = new ValidateCodeOutputVO();
        output.setReturnStatus(buildReturnStatus(-2, "User Locked"));
        output.setUserInfo(buildUserInfo("LK", "User locked", 3));
        return output;
    }

    @Override
    public UnlockUserOutputVO unlockUser(UnlockUserInputVO unlockUserInputVO) {
        if (unlockUserInputVO.getCustUserKey().equals("9090211451820076360")) {
            return successUnlockUser();
        } else if (unlockUserInputVO.getCustUserKey().equals("9090211931657114340343434")) {
            return errorCustKeyTooLongUnlockUser();
        } else if (unlockUserInputVO.getCustUserKey().equals("9090211931657114340")) {
            return errorUserNotExistUnlockUser();
        } else if (StringUtils.isBlank(unlockUserInputVO.getCustUserKey())) {
            return errorCustKeyEmptyNullChecklockUser();
        } else {
            return null;
        }
    }

    private UnlockUserOutputVO successUnlockUser() {
        UnlockUserOutputVO output = new UnlockUserOutputVO();
        output.setReturnStatus(buildReturnStatus(1, "User was not locked, counts cleared"));
        output.setUserInfo(buildUserInfo("OK", "User OK, in good standing", 0));
        return output;
    }

    private UnlockUserOutputVO errorCustKeyTooLongUnlockUser() {
        UnlockUserOutputVO output = new UnlockUserOutputVO();
        output.setReturnStatus(buildReturnStatus(-2, "CUST USER KEY TOO LONG"));
        return output;
    }

    private UnlockUserOutputVO errorUserNotExistUnlockUser() {
        UnlockUserOutputVO output = new UnlockUserOutputVO();
        output.setReturnStatus(buildReturnStatus(-2, "User does not exist"));
        return output;
    }

    private UnlockUserOutputVO errorCustKeyEmptyNullChecklockUser() {
        UnlockUserOutputVO output = new UnlockUserOutputVO();
        output.setReturnStatus(buildReturnStatus(-2, "CUST USER KEY IS NULL OR EMPTY"));
        return output;
    }

    @Override
    public GetUserHistoryOutputVO getUserHistory(GetUserHistoryInputVO getUserHistoryInputVO) {
        return null;
    }

    @Override
    public HeartBeatOutputVO heartBeat(HeartBeatInputVO heartBeatInputVO) {
        return null;
    }

    @Override
    public SetImpressionOutputVO setImpression(SetImpressionInputVO setImpressionInputVO) {
        return null;
    }

    @Override
    public UserCancelOutputVO userCancel(UserCancelInputVO userCancelInputVO) {
        return null;
    }

    private ReturnStatusVO buildReturnStatus(int code, String desc) {
        ReturnStatusVO returnStatusVO = new ReturnStatusVO();
        returnStatusVO.setCode(code);
        returnStatusVO.setDescription(desc);
        return returnStatusVO;
    }

    private UserVO buildUserInfo(String statusCode, String desc, int failedSubmissionCount) {
        UserVO userInfo = new UserVO();
        userInfo.setFailedSubmissionCount(failedSubmissionCount);
        userInfo.setGenerationCount(0);
        userInfo.setLastSubmissionFailureDate(null);
        userInfo.setLastSubmissionSuccessDate(null);
        userInfo.setRemainingGenerationCount(10);
        userInfo.setRemainingSubmissionCount(3);
        userInfo.setUserStatusCode(statusCode);
        userInfo.setUserStatusCodeDesc(desc);
        return userInfo;
    }
}



