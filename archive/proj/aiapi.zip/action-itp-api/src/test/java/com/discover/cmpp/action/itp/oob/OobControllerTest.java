package com.discover.cmpp.action.itp.oob;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.oob.model.GetStatusResponse;
import com.discover.cmpp.action.itp.oob.model.OobServiceAoResponse;
import com.discover.cmpp.action.itp.oob.model.ReturnStatus;
import com.discover.cmpp.action.itp.oob.model.SendCodeRequest;
import com.discover.cmpp.action.itp.oob.model.UnlockUserRequest;
import com.discover.cmpp.action.itp.oob.model.ValidateCodeRequest;
import com.discover.cmpp.action.itp.test.utils.TestUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.util.NestedServletException;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class OobControllerTest {

    @InjectMocks
    private OobController oobController;
    @Mock
    OobService oobService;
    private MockMvc mockMvc;
    private SendCodeRequest sendCodeRequest;
    private ValidateCodeRequest validateCodeRequest;
    private OobServiceAoResponse validateCodeResponse;
    private OobServiceAoResponse validateCodeLockUserResponse;
    private UnlockUserRequest unlockUserRequest;

    @BeforeEach
    void setUp() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(oobController)
                .addPlaceholderValue("api.context-path", TestUtils.contextPath).build();
        ReturnStatus lockedReturnStatus = new ReturnStatus();
        lockedReturnStatus.setCode(-3);

        ReturnStatus validatedReturnStatus = new ReturnStatus();
        validatedReturnStatus.setCode(0);

        sendCodeRequest = new SendCodeRequest();
        sendCodeRequest.setCustomerFirstName("Firstname");
        sendCodeRequest.setCustomerLastName("Lastname");
        sendCodeRequest.setChannelCode("EM");
        sendCodeRequest.setChannelValue("oobtest@test.com");
        sendCodeRequest.setCustUserKey("987654321");

        validateCodeRequest = new ValidateCodeRequest();
        validateCodeRequest.setCustUserKey("987654321");
        validateCodeRequest.setInputCode("12345");
        validateCodeRequest.setLockCustomer(false);

        validateCodeResponse = new OobServiceAoResponse();
        validateCodeResponse.setReturnStatus(validatedReturnStatus);
        validateCodeLockUserResponse = new OobServiceAoResponse();
        validateCodeLockUserResponse.setReturnStatus(lockedReturnStatus);
        unlockUserRequest = new UnlockUserRequest();
        unlockUserRequest.setCustUserKey("987654321");
    }

    @Test
    void test_sendCode_success() throws Exception {
        OobServiceAoResponse response = new OobServiceAoResponse();
        Mockito.when(oobService.sendCode(any(), any())).thenReturn(response);
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(sendCodeRequest);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + OobConstants.SEND_CODE_URL)
                .header(ActionItpConstants.AGENT_ID, "agent1")
                .contentType("application/json").content(requestJson)).andExpect(status().isOk()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }

    @Test
    void test_sendCode_badRequest() throws Exception {
        sendCodeRequest.setChannelCode("TTT");
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(sendCodeRequest);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + OobConstants.SEND_CODE_URL)
                .header(ActionItpConstants.AGENT_ID, "agent1")
                .contentType("application/json").content(requestJson)).andExpect(status().isBadRequest()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }

    @Test
    void test_sendCode_internalServerError() throws Exception {
        Mockito.doThrow(new OobSoapException("Error")).when(oobService).sendCode(any(), any());
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(sendCodeRequest);
        assertThrows(NestedServletException.class, () ->
                mockMvc.perform(post(TestUtils.contextPath + OobConstants.SEND_CODE_URL)
                .header(ActionItpConstants.AGENT_ID, "")
                .contentType("application/json").content(requestJson)).andExpect(status().is5xxServerError()));
    }

    @Test
    void test_getStatus_success() throws Exception {
        Mockito.when(oobService.getStatus(any())).thenReturn(new GetStatusResponse());;
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(sendCodeRequest);
        MvcResult result = mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_STATUS_PATH + "457821487"))
                .andExpect(status().isOk()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }

    @Test
    void test_getStatus_Error() throws Exception {
        Mockito.when(oobService.getStatus(any())).thenThrow(new OobSoapException("Error"));;
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(sendCodeRequest);
        assertThrows(NestedServletException.class, () ->
                mockMvc.perform(get(TestUtils.contextPath + TestUtils.FETCH_STATUS_PATH + "457821487"))
                .andExpect(status().is5xxServerError()));
    }

    @Test
    void test_validateCode_success() throws Exception {
        Mockito.when(oobService.validateOobCode(any())).thenReturn(validateCodeResponse);
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(validateCodeRequest);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + OobConstants.VALIDATE_CODE_URL)
                .contentType("application/json").content(requestJson)).andExpect(status().isOk()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertTrue(resultReponse.contains("0"));
    }

    @Test
    void test_validateCode_lockUser_success() throws Exception {
        Mockito.when(oobService.validateOobCode(any())).thenReturn(validateCodeLockUserResponse);
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        validateCodeRequest.setLockCustomer(true);

        String requestJson = ow.writeValueAsString(validateCodeRequest);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + OobConstants.VALIDATE_CODE_URL)
                .contentType("application/json").content(requestJson)).andExpect(status().isOk()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertTrue(resultReponse.contains("-3"));
    }

    @Test
    void test_validateCode_internalServerError() throws Exception {
        Mockito.doThrow(new OobSoapException("Error")).when(oobService).validateOobCode(any());
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(validateCodeRequest);
        assertThrows(NestedServletException.class, () ->
                mockMvc.perform(post(TestUtils.contextPath + OobConstants.VALIDATE_CODE_URL)
                        .contentType("application/json").content(requestJson)).andExpect(status().is5xxServerError()));
    }

    @Test
    void test_unlockUser_success() throws Exception {
        Mockito.when(oobService.unlockUser(unlockUserRequest, "agent1")).thenReturn(new OobServiceAoResponse());
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(unlockUserRequest);
        MvcResult result = mockMvc.perform(post(TestUtils.contextPath + OobConstants.UNLOCK_USER_URL)
                .header(ActionItpConstants.AGENT_ID, "agent1")
                .contentType("application/json").content(requestJson)).andExpect(status().isOk()).andReturn();
        String resultReponse = result.getResponse().getContentAsString();
        assertNotNull(resultReponse);
    }

    @Test
    void test_unlockUser_Error() throws Exception {
        Mockito.when(oobService.unlockUser(any(UnlockUserRequest.class),any(String.class))).thenThrow(new OobSoapException("Error"));;
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(unlockUserRequest);
        assertThrows(NestedServletException.class, () ->
                mockMvc.perform(post(TestUtils.contextPath +  OobConstants.UNLOCK_USER_URL)
                        .header(ActionItpConstants.AGENT_ID, "agent1")
                        .contentType("application/json").content(requestJson))
                        .andExpect(status().is4xxClientError()));
    }

    @Test
    void test_unlockUser_internalServerError() throws Exception {
        Mockito.doThrow(new OobSoapException("Error")).when(oobService).unlockUser(any(), any());
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String requestJson = ow.writeValueAsString(unlockUserRequest);
        assertThrows(NestedServletException.class, () ->
                mockMvc.perform(post(TestUtils.contextPath + OobConstants.UNLOCK_USER_URL)
                        .header(ActionItpConstants.AGENT_ID, "")
                        .contentType("application/json").content(requestJson)).andExpect(status().is5xxServerError()));
    }
}
