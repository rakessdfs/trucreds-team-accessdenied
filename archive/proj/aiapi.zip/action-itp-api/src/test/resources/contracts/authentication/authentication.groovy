package authentication;

import org.springframework.cloud.contract.spec.Contract

[
        Contract.make {
            description "LDAP Authentication Success."

            request {
                url  ("/enterprise/products/action/itp/v1/agent/authenticate")
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                body(
                        "psswd": "test",
                        "racf" : "testagent"
                )
                method POST()
            }

            response {
                status 200
                headers {
                    header('Authorization': "dummyToken")
                    contentType (applicationJson())
                }
                body([
                        "email":    "testagent@test.com",
                        "fullName": "Test Agent",
                        "userName": "testagent"
                ])
            }
        },


        Contract.make {
            description "should throw 400 Invalid Request Parameters"

            request {
                url  ("/enterprise/products/action/itp/v1/agent/authenticate")
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                body(
                        "racf": "invparams"
                )
                method POST()
            }

            response {
                status 400
            }
        },

        Contract.make {
            description "should return 401 Authentication failed"

            request {
                url  ("/enterprise/products/action/itp/v1/agent/authenticate")
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                body(
                        "psswd": "invalid",
                        "racf" : "failagent"
                )
                method POST()
            }

            response {
                status 401
                headers {
                    contentType (applicationJson())
                }
                body([
                        errors:
                                ["1009": "User not authenticated"]

                ])
            }
        },

        Contract.make {
            description "should throw 404 Resource not Found"

            request {
                url  ("/enterprise/products/action/itp/v1/agent/wrongauthenticate")
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                body(
                        "psswd": "invalid",
                        "racf":  "resourcenotfound"
                )
                method POST()
            }

            response {
                status 404
            }
        },

        Contract.make {
            description "should return 500 Api has encountered an error"

            request {
                url  ("/enterprise/products/action/itp/v1/agent/authenticate")
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                body(
                        "psswd": "error",
                        "racf" : "erroragent"
                )
                method POST()
            }

            response {
                status 500
                headers {
                    contentType (applicationJson())
                }
                body([
                        errors:
                                ["5005": "LDAP Issues"]

                ])
            }
        }
]