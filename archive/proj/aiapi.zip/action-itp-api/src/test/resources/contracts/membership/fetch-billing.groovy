package membership

import org.springframework.cloud.contract.spec.Contract


[
        Contract.make {
            description "should return billing details"
            request {
                url("/enterprise/products/action/itp/v1/membership/billing?peid=1&subscriberId=2&customerType=ITP_FF&partyId=12345")
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    header('X-DFSUSER-USER-ID': 'testRACF')
                    accept(applicationJson())
                }
                method GET()
            }

            response {
                status 200
                headers {
                    contentType(applicationJson())
                }
                body([
                        "pcmAccountNumber": "123456789",
                        "pcmFirstName": "Jamal",
                        "pcmLastName": "Murray",
                        "presenceOfSecondary": "No",
                        "nextBillingDate": null
                ])
            }
        },

        Contract.make {
            description "should return billing details"
            request {
                url("/enterprise/products/action/itp/v1/membership/billing?peid=1&subscriberId=2&customerType=ITP_BM&partyId=12345")
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    header('X-DFSUSER-USER-ID': 'testRACF')
                    accept(applicationJson())
                }
                method GET()
            }

            response {
                status 200
                headers {
                    contentType(applicationJson())
                }
                body([
                        "pcmAccountNumber": null,
                        "pcmFirstName": null,
                        "pcmLastName": null,
                        "presenceOfSecondary": null,
                        "nextBillingDate": "20210222"
                ])
            }
        },

        Contract.make {
            description "should return 400 with invalid request"
            request {
                url("/enterprise/products/action/itp/v1/membership/billing?peid=2&subscriberId=2&customerType=ITP_BM&partyId=12345") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        header('X-DFSUSER-USER-ID': 'testRACF')
                        accept(applicationJson())
                    }
                    method GET()
                }
            }

            response {
                status 400
                headers {
                    contentType(applicationJson())
                }
                body([
                        errors:
                                ["1012":"Invalid productEnrollmentId can't be null or blank"]
                ])
            }
        },

        Contract.make {
            description "should return 404 not found"
            request {
                url("/enterprise/products/action/itp/v1/notfound/membership/billing?peid=3&subscriberId=2&customerType=ITP_BM&partyId=12345") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        contentType(applicationJson())
                        accept(applicationJson())
                    }
                    method GET()
                }
            }

            response {
                status 404
            }
        },

        Contract.make {
            description "should return 500 internal server error"
            request {
                url("/enterprise/products/action/itp/v1/membership/billing?peid=4&subscriberId=2&customerType=ITP_BM&partyId=12345") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        contentType(applicationJson())
                        accept(applicationJson())
                    }
                    method GET()
                }
            }

            response {
                status 500
                headers {
                    contentType (applicationJson())
                }
                body([
                        errors:
                                ["5006": "Internal server error"]

                ])
            }
        }
]