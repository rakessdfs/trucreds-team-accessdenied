package verint

import org.springframework.cloud.contract.spec.Contract

[
        Contract.make {
            priority(1)
            description "record call should return 200 ok"
            request {
                url("/enterprise/products/action/itp/v1/recordCall") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        header('X-DFSUSER-USER-ID': 'testRACF')
                        contentType(applicationJson())
                        accept(applicationJson())
                    }
                    body(
                            "productEnrollmentId": "200",
                            "customerType": "ITP_BM",
                            "tagType" :"servicing"
                    )
                    method POST()
                }
            }

            response {
                status 200
            }
        },

        Contract.make {
            priority(3)
            description "record call should return 400 bad request"
            request {
                url("/enterprise/products/action/itp/v1/recordCall") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        header('X-DFSUSER-USER-ID': 'testRACF')
                        contentType(applicationJson())
                        accept(applicationJson())
                    }
                    body(
                            "customerType": "ITP_BM"
                    )
                    method POST()
                }
            }

            response {
                status 400
                headers {
                    contentType(applicationJson())
                }
                body([
                        "errors": [
                                "1012": "Invalid productEnrollmentId can't be null or blank"
                        ]
                ])
            }
        },

        Contract.make {
            priority(2)
            description "record call should return 500 internal server error"
            request {
                url("/enterprise/products/action/itp/v1/recordCall") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        header('X-DFSUSER-USER-ID': 'testRACF')
                        contentType(applicationJson())
                        accept(applicationJson())
                    }
                    body(
                            "productEnrollmentId": "500",
                            "customerType": "ITP_BM",
                            "tagType" : "servicing"
                    )
                    method POST()
                }
            }

            response {
                status 500
                headers {
                    contentType(applicationJson())
                }
                body([
                        "errors": [
                                "1026": "Error while starting call recording"
                        ]
                ])
            }
        }
]