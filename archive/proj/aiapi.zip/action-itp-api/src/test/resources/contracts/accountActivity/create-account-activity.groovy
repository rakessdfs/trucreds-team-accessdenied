package accountActivity

import org.springframework.cloud.contract.spec.Contract

[
        Contract.make {
            priority(1)
            description "should return create account activity"
            request {
                url("/enterprise/products/action/itp/v1/accountActivity") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        contentType(applicationJson())
                        accept(applicationJson())
                    }
                    body(
                            "activityCode": "WMF",
                            "operator": "ONLINE",
                            "productEnrollmentId": "457821487",
                            "requestDate": "2021-02-16 20:34:59"
                    )
                    method POST()
                }
            }

            response {
                status 201
            }
        },

        Contract.make {
            priority(2)
            description "should return 400 with bad request"
            request {
                url("/enterprise/products/action/itp/v1/accountActivity") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        contentType(applicationJson())
                        accept(applicationJson())
                    }
                    body(
                            "activityCode": "WMF",
                            "operator": "ONLINE",
                            "productEnrollmentId": "457821487"
                    )
                    method POST()
                }
            }

            response {
                status 400
                headers {
                    contentType(applicationJson())
                }
                body([
                        "errors": [
                                "1023": "Invalid Request Date"
                        ]
                ])
            }
        },

        Contract.make {
            description "should return 404 not found"
            request {
                url("/enterprise/products/action/itp/v1/accountActivityZZZ") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        contentType(applicationJson())
                        accept(applicationJson())
                    }
                    body(
                            "activityCode": "WMF",
                            "operator": "ONLINE",
                            "productEnrollmentId": 457821487,
                            "requestDate": "2021-02-16 20:34:59"
                    )
                    method POST()
                }
            }

            response {
                status 404
            }
        },

        Contract.make {
            description "should return 500 internal server error"
            request {
                url("/enterprise/products/action/itp/v1/accountActivity") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        contentType(applicationJson())
                        accept(applicationJson())
                    }
                    body(
                            "activityCode": "500",
                            "operator": "ONLINE",
                            "productEnrollmentId": "457821487",
                            "requestDate": "2021-02-16 20:34:59"
                    )
                    method POST()
                }
            }

            response {
                status 500
                headers {
                    contentType (applicationJson())
                }
                body([
                        errors:
                                ["1022": "Error while inserting record in Account Activity Database"]

                ])
            }
        }
]