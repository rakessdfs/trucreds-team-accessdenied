package membership

import org.springframework.cloud.contract.spec.Contract

[
    Contract.make {
        description "should return fetch membership with FF customer"
        request {
            url("/enterprise/products/action/itp/v1/membership?partyId=1111")
            headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    header('X-DFSUSER-USER-ID': 'testRACF')
                    accept(applicationJson())
                }
                method GET()
        }

        response {
            status 200
            headers {
                contentType(applicationJson())
            }
            body([
                    "cancellationDate": "0",
                    "cancellationRequestDate": "0",
                    "enrollmentDate": "123456789",
                    "enrollmentFailedReason": "",
                    "enrollmentStatus": "Enrolled",
                    "productEnrollmentId": 1,
                    "subscriberNumber": "11",
                    "cancellationReason": "",
                    "customerType": "ITP_FF",
                    "partyId": "1111"
            ])
        }
    },

    Contract.make {
        description "should return fetch membership with BM customer"
        request {
            url("/enterprise/products/action/itp/v1/membership?partyId=1112")
            headers {
                header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                header('X-DFSUSER-USER-ID': 'testRACF')
                accept(applicationJson())
            }
            method GET()
        }

        response {
            status 200
            headers {
                contentType(applicationJson())
            }
            body([
                    "cancellationDate": "0",
                    "cancellationRequestDate": "0",
                    "enrollmentDate": "123456789",
                    "enrollmentFailedReason": "",
                    "enrollmentStatus": "Enrolled",
                    "productEnrollmentId": 1,
                    "subscriberNumber": "11",
                    "cancellationReason": "",
                    "customerType": "ITP_BM",
                    "partyId": "1112"
            ])
        }
    },

    Contract.make {
        description "should return 400 with invalid request"
        request {
            url("/enterprise/products/action/itp/v1/membership?partyId=1212") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    header('X-DFSUSER-USER-ID': "testRACF")
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 400
            headers {
                contentType(applicationJson())
            }
            body([
                    errors:
                            ["1010":"Invalid agentId can't be null or blank"]
            ])
        }
    },

    Contract.make {
        description "should return 404 not found"
        request {
            url("/enterprise/products/action/itp/v1/notfound/membership?partyId=2222") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 404
        }
    },

    Contract.make {
        description "should return 500 internal server error"
        request {
            url("/enterprise/products/action/itp/v1/membership?partyId=3333") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 500
            headers {
                contentType (applicationJson())
            }
            body([
                    errors:
                            ["5006": "Internal server error"]

            ])
        }
    }

]
