package cancel

import org.springframework.cloud.contract.spec.Contract

[
        Contract.make {
            description "create cancel request successfully"
            request {
                url("/enterprise/products/action/itp/v1/cancel/membership?cancelReasonCode=DNW&productEnrollmentId=9090210762045412345") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        header('X-DFSUSER-USER-ID': 'testRACF')
                        contentType(applicationJson())
                        accept(applicationJson())
                    }
                    method POST()
                }
            }

            response {
                status 200
            }
        },

        Contract.make {
            description "should return 400 with bad request"
            request {
                url("/enterprise/products/action/itp/v1/cancel/membership?cancelReasonCode=XYZ&productEnrollmentId=9090210762045412346") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        header('X-DFSUSER-USER-ID': 'testRACF')
                        contentType(applicationJson())
                        accept(applicationJson())
                    }
                    method POST()
                }
            }

            response {
                status 400
            }
        },

        Contract.make {
            description "should return 500 internal server error"
            request {
                url("/enterprise/products/action/itp/v1/cancel/membership?cancelReasonCode=DNW&productEnrollmentId=9090210762045412347") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        header('X-DFSUSER-USER-ID': 'testRACF')
                        contentType(applicationJson())
                        accept(applicationJson())
                    }
                    method POST()
                }
            }

            response {
                status 500
            }
        }
]