package accountActivity

import org.springframework.cloud.contract.spec.Contract

[
    Contract.make {
        description "should return account activity for PEID"
        request {
            url("/enterprise/products/action/itp/v1/accountActivity/200") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 200
            headers {
                contentType(applicationJson())
            }
            body([
                    "accountActivityList": [[
                            "accountActivityId": 12,
                            "productEnrollmentId": "200",
                            "activityDesc": "activityTestDesc1",
                            "previousData": "previousTestData1",
                            "newData": "newTestData1",
                            "operator": "operator1",
                            "requestDate": "2021-01-31T20:28:57",
                    ],
                    [
                            "accountActivityId": 13,
                            "productEnrollmentId": "200",
                            "activityDesc": "activityTestDesc2",
                            "previousData": "previousTestData2",
                            "newData": "newTestData2",
                            "operator": "operator2",
                            "requestDate": "2021-05-30T20:28:57",
                    ]
                    ]
            ])
        }
    },

    Contract.make {
        description "should return 204 - PEID found but no activities"
        request {
            url("/enterprise/products/action/itp/v1/accountActivity/204") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 204
        }
    },

    Contract.make {
        description "should return 404 not found"
        request {
            url("/enterprise/products/action/itp/v1/notfound/accountActivity/404") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 404
        }
    },

    Contract.make {
        description "should return 500 internal server error"
        request {
            url("/enterprise/products/action/itp/v1/accountActivity/500") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 500
            headers {
                contentType (applicationJson())
            }
            body([
                    errors:
                            ["5006": "Internal server error"]

            ])
        }
    }




]
