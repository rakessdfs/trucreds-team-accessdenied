package customerSearch

import org.springframework.cloud.contract.spec.Contract

[
    Contract.make {
        description "should return customers search data when called with first name, last name, and dob"
        request {
            url("/enterprise/products/action/itp/v1/customer/search") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    header('X-DFSUSER-USER-ID': 'testRACF')
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                body(
                        "dateOfBirth": "05/04/2019",
                        "firstName": "ACTION",
                        "lastName": "ITP",
                        "peidOrSubscriberId" : null
                )
                method POST()
            }
        }

        response {
            status 200
            headers {
                contentType(applicationJson())
            }
            body([
                "customers": [
                    [
                         "firstName"    : "ACTION",
                         "lastName"     : "ITP",
                         "partyId"      : "123456",
                         "ssn"          : "1234"
                     ]
                ]
            ])
        }
    },

    Contract.make {
        description "should return customers search data when called with peidOrSubscriberId"
        request {
            url("/enterprise/products/action/itp/v1/customer/search") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    header('X-DFSUSER-USER-ID': 'testRACF')
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                body(
                        "dateOfBirth": "",
                        "firstName": "",
                        "lastName": "",
                        "peidOrSubscriberId" : "9090203091733124810"
                )
                method POST()
            }
        }

        response {
            status 200
            headers {
                contentType(applicationJson())
            }
            body([
                    "customers": [
                            [
                                    "firstName"    : "ACTION",
                                    "lastName"     : "ITP",
                                    "partyId"      : "123456",
                                    "ssn"          : "1234"
                            ]
                    ]
            ])
        }
    },

    Contract.make {
        description "should return 400 with invalid request"
        request {
            url("/enterprise/products/action/itp/v1/customer/search") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    header('X-DFSUSER-USER-ID': 'nullAgentID')
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                body(
                        "dateOfBirth": "05/04/2019",
                        "firstName": "ACTION",
                        "lastName": "ITP",
                        "peidOrSubscriberId": null
                )
                method POST()
            }
        }

        response {
            status 400
            headers {
                contentType(applicationJson())
            }
            body([
                    errors:
                            ["1010": "Invalid agentId can't be null or blank"]
            ])
        }
    },

    Contract.make {
        description "should return 400 with invalid request"
        request {
            url("/enterprise/products/action/itp/v1/customer/search") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    header('X-DFSUSER-USER-ID': 'invalidReq')
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                body(
                        "dateOfBirth": "",
                        "firstName": "",
                        "lastName": "",
                        "peidOrSubscriberId": null
                )
                method POST()
            }
        }

        response {
            status 400
            headers {
                contentType(applicationJson())
            }
            body([
                "errors":
                    [
                        "5000": "Invalid Arguments"
                    ]
            ])
        }
    },

    Contract.make {
        description "should return 404 not found"
        request {
            url("/enterprise/products/action/itp/v1/notfound/search") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    header('X-DFSUSER-USER-ID': 'testRACF')
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                body(
                        "dateOfBirth": "05/04/2019",
                        "firstName": "ACTION",
                        "lastName": "ITP",
                        "peidOrSubscriberId" : null
                )
                method POST()
            }
        }

        response {
            status 404
        }
    },

    Contract.make {
        description "should return 500 internal server error"
        request {
            url("/enterprise/products/action/itp/v1/customer/search") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    header('X-DFSUSER-USER-ID': 'testRACF500')
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                body(
                        "dateOfBirth": "05/04/2019",
                        "firstName": "ACTION",
                        "lastName": "ITP",
                        "peidOrSubscriberId" : null
                )
                method POST()
            }
        }

        response {
            status 500
            headers {
                contentType (applicationJson())
            }
            body([
                    errors:
                            ["5006": "Internal server error"]

            ])
        }
    }

]
