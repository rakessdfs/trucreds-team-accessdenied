package customerInfo

import org.springframework.cloud.contract.spec.Contract

[
    Contract.make {
        description "should return fetch customer information"
        request {
            url("/enterprise/products/action/itp/v1/customer/pii?party-id=111111") {
            headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    header('X-DFSUSER-USER-ID': 'testRACF')
                    accept(applicationJson())
                    contentType(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 200
            headers {
                contentType(applicationJson())
            }
            body([
                "firstName" : "TWANEY",
                "lastName"  : "AZARIYA",
                "email"     : "user123@user.com",
                "address"   : [
                    "barCode": "0",
                    "addressLine1"          : "line 1",
                    "addressLine2"          : "line 2",
                    "cityName"              : "New York",
                    "postalCode"            : "12345",
                    "stateOrSectionCode"    : "NY",
                    "countryCode"           : "USA",
                    "forbidAutoFormatting"  : false
                ],
                "primaryPhone"  : "0987654321",
                "ssn"           : "1234",
                "dateOfBirth"   : "01/01/1970"
            ])
        }
    },

    Contract.make {
        description "should return 400 with invalid request"
        request {
            url("/enterprise/products/action/itp/v1/customer/pii?party-id=222222") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    header('X-DFSUSER-USER-ID': 'nullAgentID')
                    accept(applicationJson())
                    contentType(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 400
            headers {
                contentType(applicationJson())
            }
            body([
                    errors:
                            ["1010": "Invalid agentId can't be null or blank"]
            ])
        }
    },

    Contract.make {
        description "should return 404 not found"
        request {
            url("/enterprise/products/action/itp/v1/notfound/pii") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                }
                method GET()
            }
        }

        response {
            status 404
        }
    },

    Contract.make {
        description "should return 500 internal server error"
        request {
            url("/enterprise/products/action/itp/v1/customer/pii?party-id=444444") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    header('X-DFSUSER-USER-ID': "testRACF500")
                    accept(applicationJson())
                    contentType(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 500
            headers {
                contentType (applicationJson())
            }
            body([
                    errors:
                            ["5006": "Internal server error"]

            ])
        }
    }
]