package session;

import org.springframework.cloud.contract.spec.Contract

[
        Contract.make {
            description "Token Validation Success."

            request {
                url  ("/enterprise/products/action/itp/v1/agent/token/validate")
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                body(
                        "jwtToken": "valid-jwt-token"
                )
                method POST()
            }

            response {
                status 200
                headers {
                    contentType (applicationJson())
                }
                body([
                        "username": "testagent"
                ])
            }
        },


        Contract.make {
            description "should throw 400 Invalid request body"

            request {
                url  ("/enterprise/products/action/itp/v1/agent/token/validate")
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                body(
                        "jwtToken": null
                )
                method POST()
            }

            response {
                status 400
            }
        },

        Contract.make {
            description "should return 401 Authentication failed"

            request {
                url  ("/enterprise/products/action/itp/v1/agent/token/validate")
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                body(
                        "jwtToken": "invalid-jwt-token"
                )
                method POST()
            }

            response {
                status 401
            }
        },

        Contract.make {
            description "should throw 404 Resource not Found"

            request {
                url  ("/enterprise/products/action/itp/v1/agent/token/wrong-validate-endpoint")
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                body(
                        "jwtToken": "invalid"
                )
                method POST()
            }

            response {
                status 404
            }
        }
]