package memos

import org.springframework.cloud.contract.spec.Contract

[
        Contract.make {
            description "should return create memos"
            request {
                url("/enterprise/products/action/itp/v1/memo") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        header('X-DFSUSER-USER-ID': 'testRACF')
                        contentType(applicationJson())
                        accept(applicationJson())
                    }
                    body(
                            "memoText": "Enrolled into ITP F&F",
                            "productEnrollmentId": "457821487",
                    )
                    method POST()
                }
            }

            response {
                status 201
            }
        },

        Contract.make {
            description "should return 400 with invalid agent ID"
            request {
                url("/enterprise/products/action/itp/v1/memo") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        header('X-DFSUSER-USER-ID': 'invalidID')
                        contentType(applicationJson())
                        accept(applicationJson())
                    }
                    body(
                            "memoText": "Enrolled into ITP F&F",
                            "productEnrollmentId": "23456789",
                    )
                    method POST()
                }
            }

            response {
                status 400
                headers {
                    contentType(applicationJson())
                }
                body([
                        "errors": [
                                "1010": "Invalid agentId can't be null or blank"
                        ]
                ])
            }
        },

        Contract.make {
            description "should return 400 with invalid PEID"
            request {
                url("/enterprise/products/action/itp/v1/memo") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        header('X-DFSUSER-USER-ID': '5')
                        contentType(applicationJson())
                        accept(applicationJson())
                    }
                    body(
                            "memoText": "Enrolled into ITP F&F",
                            "productEnrollmentId": " ",
                    )
                    method POST()
                }
            }

            response {
                status 400
                headers {
                    contentType(applicationJson())
                }
                body([
                        "errors": [
                                "1012": "Invalid productEnrollmentId can't be null or blank"
                        ]
                ])
            }
        },

        Contract.make {
            description "should return 400 with invalid memo text"
            request {
                url("/enterprise/products/action/itp/v1/memo") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        header('X-DFSUSER-USER-ID': '6')
                        contentType(applicationJson())
                        accept(applicationJson())
                    }
                    body(
                            "memoText": " ",
                            "productEnrollmentId": "23456789",
                    )
                    method POST()
                }
            }

            response {
                status 400
                headers {
                    contentType(applicationJson())
                }
                body([
                        "errors": [
                                "1011": "Invalid memoText can't be null or blank"
                        ]
                ])
            }
        },

        Contract.make {
            description "should return 404 not found"
            request {
                url("/enterprise/products/action/itp/v1/notfound/memo") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        header('X-DFSUSER-USER-ID': 'testRACF')
                        contentType(applicationJson())
                        accept(applicationJson())
                    }
                    body(
                            "memoText": "Enrolled into ITP F&F",
                            "productEnrollmentId": "457821487",
                    )
                    method POST()
                }
            }

            response {
                status 404
            }
        },

        Contract.make {
            description "should return 500 internal server error"
            request {
                url("/enterprise/products/action/itp/v1/memo") {
                    headers {
                        header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                        header('X-DFSUSER-USER-ID': 'testRACF500')
                        contentType(applicationJson())
                        accept(applicationJson())
                    }
                    body(
                            "memoText": "Enrolled into ITP F&F",
                            "productEnrollmentId": "23456789",
                    )
                    method POST()
                }
            }

            response {
                status 500
                headers {
                    contentType (applicationJson())
                }
                body([
                        errors:
                                ["5006": "Internal server error"]

                ])
            }
        }
]