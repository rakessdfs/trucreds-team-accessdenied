package accountActivity

import org.springframework.cloud.contract.spec.Contract

[
    Contract.make {
        description "should return all activity code entities when no params"
        request {
            url("/enterprise/products/action/itp/v1/accountActivity/fetchCodes") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 200
            headers {
                contentType(applicationJson())
            }
            body([
                    [
                        "createTs": "2022-06-08T16:22:26",
                        "updateTs": "2022-06-08T16:22:26",
                        "accountActivityCodeId": 98,
                        "activityCode": "WMS",
                        "activityDesc": "ITP LVL CHG 8 TO 9 SUCCESS - Welcome E-mail Sent",
                        "category": "Product Change Event Batch"
                    ],
                    [
                        "createTs": "2022-06-08T16:22:26",
                        "updateTs": "2022-06-08T16:22:26",
                        "accountActivityCodeId": 99,
                        "activityCode": "PDU",
                        "activityDesc": "ITP LVL CHG 8 TO 9 SUCCESS - Pearl DB Updated",
                        "category": "Product Change Event Batch"
                    ]
            ])
        }
    },

    Contract.make {
        description "should return matching activity code entity when code param passed"
        request {
            url("/enterprise/products/action/itp/v1/accountActivity/fetchCodes?activityCode=WMS") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 200
            headers {
                contentType(applicationJson())
            }
            body([
                    [
                            "createTs": "2022-06-08T16:22:26",
                            "updateTs": "2022-06-08T16:22:26",
                            "accountActivityCodeId": 98,
                            "activityCode": "WMS",
                            "activityDesc": "ITP LVL CHG 8 TO 9 SUCCESS - Welcome E-mail Sent",
                            "category": "Product Change Event Batch"
                    ]
            ])
        }
    },

    Contract.make {
        description "should return matching activity code entities when category param passed"
        request {
            url("/enterprise/products/action/itp/v1/accountActivity/fetchCodes?category=testCat") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 200
            headers {
                contentType(applicationJson())
            }
            body([
                    [
                            "createTs": "2022-06-08T16:22:26",
                            "updateTs": "2022-06-08T16:22:26",
                            "accountActivityCodeId": 98,
                            "activityCode": "WMS",
                            "activityDesc": "ITP LVL CHG 8 TO 9 SUCCESS - Welcome E-mail Sent",
                            "category": "Product Change Event Batch"
                    ],
                    [
                            "createTs": "2022-06-08T16:22:26",
                            "updateTs": "2022-06-08T16:22:26",
                            "accountActivityCodeId": 99,
                            "activityCode": "PDU",
                            "activityDesc": "ITP LVL CHG 8 TO 9 SUCCESS - Pearl DB Updated",
                            "category": "Product Change Event Batch"
                    ]
            ])
        }
    },

    Contract.make {
        description "should return 204 when no entities found"
        request {
            url("/enterprise/products/action/itp/v1/accountActivity/fetchCodes?activityCode=204") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 204
        }
    },

    Contract.make {
        description "should return 500 if error fetching from db"
        request {
            url("/enterprise/products/action/itp/v1/accountActivity/fetchCodes?category=DBERROR") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 500
            headers {
                contentType (applicationJson())
            }
            body([
                    "errors": [
                            "1063": "Error while fetching code entities"
                    ]
            ])
        }
    }
]
