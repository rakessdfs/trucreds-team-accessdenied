package memos

import org.springframework.cloud.contract.spec.Contract

[
    Contract.make {
        description "should return fetch memos"
        request {
            url("/enterprise/products/action/itp/v1/memo/1") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 200
            headers {
                contentType(applicationJson())
            }
            body([
                    "memosList": [[
                            "memoId": 12,
                            "productEnrollmentId": "1",
                            "memoText": "Enrolled into ITP F&F",
                            "createAgentId": "Peter",
                            "createTs": "2020-08-31T20:28:57",
                            "updateAgentId": null,
                            "updateTs": null
                    ],
                    [
                            "memoId": 13,
                            "productEnrollmentId": "1",
                            "memoText": "Enrolled into ITP F&F",
                            "createAgentId": "Peter",
                            "createTs": "2020-08-31T20:28:57",
                            "updateAgentId": "Peter2",
                            "updateTs": "2020-08-31T20:29:57"
                    ]
                    ]
            ])
        }
    },

    Contract.make {
        description "should return 400 with invalid request"
        request {
            url("/enterprise/products/action/itp/v1/memo/2") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 400
            headers {
                contentType(applicationJson())
            }
            body([
                    errors:
                            ["1012": "Invalid productEnrollmentId can't be null or blank"]
            ])
        }
    },

    Contract.make {
        description "should return 404 not found"
        request {
            url("/enterprise/products/action/itp/v1/notfound/memo/3") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 404
        }
    },

    Contract.make {
        description "should return 500 internal server error"
        request {
            url("/enterprise/products/action/itp/v1/memo/4") {
                headers {
                    header('HTTP_AUTH_TOKEN': $(regex('[0-9A-Za-z=]+')))
                    contentType(applicationJson())
                    accept(applicationJson())
                }
                method GET()
            }
        }

        response {
            status 500
            headers {
                contentType (applicationJson())
            }
            body([
                    errors:
                            ["5006": "Internal server error"]

            ])
        }
    }




]
