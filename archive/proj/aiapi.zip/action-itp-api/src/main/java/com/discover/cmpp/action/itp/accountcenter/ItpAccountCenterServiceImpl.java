package com.discover.cmpp.action.itp.accountcenter;

import com.discover.cmpp.action.itp.accountcenter.model.ApplicantLocationResponse;
import com.discover.cmpp.action.itp.accountcenter.model.UpdatePiiRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class ItpAccountCenterServiceImpl implements ItpAccountCenterService {

    @Autowired
    ItpAccountCenterClient itpAccountCenterClient;

    @Override
    public ResponseEntity<ApplicantLocationResponse> updateCustomerProfileInfo(Map<String, String> headerMap,
                                                                               String partyId,
                                                                               String peId, UpdatePiiRequest request)
            throws ItpAccountCenterException {
        return itpAccountCenterClient.updateCustomerProfileInfo(headerMap, partyId, peId, request);
    }
}
