package com.discover.cmpp.action.itp.memo;

public class MemoConstants {

    private MemoConstants() {
    }

    // create memo
    public static final String CREATE_MEMO_URL = "/memo";
    public static final String CREATE_MEMO_API = "API to create new memo and store it in backend";
    public static final String CREATE_MEMO_API_NOTES =
            "API accepts the request and creates the Memo on the backend DB for the requested Product Enrollment ID.";

    //fetch memo by product Enrollment Id
    public static final String FETCH_MEMO_URL = "/memo/{product-enrollment-id}";
    public static final String FETCH_MEMO_API = "API to Fetch memos based on the product enrollment id";
    public static final String FETCH_MEMO_API_NOTES =
            "API accepts the request and Fetches memos from DB and sends in to frontend";
    public static final String PRODUCT_ENROLLMENT_ID = "product-enrollment-id";
}
