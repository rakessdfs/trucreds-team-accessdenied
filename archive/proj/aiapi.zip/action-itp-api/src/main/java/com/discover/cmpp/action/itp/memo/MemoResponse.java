package com.discover.cmpp.action.itp.memo;

import lombok.Data;

import java.util.List;

@Data
public class MemoResponse {

    List<MemoDto> memosList;
}
