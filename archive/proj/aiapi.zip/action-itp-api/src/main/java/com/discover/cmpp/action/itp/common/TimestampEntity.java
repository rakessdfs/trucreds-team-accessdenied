package com.discover.cmpp.action.itp.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import java.time.LocalDateTime;

@Data
@SuperBuilder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@MappedSuperclass
public class TimestampEntity {

    @Column(name = "CREATE_TS")
    private LocalDateTime createTs;

    @Column(name = "UPDATE_TS")
    private LocalDateTime updateTs;
}
