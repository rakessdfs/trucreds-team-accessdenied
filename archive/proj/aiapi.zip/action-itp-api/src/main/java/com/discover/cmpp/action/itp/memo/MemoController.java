package com.discover.cmpp.action.itp.memo;

import com.discover.cmpp.action.itp.cloak.CloakException;
import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ErrorResponse;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.custlookup.CustLookUpException;
import com.discover.cmpp.action.itp.flux.FluxException;
import com.discover.cmpp.action.itp.membership.MembershipException;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

@RequestMapping(value = "${api.context-path}")
@RestController
@Validated
public class MemoController {

    private MemoService memoService;

    public MemoController(MemoService memoService) {
        this.memoService = memoService;
    }

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = MemoConstants.CREATE_MEMO_API, notes = MemoConstants.CREATE_MEMO_API_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_CREATED, message = ActionItpConstants.API_CREATE),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, message = ActionItpConstants.API_BAD_REQUEST,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS),
            @ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = ActionItpConstants.API_NOT_FOUND)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN, required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN),
            @ApiImplicitParam(name = ActionItpConstants.AGENT_ID, required = true,
                    dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
                    value = ActionItpConstants.AGENT_ID_VALUE)})
    @PostMapping(value = MemoConstants.CREATE_MEMO_URL)
    public <T> ResponseEntity<T> createMemo(
            @RequestHeader(ActionItpConstants.AGENT_ID) @NotBlank(
                    message = ValidationConstants.AGENT_ID_INVALID_EC) String agentId,
            @RequestBody @Valid CreateMemoRequest request) throws MemoException, FluxException,
            ActionItpException, CloakException, MembershipException, CustLookUpException {
        memoService.createMemo(request, agentId);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = MemoConstants.FETCH_MEMO_API, notes = MemoConstants.FETCH_MEMO_API_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_OK, message = ActionItpConstants.API_OK),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, message = ActionItpConstants.API_BAD_REQUEST,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS),
            @ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = ActionItpConstants.API_NOT_FOUND,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_NO_CONTENT, message = ValidationConstants.PEID_NO_CONTENT_EM,
                    response = ErrorResponse.class)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN, required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN)})
    @GetMapping(value = MemoConstants.FETCH_MEMO_URL)
    public ResponseEntity<MemoResponse> fetchMemos(
            @PathVariable(name = MemoConstants.PRODUCT_ENROLLMENT_ID, required = true) @NotBlank(
                    message = ValidationConstants.PEID_INVALID_EC) String productEnrollmentId) throws MemoException {
        return new ResponseEntity<>(memoService.fetchMemos(productEnrollmentId), HttpStatus.OK);
    }
}
