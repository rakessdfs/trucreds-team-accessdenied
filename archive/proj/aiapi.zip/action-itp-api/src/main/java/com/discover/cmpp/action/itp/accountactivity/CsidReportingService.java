package com.discover.cmpp.action.itp.accountactivity;

import java.util.List;
import java.util.Map;

public interface CsidReportingService {

    /**
     * To get next billing data based on the subscriber number provided.
     *
     * @param headerMap        - Request Header map
     * @param subscriberNumber - subscriber number
     * @return - ItpCsidAlertData list
     */

    List<ItpCsidAlertData> getItpAlerts(Map<String, String> headerMap, String subscriberNumber)
            throws AccountActivityException;
}
