package com.discover.cmpp.action.itp.oob;

public enum ChannelCodeEnum {

    EM,
    TXT,
    AM
}
