package com.discover.cmpp.action.itp.membership;

import com.discover.cmpp.action.itp.membership.model.billing.AccountKeySequenceNbrResponse;
import com.discover.cmpp.action.itp.membership.model.billing.AcctKeyTrnsfrSeqNmbrRequest;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class AccountNumberServiceImpl implements AccountNumberService {

    private AccountNumberClient accountNumberClient;

    public AccountNumberServiceImpl(AccountNumberClient accountNumberClient) {
        this.accountNumberClient = accountNumberClient;
    }

    @LogAround
    @LogExecutionTime
    @Override
    /**
     * {@inheritDoc}
     *
     */
    public ResponseEntity<AccountKeySequenceNbrResponse> fetchAccountNumber(Map<String, String> headerMap,
                        AcctKeyTrnsfrSeqNmbrRequest acctKeyTrnsfrSeqNmbrRequest) {
        return accountNumberClient.fetchAccountNumber(headerMap, acctKeyTrnsfrSeqNmbrRequest);
    }
}
