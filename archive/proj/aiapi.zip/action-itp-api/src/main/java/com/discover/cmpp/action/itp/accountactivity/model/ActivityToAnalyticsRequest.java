package com.discover.cmpp.action.itp.accountactivity.model;

import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder(toBuilder = true)
public class ActivityToAnalyticsRequest {

    @ApiModelProperty(value = "Activity code for transferring to analytics (or multiple, comma separated codes)",
            example = "AUR,PUR,EUR", required = true)
    @NotBlank(message = ValidationConstants.ACTIVITY_CODES_INVALID_EC)
    @Size(min = 3, max = 100, message = ValidationConstants.ACTIVITY_CODES_INVALID_EC)
    private String activityCodes;

    @ApiModelProperty(value = "First date to migrate activity data for", example = "2021-02-16 00:00:00")
    private String startDate = null;

    @ApiModelProperty(value = "Last date to migrate activity data for", example = "2021-02-21 00:00:00")
    private String endDate = null;
}