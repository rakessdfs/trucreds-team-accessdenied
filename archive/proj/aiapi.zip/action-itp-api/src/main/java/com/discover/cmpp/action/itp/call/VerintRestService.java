package com.discover.cmpp.action.itp.call;

import com.discover.cmpp.action.itp.call.model.TagCallRequest;
import com.discover.cmpp.action.itp.call.model.TagCallResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Retryable;

import java.util.Map;

public interface VerintRestService {

    /**
     * Calls verint contact endpoint to verify that a call is in progress on the given extension.
     *
     * @param headerMap - api headers.
     * @param ext       - phone extension received from Cisco api.
     * @return Response from verint contact call.
     * @throws CallException if exception hitting endpoint.
     */
    @Retryable
    ResponseEntity<Void> contact(Map<String, String> headerMap, String ext)
            throws CallException;

    /**
     * This method is used to tag the call in Verint, starting recording.
     *
     * @param headerMap - api headers.
     * @param request   - request to tag call - contains peid, ext, and salestype.
     * @return - Response from verint tagging call.
     */
    @Retryable
    ResponseEntity<TagCallResponse> tagCall(Map<String, String> headerMap, TagCallRequest request)
            throws CallException;
}
