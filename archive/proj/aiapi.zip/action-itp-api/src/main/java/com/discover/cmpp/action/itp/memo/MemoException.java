package com.discover.cmpp.action.itp.memo;

public class MemoException extends Exception {

    private static final long serialVersionUID = -7137924831698067982L;

    public MemoException(String message) {
        super(message);
    }
}
