package com.discover.cmpp.action.itp.cloak;

import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ActionItpUtil;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Objects;

@Service
public class CloakServiceImpl implements CloakService {

    @Autowired
    private CloakClient cloakClient;
    @Autowired
    ActionItpUtil itpUtil;

    /**
     * {@inheritDoc}
     *
     * @throws ActionItpException for exceptions
     * @throws CloakException     for cloak errors
     */
    @LogAround
    @LogExecutionTime
    @Override
    public String tokenizeSsn(Map<String, String> headerMap, String ssn) throws CloakException {
        return extractTokenizedResponse(
                cloakClient.tokenize(headerMap, createCloakRequest(ssn, CloakConstants.CLOAK_INPUT_ELEMENT_NAME_SSN)));
    }

    /**
     * {@inheritDoc}
     */
    @LogAround
    @LogExecutionTime
    @Override
    public String tokenizeDob(Map<String, String> headerMap, String dateOfBirth)
            throws CloakException {
        return extractTokenizedResponse(cloakClient.tokenize(headerMap,
                createCloakRequest(dateOfBirth, CloakConstants.CLOAK_INPUT_ELEMENT_NAME_DOB)));
    }

    /**
     * {@inheritDoc}
     */
    @LogAround
    @LogExecutionTime
    @Override
    public String detokenizeSsn(Map<String, String> headerMap, String tokenizedSsn)
            throws CloakException {
        return extractDetokenizedResponse(cloakClient.detokenize(headerMap,
                createCloakRequest(tokenizedSsn, CloakConstants.CLOAK_INPUT_ELEMENT_NAME_SSN)));
    }

    /**
     * {@inheritDoc}
     */
    @LogAround
    @LogExecutionTime
    @Override
    public String detokenizeDob(Map<String, String> headerMap, String tokenizedDateOfBirth)
            throws CloakException {
        return extractDetokenizedResponse(cloakClient.detokenize(headerMap,
                createCloakRequest(tokenizedDateOfBirth, CloakConstants.CLOAK_INPUT_ELEMENT_NAME_DOB)));
    }

    /**
     * Create Cloak Request.
     *
     * @param input SSN or DOB value
     * @param type  SSN or DOB identifier
     * @return {@link CloakRequest}
     */
    private CloakRequest createCloakRequest(String input, String type) {
        return new CloakRequest(input, type, CloakConstants.CLOAK_INPUT_ELEMENT_TYPE);
    }

    /**
     * Extract the tokenized SSN / DOB.
     *
     * @param response tokenized response
     * @return {@link String}
     * @throws CloakException for cloak errors
     */
    private String extractTokenizedResponse(ResponseEntity<CloakTokenizeResponse> response) throws CloakException {
        if (response.getStatusCode().equals(HttpStatus.OK)) {
            return Objects.requireNonNull(response.getBody()).getToken();
        } else {
            throw new CloakException("Error in fetching the SSN Token and the response receieved : " + response);
        }
    }

    /**
     * Extract the detokenized SSN / DOB.
     *
     * @param response detokenized response
     * @return {@link String}
     * @throws CloakException for cloak errors
     */
    private String extractDetokenizedResponse(ResponseEntity<CloakDetokenizeResponse> response) throws CloakException {
        if (response.getStatusCode().equals(HttpStatus.OK)) {
            return Objects.requireNonNull(response.getBody()).getValue();
        } else {
            throw new CloakException("Error in fetching the SSN Token and the response receieved : " + response);
        }
    }
}
