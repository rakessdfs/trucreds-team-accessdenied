package com.discover.cmpp.action.itp.accountactivity;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.List;
import java.util.Map;

@FeignClient(name = "csidReportingClient", url = "${csidReportingApi.service.baseUrl}")
public interface CsidReportingClient {

    @GetMapping(value = "${csidReportingApi.service.itpAlert}")
    ResponseEntity<List<ItpCsidAlertData>> getItpAlerts(@RequestHeader Map<String, String> headerMap,
                                                        @PathVariable("subscriberId") String subscriberId);
}
