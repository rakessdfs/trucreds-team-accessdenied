package com.discover.cmpp.action.itp.accountactivity;

import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class CsidReportingServiceImpl implements CsidReportingService {

    private CsidReportingClient csidReportingClient;

    public CsidReportingServiceImpl(CsidReportingClient csidReportingClient) {
        this.csidReportingClient = csidReportingClient;
    }

    @LogAround
    @LogExecutionTime
    @Override
    /**
     * {@inheritDoc}
     *
     */
    public List<ItpCsidAlertData> getItpAlerts(Map<String, String> headerMap, String subscriberNumber) {
        ResponseEntity<List<ItpCsidAlertData>> response =
                csidReportingClient.getItpAlerts(headerMap, subscriberNumber);
        List<ItpCsidAlertData> result = null;
        if (response.getStatusCode().is2xxSuccessful()) {
            result = response.getBody();
        }
        return result;
    }
}
