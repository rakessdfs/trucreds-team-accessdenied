package com.discover.cmpp.action.itp.languagesettings;

import com.discover.cmpp.action.itp.languagesettings.model.LanguageSettingsRequest;
import com.discover.cmpp.action.itp.languagesettings.model.LanguageSettingsResponse;

public interface LanguageSettingsService {

    /**
     * This method is used to save language settings based on the input request and stores in DB.
     *
     * @param languageSettingsRequest input request with language settings details
     * @throws LanguageSettingsException when exception occurred while saving language settings in DB
     */
    void saveLanguageSettings(LanguageSettingsRequest languageSettingsRequest,
                              String agentId) throws LanguageSettingsException;

    /**
     * This method is used to retrieve language settings details from DB.
     *
     * @param productEnrollmentId input to retrieve language settings details
     * @throws LanguageSettingsException when exception occurred while retrieving language settings from DB
     */
    LanguageSettingsResponse fetchLanguageSettings(String productEnrollmentId) throws LanguageSettingsException;
}
