package com.discover.cmpp.action.itp.call;

import com.discover.cmpp.action.itp.call.model.CiscoRestApiResponse;
import com.discover.cmpp.action.itp.call.model.RecordCallRequest;
import com.discover.cmpp.action.itp.call.model.TagCallRequest;
import com.discover.cmpp.action.itp.call.model.TagCallResponse;
import com.discover.cmpp.action.itp.call.model.Tags;
import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.ActionItpUtil;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.config.TaggingProperties;
import com.discover.cmpp.action.itp.memo.CreateMemoRequest;
import com.discover.cmpp.action.itp.memo.MemoService;
import lombok.SneakyThrows;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Objects;

@Service
public class CallServiceImpl implements CallService {

    private final ActionItpUtil itpUtil;
    private final VerintRestService verintService;
    private final CiscoRestService ciscoRestService;
    private final MemoService memoService;
    private final TaggingProperties taggingProperties;

    public CallServiceImpl(ActionItpUtil itpUtil,
                           CiscoRestService ciscoRestService,
                           VerintRestService verintService,
                           MemoService memoService,
                           TaggingProperties taggingProperties) {
        this.itpUtil = itpUtil;
        this.verintService = verintService;
        this.ciscoRestService = ciscoRestService;
        this.memoService = memoService;
        this.taggingProperties = taggingProperties;
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(CallServiceImpl.class);

    /**
     * {@inheritDoc}
     */
    @Override
    @SneakyThrows
    public void recordCall(RecordCallRequest request, String agentId) {
        LOGGER.info("recordCall: Tag Call starts for PEID and Agent ID {} {}",
                request.getProductEnrollmentId(), agentId);
        ResponseEntity<TagCallResponse> response = null;
        try {
            String salesType = fetchSalesTypeByTagType(request);
            if (null == salesType) {
                throw new CallException(ValidationConstants.TAG_DATA_ERROR_EC);
            }
            Map<String, String> headerMap = itpUtil.restClientHeader();
            String ext = getAgentPhoneExtension(agentId);
            if (!verifyCall(headerMap, ext)) {
                throw new CallException(ValidationConstants.CALL_NOT_ACTIVE_EC);
            }
            response = tagCall(request.getProductEnrollmentId(),
                    ext, headerMap, salesType);
            if (null == response) {
                throw new CallException("Failed to tag call with Verint for Product Enrollment ID " +
                        request.getProductEnrollmentId());
            }
            if (response.getStatusCode() != HttpStatus.OK) {
                throw new CallException("Failed to tag call - " +
                        "Verint returned status code " + response.getStatusCode() +
                        " and Product Enrollment ID : " + request.getProductEnrollmentId());
            }
            handleMemoCreation(response,
                    agentId,
                    request.getProductEnrollmentId(),
                    CallConstants.VERINT_MEMO_SUCCESS +
                            Objects.requireNonNull(response.getBody()).getContactId());
        } catch (CallException e) {
            handleMemoCreation(response,
                    agentId,
                    request.getProductEnrollmentId(),
                    CallConstants.VERINT_MEMO_FAILURE);
            throw e;
        }
        LOGGER.info("recordCall: Tag Call ends");
    }

    /**
     * Handle Memo creation.
     *
     * @param response response
     * @param agentId  agentId
     * @param peId     peId
     * @param message  message
     * @throws CallException when error occurs.
     */
    private void handleMemoCreation(ResponseEntity<TagCallResponse> response,
                                    String agentId,
                                    String peId,
                                    String message) throws CallException {
        try {
            memoService.createMemo(new CreateMemoRequest(message,
                    peId), agentId);
        } catch (Exception e) {
            if (null == response ||
                    (null != response.getBody() &&
                            null != Objects.requireNonNull(response.getBody()).getSuccess() &&
                            StringUtils.trimToNull(Objects.requireNonNull(response.getBody())
                                    .getContactId()) == null)) {
                throw new CallException("Failed to tag call with Verint and Memo " +
                        "Creation Failure for PEID " + peId);
            } else {
                LOGGER.error("Memo Creation failed, " +
                                "However - Call Tagging successful with Contact ID: {} and PEID {}",
                        Objects.requireNonNull(response.getBody()).getContactId(),
                        peId);
            }
        }
    }

    /**
     * Get agent phone extension from CiscoRestApi.
     *
     * @param racf - agent id
     * @return agent phone extension
     */
    public String getAgentPhoneExtension(String racf) throws CallException {
        try {
            LOGGER.info("Agent Racf Id: {}", racf);
            ResponseEntity<CiscoRestApiResponse> restApiResponseResponseEntity =
                    ciscoRestService.getAgentPhoneExtension(racf, CallConstants.SYS_TYPE, CallConstants.MATCH_TYPE);
            if (restApiResponseResponseEntity.getStatusCode().equals(HttpStatus.OK) &&
                    ObjectUtils.isNotEmpty(
                            Objects.requireNonNull(restApiResponseResponseEntity.getBody()).getUcce().getObj())) {
                return Objects.requireNonNull(
                        restApiResponseResponseEntity.getBody()).getUcce().getObj().getDns().getExt();
            } else {
                throw new CallException(CallConstants.ERROR_MSG_AGENT_EXTENSION_NOT_FOUND);
            }
        } catch (Exception e) {
            throw new CallException(CallConstants.ERROR_MSG_AGENT_EXTENSION_NOT_FOUND +
                    ExceptionUtils.getStackTrace(e));
        }
    }

    /**
     * Verifies the call on given extension.
     *
     * @param ext       extension number.
     * @param headerMap header map for Verint.
     * @return true or false.
     * @throws CallException If verifying process fails.
     */
    public boolean verifyCall(Map<String, String> headerMap, String ext) throws CallException {
        try {
            LOGGER.info("Agent Extension #: {}", ext);
            ResponseEntity<Void> response = verintService.contact(headerMap, ext);
            return response.getStatusCode() == HttpStatus.OK;
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), ExceptionUtils.getStackTrace(e));
            throw new CallException(ValidationConstants.ERROR_VERIFYING_CALL_EC);
        }
    }

    /**
     * Tag the call in Verint.
     *
     * @param peid      peid
     * @param ext       ext
     * @param headerMap header map
     * @param salesType sales type
     * @return tag call response
     * @throws CallException when an exception occurs.
     */
    private ResponseEntity<TagCallResponse> tagCall(String peid, String ext,
                                                    Map<String, String> headerMap,
                                                    String salesType)
            throws CallException {
        try {
            Tags tags = Tags.builder().acctNbr(peid).appId(ActionItpConstants.BLANK_STRING)
                    .ssn(ActionItpConstants.BLANK_STRING).salesType(salesType).build();
            TagCallRequest request = TagCallRequest.builder().ext(ext).tags(tags).build();
            return verintService.tagCall(headerMap, request);
        } catch (Exception e) {
            throw new CallException(CallConstants.ERROR_MSG_TAG_CALL +
                    ExceptionUtils.getStackTrace(e));
        }
    }

    /**
     * Fetch the sales type based on Tag type and customer type.
     *
     * @param request request
     * @return sales type
     * @throws CallException when an exception occurs.
     */
    private String fetchSalesTypeByTagType(RecordCallRequest request) throws CallException {
        try {
            Map<String, String> mappings = fetchApplicableTagTypes(request.getCustomerType());
            return mappings.get(request.getTagType().toLowerCase());
        } catch (Exception e) {
            throw new CallException(ValidationConstants.TAG_DATA_ERROR_EC);
        }
    }

    /**
     * Fetch all Applicable Tag Types.
     *
     * @param customerType customer type.
     * @return map.
     */
    private Map<String, String> fetchApplicableTagTypes(String customerType) {
        return taggingProperties.getItp().get(customerType);
    }
}
