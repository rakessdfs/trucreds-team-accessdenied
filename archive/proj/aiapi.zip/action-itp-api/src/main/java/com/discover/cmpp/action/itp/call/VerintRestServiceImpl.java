package com.discover.cmpp.action.itp.call;

import com.discover.cmpp.action.itp.call.model.TagCallRequest;
import com.discover.cmpp.action.itp.call.model.TagCallResponse;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class VerintRestServiceImpl implements VerintRestService {

    private final VerintRestClient verintClient;

    public VerintRestServiceImpl(VerintRestClient verintClient) {
        this.verintClient = verintClient;
    }

    @LogAround
    @LogExecutionTime
    @Override
    /**
     * {@inheritDoc}
     *
     */
    public ResponseEntity<Void> contact(Map<String, String> headerMap, String ext) {
        return verintClient.contact(headerMap, ext);
    }

    @LogAround
    @LogExecutionTime
    @Override
    /**
     * {@inheritDoc}
     *
     */
    public ResponseEntity<TagCallResponse> tagCall(Map<String, String> headerMap, TagCallRequest request) {
        return verintClient.tagCall(headerMap, request);
    }
}
