package com.discover.cmpp.action.itp.accountactivity;

import com.discover.cmpp.action.itp.accountactivity.model.AccountActivityResponse;
import com.discover.cmpp.action.itp.accountactivity.model.ActivityToAnalyticsRequest;
import com.discover.cmpp.action.itp.accountactivity.model.ActivityToAnalyticsResponse;
import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ErrorResponse;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.accountactivity.model.AccountActivityCodeRequest;
import com.discover.cmpp.action.itp.flux.schema.AccountActivityPayload;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.List;

@RequestMapping(value = "${api.context-path}")
@RestController
@Validated
public class AccountActivityController {

    // Intellij highlights yellow and says to make final - if you made these final, tess will fail
    private AccountActivityService accountActivityService;

    public AccountActivityController(AccountActivityService accountActivityService) {
        this.accountActivityService = accountActivityService;
    }

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = AccountActivityConstants.CREATE_ACTIVITY_API,
            notes = AccountActivityConstants.CREATE_ACTIVITY_API_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_CREATED, message = ActionItpConstants.API_CREATE),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, message = ActionItpConstants.API_BAD_REQUEST,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS),
            @ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = ActionItpConstants.API_NOT_FOUND)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN, required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN)})
    @PostMapping(value = AccountActivityConstants.CREATE_ACTIVITY_URL)
    public <T> ResponseEntity<T> createActivity(
            @RequestBody @Valid AccountActivityPayload request) throws AccountActivityException {
        accountActivityService.createActivity(request);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = AccountActivityConstants.CREATE_ACCOUNT_ACTIVITY_CODE_API,
            notes = AccountActivityConstants.CREATE_ACCOUNT_ACTIVITY_CODE_API_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_CREATED, message = ActionItpConstants.API_CREATE),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, message = ActionItpConstants.API_BAD_REQUEST,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS),
            @ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = ActionItpConstants.API_NOT_FOUND)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN, required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN)})
    @PostMapping(value = AccountActivityConstants.CREATE_ACCOUNT_ACTIVITY_CODE_URL)
    public <T> ResponseEntity<T> createAccountActivityCode(
            @RequestBody @Valid AccountActivityCodeRequest request) throws AccountActivityException {
        accountActivityService.createAccountActivityCode(request);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = AccountActivityConstants.FETCH_ACCOUNT_ACTIVITY_API,
            notes = AccountActivityConstants.FETCH_ACCOUNT_ACTIVITY_API_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_OK, message = ActionItpConstants.API_OK),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS),
            @ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = ActionItpConstants.API_NOT_FOUND,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_NO_CONTENT, message = ValidationConstants.PEID_NO_CONTENT_EM,
                    response = ErrorResponse.class)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN, required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN)})
    @GetMapping(value = AccountActivityConstants.FETCH_ACCOUNT_ACTIVITY_URL)
    public ResponseEntity<AccountActivityResponse> fetchAccountActivityByPeid(
            @PathVariable(name = AccountActivityConstants.PRODUCT_ENROLLMENT_ID) @NotBlank(
                    message = ValidationConstants.PEID_INVALID_EC) String productEnrollmentId)
            throws AccountActivityException {
        return new ResponseEntity<>(accountActivityService.fetchAccountActivityByPeid(
                productEnrollmentId), HttpStatus.OK);
    }

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = AccountActivityConstants.FETCH_ACCOUNT_ACTIVITY_CODES_API,
            notes = AccountActivityConstants.FETCH_ACCOUNT_ACTIVITY_CODES_API_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_OK, message = ActionItpConstants.API_OK),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS),
            @ApiResponse(code = HttpServletResponse.SC_NO_CONTENT,
                    message = ValidationConstants.NO_CODE_ENTITIES_EM, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, message = ActionItpConstants.API_BAD_REQUEST,
                    response = ErrorResponse.class)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN, required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN)})
    @GetMapping(value = AccountActivityConstants.FETCH_ACCOUNT_ACTIVITY_CODES_URL)
    public ResponseEntity<List<AccountActivityCodeEntity>> fetchAccountActivityCodes(
            @RequestParam(value = "activityCode", required = false, defaultValue = "")
            @Size(max = 20) String activityCode,
            @RequestParam(value = "category", required = false, defaultValue = "") String category)
            throws AccountActivityException {
        return new ResponseEntity<>(accountActivityService
                .fetchAccountActivityCodes(activityCode.toUpperCase(), category.toUpperCase()),
                HttpStatus.OK);
    }

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = AccountActivityConstants.OLD_ACTIVITY_TO_ANALYTICS_API,
            notes = AccountActivityConstants.OLD_ACTIVITY_TO_ANALYTICS_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_OK, message = ActionItpConstants.API_OK),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, message = ActionItpConstants.API_BAD_REQUEST,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS),
            @ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = ActionItpConstants.API_NOT_FOUND,
                    response = ErrorResponse.class)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN, required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN)})
    @PostMapping(value = AccountActivityConstants.OLD_ACTIVITY_TO_ANALYTICS_URL)
    public ResponseEntity<ActivityToAnalyticsResponse> publishOldActivitiesToAnalytics(
            @RequestBody @Valid ActivityToAnalyticsRequest request)
            throws AccountActivityException, ActionItpException {
        return new ResponseEntity<>(accountActivityService.publishActivitiesToAnalytics(request), HttpStatus.OK);
    }
}
