package com.discover.cmpp.action.itp.custlookup;

import com.discover.cmpp.action.itp.cloak.CloakException;
import com.discover.cmpp.action.itp.cloak.CloakService;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ActionItpUtil;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.custlookup.model.CustPiiSearchRequest;
import com.discover.cmpp.action.itp.custlookup.model.CustPiiSearchResponse;
import com.discover.cmpp.action.itp.custlookup.model.Customer;
import com.discover.cmpp.action.itp.custlookup.model.CustomerInfoResponse;
import com.discover.cmpp.action.itp.custlookup.model.CustomerPii;
import com.discover.cmpp.action.itp.custlookup.model.CustomerSearchRequest;
import com.discover.cmpp.action.itp.custlookup.model.CustomerSearchResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.Address;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.AddressRelationship;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.CdsLocationRequest;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.CdsLocationResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.EmailRelationship;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.PhoneRelationship;
import com.discover.cmpp.action.itp.custlookup.model.cdspersonal.CdsPersonalInfoRequest;
import com.discover.cmpp.action.itp.custlookup.model.cdspersonal.CdsPersonalInfoResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdstranslation.CdsTranslationAlternateIdResponse;
import com.discover.cmpp.action.itp.membership.MembershipConstants;
import com.discover.cmpp.action.itp.membership.MembershipException;
import com.discover.cmpp.action.itp.membership.MembershipService;
import com.discover.cmpp.action.itp.membership.ProductService;
import com.discover.cmpp.action.itp.membership.model.EnrollmentLookupResponse;
import com.discover.cmpp.action.itp.membership.model.MembershipListResponse;
import feign.FeignException;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CustLookUpServiceImpl implements CustLookUpService {

    @Autowired
    CloakService cloakService;
    @Autowired
    ActionItpUtil itpUtil;
    @Autowired
    CdsService cdsService;
    @Autowired
    ProductService productService;
    @Autowired
    MembershipService membershipService;

    private static final Logger LOGGER = LoggerFactory.getLogger(CustLookUpServiceImpl.class);

    /**
     * {@inheritDoc}
     */
    @Override
    public CustomerInfoResponse customerInfo(String agentId, String partyId)
            throws CloakException, ActionItpException, CustLookUpException {
        Map<String, String> headerMap = itpUtil.restClientCdsHeader(agentId);
        return customerLocationAndPersonalInfo(headerMap, partyId);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public CustomerSearchResponse customerSearch(String agentId, CustomerSearchRequest customerSearchRequest)
            throws CloakException, ActionItpException, CustLookUpException {
        Map<String, String> headerMap = itpUtil.restClientCdsHeader(agentId);
        // Check PeidOrSubscriberId and get partyId
        if (StringUtils.isNotBlank(customerSearchRequest.getPeidOrSubscriberId())) {
            String partyId = getPartyIdByPeidOrSubscriberId(headerMap, customerSearchRequest.getPeidOrSubscriberId());
            return getCdsPersonalSearchData(headerMap, partyId);
        } else if (StringUtils.isNotBlank(customerSearchRequest.getDateOfBirth()) &&
                StringUtils.isNotBlank(customerSearchRequest.getFirstName()) &&
                StringUtils.isNotBlank(customerSearchRequest.getLastName())) {
            String tokenizedDateOfBirth =
                    cloakService.tokenizeDob(headerMap,
                            itpUtil.convertDateFormat(customerSearchRequest.getDateOfBirth(),
                                    ValidationConstants.DOB_PATTERN, ValidationConstants.TOKENIZED_DOB_PATTERN));
            CustPiiSearchRequest custSearchRequest =
                    new CustPiiSearchRequest(customerSearchRequest.getFirstName().toUpperCase(),
                            customerSearchRequest.getLastName().toUpperCase(), tokenizedDateOfBirth);
            return getCdsCustomerPiiSearchData(headerMap, custSearchRequest);
        } else {
            throw new CustLookUpException(ValidationConstants.ARG_NOT_VALID_EC);
        }
    }

    /**
     * This method is going to retrieve the partyId from CDS based on peid or subscriber id.
     *
     * @param headerMap          header map
     * @param peidOrSubscriberId peid or subscriber id
     * @return String partyId
     */
    private String getPartyIdByPeidOrSubscriberId(Map<String, String> headerMap,
                                                  String peidOrSubscriberId) throws CustLookUpException {
        String peid = peidOrSubscriberId.startsWith(ValidationConstants.PD) ?
                getPeid(headerMap, peidOrSubscriberId) : peidOrSubscriberId;

        if (StringUtils.isNotBlank(peid)) {
            try {
                ResponseEntity<List<CdsTranslationAlternateIdResponse>> listResponseEntity =
                        cdsService.getPartyId(headerMap, peid);

                return listResponseEntity.getBody() != null ?
                        Objects.requireNonNull(listResponseEntity.getBody()).get(0).getPartyId() : null;
            } catch (FeignException.BadRequest ex) {
                throw new CustLookUpException(ValidationConstants.INVALID_PEID_OR_SUBSCRIBER_EC);
            } catch (FeignException.NotFound ex) {
                String exMessage = ex.contentUTF8();
                if (exMessage.isEmpty()) {
                    return null;
                } else {
                    throw new CustLookUpException(ValidationConstants.CDS_API_ISSUE_EC);
                }
            } catch (Exception e) {
                throw new CustLookUpException(ValidationConstants.CDS_API_ISSUE_EC);
            }
        }
        return null;
    }

    /**
     * Method to fetch the customer location and personal info from CDS based on
     * PartyId.
     *
     * @param headerMap header details
     * @param partyID   party id
     * @return @CustomerInfoResponse customer location and personal details
     */
    private CustomerInfoResponse customerLocationAndPersonalInfo(Map<String, String> headerMap, String partyID)
            throws CustLookUpException, ActionItpException, CloakException {
        boolean isCancelledMember = isPartyIdCancelled(partyID);
        CustomerInfoResponse custLookUpResponse =
                getCdsLocationInfo(headerMap, createCdsLocationRequest(partyID, isCancelledMember), isCancelledMember);
        CdsPersonalInfoRequest cdsPersonalInfoRequest =
                new CdsPersonalInfoRequest(CustLookUpConstants.PARTY_ID, partyID, true, true, true);
        CdsPersonalInfoResponse cdsPersonalInfoResponse =
                Objects.requireNonNull(getCdsPersonalInfo(headerMap, cdsPersonalInfoRequest));
        String detokenizedSsn = cloakService.detokenizeSsn(headerMap,
                Objects.requireNonNull(cdsPersonalInfoResponse.getPersonalInfo()).get(0).getSsnToken());
        String detokenizedDateOfBirth = cloakService.detokenizeDob(headerMap,
                cdsPersonalInfoResponse.getPersonalInfo().get(0).getDobToken());
        custLookUpResponse.setFirstName(cdsPersonalInfoResponse.getPersonalInfo().get(0).getName().getFirstName());
        custLookUpResponse.setLastName(cdsPersonalInfoResponse.getPersonalInfo().get(0).getName().getLastName());
        custLookUpResponse.setSsn(StringUtils.substring(detokenizedSsn, 5, 9));
        custLookUpResponse.setDateOfBirth(itpUtil.convertDateFormat(detokenizedDateOfBirth,
                ValidationConstants.TOKENIZED_DOB_PATTERN, ValidationConstants.DOB_PATTERN));
        custLookUpResponse.setPartyId(partyID);
        return custLookUpResponse;
    }

    /**
     * Method to create request body for CdslocationInfo api call.
     *
     * @param partyID           customer partyId
     * @param isCancelledMember boolean says is member cancelled.
     * @return CdsLocationRequest request body
     */
    private CdsLocationRequest createCdsLocationRequest(String partyID, boolean isCancelledMember) {
        boolean isRetrieveAll = true;
        boolean isRetrievePhoneOnly = false;
        boolean isRetrieveAddressOnly = false;
        boolean isRetrieveEmailOnly = false;
        return new CdsLocationRequest(partyID, CustLookUpConstants.PARTY_ID, isRetrieveAll, isRetrievePhoneOnly,
                isRetrieveAddressOnly, isRetrieveEmailOnly, isCancelledMember, CustLookUpConstants.SOURCE_CDE);
    }

    /**
     * Get location info from Cds.
     *
     * @param headerMap          header details
     * @param cdsLocationRequest request body
     * @return @CustLookUpResponse
     */
    private CustomerInfoResponse getCdsLocationInfo(Map<String, String> headerMap,
                                                    CdsLocationRequest cdsLocationRequest, boolean isCancelledMember)
            throws CustLookUpException {
        ResponseEntity<CdsLocationResponse> response;
        try {
            response = cdsService.getCustomerLocationInfo(headerMap, cdsLocationRequest);
            if (response.getStatusCode().equals(HttpStatus.OK)) {
                CustomerInfoResponse customerInfoResponse = new CustomerInfoResponse();
                customerInfoResponse.setAddress(extractAddress(response, isCancelledMember));
                customerInfoResponse.setPrimaryPhone(extractPhone(response, isCancelledMember));
                customerInfoResponse.setEmail(extractEmail(response, isCancelledMember));
                return customerInfoResponse;
            }
            throw new CustLookUpException(CustLookUpConstants.ERROR_MSG_CDS_CUST_LOCATION_INFO);
        } catch (Exception ex) {
            throw new CustLookUpException(CustLookUpConstants.ERROR_MSG_CDS_CUST_LOCATION_INFO +
                    ExceptionUtils.getStackTrace(ex));
        }
    }

    /**
     * Method to extract LoctionInfoResponse phone.
     *
     * @param response          - location info response
     * @param isCancelledMember - flag for cancelled member
     * @return String with phone
     */
    private String extractPhone(ResponseEntity<CdsLocationResponse> response,
                                boolean isCancelledMember) {
        List<PhoneRelationship> phoneList =
                Objects.requireNonNull(response.getBody()).getPhones() != null ?
                        Objects.requireNonNull(response.getBody()).getPhones() : new ArrayList<>();
        List<PhoneRelationship> homePhoneList = phoneList.stream()
                .filter(phone -> phone.getDesignationCode() != null &&
                        phone.getDesignationCode().equalsIgnoreCase(CustLookUpConstants.HOME_IDENTIFIER))
                .collect(Collectors.toList());
        if (isCancelledMember && homePhoneList.isEmpty() && phoneList.size() == 1) {
            homePhoneList.add(phoneList.get(CustLookUpConstants.INDX_0));
        }
        return !(homePhoneList.isEmpty()) ?
                homePhoneList.get(CustLookUpConstants.INDX_0).getPhoneNbr() :
                CustLookUpConstants.BLANKSTRING;
    }

    /**
     * Method to extract LoctionInfoResponse address.
     *
     * @param response          - location info response
     * @param isCancelledMember - flag for cancelled member
     * @return Address with address
     */
    private Address extractAddress(ResponseEntity<CdsLocationResponse> response,
                                   boolean isCancelledMember) {
        List<AddressRelationship> addressList =
                Objects.requireNonNull(response.getBody()).getAddresses() != null ?
                        Objects.requireNonNull(response.getBody()).getAddresses() : new ArrayList<>();
        List<AddressRelationship> homeAddressList = addressList.stream()
                .filter(address -> address.getDesignationCode() != null &&
                        address.getDesignationCode().equalsIgnoreCase(CustLookUpConstants.HOME_IDENTIFIER) &&
                        StringUtils.isNotBlank(address.getUpdateUserIdentifier()) &&
                        address.getUpdateUserIdentifier().equalsIgnoreCase(CustLookUpConstants.UPDATE_USER_IDENTIFIER))
                .collect(Collectors.toList());

        if (homeAddressList.isEmpty()) {
            getLatestAddress(isCancelledMember, addressList, homeAddressList);
        }
        return !(homeAddressList.isEmpty()) ?
                homeAddressList.get(CustLookUpConstants.INDX_0).getAddress() : null;
    }

    private void getLatestAddress(boolean isCancelledMember, List<AddressRelationship> addressList,
                                  List<AddressRelationship> homeAddressList) {
        Comparator<AddressRelationship> effectiveTimeStampComparator = Comparator
                .comparing(AddressRelationship::getEffectiveTimestamp);

        Optional<AddressRelationship> latestAddressUpdated = addressList.stream()
                .filter(address -> StringUtils.isBlank(address.getUpdateUserIdentifier()) &&
                        StringUtils.isNotBlank(address.getEffectiveTimestamp()))
                .max(effectiveTimeStampComparator);

        latestAddressUpdated.ifPresent(homeAddressList::add);
        if (isCancelledMember && addressList.size() == 1) {
            homeAddressList.add(addressList.get(CustLookUpConstants.INDX_0));
        }
    }

    /**
     * Method to extract LoctionInfoResponse email.
     *
     * @param response          - location info response
     * @param isCancelledMember - flag for cancelled member
     * @return String with email
     */
    private String extractEmail(ResponseEntity<CdsLocationResponse> response,
                                boolean isCancelledMember) {
        List<EmailRelationship> emailList =
                Objects.requireNonNull(response.getBody()).getEmails() != null ?
                        Objects.requireNonNull(response.getBody()).getEmails() : new ArrayList<>();
        List<EmailRelationship> homeEmailList = emailList.stream()
                .filter(email -> email.getDesignationCode() != null &&
                        email.getDesignationCode().equalsIgnoreCase(CustLookUpConstants.HOME_IDENTIFIER))
                .collect(Collectors.toList());
        if (isCancelledMember && homeEmailList.isEmpty() && emailList.size() == 1) {
            homeEmailList.add(emailList.get(CustLookUpConstants.INDX_0));
        }
        return !(homeEmailList.isEmpty()) ?
                homeEmailList.get(CustLookUpConstants.INDX_0).getEmailAddress() :
                CustLookUpConstants.BLANKSTRING;
    }

    /**
     * Method to identify if member is cancelled based on their party ID.
     *
     * @param partyId member partyId
     * @return boolean is member cancel or not
     * @throws ActionItpException when issue in fetching member info
     */
    private boolean isPartyIdCancelled(String partyId) throws ActionItpException {
        try {
            List<MembershipListResponse> memberships = membershipService.fetchMemberships(partyId);

            if (null != memberships) {
                MembershipListResponse membership = membershipService.determineMembershipFromList(memberships);
                return itpUtil.isMemberCancelled(membership);
            } else {
                throw new MembershipException(MembershipConstants.MEMBERSHIP_ERROR);
            }
        } catch (Exception e) {
            throw new ActionItpException(MembershipConstants.MEMBERSHIP_ERROR + ExceptionUtils.getStackTrace(e));
        }
    }

    /**
     * get personal info from Cds.
     *
     * @param headerMap              header details
     * @param cdsPersonalInfoRequest request body
     * @return @CdsPersonalInfoResponse
     */
    private CdsPersonalInfoResponse getCdsPersonalInfo(Map<String, String> headerMap,
                                                       CdsPersonalInfoRequest cdsPersonalInfoRequest)
            throws CustLookUpException {
        ResponseEntity<CdsPersonalInfoResponse> response;
        try {
            response = cdsService.getCustomerPersonalInfo(headerMap, cdsPersonalInfoRequest);
            if (null != response && response.getStatusCode().equals(HttpStatus.OK)) {
                if (!StringUtils.isBlank(Objects.requireNonNull(
                        response.getBody()).getPersonalInfo().get(0).getSsnToken()) && !StringUtils.isBlank(
                        Objects.requireNonNull(response.getBody()).getPersonalInfo().get(0).getDobToken()) &&
                        null != Objects.requireNonNull(response.getBody()).getPersonalInfo().get(0).getName()) {
                    return response.getBody();
                } else {
                    LOGGER.error("Error customer personal info not found in CDS with response : {}", response);
                    throw new CustLookUpException(CustLookUpConstants.ERROR_MSG_CDS_CUST_PERSONAL_NOT_FOUND);
                }
            }
            LOGGER.error("Error in While fetching customer personal info from CDS with response : {}", response);
            throw new CustLookUpException(CustLookUpConstants.ERROR_MSG_CDS_CUST_PERSONAL_INFO);
        } catch (CustLookUpException ex) {
            throw ex;
        } catch (Exception ex) {
            LOGGER.error(ExceptionUtils.getStackTrace(ex));
            throw new CustLookUpException(CustLookUpConstants.ERROR_MSG_CDS_CUST_LOCATION_INFO);
        }
    }

    /**
     * get peid from Products Enrollment API.
     *
     * @param headerMap        header details
     * @param subscriberNumber subscriber number
     * @return String
     */
    private String getPeid(Map<String, String> headerMap, String subscriberNumber) throws CustLookUpException {
        ResponseEntity<EnrollmentLookupResponse> response;
        try {
            response = productService.getPeid(headerMap, subscriberNumber);
            if (response.getStatusCode().equals(HttpStatus.OK)) {
                return Objects.requireNonNull(response.getBody()).getProductEnrollmentId();
            } else {
                throw new CustLookUpException(CustLookUpConstants.ERROR_MSG_PRODUCT_ENROLLMENT + response);
            }
        } catch (FeignException.BadRequest ex) {
            String exMessage = ex.contentUTF8();
            if (exMessage.contains("Invalid Subscriber ID")) {
                throw new CustLookUpException(ValidationConstants.INVALID_SUBSCRIBER_ID_EC);
            } else if (exMessage.contains("Membership ID cannot be found for Subscriber ID")) {
                return null;
            } else {
                throw new CustLookUpException(ValidationConstants.ERROR_MSG_PRODUCT_ENROLLMENT_EC);
            }
        } catch (Exception ex) {
            throw new CustLookUpException(ValidationConstants.ERROR_MSG_PRODUCT_ENROLLMENT_EC +
                    ExceptionUtils.getStackTrace(ex));
        }
    }

    /**
     * Fetch customer list from cds based on first name, last name and dob.
     *
     * @param headerMap         header info for api call
     * @param custSearchRequest request object
     * @return {@link CustPiiSearchResponse} object
     * @throws CustLookUpException exception
     */
    private CustomerSearchResponse getCdsCustomerPiiSearchData(Map<String,
            String> headerMap, CustPiiSearchRequest custSearchRequest) throws CustLookUpException {
        CustomerSearchResponse custPiiLookUpResponse;
        try {
            ResponseEntity<CustPiiSearchResponse> response =
                    cdsService.searchCustomerPii(headerMap, custSearchRequest);
            if (null != response && response.getStatusCode().is2xxSuccessful()) {
                custPiiLookUpResponse = new CustomerSearchResponse();
                List<CustomerPii> customerPiiList = new ArrayList<>();
                List<Customer> customers = Objects.requireNonNull(response.getBody()).getCustomers();
                if (!CollectionUtils.isEmpty(customers)) {
                    for (Customer custPii : customers) {
                        CustomerPii extractCustPii = extractsCustomerPiiSearchResponse(headerMap, custPii);
                        if (null != extractCustPii) {
                            customerPiiList.add(extractCustPii);
                        }
                    }
                }
                custPiiLookUpResponse.setCustomers(customerPiiList);
                return custPiiLookUpResponse;
            }
            throw new CustLookUpException(CustLookUpConstants.ERROR_MSG_CDS_CUST_SEARCH);
        } catch (Exception ex) {
            LOGGER.error(ExceptionUtils.getStackTrace(ex));
            throw new CustLookUpException(CustLookUpConstants.ERROR_MSG_CDS_CUST_SEARCH);
        }
    }

    /**
     * Set the customer pii query information in response.
     *
     * @param custPii piiquery object
     * @return {@link CustomerPii} response object
     */
    private CustomerPii extractsCustomerPiiSearchResponse(Map<String, String> headerMap, Customer custPii) {
        CustomerPii customerPii = null;
        if (!StringUtils.isBlank(custPii.getPartyId())) {
            try {
                String peId = itpUtil.getProductEnrollmentId(headerMap, custPii.getPartyId());

                if (StringUtils.isNotBlank(peId)) {
                    customerPii = new CustomerPii();
                    customerPii.setFirstName(custPii.getFirstName());
                    customerPii.setLastName(custPii.getLastName());
                    customerPii.setPartyId(custPii.getPartyId());
                    // De-tokenize SSN
                    customerPii.setSsn(getDetokenizedSsn(custPii.getSsnToken()));
                }
            } catch (Exception ex) {
                LOGGER.error("Partyid : {} {}", custPii.getPartyId(),
                        CustLookUpConstants.ERROR_MSG_CDS_TRANSLATION_API_V2);
                LOGGER.error(ExceptionUtils.getStackTrace(ex));
            }
        }
        return customerPii;
    }

    /**
     * Detokenize and return last 4 digits of customer ssn.
     *
     * @param ssnToken {@link String} object
     * @return {@link String} object
     */
    private String getDetokenizedSsn(String ssnToken) throws ActionItpException, CloakException {
        return StringUtils.substring(cloakService.detokenizeSsn(itpUtil.restClientHeader(), ssnToken), 5, 9);
    }

    /**
     * This method return customer search data for party id.
     *
     * @param headerMap header details
     * @param partyId   cds party id
     * @return {@link CustomerSearchResponse} search result
     * @throws CustLookUpException customer lookup exception
     * @throws CloakException      cloak exception
     * @throws ActionItpException  action itp exception
     */
    private CustomerSearchResponse getCdsPersonalSearchData(Map<String, String> headerMap, String partyId)
            throws CustLookUpException,
            CloakException, ActionItpException {
        CustomerSearchResponse customerSearchResponse = new CustomerSearchResponse();
        List<CustomerPii> customerPiiList = new ArrayList<>();
        CustomerPii customerPii = new CustomerPii();

        if (partyId != null) {
            CdsPersonalInfoRequest cdsPersonalInfoRequest =
                    new CdsPersonalInfoRequest(CustLookUpConstants.PARTY_ID, partyId, true,
                            true, true);
            CdsPersonalInfoResponse cdsPersonalInfoResponse =
                    Objects.requireNonNull(getCdsPersonalInfo(headerMap, cdsPersonalInfoRequest));
            customerPii.setFirstName(
                    Objects.requireNonNull(cdsPersonalInfoResponse.getPersonalInfo()).get(0).getName().getFirstName());
            customerPii.setLastName(cdsPersonalInfoResponse.getPersonalInfo().get(0).getName().getLastName());
            customerPii.setPartyId(partyId);
            // De-tokenize SSN
            customerPii.setSsn(getDetokenizedSsn(cdsPersonalInfoResponse.getPersonalInfo().get(0).getSsnToken()));
            customerPiiList.add(customerPii);
        }
        customerSearchResponse.setCustomers(customerPiiList);
        return customerSearchResponse;
    }
}
