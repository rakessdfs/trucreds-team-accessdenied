package com.discover.cmpp.action.itp.memo;

import org.springframework.beans.BeanUtils;

public class MemoUtil {

    private MemoUtil() {
    }

    /**
     * This method will convert the Memo Entity to its corresponding DTO.
     *
     * @param memo memoEntity
     * @return memoDto
     */
    public static MemoDto convertMemoEnityToMemoDto(MemoEntity memo) {
        MemoDto memoDto = new MemoDto();
        BeanUtils.copyProperties(memo, memoDto);
        return memoDto;
    }
}
