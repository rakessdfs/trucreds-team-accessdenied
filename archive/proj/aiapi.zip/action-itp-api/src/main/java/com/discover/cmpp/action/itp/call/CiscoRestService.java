package com.discover.cmpp.action.itp.call;

import com.discover.cmpp.action.itp.call.model.CiscoRestApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Retryable;

public interface CiscoRestService {

    /**
     * This method is used to get the agent extension and record the call.
     *
     * @param racf  - racf id of agent
     * @param sys   - sys type
     * @param match - exact, sup or all
     * @return - agent phone extension number
     */
    @Retryable
    ResponseEntity<CiscoRestApiResponse> getAgentPhoneExtension(String racf, String sys, String match)
            throws CallException;
}
