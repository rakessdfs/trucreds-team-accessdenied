package com.discover.cmpp.action.itp.cloak;

import lombok.Data;

@Data
public class CloakDetokenizeResponse {

    private String value;
    private CloakErrorVO errrorVO;
}
