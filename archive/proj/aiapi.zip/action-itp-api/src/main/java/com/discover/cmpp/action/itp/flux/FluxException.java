package com.discover.cmpp.action.itp.flux;

public class FluxException extends RuntimeException {

    public FluxException(String message) {
        super(message);
    }
}