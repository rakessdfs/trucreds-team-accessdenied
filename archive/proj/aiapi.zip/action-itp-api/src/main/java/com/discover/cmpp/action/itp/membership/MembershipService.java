package com.discover.cmpp.action.itp.membership;

import com.discover.cmpp.action.itp.cancel.CancelException;
import com.discover.cmpp.action.itp.cancel.model.CancelRequest;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.membership.model.MembershipInfo;
import com.discover.cmpp.action.itp.membership.model.MembershipListResponse;
import com.discover.cmpp.action.itp.membership.model.MembershipResponse;
import com.discover.cmpp.action.itp.membership.model.RequestReasonResponse;
import com.discover.cmpp.action.itp.membership.model.billing.BillingResponse;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

public interface MembershipService {

    /**
     * Fetch ITP Membership information for the FNF Customer.
     *
     * @param agentId of the agent
     * @param partyId party Id
     * @return Membership Response
     * @throws MembershipException when an exception occurs while fetching membership information
     */
    MembershipResponse fetchItpMembershipInformation(String agentId, String partyId)
            throws MembershipException, ActionItpException;

    /**
     * This method is used to search for customer and fetch ProductEnrollmentID from
     * CDS using partyId of the customer.
     *
     * @param agentId of the agent
     * @param partyId input request with partyId
     * @return String product enrollment ID
     * @throws MembershipException when an exception occurs while fetching membership information
     */
    String getProductEnrollmentId(String agentId, String partyId) throws MembershipException, ActionItpException;

    /**
     * Fetch ITP Billing information for the FNF Customer.
     *
     * @param peid         product enrollment Id
     * @param subscriberId subscriber Id
     * @return Billing Response
     * @throws MembershipException when an exception occurs while fetching membership information
     */
    BillingResponse fetchItpBillingInformation(String customerType, String partyId, BigDecimal peid,
                                               String subscriberId) throws MembershipException, ActionItpException;

    /**
     * Fetch the request reasons based on customer type.
     *
     * @param agentId      of the agent
     * @param customerType of the customer
     * @return {@link RequestReasonResponse} object.
     * @throws RequestReasonsException when error occurred while fetching reason codes
     */
    RequestReasonResponse fetchRequestReasons(String agentId, String customerType)
            throws RequestReasonsException;

    /**
     * Create cancel request for customer.
     *
     * @param membershipId  membership id
     * @param cancelRequest cancel request
     * @return ResponseEntity The response
     * @throws MembershipException when an exception occurs while fetching membership information
     */
    ResponseEntity<Void> cancelMembership(Map<String, String> headerMap, Long membershipId, CancelRequest cancelRequest)
            throws MembershipException, ActionItpException, CancelException;

    /**
     * Method to Extract MembershipInfo from reponseEntity.
     *
     * @param partyId     - of customer who membership info is fetched
     * @param productCode - ITF or ITB
     * @return - MembershipInfo membership info
     */
    MembershipInfo fetchMembershipInfo(String partyId, String productCode)
            throws ActionItpException, MembershipException;

    /**
     * Method to Extract MembershipInfo from responseEntity.
     *
     * @param partyId - partyId of customer
     * @return - List of Memberships
     */
    List<MembershipListResponse> fetchMemberships(String partyId)
            throws ActionItpException, MembershipException;

    /**
     * Method to extract the correct membership details from a list of memberships.
     * According to following business logic:
     * ITF          ITB         Membership Data Returned
     * Active       Active      Not possible but check whose "lastBillDate": "string",
     * Active       No Data     ITF Data
     * No Data      Active      ITB Data
     * Cancelled    Active      ITB Data
     * Active       Cancelled   ITF Data
     * Cancelled    Cancelled   Check whose "cancelCompletionDate": "string", is latest
     *
     * @param memberships - List of memberships fetched for partyID
     * @return - Information for one membership based on business logic for which info to show
     * @throws ParseException when date parsing fails
     */
    MembershipListResponse determineMembershipFromList(List<MembershipListResponse> memberships)
            throws ParseException;
}
