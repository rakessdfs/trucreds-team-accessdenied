package com.discover.cmpp.action.itp.call;

public class CallException extends Exception {

    private static final long serialVersionUID = -7137924831698067983L;

    public CallException(String message) {
        super(message);
    }
}
