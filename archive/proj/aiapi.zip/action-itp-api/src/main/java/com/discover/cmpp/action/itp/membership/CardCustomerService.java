package com.discover.cmpp.action.itp.membership;

import com.discover.cmpp.action.itp.membership.model.billing.CardCustomerDataRequest;
import com.discover.cmpp.action.itp.membership.model.billing.CardCustomerDataResponse;
import org.springframework.http.ResponseEntity;

import java.util.Map;

public interface CardCustomerService {

    /**
     * To Fetch Card member details based on AccountKey.
     *
     * @param headerMap               - Request Header map
     * @param cardCustomerDataRequest - AccountKey
     * @return - Card member details
     */
    ResponseEntity<CardCustomerDataResponse> fetchCardCustomerData(Map<String, String> headerMap,
                                                                   CardCustomerDataRequest cardCustomerDataRequest);
}
