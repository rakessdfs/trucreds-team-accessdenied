package com.discover.cmpp.action.itp.accountactivity;

import com.discover.cmpp.action.itp.common.TimestampEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "ACCOUNT_ACTIVITY")
public class AccountActivityEntity extends TimestampEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ACCOUNT_ACTIVITY_ID")
    private Long accountActivityId;

    @Column(name = "PRODUCT_ENROLLMENT_ID")
    private String productEnrollmentId;

    @ManyToOne
    @JoinColumn(name = "ACTIVITY_CODE", referencedColumnName = "ACTIVITY_CODE")
    private AccountActivityCodeEntity activityCode;

    @Column(name = "PREVIOUS_DATA")
    private String previousData;

    @Column(name = "NEW_DATA")
    private String newData;

    @Column(name = "OPERATOR")
    private String operator;

    @Column(name = "REQUEST_DATE")
    private LocalDateTime requestDate;
}
