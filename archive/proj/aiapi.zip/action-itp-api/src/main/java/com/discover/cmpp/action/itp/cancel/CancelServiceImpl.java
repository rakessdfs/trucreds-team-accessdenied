package com.discover.cmpp.action.itp.cancel;

import com.discover.cmpp.action.itp.cancel.model.CancelRequest;
import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ActionItpUtil;
import com.discover.cmpp.action.itp.common.CloudPropertiesConfiguration;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.membership.MembershipService;
import com.discover.cmpp.action.itp.membership.ProductService;
import com.discover.cmpp.action.itp.membership.model.EnrollmentLookupResponse;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Objects;

@Service
public class CancelServiceImpl implements CancelService {

    // Intellij highlights yellow and says to make final - if you made these final, tess will fail
    private MembershipService membershipService;
    private ActionItpUtil itpUtil;
    private ProductService productService;
    private CloudPropertiesConfiguration cloudPropertiesConfiguration;

    public CancelServiceImpl(MembershipService membershipService, ActionItpUtil itpUtil,
                             ProductService productService, CloudPropertiesConfiguration cloudPropertiesConfiguration) {
        this.membershipService = membershipService;
        this.itpUtil = itpUtil;
        this.productService = productService;
        this.cloudPropertiesConfiguration = cloudPropertiesConfiguration;
    }

    /**
     * {@inheritDoc}
     */
    @LogAround
    @LogExecutionTime
    @Override
    public void cancelRequest(String agentId, String peid, String cancelReasonCode) throws CancelException,
            ActionItpException {
        Map<String, String> map = itpUtil.restClientHeader();

        try {
            CancelRequest cancelRequest = new CancelRequest();
            cancelRequest.setBusinessOrgCode(CancelConstants.BUSINESS_CODE_EC);
            cancelRequest.setContactChannelCode(CancelConstants.REQUEST_SRC_CODE_ACT);
            cancelRequest.setProcessRequestReasonCode(cancelReasonCode);
            cancelRequest.setProcessRequestSourceCode(CancelConstants.REQUEST_SRC_CODE_ACT);
            cancelRequest.setUserId(agentId);

            ResponseEntity<EnrollmentLookupResponse> enrollmentInfo =
                    productService.getEnrollmentInfo(map, peid);
            if (null != enrollmentInfo &&
                    StringUtils.isNotBlank(Objects.requireNonNull(enrollmentInfo.getBody()).getMembershipId())) {
                if (cloudPropertiesConfiguration.isNewCancelApiEnabled()) {
                    map.put(ActionItpConstants.AGENT_ID, agentId);
                }
                membershipService.cancelMembership(map,
                        Long.parseLong(Objects.requireNonNull(enrollmentInfo.getBody()).getMembershipId()),
                        cancelRequest);
            } else {
                throw new CancelException(ValidationConstants.MEMBERSHIP_ID_NOT_FOUND_EC);
            }
        } catch (Exception e) {
            throw new CancelException(e.getMessage());
        }
    }
}
