package com.discover.cmpp.action.itp.cancel.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CancelRequest {

    private String businessOrgCode;
    private String contactChannelCode;
    private String contactReasonCode;
    private String processRequestCreateTimestamp;
    private String processRequestReasonCode;
    private String processRequestSourceCode;
    private String userId;
}


