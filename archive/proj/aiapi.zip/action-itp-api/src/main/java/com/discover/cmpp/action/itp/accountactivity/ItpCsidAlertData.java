package com.discover.cmpp.action.itp.accountactivity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
public class ItpCsidAlertData {

    private String alertProcStatCode;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Timestamp createDate;    //example: yyyy-MM-dd HH:mm:ss.SSSSSS
    private String email;
    private String enrollmentId;
    private String enrollmentStatus;
    private String eventSubject;
    private String formCode;
    private ItpCsidAlertPkData itpCsidAlertPkEntity;
    private BigDecimal membershipId;
    private String onlineChannelInd;
    private String realtnMembershipId;
    private String reasonCode;
    private String smsFormCode;
    private String subscriberId;
    private String subscriptionType;
    private String textOptInInd;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Timestamp updateDate;    //example: yyyy-MM-dd HH:mm:ss.SSSSSS
}