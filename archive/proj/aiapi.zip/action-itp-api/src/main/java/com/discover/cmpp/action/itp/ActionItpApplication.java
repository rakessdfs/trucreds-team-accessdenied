package com.discover.cmpp.action.itp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.retry.annotation.EnableRetry;

@EnableRetry
@SpringBootApplication
@EnableAspectJAutoProxy
@EnableFeignClients
@EnableCaching
@ComponentScan("com.discover.cmpp.*")
@EnableKafka
public class ActionItpApplication {

    public static void main(String[] args) {
        SpringApplication.run(ActionItpApplication.class, args);
    }
}