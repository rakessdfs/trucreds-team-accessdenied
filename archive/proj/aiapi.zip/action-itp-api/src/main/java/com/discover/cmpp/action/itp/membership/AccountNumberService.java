package com.discover.cmpp.action.itp.membership;

import com.discover.cmpp.action.itp.membership.model.billing.AccountKeySequenceNbrResponse;
import com.discover.cmpp.action.itp.membership.model.billing.AcctKeyTrnsfrSeqNmbrRequest;
import org.springframework.http.ResponseEntity;

import java.util.Map;

public interface AccountNumberService {

    /**
     * To get AccountNumber based on the AccountKey provided.
     *
     * @param headerMap                   - Request Header map
     * @param acctKeyTrnsfrSeqNmbrRequest - request with accountKey
     * @return - AccountNumber
     */
    ResponseEntity<AccountKeySequenceNbrResponse> fetchAccountNumber(Map<String, String> headerMap,
                        AcctKeyTrnsfrSeqNmbrRequest acctKeyTrnsfrSeqNmbrRequest);
}
