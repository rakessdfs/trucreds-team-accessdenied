package com.discover.cmpp.action.itp.memo;

import com.discover.cmpp.action.itp.cloak.CloakException;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.CloudPropertiesConfiguration;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.custlookup.CustLookUpException;
import com.discover.cmpp.action.itp.custlookup.CustLookUpService;
import com.discover.cmpp.action.itp.custlookup.model.CustomerPii;
import com.discover.cmpp.action.itp.custlookup.model.CustomerSearchRequest;
import com.discover.cmpp.action.itp.custlookup.model.CustomerSearchResponse;
import com.discover.cmpp.action.itp.flux.FluxException;
import com.discover.cmpp.action.itp.flux.publish.memo.MemoPublishService;
import com.discover.cmpp.action.itp.flux.schema.MemoMessage;
import com.discover.cmpp.action.itp.membership.MembershipConstants;
import com.discover.cmpp.action.itp.membership.MembershipException;
import com.discover.cmpp.action.itp.membership.MembershipService;
import com.discover.cmpp.action.itp.membership.model.MembershipListResponse;
import com.discover.cmpp.utils.CommonConstants;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.discover.cmpp.action.itp.common.ActionItpConstants.ITP_PRODUCT_TYPE_CODE;

@Service
public class MemoServiceImpl implements MemoService {

    private final MemoRepository memoRepository;
    private final MemoPublishService memoPublishService;
    private final CustLookUpService custLookUpService;
    private final CloudPropertiesConfiguration cloudPropertiesConfiguration;
    private final MembershipService membershipService;
    private static final Logger LOGGER = LoggerFactory.getLogger(MemoServiceImpl.class);

    public MemoServiceImpl(MemoRepository memoRepository,
                           MemoPublishService memoPublishService,
                           CloudPropertiesConfiguration cloudPropertiesConfiguration,
                           CustLookUpService custLookUpService,
                           MembershipService membershipService) {
        this.memoRepository = memoRepository;
        this.memoPublishService = memoPublishService;
        this.cloudPropertiesConfiguration = cloudPropertiesConfiguration;
        this.custLookUpService = custLookUpService;
        this.membershipService = membershipService;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void createMemo(CreateMemoRequest createMemoRequest, String createAgentId) throws MemoException,
            FluxException, ActionItpException, MembershipException, CloakException, CustLookUpException {
        MemoEntity memoEntity = createPersistMemoEntity(createMemoRequest, createAgentId);
        try {
            memoEntity = memoRepository.save(memoEntity);
        } catch (Exception e) {
            throw new MemoException(
                    "Error in saving new memo in DB with exception: " + ExceptionUtils.getStackTrace(e));
        }

        if (cloudPropertiesConfiguration.isPublishMemoToAnalytics()) {
            publishFluxEvent(createMemoRequest, createAgentId, memoEntity);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public MemoResponse fetchMemos(String productEnrollmentId) throws MemoException {
        MemoResponse memoResponse = null;
        try {
            List<MemoEntity> memoEntityList =
                    memoRepository.findAllByProductEnrollmentIdOrderByCreateTsAsc(productEnrollmentId);
            if (!CollectionUtils.isEmpty(memoEntityList)) {
                memoResponse = new MemoResponse();
                List<MemoDto> memoDtoList = new ArrayList<>();
                memoEntityList.stream().forEach(memo -> memoDtoList.add(MemoUtil.convertMemoEnityToMemoDto(memo))
                );
                memoResponse.setMemosList(memoDtoList);
            } else {
                throw new MemoException(ValidationConstants.PEID_NO_CONTENT_EC);
            }
        } catch (Exception e) {
            throw new MemoException(ExceptionUtils.getStackTrace(e));
        }
        return memoResponse;
    }

    private MemoEntity createPersistMemoEntity(CreateMemoRequest createMemoRequest, String createAgentId) {
        return MemoEntity.builder().memoText(createMemoRequest.getMemoText())
                .productEnrollmentId(createMemoRequest.getProductEnrollmentId()).createAgentId(createAgentId).build();
    }

    private void publishFluxEvent(CreateMemoRequest createMemoRequest, String createAgentId, MemoEntity memoEntity)
            throws CloakException, ActionItpException, CustLookUpException, MembershipException {
        CustomerSearchRequest customerSearchRequest = new CustomerSearchRequest();
        customerSearchRequest.setPeidOrSubscriberId(createMemoRequest.getProductEnrollmentId());
        CustomerSearchResponse customerSearchResponse = custLookUpService
                .customerSearch(createAgentId, customerSearchRequest);

        if (null != customerSearchResponse) {
            Optional<CustomerPii> customerPii = customerSearchResponse.getCustomers().stream().findFirst();
            if (customerPii.isPresent()) {
                List<MembershipListResponse> memberships = membershipService.fetchMemberships(
                        customerPii.get().getPartyId());

                MembershipListResponse membership;
                if (null != memberships) {
                    try {
                        membership = membershipService.determineMembershipFromList(memberships);
                    } catch (Exception e) {
                        throw new MembershipException(MembershipConstants.MEMBERSHIP_ERROR);
                    }
                } else {
                    throw new MembershipException(MembershipConstants.MEMBERSHIP_ERROR);
                }

                MemoMessage memoMessage = MemoMessage.builder().memoText(memoEntity.getMemoText())
                        .createAgentId(memoEntity.getCreateAgentId())
                        .createTimestamp(memoEntity.getCreateTs().toString())
                        .membershipNumber(memoEntity.getMemoId().toString())
                        .customerType(CommonConstants
                                .CUSTOMERTYPE_TO_LEVEL_MAP
                                .get(membership.getLevelNumber()))
                        .productType(ITP_PRODUCT_TYPE_CODE)
                        .customerLevel(membership.getLevelNumber())
                        .productEnrollmentId(memoEntity.getProductEnrollmentId())
                        .build();
                memoPublishService.publishEvent(memoMessage);
            } else {
                LOGGER.error("Error finding customerPii info for peid: {} ",
                        createMemoRequest.getProductEnrollmentId());
            }
        } else {
            LOGGER.error("Customer search response is null/empty for peid: {} ",
                    createMemoRequest.getProductEnrollmentId());
        }
    }
}
