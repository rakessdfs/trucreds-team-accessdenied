package com.discover.cmpp.action.itp.languagesettings;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.ErrorResponse;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.languagesettings.model.LanguageSettingsRequest;
import com.discover.cmpp.action.itp.languagesettings.model.LanguageSettingsResponse;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

@RequestMapping(value = "${api.context-path}")
@RestController
@Validated
public class LanguageSettingsController {

    // Intellij highlights yellow and says to make final - if you made these final, tess will fail
    private LanguageSettingsService languageSettingsService;

    public LanguageSettingsController(LanguageSettingsService languageSettingsService) {
        this.languageSettingsService = languageSettingsService;
    }

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = LanguageSettingsConstants.SAVE_LANGUAGE_API,
            notes = LanguageSettingsConstants.SAVE_LANGUAGE_API_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_CREATED, message = ActionItpConstants.API_CREATE),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, message = ActionItpConstants.API_BAD_REQUEST,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS),
            @ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = ActionItpConstants.API_NOT_FOUND)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN, required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN),
            @ApiImplicitParam(name = ActionItpConstants.AGENT_ID, required = true,
                    dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
                    value = ActionItpConstants.AGENT_ID_VALUE)})
    @PostMapping(value = LanguageSettingsConstants.SAVE_LANGUAGE_URL)
    public <T> ResponseEntity<T> saveLanguageSettings(
            @RequestHeader(ActionItpConstants.AGENT_ID) @NotBlank(
                    message = ValidationConstants.AGENT_ID_INVALID_EC) String agentId,
            @RequestBody @Valid LanguageSettingsRequest request) throws LanguageSettingsException {
        languageSettingsService.saveLanguageSettings(request, agentId);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = LanguageSettingsConstants.FETCH_LANGUAGE_API,
            notes = LanguageSettingsConstants.FETCH_LANGUAGE_API_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_CREATED, message = ActionItpConstants.API_CREATE),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, message = ActionItpConstants.API_BAD_REQUEST,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS),
            @ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = ActionItpConstants.API_NOT_FOUND)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN, required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN)})
    @GetMapping(value = LanguageSettingsConstants.FETCH_LANGUAGE_URL)
    public ResponseEntity<LanguageSettingsResponse> getLanguageSettings(
            @PathVariable(name = LanguageSettingsConstants.PRODUCT_ENROLLMENT_ID) @NotBlank(
                    message = ValidationConstants.PEID_INVALID_EC)
                    String productEnrollmentId) throws LanguageSettingsException {
        return new ResponseEntity<>(
                languageSettingsService.fetchLanguageSettings(productEnrollmentId), HttpStatus.OK);
    }
}
