package com.discover.cmpp.action.itp.cloak;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class CloakRequest {

    private String input;
    private String dataElementName;
    private String dataElementType;
}
