package com.discover.cmpp.action.itp.custlookup;

import com.discover.cmpp.action.itp.custlookup.model.CustPiiSearchRequest;
import com.discover.cmpp.action.itp.custlookup.model.CustPiiSearchResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.CdsLocationRequest;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.CdsLocationResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdspersonal.CdsPersonalInfoRequest;
import com.discover.cmpp.action.itp.custlookup.model.cdspersonal.CdsPersonalInfoResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdstranslation.CdsTranslationAlternateIdResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdstranslation.CdsTranslationReqSrcCodeResponse;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class CdsServiceImpl implements CdsService {

    private CdsCustAccessClient cdsCustAccessClient;
    private CdsCustSearchClient cdsCustSearchClient;
    private CdsCustTranslationAccessClient cdsCustTranslationAccessClient;

    public CdsServiceImpl(CdsCustAccessClient cdsCustAccessClient, CdsCustSearchClient cdsCustSearchClient,
                          CdsCustTranslationAccessClient cdsCustTranslationAccessClient) {
        this.cdsCustAccessClient = cdsCustAccessClient;
        this.cdsCustSearchClient = cdsCustSearchClient;
        this.cdsCustTranslationAccessClient = cdsCustTranslationAccessClient;
    }

    @LogAround
    @LogExecutionTime
    @Override
    /**
     * {@inheritDoc}
     *
     */
    public ResponseEntity<CdsLocationResponse> getCustomerLocationInfo(Map<String, String> headerMap,
                                                                       CdsLocationRequest cdsLocationRequest) {
        return cdsCustAccessClient.customerLocationInfo(headerMap, cdsLocationRequest);
    }

    @LogAround
    @LogExecutionTime
    @Override
    /**
     * {@inheritDoc}
     *
     */
    public ResponseEntity<CdsPersonalInfoResponse> getCustomerPersonalInfo(Map<String, String> headerMap,
                        CdsPersonalInfoRequest cdsPersonalInfoRequest) {
        return cdsCustAccessClient.customerPersonalInfo(headerMap, cdsPersonalInfoRequest);
    }

    @LogAround
    @LogExecutionTime
    @Override
    /**
     * {@inheritDoc}
     *
     */
    public ResponseEntity<CustPiiSearchResponse> searchCustomerPii(Map<String, String> headerMap,
                                                                   CustPiiSearchRequest custSearchRequest) {
        return cdsCustSearchClient.customerPiiQuery(headerMap, custSearchRequest);
    }

    @LogAround
    @LogExecutionTime
    @Override
    /**
     * {@inheritDoc}
     *
     */
    public ResponseEntity<List<CdsTranslationAlternateIdResponse>> getPartyId(
            Map<String, String> headerMap, String peid) {
        return cdsCustTranslationAccessClient.getPartyId(headerMap, peid);
    }

    @LogAround
    @LogExecutionTime
    @Override
    /**
     * {@inheritDoc}
     *
     */
    public ResponseEntity<List<CdsTranslationReqSrcCodeResponse>> getIsItpUser(
            Map<String, String> headerMap, String prtyId) {
        return cdsCustTranslationAccessClient.getIsItpUser(headerMap, prtyId);
    }
}
