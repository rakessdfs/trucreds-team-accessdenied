package com.discover.cmpp.action.itp.common;

import com.discover.cmpp.action.itp.accountactivity.AccountActivityException;
import com.discover.cmpp.action.itp.accountcenter.ItpAccountCenterException;
import com.discover.cmpp.action.itp.accountcenter.customer.profile.CustomerProfileConstants;
import com.discover.cmpp.action.itp.call.CallException;
import com.discover.cmpp.action.itp.cancel.CancelException;
import com.discover.cmpp.action.itp.cloak.CloakException;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.custlookup.CustLookUpConstants;
import com.discover.cmpp.action.itp.custlookup.CustLookUpException;
import com.discover.cmpp.action.itp.flux.FluxException;
import com.discover.cmpp.action.itp.languagesettings.LanguageSettingsConstants;
import com.discover.cmpp.action.itp.languagesettings.LanguageSettingsException;
import com.discover.cmpp.action.itp.membership.MembershipConstants;
import com.discover.cmpp.action.itp.membership.MembershipException;
import com.discover.cmpp.action.itp.membership.RequestReasonsException;
import com.discover.cmpp.action.itp.memo.MemoException;
import com.discover.cmpp.action.itp.oob.OobSoapException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@ControllerAdvice
public class ActionItpExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(ActionItpExceptionHandler.class);

    /**
     * Handle Field Specific Constraint validations from the Controller.
     *
     * @param ex exception
     * @return {@link ResponseEntity} responseEntity
     */
    @ExceptionHandler(value = ConstraintViolationException.class)
    public ResponseEntity<ErrorResponse> handleConstraintValidations(ConstraintViolationException ex) {
        LOGGER.error(ValidationConstants.EXCEPTION_MSG, ex.getMessage());
        List<String> errorCodes =
                ex.getConstraintViolations().stream().map(ConstraintViolation::getMessage).collect(Collectors.toList());
        return ExceptionUtils.createErrorResponse(errorCodes, HttpStatus.BAD_REQUEST);
    }

    /**
     * Handle Field Specific MethodArgument validations from the Controller.
     *
     * @param ex exception
     * @return {@link ResponseEntity} responseEntity
     */
    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex) {
        LOGGER.error(ValidationConstants.EXCEPTION_MSG, ex.getMessage());
        List<String> errorCodes = ex.getBindingResult().getFieldErrors().stream().map(FieldError::getDefaultMessage)
                .collect(Collectors.toList());
        return ExceptionUtils.createErrorResponse(errorCodes, HttpStatus.BAD_REQUEST);
    }

    /**
     * Handle CDS API Exceptions.
     *
     * @param ex exception
     * @return {@link ResponseEntity} responseEntity
     */
    @ExceptionHandler(value = CustLookUpException.class)
    public ResponseEntity<ErrorResponse> handleCustLookUpException(CustLookUpException ex) {
        LOGGER.error(ValidationConstants.EXCEPTION_MSG, ex.getMessage());
        if (ex.getMessage().contains(CustLookUpConstants.NOT_FOUND)) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else if (ex.getMessage().contains(ValidationConstants.INVALID_SUBSCRIBER_ID_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.INVALID_SUBSCRIBER_ID_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.MEMBER_NOT_FOUND_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.MEMBER_NOT_FOUND_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.INVALID_PEID_OR_SUBSCRIBER_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.INVALID_PEID_OR_SUBSCRIBER_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.ARG_NOT_VALID_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.ARG_NOT_VALID_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.ERROR_MSG_PRODUCT_ENROLLMENT_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(
                    ValidationConstants.ERROR_MSG_PRODUCT_ENROLLMENT_EC),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        } else {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.CDS_API_ISSUE_EC),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Handle Action ITP API Exceptions.
     *
     * @param ex exception
     * @return {@link ResponseEntity} responseEntity
     */
    @ExceptionHandler(value = ActionItpException.class)
    public ResponseEntity<ErrorResponse> handleActionItpApiException(ActionItpException ex) {
        if (ex.getMessage().contains(ValidationConstants.AGENT_ID_INVALID_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.AGENT_ID_INVALID_EC),
                    HttpStatus.BAD_REQUEST);
        } else {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.ACTION_ITP_API_ISSUE_EC),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Handle Cloak API Exceptions.
     *
     * @param ex exception
     * @return {@link ResponseEntity} responseEntity
     */
    @ExceptionHandler(value = CloakException.class)
    public ResponseEntity<ErrorResponse> handleCloakException(CloakException ex) {
        LOGGER.error(ValidationConstants.EXCEPTION_MSG, ex.getMessage());
        return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.CLOAK_API_ISSUE_EC),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGlobalException(Exception ex) {
        LOGGER.error(ValidationConstants.EXCEPTION_MSG, ex.getMessage());
        if (ex.getMessage().contains(ValidationConstants.JSON_PARSING_ERROR)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(
                    ValidationConstants.PARSING_ERROR_EC),
                    HttpStatus.BAD_REQUEST);
        } else {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.INTERNAL_SERVER_ISSUE_EC),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Handle Memo Api Exceptions.
     *
     * @param ex exception
     * @return {@link ResponseEntity} responseEntity
     */
    @ExceptionHandler(value = MemoException.class)
    public ResponseEntity<ErrorResponse> handleMemoException(MemoException ex) {
        LOGGER.error(ValidationConstants.EXCEPTION_MSG, ex.getMessage());
        if (ex.getMessage().contains(ValidationConstants.PEID_INVALID_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.PEID_INVALID_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.AGENT_ID_INVALID_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.AGENT_ID_INVALID_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.MEMO_TEXT_INVALID_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.MEMO_TEXT_INVALID_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.PEID_NO_CONTENT_EC)) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.INTERNAL_SERVER_ISSUE_EC),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Handle Membership Exception.
     *
     * @param ex actual Exception
     * @return response entity
     */
    @ExceptionHandler(value = MembershipException.class)
    public ResponseEntity<ErrorResponse> handleMembershipException(MembershipException ex) {
        LOGGER.error(ValidationConstants.EXCEPTION_MSG,
                org.apache.commons.lang3.exception.ExceptionUtils.getStackTrace(ex));
        if (ex.getMessage().equalsIgnoreCase(MembershipConstants.MEMBERSHIP_NOT_FOUND)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.MEMBERSHIP_INVALID_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.AGENT_ID_INVALID_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.AGENT_ID_INVALID_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.PEID_INVALID_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.PEID_INVALID_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.PEID_INVALID_LENGTH_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.PEID_INVALID_LENGTH_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.PEID_NOT_FOUND_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.PEID_NOT_FOUND_EC),
                    HttpStatus.BAD_REQUEST);
        } else {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.INTERNAL_SERVER_ISSUE_EC),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Handle Account Activity Api Exceptions.
     *
     * @param ex exception
     * @return {@link ResponseEntity} responseEntity
     */
    @ExceptionHandler(value = AccountActivityException.class)
    public ResponseEntity<ErrorResponse> handleAccountActivityException(AccountActivityException ex) {
        LOGGER.error(ValidationConstants.EXCEPTION_MSG, ex.getMessage());
        if (ex.getMessage().contains(ValidationConstants.PEID_INVALID_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.PEID_INVALID_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.PEID_NO_CONTENT_EC)) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else if (ex.getMessage().contains(ValidationConstants.INVALID_OPERATOR_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.INVALID_OPERATOR_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.INVALID_REQUEST_DATE_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.INVALID_REQUEST_DATE_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.ACCOUNT_ACTIVITY_NO_CONTENT_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.ACCOUNT_ACTIVITY_NO_CONTENT_EC),
                    HttpStatus.NO_CONTENT);
        } else if (ex.getMessage().contains(ValidationConstants.NO_CODE_ENTITIES_EC)) {
            return ExceptionUtils.createErrorResponse(
                    Arrays.asList(ValidationConstants.NO_CODE_ENTITIES_EC),
                    HttpStatus.NO_CONTENT);
        } else if (ex.getMessage().contains(ValidationConstants.FAILED_TO_GET_CODE_ENTITIES_EC)) {
            return ExceptionUtils.createErrorResponse(
                    Arrays.asList(ValidationConstants.FAILED_TO_GET_CODE_ENTITIES_EC),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        } else {
            return ExceptionUtils.createErrorResponse(
                    Arrays.asList(ValidationConstants.ERROR_INSERTING_IN_ACCOUNT_ACTIVITY_DB_EC),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Handle Verint Api Exceptions.
     *
     * @param ex exception
     * @return {@link ResponseEntity} responseEntity
     */
    @ExceptionHandler(value = CallException.class)
    public ResponseEntity<ErrorResponse> handleCallException(CallException ex) {
        LOGGER.error(ValidationConstants.EXCEPTION_MSG, ex.getMessage());
        if (ex.getMessage().contains(ValidationConstants.PEID_INVALID_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.PEID_INVALID_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.INVALID_CUST_TYPE_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.INVALID_CUST_TYPE_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.AGENT_ID_INVALID_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.AGENT_ID_INVALID_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.TAG_DATA_ERROR_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.TAG_DATA_ERROR_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.CALL_NOT_ACTIVE_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.CALL_NOT_ACTIVE_EC),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        } else if (ex.getMessage().contains(ValidationConstants.ERROR_VERIFYING_CALL_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.ERROR_VERIFYING_CALL_EC),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        } else {
            return ExceptionUtils.createErrorResponse(
                    Arrays.asList(ValidationConstants.ERROR_RECORDING_CALL_EC),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Handle Cancel Api Exceptions.
     *
     * @param ex exception
     * @return {@link ResponseEntity} responseEntity
     */
    @ExceptionHandler(value = CancelException.class)
    public ResponseEntity<ErrorResponse> handleCancelException(CancelException ex) {
        LOGGER.error(ValidationConstants.EXCEPTION_MSG, ex.getMessage());
        if (ex.getMessage().contains(ValidationConstants.MEMBERSHIP_ID_NOT_FOUND_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.MEMBERSHIP_ID_NOT_FOUND_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.BAD_REQUEST)) {
            return ExceptionUtils.createErrorResponse(
                    Arrays.asList(ValidationConstants.CANCEL_MEMBERSHIP_BAD_REQUEST_EC),
                    HttpStatus.BAD_REQUEST);
        } else {
            return ExceptionUtils.createErrorResponse(
                    Arrays.asList(ValidationConstants.ERROR_CANCEL_MEMBERSHIP_EC),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Handle Request Reason API Exceptions.
     *
     * @param ex exception
     * @return {@link ResponseEntity} responseEntity
     */
    @ExceptionHandler(value = RequestReasonsException.class)
    public ResponseEntity<ErrorResponse> handleRequestReasonsException(RequestReasonsException ex) {
        LOGGER.error(ValidationConstants.EXCEPTION_MSG, ex.getMessage());
        if (ex.getMessage().contains(MembershipConstants.REQUEST_REASONS_NOT_FOUND)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.REQUEST_REASONS_NOT_FOUND_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.AGENT_ID_INVALID_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.AGENT_ID_INVALID_EC),
                    HttpStatus.BAD_REQUEST);
        } else {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.INTERNAL_SERVER_ISSUE_EC),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Handle Flux Listener Exceptions.
     *
     * @param ex exception
     * @return {@link ResponseEntity} responseEntity
     */
    @ExceptionHandler(value = FluxException.class)
    public ResponseEntity<ErrorResponse> handleFluxException(FluxException ex) {
        LOGGER.error(ValidationConstants.EXCEPTION_MSG, ex.getMessage());
        if (ex.getMessage().contains(ActionItpConstants.FLUX_PUBLISH_ERROR)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.ERROR_FLUX_PUBLISH_EVENT_EC),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.ERROR_FLUX_PAYLOAD_EC),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Handle OOB Service Exceptions.
     *
     * @param ex exception
     * @return {@link ResponseEntity} responseEntity
     */
    @ExceptionHandler(value = OobSoapException.class)
    public ResponseEntity<ErrorResponse> handleOobSoapException(OobSoapException ex) {
        LOGGER.error(ValidationConstants.EXCEPTION_MSG, ex.getMessage());
        Optional<ActionItpError> response = ActionItpConstants.OOB_ACTION_ITP_ERROR_MAP.stream()
                .filter(actionItpError -> ex.getMessage().contains(actionItpError.description))
                .findFirst();

        return response.map(actionItpError -> ExceptionUtils.createErrorResponse(
                Arrays.asList(actionItpError.code),
                actionItpError.status)).orElseGet(() -> ExceptionUtils.createErrorResponse(
                Arrays.asList(ValidationConstants.ERROR_OOB_SERVICE_EC),
                HttpStatus.INTERNAL_SERVER_ERROR));
    }

    /**
     * Handle Language Settings Service Exceptions.
     *
     * @param ex exception
     * @return {@link ResponseEntity} responseEntity
     */
    @ExceptionHandler(value = LanguageSettingsException.class)
    public ResponseEntity<ErrorResponse> handleLanguageSettingsException(LanguageSettingsException ex) {
        LOGGER.error(ValidationConstants.EXCEPTION_MSG, ex.getMessage());
        if (ex.getMessage().contains(ValidationConstants.LANGUAGE_NO_DATA_UPDATE_EM)) {
            return new ResponseEntity<>(HttpStatus.CREATED);
        } else if (ex.getMessage().contains(ValidationConstants.PEID_INVALID_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(
                    ValidationConstants.PEID_INVALID_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(ValidationConstants.PEID_NO_CONTENT_EC)) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else if (ex.getMessage().contains(
                ValidationConstants.ERROR_LANGUAGE_CODE_EC)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(
                    ValidationConstants.ERROR_LANGUAGE_CODE_EC),
                    HttpStatus.BAD_REQUEST);
        } else if (ex.getMessage().contains(LanguageSettingsConstants.SAVE_LANGUAGE_EXCEPTION)) {
            return ExceptionUtils.createErrorResponse(Arrays.asList(
                    ValidationConstants.ERROR_INSERTING_IN_LANGUAGE_DB_EC),
                    HttpStatus.BAD_REQUEST);
        } else {
            return ExceptionUtils.createErrorResponse(Arrays.asList(
                    ValidationConstants.INTERNAL_SERVER_ISSUE_EC),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Handle Itp Account Center Api Exceptions.
     *
     * @param ex exception
     * @return {@link ResponseEntity} responseEntity
     */
    @ExceptionHandler(value = ItpAccountCenterException.class)
    public ResponseEntity<ErrorResponse> handleItpAccountCenterException(ItpAccountCenterException ex) {
        LOGGER.error(ValidationConstants.EXCEPTION_MSG, ex.getMessage());
        if (ex.getMessage().contains(CustomerProfileConstants.NOT_FOUND) ||
                ex.getMessage().contains(CustomerProfileConstants.NO_ACTION)) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return ExceptionUtils.createErrorResponse(Arrays.asList(ValidationConstants.INTERNAL_SERVER_ISSUE_EC),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
