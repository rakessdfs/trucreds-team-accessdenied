package com.discover.cmpp.action.itp.custlookup;

import com.discover.cmpp.action.itp.cloak.CloakException;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.custlookup.model.CustomerInfoResponse;
import com.discover.cmpp.action.itp.custlookup.model.CustomerSearchRequest;
import com.discover.cmpp.action.itp.custlookup.model.CustomerSearchResponse;

public interface CustLookUpService {

    /**
     * This method is used to fetch PII information from
     * CDS using partyId of the customer.
     *
     * @param agentId of the agent
     * @param partyId of the cds customer
     * @return CustomerInfoResponse response with customer cds info
     * @throws CloakException      when cloak api issue
     * @throws CustLookUpException when is CDS api issue
     * @throws ActionItpException  when Action ITP api issue
     */
    CustomerInfoResponse customerInfo(String agentId, String partyId)
            throws CloakException, ActionItpException, CustLookUpException;

    /**
     * This method is used to search for customers and fetch PII information from
     * CDS using firstName lastName and DOBToken.
     *
     * @param agentId               of the agent
     * @param customerSearchRequest input request with customer query
     * @return CustomerSearchResponse response with list customer with fn, ln, partyId and ssn
     * @throws CloakException      when cloak api issue
     * @throws CustLookUpException when is CDS api issue
     * @throws ActionItpException  when Action ITP api issue
     */
    CustomerSearchResponse customerSearch(String agentId, CustomerSearchRequest customerSearchRequest)
            throws CloakException, ActionItpException, CustLookUpException;
}