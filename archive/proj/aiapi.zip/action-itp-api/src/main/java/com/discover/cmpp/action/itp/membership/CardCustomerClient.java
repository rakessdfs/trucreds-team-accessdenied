package com.discover.cmpp.action.itp.membership;

import com.discover.cmpp.action.itp.membership.model.billing.CardCustomerDataRequest;
import com.discover.cmpp.action.itp.membership.model.billing.CardCustomerDataResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.Map;

@FeignClient(name = "cardCustomerDataApi", url = "${cardCustomerDataApi.service.baseUrl}")
public interface CardCustomerClient {

    @PostMapping(value = "${cardCustomerDataApi.service.cardCustomerDataQuery}")
    ResponseEntity<CardCustomerDataResponse> fetchCardCustomerData(@RequestHeader Map<String,
            String> headerMap, CardCustomerDataRequest cardCustomerDataRequest);
}
