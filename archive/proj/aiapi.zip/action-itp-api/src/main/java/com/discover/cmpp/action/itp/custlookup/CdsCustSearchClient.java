package com.discover.cmpp.action.itp.custlookup;

import com.discover.cmpp.action.itp.custlookup.model.CustPiiSearchRequest;
import com.discover.cmpp.action.itp.custlookup.model.CustPiiSearchResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.Map;

@FeignClient(name = "CdsCustSearch", url = "${cdsCustSearch.service.baseUrl}")
public interface CdsCustSearchClient {

    @PostMapping(value = "${cdsCustSearch.service.custPiiLookUp}")
    ResponseEntity<CustPiiSearchResponse> customerPiiQuery(@RequestHeader Map<String, String> headerMap,
                                                           CustPiiSearchRequest request);
}
