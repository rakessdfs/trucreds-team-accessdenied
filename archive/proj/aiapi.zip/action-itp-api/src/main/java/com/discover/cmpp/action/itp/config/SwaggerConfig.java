package com.discover.cmpp.action.itp.config;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Configuration class for Swagger API documentation.
 *
 * @author ppratap
 * @version 1.0.0
 * @since 1.0.0
 */
@EnableSwagger2
@Configuration
public class SwaggerConfig {

    @Value("${server.servlet.context-path}")
    private String contextPath;
    @Value("${api.swagger.title}")
    private String title;
    @Value("${api.swagger.contact.name}")
    private String contactName;
    @Value("${api.swagger.contact.email}")
    private String contactEmail;
    @Value("${api.swagger.contact.url}")
    private String contactUrl;
    @Value("${api.swagger.version}")
    private String apiVersion;
    @Value("${api.swagger.description}")
    private String apiDescription;

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder().title(title).description(apiDescription).version(apiVersion)
                .contact(new Contact(contactName, contactUrl, contactEmail)).build();
    }

    @Bean
    public Docket itpServicingApiDocket() {
        return new Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfo()).select()
                .apis(RequestHandlerSelectors.basePackage(ActionItpConstants.BASE_PACKAGE)).build()
                .useDefaultResponseMessages(false);
    }
}
