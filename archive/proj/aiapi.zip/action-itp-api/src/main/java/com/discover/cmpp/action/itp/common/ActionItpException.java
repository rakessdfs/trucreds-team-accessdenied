package com.discover.cmpp.action.itp.common;

public class ActionItpException extends RuntimeException {

    private static final long serialVersionUID = -7137924831698067982L;

    public ActionItpException(String message) {
        super(message);
    }
}
