package com.discover.cmpp.action.itp.common;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ActionItpError {

    protected String code;

    protected String description;

    protected HttpStatus status;
}