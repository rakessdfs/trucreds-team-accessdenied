package com.discover.cmpp.action.itp.flux;

public class ActivityPayloadConstants {

    private ActivityPayloadConstants() {
    }

    public static final String ACTIVITY_CODE = "activityCode";

    public static final String PREVIOUS_DATA = "previousData";

    public static final String NEW_DATA = "newData";

    public static final String OPERATOR = "operator";

    public static final String PRODUCT_ENROLLMENT_ID = "productEnrollmentId";

    public static final String REQUEST_DATE = "requestDate";
}
