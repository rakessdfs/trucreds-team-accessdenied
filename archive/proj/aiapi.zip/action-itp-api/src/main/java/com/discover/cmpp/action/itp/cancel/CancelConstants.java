package com.discover.cmpp.action.itp.cancel;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class CancelConstants {

    public static final String CANCEL_REQUEST_API_URL = "/cancel/membership";
    public static final String CANCEL_REQUEST_API = "API to Cancel membersip by DFS Agents";
    public static final String CANCEL_REQUEST_API_NOTES =
            "API for submitting cancel request for the customer by DFS Agents";
    public static final String PRODUCT_ENROLLMENT_ID = "productEnrollmentId";
    public static final String PARTY_ID = "partyId";
    public static final String CANCEL_RSN_CDE = "cancelReasonCode";
    public static final String CANCEL_MEMBERSHIP_ERROR = "Error cancelling membership in pearl: {}";
    public static final String BUSINESS_CODE_EC = "EC";
    public static final String REQUEST_SRC_CODE_ACT = "ACT";
}
