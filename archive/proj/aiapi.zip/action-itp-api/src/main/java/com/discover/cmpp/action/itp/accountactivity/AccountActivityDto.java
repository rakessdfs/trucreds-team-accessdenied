package com.discover.cmpp.action.itp.accountactivity;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AccountActivityDto {

    private Long accountActivityId;
    private String productEnrollmentId;
    private String activityDesc;
    private String previousData;
    private String newData;
    private String operator;
    private LocalDateTime requestDate;
}
