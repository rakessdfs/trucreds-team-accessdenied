package com.discover.cmpp.action.itp.config;

import ch.vorburger.exec.ManagedProcessException;
import ch.vorburger.mariadb4j.springframework.MariaDB4jSpringService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import javax.sql.DataSource;

@Configuration
@Profile({"local", "test", "load-test"})
public class EmbeddedMariaDbConfig {

    @Bean
    @Profile({"local", "load-test"})
    public MariaDB4jSpringService mariaDB4jSpringService() {
        return new MariaDB4jSpringService();
    }

    @Bean("dataSource")
    @Profile({"local", "load-test"})
    public DataSource localDataSource(MariaDB4jSpringService mariaDB4jSpringService,
                                      @Value("${spring.datasource.databaseName}") String databaseName,
                                      @Value("${spring.datasource.username}") String datasourceUsername,
                                      @Value("${spring.datasource.driver-class-name}") String datasourceDriver)
            throws ManagedProcessException {
        mariaDB4jSpringService.getDB().createDB(databaseName);

        return DataSourceBuilder.create().username(datasourceUsername)
                .url(mariaDB4jSpringService.getConfiguration().getURL(databaseName)).driverClassName(datasourceDriver)
                .build();
    }

    @Bean
    @Profile("test")
    public MariaDbConfig mariaSpring(@Value("${mariaDB4j.baseDir}") String baseDir) {
        return new MariaDbConfig(baseDir);
    }

    @Bean("dataSource")
    @Profile("test")
    public DataSource testDataSource(MariaDbConfig mariaSpring,
                                     @Value("${spring.datasource.databaseName}") String databaseName,
                                     @Value("${spring.datasource.username}") String datasourceUsername,
                                     @Value("${spring.datasource.driver-class-name}") String datasourceDriver)
            throws ManagedProcessException {
        mariaSpring.getMariaDbSpringService().getDB().createDB(databaseName);

        return DataSourceBuilder.create().username(datasourceUsername)
                .url(mariaSpring.getMariaDbSpringService().getConfiguration().getURL(databaseName))
                .driverClassName(datasourceDriver).build();
    }
}