package com.discover.cmpp.action.itp.custlookup;

import com.discover.cmpp.action.itp.custlookup.model.cdslocation.CdsLocationRequest;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.CdsLocationResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdspersonal.CdsPersonalInfoRequest;
import com.discover.cmpp.action.itp.custlookup.model.cdspersonal.CdsPersonalInfoResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.Map;

@FeignClient(name = "CdsCustAccess", url = "${cdsCustAccess.service.baseUrl}")
public interface CdsCustAccessClient {

    @PostMapping(value = "${cdsCustAccess.service.location}")
    ResponseEntity<CdsLocationResponse> customerLocationInfo(@RequestHeader Map<String, String> headerMap,
                                                             CdsLocationRequest request);

    @PostMapping(value = "${cdsCustAccess.service.personalInfo}")
    ResponseEntity<CdsPersonalInfoResponse> customerPersonalInfo(@RequestHeader Map<String, String> headerMap,
                                                                 CdsPersonalInfoRequest request);
}
