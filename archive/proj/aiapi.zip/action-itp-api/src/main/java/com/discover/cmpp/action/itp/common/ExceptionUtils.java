package com.discover.cmpp.action.itp.common;

import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.List;

public interface ExceptionUtils {

    /**
     * This method to create the error response.
     *
     * @param errorCodes error code
     * @param httpStatus error message
     * @return ResponseEntity ErrorResponse with error detail
     */
    static ResponseEntity<ErrorResponse> createErrorResponse(List<String> errorCodes, HttpStatus httpStatus) {
        HashMap<String, String> errorMap = new HashMap<>();
        errorCodes.stream().forEach(code -> errorMap.put(code, ValidationConstants.getErrorMap().get(code)));
        ErrorResponse errorResponse = new ErrorResponse(errorMap);
        return new ResponseEntity<>(errorResponse, httpStatus);
    }
}
