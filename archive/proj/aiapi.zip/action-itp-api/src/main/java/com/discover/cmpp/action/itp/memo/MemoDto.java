package com.discover.cmpp.action.itp.memo;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class MemoDto {

    private Long memoId;
    private String productEnrollmentId;
    private String memoText;
    private String createAgentId;
    private LocalDateTime createTs;
    private String updateAgentId;
    private LocalDateTime updateTs;
}
