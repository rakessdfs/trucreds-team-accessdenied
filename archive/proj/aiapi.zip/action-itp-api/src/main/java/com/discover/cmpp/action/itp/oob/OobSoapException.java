package com.discover.cmpp.action.itp.oob;

public class OobSoapException extends Exception {

    private static final long serialVersionUID = -7117924831698067982L;

    public OobSoapException(String message) {
        super(message);
    }
}
