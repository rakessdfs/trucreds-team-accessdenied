package com.discover.cmpp.action.itp.accountactivity.model;

import com.discover.cmpp.action.itp.accountactivity.AccountActivityDto;
import lombok.Data;

import java.util.List;

@Data
public class AccountActivityResponse {

    List<AccountActivityDto> accountActivityList;
}
