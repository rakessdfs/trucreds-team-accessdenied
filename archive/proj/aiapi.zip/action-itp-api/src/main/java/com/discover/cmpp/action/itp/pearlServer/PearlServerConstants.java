package com.discover.cmpp.action.itp.pearlServer;

public class PearlServerConstants {

    private PearlServerConstants() {
    }

    // Pearl Server Get Memos
    public static final String GET_PCM_MEMOS_URL = "/getMemos/{membershipId}";
    public static final String GET_PCM_MEMOS_API = "API to fetch PCM memos";
    public static final String GET_PCM_MEMOS_API_NOTES =
            "API hits pearl server endpoint to fetch memos";

    // Pearl Server Get Account Activity
    public static final String GET_PCM_ACTIVITIES_URL = "/getActivities/{membershipId}";
    public static final String GET_PCM_ACTIVITIES_API = "API to fetch PCM account activity";
    public static final String GET_PCM_ACTIVITIES_API_NOTES =
            "API hits pearl server endpoint to fetch account activity";

    // Pearl Server Get Account Activity
    public static final String GET_PCM_MEMBERSHIP_URL = "/getMembership/{membershipId}";
    public static final String GET_PCM_MEMBERSHIP_API = "API to fetch PCM membership data";
    public static final String GET_PCM_MEMBERSHIP_API_NOTES =
            "API hits pearl server endpoint to membership data";
}
