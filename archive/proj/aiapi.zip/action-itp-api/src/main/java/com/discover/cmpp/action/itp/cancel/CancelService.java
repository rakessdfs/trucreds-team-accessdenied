package com.discover.cmpp.action.itp.cancel;

import com.discover.cmpp.action.itp.common.ActionItpException;

public interface CancelService {

    /**
     * To cancel the customer membership in pearl.
     *
     * @param agentId          agentId
     * @param peid             product enrollment Id
     * @param cancelReasonCode cancellation Reason Code
     * @return void
     */
    void cancelRequest(String agentId, String peid, String cancelReasonCode) throws CancelException,
            ActionItpException;
}
