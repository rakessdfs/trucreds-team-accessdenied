package com.discover.cmpp.action.itp.common;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.HashMap;

@AllArgsConstructor
@Data
public class ErrorResponse {

    @ApiModelProperty(value = "Error map (errorCode : errorDescription)",
            example = "{\"1002\":\"Invalid Date Of Birth\"}")
    private HashMap<String, String> errors;
}
