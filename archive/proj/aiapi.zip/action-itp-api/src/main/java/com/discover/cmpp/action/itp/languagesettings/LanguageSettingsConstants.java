package com.discover.cmpp.action.itp.languagesettings;

public class LanguageSettingsConstants {

    private LanguageSettingsConstants() {
    }

    public static final String SAVE_LANGUAGE_URL = "/language";
    public static final String FETCH_LANGUAGE_URL = "/language/{product-enrollment-id}";
    public static final String SAVE_LANGUAGE_API_NOTES = "API to create and update language settings " +
            "and language preference and store it in backend";
    public static final String SAVE_LANGUAGE_API = "API accepts the request and create/updates " +
            "language preference on the backend DB for the requested Product Enrollment ID.";

    public static final String SAVE_LANGUAGE_EXCEPTION = "Error in saving language " +
            "preference in DB with exception:";
    public static final String FETCH_LANGUAGE_API_NOTES = "API to fetch language " +
            "preference from DB";
    public static final String FETCH_LANGUAGE_API = "API fetches the language " +
            "preference on the backend DB for the requested Product Enrollment ID.";
    public static final String FETCH_LANGUAGE_EXCEPTION = "Error in fetching language " +
            "preference in DB with exception:";
    public static final String PRODUCT_ENROLLMENT_ID = "product-enrollment-id";

    public static final String ACCOUNT_ACTIVITY_CODE_CLP = "CLP";
    public static final String BLANKSTRING = "";
}
