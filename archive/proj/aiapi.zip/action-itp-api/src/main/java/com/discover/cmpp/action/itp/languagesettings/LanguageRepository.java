package com.discover.cmpp.action.itp.languagesettings;

import com.discover.cmpp.action.itp.languagesettings.model.LanguageEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LanguageRepository extends JpaRepository<LanguageEntity, Long> {

}
