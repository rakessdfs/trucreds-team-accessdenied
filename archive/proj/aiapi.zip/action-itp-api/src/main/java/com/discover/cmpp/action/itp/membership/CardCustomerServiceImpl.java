package com.discover.cmpp.action.itp.membership;

import com.discover.cmpp.action.itp.membership.model.billing.CardCustomerDataRequest;
import com.discover.cmpp.action.itp.membership.model.billing.CardCustomerDataResponse;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class CardCustomerServiceImpl implements CardCustomerService {

    private CardCustomerClient cardCustomerClient;

    public CardCustomerServiceImpl(CardCustomerClient cardCustomerClient) {
        this.cardCustomerClient = cardCustomerClient;
    }

    @Override
    @LogAround
    @LogExecutionTime
    /**
     * {@inheritDoc}
     *
     */
    public ResponseEntity<CardCustomerDataResponse> fetchCardCustomerData(Map<String, String> headerMap,
                        CardCustomerDataRequest cardCustomerDataRequest) {
        return cardCustomerClient.fetchCardCustomerData(headerMap, cardCustomerDataRequest);
    }
}
