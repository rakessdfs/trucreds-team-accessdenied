package com.discover.cmpp.action.itp.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@ConfigurationProperties(prefix = "tagging")
@Getter
@Setter
public class TaggingProperties {

    private Map<String, Map<String, String>> itp;
}
