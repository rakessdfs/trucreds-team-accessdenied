package com.discover.cmpp.action.itp.accountactivity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AccountActivityCodeRepository extends JpaRepository<AccountActivityCodeEntity, Long> {

    /**
     * Fetch account activity codes by account activity.
     *
     * @param activityCode activity code
     * @return {@link AccountActivityCodeEntity}
     */
    List<AccountActivityCodeEntity> findAllByActivityCode(String activityCode);

    /**
     * Fetch account activity codes by category.
     *
     * @param category category
     * @return {@link AccountActivityCodeEntity}
     */
    List<AccountActivityCodeEntity> findAllByCategory(String category);
}
