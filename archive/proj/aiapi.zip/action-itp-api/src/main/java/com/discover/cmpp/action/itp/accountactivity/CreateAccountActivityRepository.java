package com.discover.cmpp.action.itp.accountactivity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CreateAccountActivityRepository extends JpaRepository<CreateAccountActivityEntity, Long> {

}
