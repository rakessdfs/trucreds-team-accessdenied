package com.discover.cmpp.action.itp.custlookup;

import com.discover.cmpp.action.itp.custlookup.model.CustPiiSearchRequest;
import com.discover.cmpp.action.itp.custlookup.model.CustPiiSearchResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.CdsLocationRequest;
import com.discover.cmpp.action.itp.custlookup.model.cdslocation.CdsLocationResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdspersonal.CdsPersonalInfoRequest;
import com.discover.cmpp.action.itp.custlookup.model.cdspersonal.CdsPersonalInfoResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdstranslation.CdsTranslationAlternateIdResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdstranslation.CdsTranslationReqSrcCodeResponse;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

public interface CdsService {

    /**
     * To Get the Customer location info(address, phone, email) from CDS.
     *
     * @param headerMap          - Request Header map
     * @param cdsLocationRequest - details of Customer who request location info
     * @return - Location info
     */
    ResponseEntity<CdsLocationResponse> getCustomerLocationInfo(Map<String, String> headerMap,
                                                                CdsLocationRequest cdsLocationRequest);

    /**
     * To Get the Customer personal info(name, ssn, dob) from CDS.
     *
     * @param headerMap              - Request Header map
     * @param cdsPersonalInfoRequest - details of Customer who request personal info
     * @return - personal info
     */
    ResponseEntity<CdsPersonalInfoResponse> getCustomerPersonalInfo(Map<String, String> headerMap,
                                                                    CdsPersonalInfoRequest cdsPersonalInfoRequest);

    /**
     * To search for Customer using FirstName, LastName and dob in CDS.
     *
     * @param headerMap         - Request Header map
     * @param custSearchRequest - request with  Customer's FirstName, LastName and dob
     * @return - List of Customer found
     */
    ResponseEntity<CustPiiSearchResponse> searchCustomerPii(Map<String,
            String> headerMap, CustPiiSearchRequest custSearchRequest);

    /**
     * To search for Party Id using Product Enrollment Id.
     *
     * @param headerMap - Request header map
     * @param peid      - Request customer's peid
     * @return ResponseEntity List
     */
    ResponseEntity<List<CdsTranslationAlternateIdResponse>> getPartyId(Map<String,
            String> headerMap, String peid);

    /**
     * To search for requestSourceCode using partyId. If PD code is found, then its FnF Customer.
     *
     * @param headerMap - Request header map
     * @param partyId   - Request customer's partyId
     * @return ResponseEntity List
     */
    ResponseEntity<List<CdsTranslationReqSrcCodeResponse>> getIsItpUser(Map<String,
            String> headerMap, String partyId);
}
