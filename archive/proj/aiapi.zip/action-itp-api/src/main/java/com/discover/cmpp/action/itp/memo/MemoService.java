package com.discover.cmpp.action.itp.memo;

import com.discover.cmpp.action.itp.cloak.CloakException;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.custlookup.CustLookUpException;
import com.discover.cmpp.action.itp.membership.MembershipException;

public interface MemoService {

    /**
     * This method is used to create memo based on the input request and stores in DB.
     *
     * @param createMemoRequest input request with memo details
     * @param createAgentId     agentId who create's new memo.
     * @throws MemoException when exception occurred while saving memo in DB
     */
    void createMemo(CreateMemoRequest createMemoRequest, String createAgentId) throws MemoException,
            ActionItpException, MembershipException, CloakException, CustLookUpException;

    /**
     * This method is used to create memo based on the input request and stores in DB.
     *
     * @param productEnrollmentId product enrollment id
     * @return MemoResponse list of memos
     * @throws MemoException when exception occurred while fetching memo from DB
     */
    MemoResponse fetchMemos(String productEnrollmentId) throws MemoException;
}
