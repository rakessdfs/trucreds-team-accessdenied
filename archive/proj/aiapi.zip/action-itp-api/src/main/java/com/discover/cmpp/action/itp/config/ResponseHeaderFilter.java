package com.discover.cmpp.action.itp.config;

import org.springframework.stereotype.Component;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.discover.cmpp.action.itp.common.ActionItpConstants.CACHE_CONTROL;
import static com.discover.cmpp.action.itp.common.ActionItpConstants.CACHE_CONTROL_VALUE;
import static com.discover.cmpp.action.itp.common.ActionItpConstants.EXPIRES;
import static com.discover.cmpp.action.itp.common.ActionItpConstants.EXPIRES_VALUE;
import static com.discover.cmpp.action.itp.common.ActionItpConstants.PRAGMA;
import static com.discover.cmpp.action.itp.common.ActionItpConstants.PRAGMA_VALUE;

@WebFilter("/*")
@Component
public class ResponseHeaderFilter implements Filter {

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {
        HttpServletResponse httpServletResponse = (HttpServletResponse) servletResponse;
        httpServletResponse.setHeader(CACHE_CONTROL, CACHE_CONTROL_VALUE);
        httpServletResponse.setHeader(PRAGMA, PRAGMA_VALUE);
        httpServletResponse.setHeader(EXPIRES, EXPIRES_VALUE);
        filterChain.doFilter(servletRequest, servletResponse);
    }
}