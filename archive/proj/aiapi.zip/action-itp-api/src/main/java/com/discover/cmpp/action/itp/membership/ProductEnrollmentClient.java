package com.discover.cmpp.action.itp.membership;

import com.discover.cmpp.action.itp.membership.model.EnrollmentLookupResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

@FeignClient(name = "productEnrollmentApi", url = "${productEnrollmentApi.service.baseUrl}")
public interface ProductEnrollmentClient {

    @GetMapping(value = "${productEnrollmentApi.service.enrollmentLookup}")
    ResponseEntity<EnrollmentLookupResponse> getEnrollmentInfo(
            @RequestHeader Map<String, String> headerMap,
            @RequestParam(value = "productEnrollmentId") String peId);

    @GetMapping(value = "${productEnrollmentApi.service.enrollmentLookup}")
    ResponseEntity<EnrollmentLookupResponse> getPeid(
            @RequestHeader Map<String, String> headerMap,
            @RequestParam(value = "subscriberId") String subscriberId);
}
