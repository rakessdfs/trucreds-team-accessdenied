package com.discover.cmpp.action.itp.languagesettings;

public class LanguageSettingsException extends Exception {

    public LanguageSettingsException(String message) {
        super(message);
    }
}
