package com.discover.cmpp.action.itp.accountactivity;

import com.discover.cmpp.action.itp.accountactivity.model.AccountActivityResponse;
import com.discover.cmpp.action.itp.accountactivity.model.ActivityToAnalyticsRequest;
import com.discover.cmpp.action.itp.accountactivity.model.ActivityToAnalyticsResponse;
import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ActionItpUtil;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.custlookup.CdsService;
import com.discover.cmpp.action.itp.custlookup.model.cdstranslation.CdsTranslationAlternateIdResponse;
import com.discover.cmpp.action.itp.flux.publish.accountactivity.AccountActivityPublishService;
import com.discover.cmpp.action.itp.accountactivity.model.AccountActivityCodeRequest;
import com.discover.cmpp.action.itp.flux.schema.AccountActivityPayload;
import com.discover.cmpp.action.itp.flux.schema.AnalyticsActivityMessage;
import com.discover.cmpp.action.itp.membership.ProductService;
import com.discover.cmpp.action.itp.membership.model.EnrollmentLookupResponse;
import com.discover.cmpp.action.itp.membership.model.MembershipInfo;
import com.discover.cmpp.utils.CommonConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

import static com.discover.cmpp.action.itp.accountactivity.AccountActivityConstants.ACTIVITY_CODE_CACHE_NAME;
import static com.discover.cmpp.action.itp.common.validation.ValidationConstants.FAILED_TO_GET_CODE_ENTITIES_EC;
import static com.discover.cmpp.action.itp.common.validation.ValidationConstants.NO_CODE_ENTITIES_EC;
import static java.time.ZoneOffset.UTC;
import static org.apache.commons.lang.StringUtils.isNotBlank;

@Service
public class AccountActivityServiceImpl implements AccountActivityService {

    private final AccountActivityRepository accountActivityRepository;
    private final CreateAccountActivityRepository createAccountActivityRepository;
    private final AccountActivityPublishService activityPublishService;
    private final AccountActivityCodeRepository accountActivityCodeRepository;
    private final CdsService cdsService;
    private final ActionItpUtil itpUtil;
    private final ProductService productService;
    private final CsidReportingService csidReportingService;
    private final CacheManager cacheManager;

    private static final Logger LOGGER = LoggerFactory.getLogger(AccountActivityServiceImpl.class);

    // Sonar disabled for constructor since 8 params is more than 7 allowed in a method,
    // but can't get around it since this is a constructor and not normal method
    public AccountActivityServiceImpl(AccountActivityRepository accountActivityRepository, //NOSONAR
                                      CreateAccountActivityRepository createAccountActivityRepository,
                                      AccountActivityPublishService activityPublishService,
                                      AccountActivityCodeRepository accountActivityCodeRepository,
                                      CdsService cdsService, ActionItpUtil itpUtil, ProductService productService,
                                      CsidReportingService csidReportingService, CacheManager cacheManager) {
        this.accountActivityRepository = accountActivityRepository;
        this.createAccountActivityRepository = createAccountActivityRepository;
        this.activityPublishService = activityPublishService;
        this.accountActivityCodeRepository = accountActivityCodeRepository;
        this.cdsService = cdsService;
        this.itpUtil = itpUtil;
        this.productService = productService;
        this.csidReportingService = csidReportingService;
        this.cacheManager = cacheManager;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void createActivity(AccountActivityPayload accountActivityPayload) throws AccountActivityException {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            LocalDateTime requestDate = LocalDateTime.parse(accountActivityPayload.getRequestDate(),
                    formatter);
            createAccountActivityRepository.save(createPersistActivityEntity(accountActivityPayload, requestDate));
        } catch (DateTimeParseException e) {
            throw new AccountActivityException(ValidationConstants.INVALID_REQUEST_DATE_EC);
        } catch (Exception e) {
            LOGGER.error("Error while saving new activity in DB with exception: {}", ExceptionUtils.getStackTrace(e));
            throw new AccountActivityException(ValidationConstants.ERROR_INSERTING_IN_ACCOUNT_ACTIVITY_DB_EC);
        }
    }

    private CreateAccountActivityEntity createPersistActivityEntity(AccountActivityPayload accountActivityPayload,
                                                                    LocalDateTime requestDate) {
        return CreateAccountActivityEntity.builder()
                .productEnrollmentId(accountActivityPayload.getProductEnrollmentId())
                .activityCode(accountActivityPayload.getActivityCode())
                .operator(accountActivityPayload.getOperator())
                .previousData(accountActivityPayload.getPreviousData())
                .newData(accountActivityPayload.getNewData())
                .requestDate(requestDate)
                .createTs(OffsetDateTime.now(UTC).toLocalDateTime())
                .build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void createAccountActivityCode(AccountActivityCodeRequest accountActivityCodeRequest)
            throws AccountActivityException {
        try {
            accountActivityCodeRepository.save(createPersistAccountActivityCodeEntity(accountActivityCodeRequest));
            LOGGER.info("Successfully inserted new activity code entity");
        } catch (Exception e) {
            LOGGER.error("Error while saving new activity in DB with exception: {}", ExceptionUtils.getStackTrace(e));
            throw new AccountActivityException(ValidationConstants.ERROR_INSERTING_IN_ACCOUNT_ACTIVITY_DB_EC);
        }
        try {
            LOGGER.info("Clearing cache after DB update");
            Objects.requireNonNull(cacheManager.getCache(ACTIVITY_CODE_CACHE_NAME)).clear();
        } catch (NullPointerException e) {
            LOGGER.error("Error clearing cache with exception: {}", ExceptionUtils.getStackTrace(e));
            throw new AccountActivityException(ValidationConstants.FAILED_TO_REFRESH_CACHE_EC);
        }
    }

    private AccountActivityCodeEntity createPersistAccountActivityCodeEntity(
            AccountActivityCodeRequest accountActivityCodeRequest) {
        return AccountActivityCodeEntity.builder()
                .activityCode(accountActivityCodeRequest.getActivityCode())
                .activityDesc(accountActivityCodeRequest.getActivityDesc())
                .category(accountActivityCodeRequest.getCategory())
                .createTs(OffsetDateTime.now(UTC).toLocalDateTime())
                .build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public AccountActivityResponse fetchAccountActivityByPeid(String productEnrollmentId)
            throws AccountActivityException {
        AccountActivityResponse accountActivityResponse = new AccountActivityResponse();
        List<AccountActivityDto> accountActivityDtoList = new ArrayList<>();

        try {
            List<AccountActivityEntity> accountActivityEntityList =
                    accountActivityRepository.findAllByProductEnrollmentIdOrderByRequestDateDesc(productEnrollmentId);
            if (!CollectionUtils.isEmpty(accountActivityEntityList)) {
                accountActivityEntityList.forEach(
                        activity -> accountActivityDtoList.add(
                                AccountActivityUtil.convertAccountActivityEntityToAccountActivityDto(activity))
                );
            } else {
                LOGGER.info("No activities found for enrollment id: {}",
                        productEnrollmentId);
            }
        } catch (Exception e) {
            throw new AccountActivityException(ExceptionUtils.getStackTrace(e));
        }

        try {
            // Fetch account alerts
            String subscriberNumber = "";
            Map<String, String> headerMap = itpUtil.restClientHeader();
            ResponseEntity<EnrollmentLookupResponse> enrollmentLookupRsponse =
                    productService.getEnrollmentInfo(headerMap, productEnrollmentId);
            if (enrollmentLookupRsponse.getStatusCode().is2xxSuccessful()) {
                subscriberNumber = Objects.requireNonNull(enrollmentLookupRsponse.getBody()).getSubscriberId();

                if (StringUtils.isNotBlank(subscriberNumber)) {
                    List<ItpCsidAlertData> alertsList = csidReportingService.getItpAlerts(headerMap, subscriberNumber);

                    if (alertsList != null) {
                        // Convert alerts and add to accountActivityDtoList
                        alertsList.forEach(
                                alert -> addAlertToActivities(accountActivityDtoList, alert)
                        );
                    }
                }
            } else {
                // Print Error log and continue processing
                LOGGER.error("Enrollment Lookup request failed for product enrollment id: {}",
                        productEnrollmentId);
            }
        } catch (Exception e) {
            LOGGER.error("Error fetching alerts from reporting API. Will only display account activity. " +
                    "Error: {}\nStack Trace: {}", e.getMessage(), e.getStackTrace());
        }

        if (CollectionUtils.isEmpty(accountActivityDtoList)) {
            throw new AccountActivityException(ValidationConstants.PEID_NO_CONTENT_EC);
        }
        // Sort activities list per request date field
        Collections.sort(accountActivityDtoList, (x, y) -> y.getRequestDate().compareTo(x.getRequestDate()));
        accountActivityResponse.setAccountActivityList(accountActivityDtoList);

        return accountActivityResponse;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Cacheable(cacheNames = { ACTIVITY_CODE_CACHE_NAME }) // Use actuator to clear cache manually
    public List<AccountActivityCodeEntity> fetchAccountActivityCodes(String activityCode, String category)
            throws AccountActivityException {
        LOGGER.info("Cache not yet loaded for given activity code and category, querying DB");
        List<AccountActivityCodeEntity> entities;
        try {
            if (isNotBlank(activityCode)) {
                entities = accountActivityCodeRepository.findAllByActivityCode(activityCode);
            } else if (isNotBlank(category)) {
                entities = accountActivityCodeRepository.findAllByCategory(category);
            } else {
                entities = accountActivityCodeRepository.findAll();
            }
        } catch (Exception e) {
            LOGGER.error("Error fetching code entities");
            throw new AccountActivityException(e.getMessage() + " Error code: " + FAILED_TO_GET_CODE_ENTITIES_EC);
        }
        if (entities.isEmpty()) {
            LOGGER.error("No account activity code entities returned");
            throw new AccountActivityException("Empty entities list returned. Error code: " + NO_CODE_ENTITIES_EC);
        }
        return entities;
    }

    private void addAlertToActivities(List<AccountActivityDto> accountActivityDtoList, ItpCsidAlertData alert) {
        AccountActivityDto convertedAlert =
                AccountActivityUtil.convertAlertDataToAccountActivityDto(alert);
        // If null and form code doesn't indicate it's a credit summary, don't return alert
        if (null != convertedAlert.getActivityDesc()) {
            accountActivityDtoList.add(convertedAlert);
        }
    }

    /**
     * {@inheritDoc}
     *
     * @return
     */
    @Override
    public ActivityToAnalyticsResponse publishActivitiesToAnalytics(ActivityToAnalyticsRequest request)
            throws AccountActivityException, ActionItpException {
        // Validate activity codes
        List<AccountActivityEntity> finalActivityEntityList;
        String[] codes = request.getActivityCodes().split(",");
        List<AccountActivityCodeEntity> finalCodeEntityList = fetchCodeEntities(codes);
        // If no dates, fetch all activities from db for codes and add to list
        finalActivityEntityList =
                findActivities(finalCodeEntityList, request.getStartDate(), request.getEndDate());
        AtomicInteger publishedActivitiesCount = new AtomicInteger();
        ActivityToAnalyticsResponse activityToAnalyticsResponse;
        // For each activity:
        //  - Fetch info that isn't available in DB
        //  - Publish to flux
        finalActivityEntityList.stream().forEach(entity -> {
            try {
                String partyId = getPartyId(entity);
                if (StringUtils.isNotBlank(partyId)) {
                    MembershipInfo membershipDetails = getMembershipInfo(partyId);
                    if (membershipDetails != null) {
                        AnalyticsActivityMessage message = new AnalyticsActivityMessage(
                                membershipDetails.getMembershipEntity().getProductTypeCode(),
                                entity.getProductEnrollmentId(),
                                membershipDetails.getMembershipEntity().getMembershipPK().getMembershipId().toString(),
                                entity.getActivityCode().getActivityCode(),
                                entity.getActivityCode().getActivityDesc(),
                                entity.getPreviousData(),
                                entity.getNewData(),
                                entity.getOperator(),
                                entity.getRequestDate().toString(),
                                CommonConstants.CUSTOMERTYPE_TO_LEVEL_MAP
                                        .get(membershipDetails.getMembershipEntity().getLevelNumber()),
                                membershipDetails.getMembershipEntity().getLevelNumber());
                        if (activityPublishService.publishEvent(message)) {
                            publishedActivitiesCount.getAndIncrement();
                        }
                    } else {
                        LOGGER.error("Invalid membership info for product enrollment id: {}",
                                entity.getProductEnrollmentId());
                    }
                } else {
                    LOGGER.error("Invalid Party id for product enrollment id: {}", entity.getProductEnrollmentId());
                }
            } catch (Exception e) {
                LOGGER.error("Error while publishing account activity for peId: {}", entity.getProductEnrollmentId());
            }
        });
        activityToAnalyticsResponse = new ActivityToAnalyticsResponse();
        activityToAnalyticsResponse.setDatabaseActivitiesCount(finalActivityEntityList.size());
        activityToAnalyticsResponse.setPublishedActivitiesCount(publishedActivitiesCount.intValue());
        return activityToAnalyticsResponse;
    }

    private List<AccountActivityEntity> findActivities(List<AccountActivityCodeEntity> finalCodeEntityList,
                                                       String startDateStr, String endDateStr)
            throws AccountActivityException {
        List<AccountActivityEntity> finalActivityEntityList = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(
                ActionItpConstants.ACCOUNT_ACTIVITY_REQUEST_DATE_FORMAT);
        LocalDateTime startDate = null;
        LocalDateTime endDate = null;
        if (StringUtils.isNotBlank(startDateStr) && StringUtils.isNotBlank(endDateStr)) {
            try {
                startDate = LocalDateTime.parse(startDateStr, formatter);
                endDate = LocalDateTime.parse(endDateStr, formatter);
            } catch (Exception e) {
                throw new AccountActivityException(ValidationConstants.INVALID_REQUEST_DATE_EC);
            }
        }
        LocalDateTime finalStartDate = startDate;
        LocalDateTime finalEndDate = endDate;
        finalCodeEntityList.stream().forEach(entity -> {
            List<AccountActivityEntity> accountActivityEntityList;
            if ((finalStartDate != null) && (finalEndDate != null)) {
                accountActivityEntityList = accountActivityRepository
                        .findAllByActivityCodeAndRequestDateBetweenOrderByRequestDateDesc(entity,
                                finalStartDate, finalEndDate);
            } else {
                accountActivityEntityList = accountActivityRepository
                        .findAllByActivityCodeOrderByRequestDateDesc(entity);
            }
            if (!accountActivityEntityList.isEmpty()) {
                finalActivityEntityList.addAll(accountActivityEntityList);
            } else {
                LOGGER.error("Could not get any account activity for activity code: {}, startDate: {}, endDate: {}",
                        entity.getActivityCode(), startDateStr, endDateStr);
            }
        });
        if (finalActivityEntityList.isEmpty()) {
            throw new AccountActivityException(ValidationConstants.ACCOUNT_ACTIVITY_NO_CONTENT_EC);
        }
        return finalActivityEntityList;
    }

    private List<AccountActivityCodeEntity> fetchCodeEntities(String[] codes) throws AccountActivityException {
        if (codes.length == 0) {
            throw new AccountActivityException("Activity code missing");
        }
        List<AccountActivityCodeEntity> finalCodeEntityList = new ArrayList<>();
        for (String code : codes) {
            try {
                List<AccountActivityCodeEntity> entityList =
                        accountActivityCodeRepository.findAllByActivityCode(code);
                if (entityList.isEmpty()) {
                    throw new AccountActivityException("Invalid activity code");
                } else {
                    finalCodeEntityList.addAll(entityList);
                }
            } catch (Exception e) {
                LOGGER.error("Could not get entity for activity code: {}", code);
            }
        }
        if (finalCodeEntityList.isEmpty()) {
            throw new AccountActivityException("Please provide valid activity code(s)");
        }
        return finalCodeEntityList;
    }

    private String getPartyId(AccountActivityEntity finalActivityEntity) throws ActionItpException {
        Map<String, String> headerMap = itpUtil.restClientCdsHeader(finalActivityEntity.getOperator());
        String partyId = null;

        ResponseEntity<List<CdsTranslationAlternateIdResponse>> listResponseEntity =
                cdsService.getPartyId(headerMap, finalActivityEntity.getProductEnrollmentId());
        if (listResponseEntity.getBody() != null) {
            partyId = Objects.requireNonNull(listResponseEntity.getBody()).get(0).getPartyId();
        }
        if (partyId == null) {
            LOGGER.error("Could not get partyID for PEID: {}", finalActivityEntity.getProductEnrollmentId());
        }
        return partyId;
    }

    private MembershipInfo getMembershipInfo(String partyId) throws ActionItpException {
        Map<String, String> headerMap = itpUtil.restClientHeader();

        ResponseEntity<MembershipInfo> membershipInfoResponseEntity = productService
                .getMembershipByPartyId(headerMap,
                        partyId,
                        ActionItpConstants.ITF_PRODUCT_TYPE_CODE);
        if (membershipInfoResponseEntity.getStatusCode().is2xxSuccessful()) {
            if (null == membershipInfoResponseEntity.getBody()) {
                membershipInfoResponseEntity = productService
                        .getMembershipByPartyId(headerMap, partyId, ActionItpConstants.ITB_PRODUCT_TYPE_CODE);
            }
            return membershipInfoResponseEntity.getBody();
        }
        LOGGER.error("Could not get membership info for partyID: {}", partyId);
        return null;
    }
}
