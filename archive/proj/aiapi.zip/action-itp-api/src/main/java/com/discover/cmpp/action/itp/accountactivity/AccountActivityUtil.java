package com.discover.cmpp.action.itp.accountactivity;

import static com.discover.cmpp.action.itp.accountactivity.AccountActivityConstants.CREDIT_SUMMARY_ACTIVITY_DESC;
import static com.discover.cmpp.action.itp.accountactivity.AccountActivityConstants.CREDIT_SUMMARY_FORM_CODE;

public class AccountActivityUtil {

    private AccountActivityUtil() {
    }

    /**
     * This method will convert the Account Activity Entity to its corresponding DTO.
     *
     * @param accountActivity AccountActivityEntity
     * @return AccountActivityDto
     */
    public static AccountActivityDto convertAccountActivityEntityToAccountActivityDto(
            AccountActivityEntity accountActivity) {
        AccountActivityDto dto = new AccountActivityDto();
        dto.setAccountActivityId(accountActivity.getAccountActivityId());
        dto.setProductEnrollmentId(accountActivity.getProductEnrollmentId());
        dto.setActivityDesc(accountActivity.getActivityCode().getActivityDesc());
        dto.setPreviousData(accountActivity.getPreviousData());
        dto.setNewData(accountActivity.getNewData());
        dto.setOperator(accountActivity.getOperator());
        dto.setRequestDate(accountActivity.getRequestDate());
        return dto;
    }

    public static AccountActivityDto convertAlertDataToAccountActivityDto(ItpCsidAlertData alert) {
        AccountActivityDto accountActivityRecord = new AccountActivityDto();
        accountActivityRecord.setOperator("DSTRBTCH");
        accountActivityRecord.setProductEnrollmentId(alert.getEnrollmentId());
        accountActivityRecord.setRequestDate(alert.getCreateDate().toLocalDateTime());

        String desc = alert.getEventSubject();
        if (null == desc && alert.getFormCode().equalsIgnoreCase(CREDIT_SUMMARY_FORM_CODE)) {
            desc = CREDIT_SUMMARY_ACTIVITY_DESC;
        }
        accountActivityRecord.setActivityDesc(desc);

        return accountActivityRecord;
    }
}
