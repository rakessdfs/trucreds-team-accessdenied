package com.discover.cmpp.action.itp.oob;

import com.discover.cmpp.action.itp.oob.model.GetStatusResponse;
import com.discover.cmpp.action.itp.oob.model.OobServiceAoResponse;
import com.discover.cmpp.action.itp.oob.model.SendCodeRequest;
import com.discover.cmpp.action.itp.oob.model.UnlockUserRequest;
import com.discover.cmpp.action.itp.oob.model.ValidateCodeRequest;

public interface OobService {

    /**
     * This method is used to send code to user.
     *
     * @param alertPayload input parameter product enrollment is
     * @param requestedBy  agent id
     * @throws OobSoapException when exception occurred while sending code
     */
    OobServiceAoResponse sendCode(SendCodeRequest alertPayload, String requestedBy) throws OobSoapException;

    /**
     * This method is used to get user status.
     *
     * @param peid input parameter product enrollment is
     * @throws OobSoapException when exception occurred while fetching user status
     */
    GetStatusResponse getStatus(String peid) throws OobSoapException;

    /**
     * This method is used to get user status.
     *
     * @param request ValidateCodeRequest
     * @return OobServiceAoResponse Validated code response
     * @throws OobSoapException when exception occurred while fetching user status
     */
    OobServiceAoResponse validateOobCode(ValidateCodeRequest request) throws OobSoapException;

    /**
     * This method is responsible unlocking customer account post authentication.
     *
     * @param unlockUserRequest unlock user request
     * @param requestedBy       requested by
     * @return OobServiceAoResponse unlock user response
     * @throws OobSoapException when exception occurred while fetching user status
     */
    OobServiceAoResponse unlockUser(UnlockUserRequest unlockUserRequest, String requestedBy) throws OobSoapException;
}
