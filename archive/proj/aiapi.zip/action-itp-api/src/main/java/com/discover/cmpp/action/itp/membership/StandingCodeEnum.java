package com.discover.cmpp.action.itp.membership;

public enum StandingCodeEnum {

    CAN("Cancelled"),
    ENR("Enrolled"),
    PCN("Pending Cancellation"),
    PEN("Pending Enrollment"),
    PRC("Pending Reinstatement Cancellation"),
    PRI("Pending Reinstatement");

    private final String standingName;

    StandingCodeEnum(String standingName) {
        this.standingName = standingName;
    }

    String getStandingName() {
        return standingName;
    }
}
