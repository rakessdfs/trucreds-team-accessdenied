package com.discover.cmpp.action.itp.pearlServer;

import com.dfs.ws.jwt.generator.WSJWTException;
import com.dfs.ws.jwt.generator.WSJWTGenerator;
import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.oob.OobSoapException;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.interceptor.AbstractSoapInterceptor;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.Phase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * SoapInterceptor - used to add the generated JWT2 token to header.
 *
 * <p>Adds the token to HTTP_AUTH_TOKEN header in order to authenticate the soap service call
 */
@Component
public class PearlServerSoapInterceptor extends AbstractSoapInterceptor {

    private static final Logger LOGGER = LoggerFactory.getLogger(PearlServerSoapInterceptor.class);

    @Autowired
    WSJWTGenerator jwtGenerator;

    public PearlServerSoapInterceptor(WSJWTGenerator jwtGenerator) {
        super(Phase.POST_LOGICAL);
        this.jwtGenerator = jwtGenerator;
    }

    @Override
    public void handleMessage(SoapMessage message) {
        Map<String, List<String>> httpHeaders = new HashMap<>();
        try {
            httpHeaders.put(ActionItpConstants.HTTP_AUTH_TOKEN, Collections.singletonList(getJwtToken()));
        } catch (Exception e) {
            LOGGER.error("Exception when handling Soap message {}", e.getMessage());
        }
        message.put(Message.PROTOCOL_HEADERS, httpHeaders);
    }

    private String getJwtToken() throws OobSoapException {
        String jwtToken = ActionItpConstants.BLANK_STRING;
        try {
            jwtToken = jwtGenerator.getJWTToken();
        } catch (WSJWTException e) {
            throw new OobSoapException(
                    "JWT exception occured when getting token" + ExceptionUtils.getStackTrace(e));
        }
        return jwtToken;
    }
}