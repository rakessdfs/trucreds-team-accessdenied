package com.discover.cmpp.action.itp.membership;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ErrorResponse;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.membership.model.MembershipResponse;
import com.discover.cmpp.action.itp.membership.model.RequestReasonResponse;
import com.discover.cmpp.action.itp.membership.model.billing.BillingResponse;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@RequestMapping(value = "${api.context-path}")
@RestController
@Validated
public class MembershipController {

    private final MembershipService membershipService;

    public MembershipController(MembershipService membershipService) {
        this.membershipService = membershipService;
    }

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = MembershipConstants.FETCH_MEMBERSHIP_API,
            notes = MembershipConstants.FETCH_MEMBERSHIP_API_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_OK, message = ActionItpConstants.API_OK,
                    response = MembershipResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST,
                    message = ActionItpConstants.API_BAD_REQUEST,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED,
                    message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN,
            required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN),
            @ApiImplicitParam(name = ActionItpConstants.AGENT_ID, required = true,
                    dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
                    value = ActionItpConstants.AGENT_ID_VALUE)})
    @GetMapping(value = MembershipConstants.FETCH_MEMBERSHIP_URL)
    public ResponseEntity<MembershipResponse> fetchMembershipInformation(
            @RequestHeader(ActionItpConstants.AGENT_ID) @NotBlank(
                    message = ValidationConstants.AGENT_ID_INVALID_EC) String agentId,
            @RequestParam(value = MembershipConstants.PARTY_ID_PARAM, required = true)
            @NotBlank(message = ValidationConstants.PARTYID_INVALID_EC) String partyId) throws MembershipException,
            ActionItpException {
        return new ResponseEntity<>(membershipService.fetchItpMembershipInformation(agentId, partyId), HttpStatus.OK);
    }

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = MembershipConstants.FETCH_BILLING_DETAILS_API,
            notes = MembershipConstants.FETCH_BILLING_API_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_OK, message = ActionItpConstants.API_OK,
                    response = BillingResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR),
            @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST,
                    message = ActionItpConstants.API_BAD_REQUEST,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED,
                    message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN,
            required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN),
            @ApiImplicitParam(name = ActionItpConstants.AGENT_ID, required = true,
                    dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
                    value = ActionItpConstants.AGENT_ID_VALUE)})
    @GetMapping(value = MembershipConstants.FETCH_BILLING_URL)
    public ResponseEntity<BillingResponse> fetchBillingInformation(
            @RequestHeader(ActionItpConstants.AGENT_ID)
            @Valid @NotBlank(message = ValidationConstants.AGENT_ID_INVALID_EC) String agentId,

            @RequestParam(value = MembershipConstants.PEID_PARAM, required = false)
            @NotNull(message = ValidationConstants.PEID_INVALID_EC)
                    BigDecimal peid,

            @RequestParam(value = MembershipConstants.SUBSCRIBER_ID_PARAM, required = true) String subscriberId,
            @RequestParam(value = MembershipConstants.CUSTOMER_TYPE_PARAM, required = true) String customerType,
            @RequestParam(value = MembershipConstants.PARTY_ID_PARAM, required = true) String partyId)
            throws MembershipException, ActionItpException {
        return new ResponseEntity<>(membershipService.fetchItpBillingInformation(customerType, partyId, peid,
                subscriberId), HttpStatus.OK);
    }

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = MembershipConstants.FETCH_REQUEST_REASONS_API,
            notes = MembershipConstants.FETCH_REQUEST_REASONS_API_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_OK, message = ActionItpConstants.API_OK,
                    response = MembershipResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST,
                    message = ActionItpConstants.API_BAD_REQUEST,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED,
                    message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN,
            required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN),
            @ApiImplicitParam(name = ActionItpConstants.AGENT_ID, required = true,
                    dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
                    value = ActionItpConstants.AGENT_ID_VALUE)})
    @GetMapping(value = MembershipConstants.FETCH_REQUEST_REASONS_URL)
    public ResponseEntity<RequestReasonResponse> fetchRequestReasons(
            @RequestHeader(ActionItpConstants.AGENT_ID) @NotBlank(
                    message = ValidationConstants.AGENT_ID_INVALID_EC) String agentId,
            @RequestParam(value = MembershipConstants.CUSTOMER_TYPE_PARAM, required = true)
            @NotBlank(message = ValidationConstants.INVALID_CUST_TYPE_EC) String customerType)
            throws RequestReasonsException {
        return new ResponseEntity<>(membershipService.fetchRequestReasons(agentId, customerType), HttpStatus.OK);
    }
}
