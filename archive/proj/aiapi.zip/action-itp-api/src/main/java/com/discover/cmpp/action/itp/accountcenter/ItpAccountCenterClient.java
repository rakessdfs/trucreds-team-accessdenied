package com.discover.cmpp.action.itp.accountcenter;

import com.discover.cmpp.action.itp.accountcenter.model.ApplicantLocationResponse;
import com.discover.cmpp.action.itp.accountcenter.model.UpdatePiiRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.Map;

import static com.discover.cmpp.action.itp.common.ActionItpConstants.PARTY_ID_HEADER;
import static com.discover.cmpp.action.itp.common.ActionItpConstants.X_DFSUSER_PEID;

@FeignClient(name = "itpAccountCenterApi", url = "${itpAccountCenterApi.service.baseUrl}")
public interface ItpAccountCenterClient {

    @PostMapping(value = "${itpAccountCenterApi.service.updateCustomerProfileInfo}")
    ResponseEntity<ApplicantLocationResponse> updateCustomerProfileInfo(@RequestHeader Map<String, String> headerMap,
                                                                        @RequestHeader(PARTY_ID_HEADER) String partyId,
                                                                        @RequestHeader(X_DFSUSER_PEID) String peId,
                                                                        UpdatePiiRequest request)
            throws ItpAccountCenterException;
}
