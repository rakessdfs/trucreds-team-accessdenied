package com.discover.cmpp.action.itp.membership;

public class RequestReasonsException extends Exception {

    private static final long serialVersionUID = -7137924831698067982L;

    public RequestReasonsException(String message) {
        super(message);
    }
}