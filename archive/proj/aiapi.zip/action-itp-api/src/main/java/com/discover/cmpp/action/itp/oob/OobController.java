package com.discover.cmpp.action.itp.oob;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.ErrorResponse;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.oob.model.GetStatusResponse;
import com.discover.cmpp.action.itp.oob.model.OobServiceAoResponse;
import com.discover.cmpp.action.itp.oob.model.SendCodeRequest;
import com.discover.cmpp.action.itp.oob.model.UnlockUserRequest;
import com.discover.cmpp.action.itp.oob.model.ValidateCodeRequest;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

@RequestMapping(value = "${api.context-path}")
@RestController
@Validated
public class OobController {

    @Autowired
    OobService oobService;

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = OobConstants.SEND_CODE_API,
            notes = OobConstants.SEND_CODE_API_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_OK, message = ActionItpConstants.API_OK),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, message = ActionItpConstants.API_BAD_REQUEST,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED,
                    message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN, required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN)})
    @PostMapping(value = OobConstants.SEND_CODE_URL)
    public ResponseEntity<OobServiceAoResponse> sendCode(
            @RequestHeader(ActionItpConstants.AGENT_ID) @NotBlank(
                    message = ValidationConstants.AGENT_ID_INVALID_EC) String agentId,
            @RequestBody @Valid SendCodeRequest request) throws OobSoapException {
        OobServiceAoResponse response = oobService.sendCode(request, agentId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = OobConstants.GET_STATUS_API, notes = OobConstants.GET_STATUS_API_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_OK, message = ActionItpConstants.API_OK),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, message = ActionItpConstants.API_BAD_REQUEST,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS),
            @ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = ActionItpConstants.API_NOT_FOUND,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_NO_CONTENT, message = ValidationConstants.PEID_NO_CONTENT_EM,
                    response = ErrorResponse.class)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN, required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN)})
    @GetMapping(value = OobConstants.GET_STATUS_URL)
    public ResponseEntity<GetStatusResponse> getUserStatus(
            @PathVariable(name = OobConstants.PRODUCT_ENROLLMENT_ID, required = true) @NotBlank(
                    message = ValidationConstants.PEID_INVALID_EC) String productEnrollmentId) throws OobSoapException {
        return new ResponseEntity<>(oobService.getStatus(productEnrollmentId), HttpStatus.OK);
    }

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = OobConstants.VALIDATE_CODE_API,
            notes = OobConstants.VALIDATE_CODE_API_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_OK, message = ActionItpConstants.API_OK),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, message = ActionItpConstants.API_BAD_REQUEST,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED,
                    message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN, required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN)})
    @PostMapping(value = OobConstants.VALIDATE_CODE_URL)
    public ResponseEntity<OobServiceAoResponse> validateCode(@RequestBody @Valid ValidateCodeRequest request)
            throws OobSoapException {
        return new ResponseEntity<>(oobService.validateOobCode(request), HttpStatus.OK);
    }

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = OobConstants.UNLOCK_USER_API,
            notes = OobConstants.SEND_CODE_API_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_OK, message = ActionItpConstants.API_OK),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, message = ActionItpConstants.API_BAD_REQUEST,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED,
                    message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN, required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN)})
    @PostMapping(value = OobConstants.UNLOCK_USER_URL)
    public ResponseEntity<OobServiceAoResponse> unlockUser(
            @RequestHeader(ActionItpConstants.AGENT_ID) @NotBlank(
                    message = ValidationConstants.AGENT_ID_INVALID_EC) String agentId,
            @RequestBody @Valid UnlockUserRequest request) throws OobSoapException {
        return new ResponseEntity<>(oobService.unlockUser(request, agentId), HttpStatus.OK);
    }
}
