package com.discover.cmpp.action.itp.cloak;

import com.discover.cmpp.action.itp.common.ActionItpException;
import org.springframework.validation.annotation.Validated;

import java.util.Map;

@Validated
public interface CloakService {

    /**
     * This service is used to generate token for the SSN Number of the
     * customer.
     *
     * @param headerMap header details
     * @param ssn       SSN
     * @return {@link String} token for the SSN
     * @throws CloakException     for cloak errors
     * @throws ActionItpException in case of exceptions
     */
    String tokenizeSsn(Map<String, String> headerMap, String ssn) throws ActionItpException, CloakException;

    /**
     * This service is used to generate token for the Date of Birth of the
     * customer.
     *
     * @param headerMap   header details
     * @param dateOfBirth date of birth
     * @return {@link String} tokenized DOB
     * @throws CloakException     cloak errors
     * @throws ActionItpException for all other exceptions
     */
    String tokenizeDob(Map<String, String> headerMap, String dateOfBirth)
            throws ActionItpException, CloakException;

    /**
     * This service is used to detokenize the SSN Number of the customer.
     *
     * @param headerMap    header details
     * @param tokenizedSsn tokenizedSSN
     * @return {@link String} SSN
     * @throws CloakException cloak errors
     */
    String detokenizeSsn(Map<String, String> headerMap, String tokenizedSsn)
            throws ActionItpException, CloakException;

    /**
     * This service is used to tokenize the Date of Birth of the customer.
     *
     * @param headerMap            header details
     * @param tokenizedDateOfBirth tokenized dob
     * @return {@link String} detokenized Dob
     * @throws CloakException     cloak errors
     * @throws ActionItpException for other errors
     */
    String detokenizeDob(Map<String, String> headerMap, String tokenizedDateOfBirth)
            throws ActionItpException, CloakException;
}
