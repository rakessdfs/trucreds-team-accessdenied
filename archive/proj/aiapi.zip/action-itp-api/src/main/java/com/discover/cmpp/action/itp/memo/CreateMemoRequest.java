package com.discover.cmpp.action.itp.memo;

import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateMemoRequest {

    @ApiModelProperty(value = "memo text for the new memo to be created", example = "Enrolled into ITP F&F",
            required = true)
    @NotBlank(message = ValidationConstants.MEMO_TEXT_INVALID_EC)
    private String memoText;
    @ApiModelProperty(value = "product enrollment id of the customer for whome memo is created", example = "457821487",
            required = true)
    @NotBlank(message = ValidationConstants.PEID_INVALID_EC)
    private String productEnrollmentId;
}
