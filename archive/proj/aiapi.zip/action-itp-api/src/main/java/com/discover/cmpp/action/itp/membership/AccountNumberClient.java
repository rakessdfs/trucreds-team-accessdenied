package com.discover.cmpp.action.itp.membership;

import com.discover.cmpp.action.itp.membership.model.billing.AccountKeySequenceNbrResponse;
import com.discover.cmpp.action.itp.membership.model.billing.AcctKeyTrnsfrSeqNmbrRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.Map;

@FeignClient(name = "accountNumberApi", url = "${accountNumberApi.service.baseUrl}")
public interface AccountNumberClient {

    @PostMapping(value = "${accountNumberApi.service.accountNumberQuery}")
    ResponseEntity<AccountKeySequenceNbrResponse> fetchAccountNumber(@RequestHeader Map<String,
            String> headerMap, AcctKeyTrnsfrSeqNmbrRequest acctKeyTrnsfrSeqNmbrRequest);
}
