package com.discover.cmpp.action.itp.oob;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.CloudPropertiesConfiguration;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.oob.model.GetStatusResponse;
import com.discover.cmpp.action.itp.oob.model.OobServiceAoResponse;
import com.discover.cmpp.action.itp.oob.model.ReturnStatus;
import com.discover.cmpp.action.itp.oob.model.SendCodeRequest;
import com.discover.cmpp.action.itp.oob.model.UnlockUserRequest;
import com.discover.cmpp.action.itp.oob.model.UserInfo;
import com.discover.cmpp.action.itp.oob.model.ValidateCodeRequest;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import com.discover.internet.service.oob.ao.OOBServiceAOBean;
import com.discover.internet.service.oob.vo.GetStatusInputVO;
import com.discover.internet.service.oob.vo.GetStatusOutputVO;
import com.discover.internet.service.oob.vo.ReturnStatusVO;
import com.discover.internet.service.oob.vo.SendCodeInputVO;
import com.discover.internet.service.oob.vo.SendCodeOutputVO;
import com.discover.internet.service.oob.vo.SupplementalField;
import com.discover.internet.service.oob.vo.UnlockUserInputVO;
import com.discover.internet.service.oob.vo.UnlockUserOutputVO;
import com.discover.internet.service.oob.vo.UserVO;
import com.discover.internet.service.oob.vo.ValidateCodeInputVO;
import com.discover.internet.service.oob.vo.ValidateCodeOutputVO;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.stereotype.Service;

import static com.discover.cmpp.action.itp.oob.OobConstants.OOB_SEND_CODE_REQUEST_FAILED;
import static com.discover.cmpp.action.itp.oob.OobConstants.OOB_UNLOCK_USER_REQUEST_FAILED;

@Service
public class OobServiceImpl implements OobService {

    private final OOBServiceAOBean oobServiceAoBean;
    private final CloudPropertiesConfiguration cloudPropertiesConfiguration;

    public OobServiceImpl(OOBServiceAOBean oobServiceAoBean,
                          CloudPropertiesConfiguration cloudPropertiesConfiguration) {
        this.oobServiceAoBean = oobServiceAoBean;
        this.cloudPropertiesConfiguration = cloudPropertiesConfiguration;
    }

    @LogAround
    @LogExecutionTime
    @Override
    /**
     * {@inheritDoc}
     *
     */
    public OobServiceAoResponse sendCode(SendCodeRequest alertPayload, String requestedBy) throws OobSoapException {
        SendCodeInputVO sendCodeInputVO = buildSendCodeInputVO(alertPayload, requestedBy);
        SendCodeOutputVO sendCodeOutputVO;
        int code;
        try {
            sendCodeOutputVO = oobServiceAoBean.sendCode(sendCodeInputVO);
            code = sendCodeOutputVO.getReturnStatus().getCode();
        } catch (Exception oobServiceException) {
            throw new OobSoapException(OOB_SEND_CODE_REQUEST_FAILED +
                    ExceptionUtils.getStackTrace(oobServiceException));
        }
        if (code < 0) {
            throw new OobSoapException(OOB_SEND_CODE_REQUEST_FAILED + code +
                    OobConstants.DESCRIPTION + sendCodeOutputVO.getReturnStatus().getDescription());
        }
        return getOobServiceAoResponse(sendCodeOutputVO.getReturnStatus(), sendCodeOutputVO.getUserInfo());
    }

    @Override
    public GetStatusResponse getStatus(String peid) throws OobSoapException {
        GetStatusInputVO getStatusInputVO = buildGetStatusInputVO(peid);
        GetStatusOutputVO getStatusOutputVO;
        int code;
        try {
            getStatusOutputVO = oobServiceAoBean.getStatus(getStatusInputVO);
            code = getStatusOutputVO.getReturnStatus().getCode();
        } catch (Exception exception) {
            throw new OobSoapException("OOB Get Status Request failed" + ExceptionUtils.getStackTrace(exception));
        }
        GetStatusResponse response = new GetStatusResponse();
        if (getStatusOutputVO.getReturnStatus().getCode() == OobConstants.SUCCESS) {
            UserVO userInfo = getStatusOutputVO.getUserInfo();
            response.setUserStatusCode(userInfo.getUserStatusCode());
            response.setUserStatusCodeDesc(userInfo.getUserStatusCodeDesc());
            response.setEmailChannelActive(getStatusOutputVO.isEmailChannelActive());
            response.setSmsChannelActive(getStatusOutputVO.isSmsChannelActive());
            response.setVoiceChannelActive(getStatusOutputVO.isVoiceChannelActive());
        } else if (code < 0) {
            throw new OobSoapException(OOB_SEND_CODE_REQUEST_FAILED + code +
                    OobConstants.DESCRIPTION + getStatusOutputVO.getReturnStatus().getDescription());
        } else {
            throw new OobSoapException(OOB_SEND_CODE_REQUEST_FAILED + OobConstants.NOT_ENROLLED +
                    OobConstants.DESCRIPTION + getStatusOutputVO.getReturnStatus().getDescription());
        }
        return response;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OobServiceAoResponse validateOobCode(ValidateCodeRequest request) throws OobSoapException {
        ValidateCodeOutputVO validateCodeOutputVO;
        int returnCode;
        try {
            validateCodeOutputVO = oobServiceAoBean.validateCode(buildValidateCodeInputVO(request));
            if (request.isLockCustomer()) {
                // validateCode has already been called once. Based on configured number to lock,
                // call validateCode that many more times
                for (int i = 1; i < cloudPropertiesConfiguration.getOobLockNumberOfCalls(); i++) {
                    validateCodeOutputVO = oobServiceAoBean.validateCode(buildValidateCodeInputVO(request));
                }
            }

            returnCode = validateCodeOutputVO.getReturnStatus().getCode();
        } catch (Exception exception) {
            throw new OobSoapException("OOB Validate Code Request failed" +
                    ExceptionUtils.getStackTrace(exception));
        }
        if (request.isLockCustomer()) {
            if (!validateCodeOutputVO.getUserInfo().getUserStatusCode()
                    .equalsIgnoreCase(OobConstants.LOCKED_USER_STATUS_CODE)) {
                throw new OobSoapException(ValidationConstants.ERROR_OOB_SERVICE_FAILED_TO_LOCK_EM + " Code:" +
                        returnCode + " Description: " + validateCodeOutputVO.getReturnStatus().getDescription() +
                        " User Status is: " + validateCodeOutputVO.getUserInfo().getUserStatusCodeDesc());
            }
        } else if (returnCode < 0) {
            throw new OobSoapException("OOB Validate Code Request failed" + " Code:" + returnCode + " Description: " +
                    validateCodeOutputVO.getReturnStatus().getDescription());
        } else {
            return getOobServiceAoResponse(validateCodeOutputVO.getReturnStatus(), validateCodeOutputVO.getUserInfo());
        }
        return getOobServiceAoResponse(validateCodeOutputVO.getReturnStatus(), validateCodeOutputVO.getUserInfo());
    }

    @LogAround
    @LogExecutionTime
    @Override
    /**
     * {@inheritDoc}
     *
     */
    public OobServiceAoResponse unlockUser(UnlockUserRequest unlockUserRequest,
                                           String requestedBy) throws OobSoapException {
        UnlockUserInputVO unlockUserInputVO = buildUnlockUserInputVO(unlockUserRequest, requestedBy);
        UnlockUserOutputVO unlockUserOutputVO;

        try {
            unlockUserOutputVO = oobServiceAoBean.unlockUser(unlockUserInputVO);
        } catch (Exception oobServiceException) {
            throw new OobSoapException(OOB_UNLOCK_USER_REQUEST_FAILED +
                    ExceptionUtils.getStackTrace(oobServiceException));
        }
        if (unlockUserOutputVO.getReturnStatus().getCode() < 0) {
            throw new OobSoapException(OOB_UNLOCK_USER_REQUEST_FAILED + " - " +
                    unlockUserOutputVO.getReturnStatus().getDescription());
        }
        return getOobServiceAoResponse(unlockUserOutputVO.getReturnStatus(), unlockUserOutputVO.getUserInfo());
    }

    /**
     * This method is to build the input request for unlocking customer account.
     */
    private UnlockUserInputVO buildUnlockUserInputVO(UnlockUserRequest unlockUserRequest, String requestedBy) {
        UnlockUserInputVO unlockUserInputVO = new UnlockUserInputVO();
        unlockUserInputVO.setCustUserKey(unlockUserRequest.getCustUserKey());
        unlockUserInputVO.setCustUserGroupCode((OobConstants.CUST_USER_GROUP_CODE));
        unlockUserInputVO.setRequestedBy(requestedBy);
        return unlockUserInputVO;
    }

    private OobServiceAoResponse getOobServiceAoResponse(ReturnStatusVO returnStatus, UserVO userInfo) {
        OobServiceAoResponse response = new OobServiceAoResponse();
        response.setReturnStatus(populateReturnStatus(returnStatus));
        response.setUserInfo(populateUserInfo(null == userInfo ?
                new UserVO() : userInfo));
        return response;
    }

    private SendCodeInputVO buildSendCodeInputVO(SendCodeRequest alertPayload, String requestedBy) {
        SendCodeInputVO sendCodeInputVO = new SendCodeInputVO();
        sendCodeInputVO.setChannelCode(alertPayload.getChannelCode());
        sendCodeInputVO.setChannelValue(alertPayload.getChannelValue());
        sendCodeInputVO.setRequestedBy(requestedBy);
        sendCodeInputVO.setCustUserGroupCode(OobConstants.CUST_USER_GROUP_CODE);
        sendCodeInputVO.setCustUserKey(alertPayload.getCustUserKey());
        setTemplateFieldsList(alertPayload, sendCodeInputVO);
        return sendCodeInputVO;
    }

    private ValidateCodeInputVO buildValidateCodeInputVO(ValidateCodeRequest request) {
        ValidateCodeInputVO inputVO = new ValidateCodeInputVO();
        inputVO.setCode(request.getInputCode());
        inputVO.setCustUserGroupCode(OobConstants.CUST_USER_GROUP_CODE);
        inputVO.setCustUserKey(request.getCustUserKey());
        inputVO.setForceFailure(request.isLockCustomer());
        return inputVO;
    }

    private void setTemplateFieldsList(SendCodeRequest alertPayload, SendCodeInputVO sendCodeInputVO) {
        sendCodeInputVO.getSupplementalFields().add(createSupplementalField(OobConstants.TEMPLATE_FIELD_ACCOUNT_NUMBER,
                OobConstants.ACCOUNT_NUMBER_VALUE));
        sendCodeInputVO.getSupplementalFields().add(createSupplementalField(
                OobConstants.TEMPLATE_FIELD_FINANCIAL_AGREEMENT_NUMBER, OobConstants.FINANCIAL_AGREEMENT_NUMBER_VALUE));
        String nameOnCard = alertPayload.getCustomerFirstName() + ActionItpConstants.BLANK_STRING +
                alertPayload.getCustomerLastName();
        sendCodeInputVO.getSupplementalFields()
                .add(createSupplementalField(OobConstants.TEMPLATE_FIELD_NAME_ON_CARD, nameOnCard));
    }

    private SupplementalField createSupplementalField(String key, String value) {
        SupplementalField supplementalField = new SupplementalField();
        supplementalField.setName(key);
        supplementalField.setValue(value);
        return supplementalField;
    }

    private GetStatusInputVO buildGetStatusInputVO(String peid) {
        GetStatusInputVO getStatusInputVO = new GetStatusInputVO();

        getStatusInputVO.setCustUserKey(peid);
        getStatusInputVO.setCustUserGroupCode(OobConstants.CUST_USER_GROUP_CODE);
        getStatusInputVO.setCheckAbandon(false);
        return getStatusInputVO;
    }

    private ReturnStatus populateReturnStatus(ReturnStatusVO returnStatusVO) {
        ReturnStatus returnStatus = new ReturnStatus();
        returnStatus.setCode(returnStatusVO.getCode());
        returnStatus.setDescription(returnStatusVO.getDescription());
        return returnStatus;
    }

    private UserInfo populateUserInfo(UserVO userVO) {
        UserInfo userInfo = new UserInfo();
        userInfo.setFailedSubmissionCount(userVO.getFailedSubmissionCount());
        userInfo.setGenerationCount(userVO.getGenerationCount());
        userInfo.setUserStatusCode(userVO.getUserStatusCode());
        userInfo.setUserStatusCodeDesc(userVO.getUserStatusCodeDesc());
        userInfo.setRemainingSubmissionCount(userVO.getRemainingSubmissionCount());
        userInfo.setRemainingGenerationCount(userVO.getRemainingGenerationCount());
        return userInfo;
    }
}
