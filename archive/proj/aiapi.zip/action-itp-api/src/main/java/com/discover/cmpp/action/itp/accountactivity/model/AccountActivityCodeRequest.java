package com.discover.cmpp.action.itp.accountactivity.model;

import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
public class AccountActivityCodeRequest {

    @ApiModelProperty(value = "activity code", example = "", required = true)
    @NotBlank(message = ValidationConstants.INVALID_ACTIVITY_CODE_EC)
    @Size(min = 1, max = 20, message = ValidationConstants.INVALID_ACTIVITY_CODE_EC)
    private String activityCode;

    @ApiModelProperty(value = "activity code description", example = "", required = true)
    @NotBlank(message = ValidationConstants.INVALID_ACTIVITY_DESC_EC)
    @Size(min = 0, max = 500, message = ValidationConstants.INVALID_ACTIVITY_DESC_EC)
    private String activityDesc;

    @ApiModelProperty(value = "category", example = "", required = true)
    @NotBlank(message = ValidationConstants.INVALID_CATEGORY_EC)
    @Size(min = 0, max = 100, message = ValidationConstants.INVALID_CATEGORY_EC)
    private String category;
}
