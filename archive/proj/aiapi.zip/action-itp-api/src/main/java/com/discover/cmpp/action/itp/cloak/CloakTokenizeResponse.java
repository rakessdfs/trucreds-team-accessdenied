package com.discover.cmpp.action.itp.cloak;

import lombok.Data;

@Data
public class CloakTokenizeResponse {

    private String token;
    private CloakErrorVO errrorVO;
}
