package com.discover.cmpp.action.itp.membership;

import com.discover.cmpp.action.itp.membership.model.CsidApiResponse;
import org.springframework.http.ResponseEntity;

import java.util.Map;

public interface CsidSubscriberService {

    /**
     * To get next billing data based on the subscriber number provided.
     *
     * @param headerMap        - Request Header map
     * @param subscriberNumber - subscriber number
     * @return - next billing date
     */

    ResponseEntity<CsidApiResponse> getBillingStatus(Map<String, String> headerMap, String subscriberNumber)
            throws MembershipException;
}
