package com.discover.cmpp.action.itp.common;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Configuration
@ConfigurationProperties(prefix = "app")
public class CloudPropertiesConfiguration {

    private boolean publishMemoToAnalytics;
    private boolean newCancelApiEnabled;
    private int oobLockNumberOfCalls;
    private boolean configServerHealthCheckEnabled;
}