package com.discover.cmpp.action.itp.accountactivity;

import com.discover.cmpp.action.itp.accountactivity.model.AccountActivityResponse;
import com.discover.cmpp.action.itp.accountactivity.model.ActivityToAnalyticsRequest;
import com.discover.cmpp.action.itp.accountactivity.model.ActivityToAnalyticsResponse;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.accountactivity.model.AccountActivityCodeRequest;
import com.discover.cmpp.action.itp.flux.schema.AccountActivityPayload;

import java.util.List;

public interface AccountActivityService {

    /**
     * This method is used to create activity based on the input request and stores in DB.
     *
     * @param accountActivityPayload input request with details
     * @throws AccountActivityException when exception occurred while saving activity in DB
     */
    void createActivity(AccountActivityPayload accountActivityPayload) throws AccountActivityException;

    /**
     * This method is used to create account activity code based on the input request and stores in DB.
     *
     * @param accountActivityCodeRequest input request with details
     * @throws AccountActivityException when exception occurred while saving activity in DB
     */
    void createAccountActivityCode(AccountActivityCodeRequest accountActivityCodeRequest)
            throws AccountActivityException;

    /**
     * This method is used to fetch the account activity for a given Product Enrollment ID.
     *
     * @param productEnrollmentId product enrollment id
     * @return AccountActivityResponse list of account activities
     * @throws AccountActivityException when exception occurred while fetching account activity from DB
     */
    AccountActivityResponse fetchAccountActivityByPeid(String productEnrollmentId)
            throws AccountActivityException;

    /**
     * This method is used to fetch the account activity constants from the cache/db.
     * If an activity code is provided, it just returns the info for that code.
     * If a category is provided, it provides info for all the rows with that category.
     * If neither is provided, then all account activity constant info is returned.
     *
     * @param activityCode account activity code
     * @param category account activity category
     * @return List of AccountActivityCodeEntity list of code entities from the account activity cache/db
     * @throws AccountActivityException when exception occurred while fetching from cache/db
     */
    List<AccountActivityCodeEntity> fetchAccountActivityCodes(String activityCode, String category)
            throws AccountActivityException;

    /**
     * This method is used to fetch account activities for the specified code(s).
     * and send them to analytics for the given date range (or for all activity before
     * this method is called if no range is provided).
     *
     * @param request input request with details
     * @return ActivityToAnalyticsResponse with count of database activities, and published activites
     * @throws AccountActivityException when exception occurred fetching from db or sending to flux
     */
    ActivityToAnalyticsResponse publishActivitiesToAnalytics(ActivityToAnalyticsRequest request)
            throws AccountActivityException, ActionItpException;
}
