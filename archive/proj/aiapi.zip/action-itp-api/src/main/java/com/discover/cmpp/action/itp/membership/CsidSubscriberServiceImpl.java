package com.discover.cmpp.action.itp.membership;

import com.discover.cmpp.action.itp.membership.model.CsidApiResponse;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class CsidSubscriberServiceImpl implements CsidSubscriberService {

    private CsidSubscriberClient csidSubscriberClient;

    public CsidSubscriberServiceImpl(CsidSubscriberClient csidSubscriberClient) {
        this.csidSubscriberClient = csidSubscriberClient;
    }

    @LogAround
    @LogExecutionTime
    @Override
    /**
     * {@inheritDoc}
     *
     */
    public ResponseEntity<CsidApiResponse> getBillingStatus(Map<String, String> headerMap, String subscriberNumber) {
        return csidSubscriberClient.getBillingStatus(headerMap, subscriberNumber);
    }
}
