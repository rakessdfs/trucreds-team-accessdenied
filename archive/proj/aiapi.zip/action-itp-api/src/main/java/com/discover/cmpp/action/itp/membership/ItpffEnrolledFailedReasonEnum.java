package com.discover.cmpp.action.itp.membership;

public enum ItpffEnrolledFailedReasonEnum {

    DSC("Disclosure Failure"),
    ECR("ECS Credit Report Failure"),
    EQF("Equifax"),
    PII("Invalid DFS PII"),
    TRU("TransUnion"),
    VTO("Vendor Time-out"),
    E60("Enrolled But Not Registered/No Credentials");

    private final String itpffEnrolledFailedReason;

    ItpffEnrolledFailedReasonEnum(String itpffEnrolledFailedReason) {
        this.itpffEnrolledFailedReason = itpffEnrolledFailedReason;
    }

    String getItpffEnrolledFailedReason() {
        return itpffEnrolledFailedReason;
    }
}
