package com.discover.cmpp.action.itp.membership;

import com.discover.cmpp.action.itp.membership.model.EnrollmentLookupResponse;
import com.discover.cmpp.action.itp.membership.model.MembershipInfo;
import com.discover.cmpp.action.itp.membership.model.MembershipListRequest;
import com.discover.cmpp.action.itp.membership.model.MembershipListResponse;
import com.discover.cmpp.action.itp.membership.model.ProcessRequestResponse;
import com.discover.cmpp.action.itp.membership.model.ProcessRequestSearchCriteria;
import com.discover.cmpp.action.itp.membership.model.RequestReasonResponseEntity;
import com.discover.cmpp.action.itp.membership.model.RequestReasonSearchCriteria;
import com.discover.cmpp.action.itp.membership.model.billing.ReferralEntity;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

public interface ProductService {

    /**
     * To get Referral Details of customer.
     *
     * @param headerMap - Request Header map
     * @param peId      - Customer's productEnrollmentId
     * @return - Referral details
     */
    ResponseEntity<ReferralEntity> getReferrals(Map<String, String> headerMap, String peId);

    /**
     * To get Enrollment info of customer.
     *
     * @param headerMap - Request Header map
     * @param peId      - Customer's productEnrollmentId
     * @return - Enrollment info
     */
    ResponseEntity<EnrollmentLookupResponse> getEnrollmentInfo(Map<String, String> headerMap, String peId);

    /**
     * To get the Required Process Request.
     *
     * @param headerMap             - Request Header map
     * @param requestSearchCriteria - Process request search criteria
     * @return - List of Process request match
     */
    ResponseEntity<List<ProcessRequestResponse>> fetchProcessRequests(Map<String, String> headerMap,
                                                                      ProcessRequestSearchCriteria
                                                                              requestSearchCriteria);

    /**
     * To get Membership info of customer.
     *
     * @param headerMap   - Request Header map
     * @param partyId     - partId of customer
     * @param productCode - product code
     * @return - Membership info
     */
    ResponseEntity<MembershipInfo> getMembershipByPartyId(Map<String, String> headerMap, String partyId,
                                                          String productCode);

    /**
     * To fetch list of memberships of customer.
     *
     * @param headerMap             - request header map
     * @param membershipListRequest - {@link MembershipListRequest} object
     * @return MembershipListResponse
     */

    ResponseEntity<List<MembershipListResponse>> fetchMemberships(Map<String, String> headerMap,
                                                                  MembershipListRequest membershipListRequest);

    /**
     * To search for Peid using subscriber number.
     *
     * @param headerMap        - Request Header map
     * @param subscriberNumber subscriber number
     * @return - EnrollmentLookupResponse
     */
    ResponseEntity<EnrollmentLookupResponse> getPeid(Map<String,
            String> headerMap, String subscriberNumber);

    /**
     * Method to fetch list of request reasons based on level number and source code.
     *
     * @param requestReasonSearchCriteria a @{@link RequestReasonSearchCriteria} object
     * @return a list of @{@link RequestReasonResponseEntity} objects
     */
    ResponseEntity<List<RequestReasonResponseEntity>> getRequestReasonCodes(Map<String, String> headerMap,
                                                                            RequestReasonSearchCriteria
                                                                                    requestReasonSearchCriteria);
}
