package com.discover.cmpp.action.itp.custlookup;

import com.discover.cmpp.action.itp.cloak.CloakException;
import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ErrorResponse;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.custlookup.model.CustomerInfoResponse;
import com.discover.cmpp.action.itp.custlookup.model.CustomerSearchRequest;
import com.discover.cmpp.action.itp.custlookup.model.CustomerSearchResponse;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

@RequestMapping(value = "${api.context-path}")
@RestController
public class CustLookUpController {

    @Autowired
    CustLookUpService acctLookUpService;

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = CustLookUpConstants.CUST_PII_INFO_API, notes = CustLookUpConstants.CUST_PII_INFO_API_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_OK, message = ActionItpConstants.API_OK,
                    response = CustomerInfoResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_NO_CONTENT,
                    message = CustLookUpConstants.API_CUST_NOT_FOUND_ERROR, response = void.class),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, message = ActionItpConstants.API_BAD_REQUEST,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS),
            @ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = ActionItpConstants.API_NOT_FOUND)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN,
            required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN),
            @ApiImplicitParam(name = ActionItpConstants.AGENT_ID, required = true,
                    dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
                    value = ActionItpConstants.AGENT_ID_VALUE)})
    @GetMapping(value = CustLookUpConstants.CUST_PII_INFO_URL)
    public ResponseEntity<Object> customerInfo(
            @RequestHeader(ActionItpConstants.AGENT_ID)
            @NotBlank(message = ValidationConstants.AGENT_ID_INVALID_EC) String agentId,
            @RequestParam(value = CustLookUpConstants.PII_INFO_PARTY_ID, required = true)
            @NotBlank(message = ValidationConstants.PARTYID_INVALID_EC) String partyId)
            throws CloakException, ActionItpException, CustLookUpException {
        return new ResponseEntity<>(acctLookUpService.customerInfo(agentId, partyId), HttpStatus.OK);
    }

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = CustLookUpConstants.CUST_PII_LOOK_UP_API, notes =
            CustLookUpConstants.CUST_PII_LOOK_UP_API_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_OK, message = ActionItpConstants.API_OK,
                    response = CustomerSearchResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, message = ActionItpConstants.API_BAD_REQUEST,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS),
            @ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = ActionItpConstants.API_NOT_FOUND)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN,
            required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN),
            @ApiImplicitParam(name = ActionItpConstants.AGENT_ID, required = true,
                    dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
                    value = ActionItpConstants.AGENT_ID_VALUE)})
    @PostMapping(value = CustLookUpConstants.CUST_PII_LOOK_UP_URL)
    public ResponseEntity<Object> customerSearch(
            @RequestHeader(ActionItpConstants.AGENT_ID) @NotBlank(
                    message = ValidationConstants.AGENT_ID_INVALID_EC) String agentId,
            @RequestBody @Valid CustomerSearchRequest request)
            throws CloakException, ActionItpException, CustLookUpException {
        return new ResponseEntity<>(acctLookUpService.customerSearch(agentId, request), HttpStatus.OK);
    }
}
