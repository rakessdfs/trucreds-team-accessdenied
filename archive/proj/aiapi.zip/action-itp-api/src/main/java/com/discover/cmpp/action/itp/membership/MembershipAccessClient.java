package com.discover.cmpp.action.itp.membership;

import com.discover.cmpp.action.itp.cancel.CancelException;
import com.discover.cmpp.action.itp.cancel.model.CancelRequest;
import com.discover.cmpp.action.itp.membership.model.MembershipInfo;
import com.discover.cmpp.action.itp.membership.model.MembershipListRequest;
import com.discover.cmpp.action.itp.membership.model.MembershipListResponse;
import com.discover.cmpp.action.itp.membership.model.ProcessRequestResponse;
import com.discover.cmpp.action.itp.membership.model.ProcessRequestSearchCriteria;
import com.discover.cmpp.action.itp.membership.model.RequestReasonResponseEntity;
import com.discover.cmpp.action.itp.membership.model.RequestReasonSearchCriteria;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.List;
import java.util.Map;

@FeignClient(name = "productsApi", url = "${productsApi.service.baseUrl}")
public interface MembershipAccessClient {

    @PostMapping(value = "${productsApi.service.processDetailsLookup}")
    ResponseEntity<List<ProcessRequestResponse>> fetchProcessRequests(@RequestHeader Map<String,
            String> headerMap, ProcessRequestSearchCriteria requestSearchCriteria);

    @GetMapping(value = "${productsApi.service.membershipByPartyId}")
    ResponseEntity<MembershipInfo> getMembershipByPartyId(@RequestHeader Map<String, String> headerMap,
                                                          @PathVariable("partyId") String partyId,
                                                          @PathVariable("productCode") String productCode);

    @PostMapping(value = "${productsApi.service.membershipsByPartyId}")
    ResponseEntity<List<MembershipListResponse>> fetchMemberships(@RequestHeader Map<String, String> headerMap,
                                                                  MembershipListRequest membershipListRequest);

    @PostMapping(value = "${productsApi.service.requestReasonsQuery}")
    ResponseEntity<List<RequestReasonResponseEntity>> fetchRequestReasonCodes(@RequestHeader Map<String,
            String> headerMap, RequestReasonSearchCriteria requestReasonSearchCriteria);

    @PutMapping(value = "${productsApi.service.cancelRequest}")
    ResponseEntity<Void> cancelMembership(@RequestHeader Map<String, String> headerMap, @PathVariable("membershipId")
            Long membershipId, CancelRequest request) throws CancelException;
}
