package com.discover.cmpp.action.itp.membership;

import com.discover.cmpp.action.itp.cancel.CancelClient;
import com.discover.cmpp.action.itp.cancel.CancelException;
import com.discover.cmpp.action.itp.cancel.model.CancelRequest;
import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ActionItpUtil;
import com.discover.cmpp.action.itp.common.CloudPropertiesConfiguration;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.custlookup.CdsService;
import com.discover.cmpp.action.itp.custlookup.CustLookUpConstants;
import com.discover.cmpp.action.itp.custlookup.model.cdspersonal.CdsPersonalInfoRequest;
import com.discover.cmpp.action.itp.custlookup.model.cdspersonal.CdsPersonalInfoResponse;
import com.discover.cmpp.action.itp.membership.model.CsidApiResponse;
import com.discover.cmpp.action.itp.membership.model.EnrollmentLookupResponse;
import com.discover.cmpp.action.itp.membership.model.MembershipInfo;
import com.discover.cmpp.action.itp.membership.model.MembershipListRequest;
import com.discover.cmpp.action.itp.membership.model.MembershipListResponse;
import com.discover.cmpp.action.itp.membership.model.MembershipResponse;
import com.discover.cmpp.action.itp.membership.model.ProcessRequestResponse;
import com.discover.cmpp.action.itp.membership.model.ProcessRequestSearchCriteria;
import com.discover.cmpp.action.itp.membership.model.RequestReason;
import com.discover.cmpp.action.itp.membership.model.RequestReasonResponse;
import com.discover.cmpp.action.itp.membership.model.RequestReasonResponseEntity;
import com.discover.cmpp.action.itp.membership.model.RequestReasonSearchCriteria;
import com.discover.cmpp.action.itp.membership.model.billing.AccountKeySequenceNbrResponse;
import com.discover.cmpp.action.itp.membership.model.billing.AcctKeyTrnsfrSeqNmbrRequest;
import com.discover.cmpp.action.itp.membership.model.billing.BillingResponse;
import com.discover.cmpp.action.itp.membership.model.billing.CardCustomerDataRequest;
import com.discover.cmpp.action.itp.membership.model.billing.CardCustomerDataResponse;
import com.discover.cmpp.action.itp.membership.model.billing.ReferralEntity;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.utils.CommonConstants;
import feign.FeignException;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.discover.cmpp.action.itp.common.ActionItpConstants.CUSTOMER_ROLE_CODE;
import static com.discover.cmpp.action.itp.common.ActionItpConstants.INDEX_ZERO;
import static com.discover.cmpp.action.itp.common.validation.ValidationConstants.TOKENIZED_DOB_PATTERN;

@Service
public class MembershipServiceImpl implements MembershipService {

    private static final Logger LOGGER = LoggerFactory.getLogger(MembershipServiceImpl.class);
    private ActionItpUtil itpUtil;
    private CardCustomerService cardCustomerService;
    private AccountNumberService accountNumberService;
    private CsidSubscriberService csidSubscriberService;
    private ProductService productService;
    private CdsService cdsService;
    private CancelClient cancelClient;
    private CloudPropertiesConfiguration cloudPropertiesConfiguration;
    private MembershipAccessClient membershipAccessClient;

    // Sonar disabled for constructor since 9 params is more than 7 allowed in a method,
    // but can't get around it since this is a constructor and not normal method
    public MembershipServiceImpl(ActionItpUtil itpUtil, CardCustomerService cardCustomerService, //NOSONAR
                                 AccountNumberService accountNumberService, CsidSubscriberService csidSubscriberService,
                                 ProductService productService, CdsService cdsService,
                                 CancelClient cancelClient, CloudPropertiesConfiguration cloudPropertiesConfiguration,
                                 MembershipAccessClient membershipAccessClient) {
        this.itpUtil = itpUtil;
        this.cardCustomerService = cardCustomerService;
        this.accountNumberService = accountNumberService;
        this.csidSubscriberService = csidSubscriberService;
        this.productService = productService;
        this.cdsService = cdsService;
        this.cancelClient = cancelClient;
        this.cloudPropertiesConfiguration = cloudPropertiesConfiguration;
        this.membershipAccessClient = membershipAccessClient;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @LogAround
    public MembershipResponse fetchItpMembershipInformation(String agentId, String partyId) throws ActionItpException {
        ProcessRequestResponse processRequestResponse = null;
        try {
            String peId = getProductEnrollmentId(agentId, partyId);

            String subscriberNumber = getSubscriberNumber(peId);

            List<MembershipListResponse> memberships = fetchMemberships(partyId);

            if (null != memberships) {
                MembershipListResponse membership = determineMembershipFromList(memberships);
                if (itpUtil.isMemberCancelled(membership)) {
                    processRequestResponse = fetchProcessRequests(itpUtil.restClientHeader(), membership);
                }
                return formulateResponse(membership, subscriberNumber, processRequestResponse, peId, partyId);
            } else {
                throw new MembershipException(MembershipConstants.MEMBERSHIP_NOT_FOUND);
            }
        } catch (Exception e) {
            throw new ActionItpException(MembershipConstants.MEMBERSHIP_ERROR + ExceptionUtils.getStackTrace(e));
        }
    }

    /**
     * {@inheritDoc}
     */
    public String getProductEnrollmentId(String agentId, String partyId)
            throws MembershipException, ActionItpException {
        return Optional.ofNullable(cdsService.getCustomerPersonalInfo(itpUtil.restClientCdsHeader(agentId),
                CdsPersonalInfoRequest.builder()
                        .identifierType(CustLookUpConstants.PARTY_ID).identifier(partyId).build()).getBody())
                .map(this::getProductEnrollmentIdentifier)
                .orElseThrow(() -> new MembershipException(MembershipConstants.SUBSCRIBER_NUMBER_NOT_FOUND));
    }

    private String getProductEnrollmentIdentifier(CdsPersonalInfoResponse cdsPersonalInfoResponse) {
        String peId = null;
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] partyToSourceIdAssociations
                = cdsPersonalInfoResponse.getPersonalInfo().get(0).getPartyToSourceIdAssociation();
        Optional<CdsPersonalInfoResponse.PartyToSourceIdAssociation> association
                = Arrays.stream(partyToSourceIdAssociations)
                .filter(x -> (
                        x.getExpiryTimestamp() == null ||
                                x.getExpiryTimestamp().compareTo(Instant.now()) >= 0) &&
                        x.getRequestSourceCode().equalsIgnoreCase(MembershipConstants.REQ_SRC_CODE_PD))
                .findAny();

        if (association.isPresent()) {
            peId = association.get().getAlternatePartyId();
        }
        return peId;
    }

    /**
     * Get subscriber number from Product Enrollment API.
     *
     * @param peId product enrollment Id
     * @return subscriber number
     */
    private String getSubscriberNumber(String peId) throws ActionItpException, MembershipException {
        ResponseEntity<EnrollmentLookupResponse> enrollmentInfo = productService
                .getEnrollmentInfo(itpUtil.restClientHeader(), peId);
        return Optional.ofNullable(Objects.requireNonNull(enrollmentInfo.getBody()).getSubscriberId())
                .orElseThrow(() -> new MembershipException(MembershipConstants.SUBSCRIBER_NUMBER_NOT_FOUND));
    }

    /**
     * Fetch the Required Process Request.
     *
     * @param headerMap  header map
     * @param membership membership
     * @return ProcessRequestResponse
     * @throws MembershipException when an exception occurs or no records found for PCN and CAN standing code
     */
    private ProcessRequestResponse fetchProcessRequests(Map<String, String> headerMap,
                                                        MembershipListResponse membership) throws MembershipException {
        ProcessRequestResponse processRequestResponse = null;
        ResponseEntity<List<ProcessRequestResponse>> processResponseList =
                productService
                        .fetchProcessRequests(headerMap, createProcessRequestCriteria(membership));
        if (processResponseList.getStatusCode().is2xxSuccessful()) {
            List<ProcessRequestResponse> processList = Objects.requireNonNull(processResponseList.getBody()).stream()
                    .sorted(Comparator
                            .comparing(ProcessRequestResponse::getProcessRequestDate).reversed())
                    .collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(processList)) {
                processRequestResponse = processList.get(INDEX_ZERO);
            }
        } else {
            throw new MembershipException(MembershipConstants.MEMBERSHIP_PROCESS_REQUEST_NOT_FOUND);
        }
        return processRequestResponse;
    }


    /**
     * Formulate the process request api input.
     *
     * @param membershipResponse membership information
     * @return request criteria
     */
    private ProcessRequestSearchCriteria createProcessRequestCriteria(MembershipListResponse membershipResponse) {
        ProcessRequestSearchCriteria searchCriteria = new ProcessRequestSearchCriteria();
        searchCriteria.setProductTypeCode(membershipResponse.getProductTypeCode());
        searchCriteria.setMembershipId(
                String.valueOf(membershipResponse.getMembershipId()));
        searchCriteria.setProcessRequestCode(ActionItpConstants.CAN_PROCESS_REQ_CODE);
        List<String> processStatusCodeList = new ArrayList<>();
        processStatusCodeList.add(ActionItpConstants.INP_PROCESS_STATUS_CODE);
        processStatusCodeList.add(ActionItpConstants.CMP_PROCESS_STATUS_CODE);
        processStatusCodeList.add(ActionItpConstants.PEN_PROCESS_STATUS_CODE);
        processStatusCodeList.add(ActionItpConstants.CAN_PROCESS_STATUS_CODE);
        searchCriteria.setProcessStatusCodes(processStatusCodeList);
        searchCriteria.setDate(null);
        return searchCriteria;
    }

    /**
     * Formulate the Membership Response.
     *
     * @param membershipDetails      membership response
     * @param processRequestResponse process Response
     * @return MembershipResponse response
     */
    @LogAround
    private MembershipResponse formulateResponse(MembershipListResponse membershipDetails, String subscriberNumber,
                                                 ProcessRequestResponse processRequestResponse,
                                                 String peid, String partyId) {
        MembershipResponse membershipResponse = new MembershipResponse();
        membershipResponse.setPartyId(partyId);
        membershipResponse.setEnrollmentDate(membershipDetails.getMembershipRequestDate());
        membershipResponse.setEnrollmentStatus(
                StandingCodeEnum.valueOf(membershipDetails.getStandingCode()).getStandingName());
        membershipResponse.setProductEnrollmentId(peid);
        membershipResponse.setCancellationDate(membershipDetails.getCancelCompletionDate());
        membershipResponse.setCancellationRequestDate(membershipDetails.getCancelRequestDate());
        // Fetch product enrollment ID
        membershipResponse.setSubscriberNumber(subscriberNumber);
        membershipResponse.setCancellationCode(ActionItpConstants.BLANK_STRING);
        if (membershipDetails.getStandingCode()
                .equalsIgnoreCase(MembershipConstants.StandingCode.PCN.name()) ||
                membershipDetails.getStandingCode()
                        .equalsIgnoreCase(MembershipConstants.StandingCode.CAN.name())) {
            String reasonDesc = reasonDescriptionEnum(processRequestResponse,
                    membershipDetails.getLevelNumber());
            if (membershipDetails.getLevelNumber().equals(CommonConstants.LEVEL_6)) {
                membershipResponse.setEnrollmentFailedReason(reasonDesc);
            } else {
                membershipResponse.setCancellationCode(
                        processRequestResponse.getProcessRequestReasonCode());
                if (BmCancellationReasonList.Bm_Enrol_fail_Rsn_list.contains(
                        processRequestResponse.getProcessRequestReasonCode())) {
                    membershipResponse.setEnrollmentFailedReason(reasonDesc);
                } else {
                    membershipResponse.setCancellationReason(reasonDesc);
                }
            }
        }
        membershipResponse.setStandingCode(membershipDetails.getStandingCode());
        membershipResponse.setCustomerType(CommonConstants
                .CUSTOMERTYPE_TO_LEVEL_MAP.get(membershipDetails.getLevelNumber()));

        return membershipResponse;
    }

    /**
     * Find the processRequestCode is present in the Enum or not.
     *
     * @param processRequestResponse reason code
     * @return Boolean
     */
    @LogAround
    private String reasonDescriptionEnum(
            ProcessRequestResponse processRequestResponse, Integer levelNumber) {
        String reasonDesc = ActionItpConstants.BLANK_STRING;

        if (processRequestResponse != null &&
                processRequestResponse.getProcessRequestReasonCode() != null) {
            if (levelNumber.equals(CommonConstants.LEVEL_6)) {
                try {
                    reasonDesc = ItpffEnrolledFailedReasonEnum.valueOf(
                            processRequestResponse.getProcessRequestReasonCode())
                            .getItpffEnrolledFailedReason();
                } catch (Exception e) {
                    reasonDesc = ActionItpConstants.BLANK_STRING;
                }
            }
            if (levelNumber.equals(CommonConstants.LEVEL_8) || levelNumber.equals(CommonConstants.LEVEL_9)) {
                reasonDesc = BmCancellationReasonList.Bm_Cancel_Rsn_map.get(
                        processRequestResponse.getProcessRequestReasonCode());
                if (null == reasonDesc) {
                    reasonDesc = processRequestResponse.getProcessRequestReasonCode();
                }
            }
        }

        return reasonDesc;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BillingResponse fetchItpBillingInformation(String customerType, String partyId, BigDecimal peid,
                                                      String subscriberId) throws ActionItpException,
            MembershipException {
        BillingResponse billingResponse = new BillingResponse();
        Map<String, String> headerMap = itpUtil.restClientHeader();
        if (CommonConstants.ITP_FF.equalsIgnoreCase(customerType)) {
            int accountKey = getAccountKey(headerMap, peid);
            CardCustomerDataResponse cardCustomerDataResponse = getCardCustomerDataResponse(headerMap, accountKey);
            AccountKeySequenceNbrResponse accountKeySequenceNbrResponse = getAccountKeySequenceNbrResponse(headerMap,
                    accountKey);
            return formulateBillingResponse(billingResponse, Objects.requireNonNull(cardCustomerDataResponse),
                    Objects.requireNonNull(accountKeySequenceNbrResponse));
        } else if (CommonConstants.ITP_BM.equalsIgnoreCase(customerType)) {
            MembershipInfo membership = fetchMembershipInfo(partyId, ActionItpConstants.ITB_PRODUCT_TYPE_CODE);
            if (null != membership && !(membership.getMembershipEntity().getStandingCode().equalsIgnoreCase(
                    MembershipConstants.StandingCode.PCN.name()) ||
                    membership.getMembershipEntity().getStandingCode()
                            .equalsIgnoreCase(MembershipConstants.StandingCode.CAN.name()))) {
                return formulateBillingDateResponse(billingResponse, getCsiApiDataResponse(headerMap, subscriberId));
            }
        } else {
            LOGGER.warn("No billing information available for customer type {}", customerType);
        }
        return billingResponse;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RequestReasonResponse fetchRequestReasons(String agentId, String customerType)
            throws RequestReasonsException {
        try {
            Map<String, String> headerMap = itpUtil.restClientHeader();
            String productTypeCode = MembershipConstants.PRODUCT_TYPE_CODE_ITB;
            if (CommonConstants.LEVEL_6.equals(CommonConstants.LEVEL_TO_CUSTOMERTYPE_MAP.get(customerType))) {
                productTypeCode = MembershipConstants.PRODUCT_TYPE_CODE_ITF;
            }
            RequestReasonSearchCriteria reasonSearchCriteria = RequestReasonSearchCriteria.builder()
                    .centerCode(MembershipConstants.CENTER_CODE)
                    .processRequestSourceCode(MembershipConstants.PROCESS_REQUEST_SOURCE_CODE)
                    .productLevelNumber(CommonConstants.LEVEL_TO_CUSTOMERTYPE_MAP.get(customerType))
                    .productProcessCode(MembershipConstants.PRODUCT_PROCESS_CODE)
                    .productTypeCode(productTypeCode)
                    .build();
            ResponseEntity<List<RequestReasonResponseEntity>> listResponseEntity =
                    productService.getRequestReasonCodes(headerMap, reasonSearchCriteria);
            if (null != listResponseEntity && listResponseEntity.getStatusCode().is2xxSuccessful()) {
                List<RequestReasonResponseEntity> entityList = listResponseEntity.getBody();
                RequestReasonResponse requestReasonResponse = new RequestReasonResponse();
                List<RequestReason> requestReasons = new ArrayList<>();
                for (RequestReasonResponseEntity entity : entityList) {
                    requestReasons.add(RequestReason.builder()
                            .code(entity.getRequestReasonCode())
                            .description(entity.getRequestReasonName())
                            .build());
                }
                requestReasonResponse.setRequestReasons(requestReasons);
                return requestReasonResponse;
            } else {
                throw new RequestReasonsException(MembershipConstants.REQUEST_REASONS_NOT_FOUND);
            }
        } catch (FeignException.BadRequest ex) {
            throw new RequestReasonsException(MembershipConstants.REQUEST_REASONS_NOT_FOUND + ex);
        } catch (Exception ex) {
            throw new RequestReasonsException(MembershipConstants.REQUEST_REASONS_ERROR
                    + ExceptionUtils.getStackTrace(ex));
        }
    }

    /**
     * Get Referral Entity.
     *
     * @param headerMap header map
     * @param peid      product enrollment Id
     * @return int
     * @throws MembershipException when an exception occurs while fetching membership information
     */
    private int getAccountKey(Map<String, String> headerMap, BigDecimal peid) throws MembershipException {
        try {
            ResponseEntity<ReferralEntity> referralEntityResponse = productService
                    .getReferrals(headerMap, peid.toString());
            if (referralEntityResponse.getStatusCode().equals(HttpStatus.OK)) {
                return Objects.requireNonNull(referralEntityResponse.getBody()).getCmAccountKey();
            } else {
                throw new MembershipException(MembershipConstants.BILLING_ERROR);
            }
        } catch (FeignException.BadRequest ex) {
            throw new MembershipException(ValidationConstants.PEID_INVALID_LENGTH_EC + ex);
        } catch (FeignException.NotFound ex) {
            String exMessage = ex.contentUTF8();
            if (exMessage.isEmpty()) {
                throw new MembershipException(ValidationConstants.PEID_NOT_FOUND_EC + ex);
            } else {
                throw new MembershipException(MembershipConstants.BILLING_ERROR + ex);
            }
        } catch (Exception ex) {
            throw new MembershipException(MembershipConstants.BILLING_ERROR + ex);
        }
    }

    /**
     * Get Card Customer Data Response.
     *
     * @param headerMap  header map
     * @param accountKey account key
     * @return CardCustomerDataResponse
     */
    private CardCustomerDataResponse getCardCustomerDataResponse(Map<String, String> headerMap,
                                                                 int accountKey) throws MembershipException {
        CardCustomerDataRequest cardCustomerDataRequest = createCardCustomerDataRequest(accountKey);
        try {
            ResponseEntity<CardCustomerDataResponse> cardCustomerDataResponseEntity = cardCustomerService
                    .fetchCardCustomerData(headerMap, cardCustomerDataRequest);
            if (cardCustomerDataResponseEntity.getStatusCode().equals(HttpStatus.OK)) {
                return cardCustomerDataResponseEntity.getBody();
            } else {
                throw new MembershipException(MembershipConstants.BILLING_ERROR);
            }
        } catch (Exception ex) {
            throw new MembershipException(MembershipConstants.BILLING_ERROR + ex);
        }
    }

    /**
     * Get Card Customer Data Response.
     *
     * @param headerMap    header map
     * @param subscriberId subscriber number
     * @return CardCustomerDataResponse
     */
    private CsidApiResponse getCsiApiDataResponse(Map<String, String> headerMap, String subscriberId)
            throws MembershipException {
        try {
            ResponseEntity<CsidApiResponse> csiapiResponseDataResponseEntity = csidSubscriberService
                    .getBillingStatus(headerMap, subscriberId);
            if (csiapiResponseDataResponseEntity.getStatusCode().equals(HttpStatus.OK)) {
                return csiapiResponseDataResponseEntity.getBody();
            }
        } catch (Exception ex) {
            throw new MembershipException(MembershipConstants.BILLING_ERROR + ex);
        }
        return null;
    }

    /**
     * Formulate the card customer data request api input.
     *
     * @param accountKey account key
     * @return CardCustomerDataRequest
     */
    private CardCustomerDataRequest createCardCustomerDataRequest(int accountKey) {
        CardCustomerDataRequest cardCustomerDataRequest = new CardCustomerDataRequest();
        cardCustomerDataRequest.setAccountKey(accountKey);
        cardCustomerDataRequest.setCustomerRoleCode(CUSTOMER_ROLE_CODE);
        return cardCustomerDataRequest;
    }

    /**
     * Get Account Key Sequence Number Response.
     *
     * @param headerMap  header map
     * @param accountKey account key
     * @return AccountKeySequenceNbrResponse
     */
    private AccountKeySequenceNbrResponse getAccountKeySequenceNbrResponse(
            Map<String, String> headerMap, int accountKey) throws MembershipException {
        AcctKeyTrnsfrSeqNmbrRequest acctKeyTrnsfrSeqNmbrRequest = createAcctKeyTrnsfrSeqNmbrRequest(accountKey);
        try {
            ResponseEntity<AccountKeySequenceNbrResponse> accountKeySequenceNbrResponseEntity = accountNumberService
                    .fetchAccountNumber(headerMap, acctKeyTrnsfrSeqNmbrRequest);
            if (accountKeySequenceNbrResponseEntity.getStatusCode().equals(HttpStatus.OK)) {
                return accountKeySequenceNbrResponseEntity
                        .getBody();
            } else {
                throw new MembershipException(MembershipConstants.BILLING_ERROR);
            }
        } catch (Exception ex) {
            throw new MembershipException(MembershipConstants.BILLING_ERROR + ex);
        }
    }

    /**
     * Create Account Key Transfer Sequence Number Response.
     *
     * @param accountKey account key
     * @return AcctKeyTrnsfrSeqNmbrRequest
     */
    private AcctKeyTrnsfrSeqNmbrRequest createAcctKeyTrnsfrSeqNmbrRequest(int accountKey) {
        AcctKeyTrnsfrSeqNmbrRequest acctKeyTrnsfrSeqNmbrRequest = new AcctKeyTrnsfrSeqNmbrRequest();
        acctKeyTrnsfrSeqNmbrRequest.setAcctKey(accountKey);
        return acctKeyTrnsfrSeqNmbrRequest;
    }

    /**
     * Formulate the Billing Response.
     *
     * @param cardCustomerDataResponse card customer data response
     * @return BillingResponse billingResponse
     */
    private BillingResponse formulateBillingResponse(BillingResponse billingResponse,
                                                     CardCustomerDataResponse cardCustomerDataResponse,
                                                     AccountKeySequenceNbrResponse accountKeySequenceNbrResponse) {
        billingResponse.setPcmFirstName(cardCustomerDataResponse.getFirstName());
        billingResponse.setPcmLastName(cardCustomerDataResponse.getLastName());
        billingResponse.setPcmAccountNumber(accountKeySequenceNbrResponse.getAcctNbr());
        billingResponse.setPresenceOfSecondary(cardCustomerDataResponse.getPresenceOfSecondary()
                .equals("Y") ? "Yes" : "No");
        return billingResponse;
    }

    /**
     * Formulate the Billing Response.
     *
     * @param csidApiResponse customer billing date response
     * @return BillingResponse billingResponse
     */
    private BillingResponse formulateBillingDateResponse(BillingResponse billingResponse,
                                                         CsidApiResponse csidApiResponse) {
        if (null != csidApiResponse) {
            billingResponse.setNextBillingDate(csidApiResponse.getResponseObject().getResponse().getSubscriberData()
                    .getNextBillDate());
        }
        return billingResponse;
    }

    /**
     * Method to Extract MembershipInfo from responseEntity.
     *
     * @param partyId     - of customer who membership info is fetched
     * @param productCode - ITF or ITB
     * @return - membership info
     */
    public MembershipInfo fetchMembershipInfo(String partyId, String productCode)
            throws ActionItpException, MembershipException {
        Map<String, String> headerMap = itpUtil.restClientHeader();
        ResponseEntity<MembershipInfo> membershipInfoResponseEntity = productService
                .getMembershipByPartyId(headerMap,
                        partyId,
                        productCode);
        if (membershipInfoResponseEntity.getStatusCode().is2xxSuccessful()) {
            return membershipInfoResponseEntity.getBody();
        }
        throw new MembershipException(MembershipConstants.MEMBERSHIP_ERROR);
    }

    /**
     * Method to extract the correct membership details from a list of memberships.
     * According to following business logic:
     * ITF          ITB         Membership Data Returned
     * Active       Active      Not possible but check whose "lastBillDate": "string",
     * Active       No Data     ITF Data
     * No Data      Active      ITB Data
     * Cancelled    Active      ITB Data
     * Active       Cancelled   ITF Data
     * Cancelled    Cancelled   Check whose "cancelCompletionDate": "string", is latest
     *
     * @param memberships - List of memberships fetched for partyID
     * @return - Information for one membership based on business logic for which info to show
     * @throws ParseException when date parsing fails
     */
    public MembershipListResponse determineMembershipFromList(List<MembershipListResponse> memberships)
            throws ParseException {
        // Max possible size is 2 since search is done for only ITF and ITB.
        // If there's only one result, that should be returned
        if (memberships.size() < 2) {
            return memberships.get(INDEX_ZERO);
        }
        // If there are 2 results, one is ITF and other is ITB
        MembershipListResponse member1 = memberships.get(INDEX_ZERO);
        MembershipListResponse member2 = memberships.get(INDEX_ZERO + 1);

        SimpleDateFormat dateFormatter = new SimpleDateFormat(TOKENIZED_DOB_PATTERN);

        if (itpUtil.isMemberCancelled(member1) && itpUtil.isMemberCancelled(member2)) {
            return getLatestCanceledMembershipDetails(member1, member2, dateFormatter);
        } else if (!itpUtil.isMemberCancelled(member1) && itpUtil.isMemberCancelled(member2)) {
            return member1;
        } else if (itpUtil.isMemberCancelled(member1) && !itpUtil.isMemberCancelled(member2)) {
            return member2;
        } else {
            // Case where both memberships are active should never occur, but is handled in case
            Date billDate1 = dateFormatter.parse(member1.getLastBillDate());
            Date billDate2 = dateFormatter.parse(member2.getLastBillDate());
            return billDate1.after(billDate2) ? member1 : member2;
        }
    }

    private MembershipListResponse getLatestCanceledMembershipDetails(MembershipListResponse member1,
                                                                      MembershipListResponse member2,
                                                                      SimpleDateFormat dateFormatter)
            throws ParseException {
        Date cancelDate1;
        Date cancelDate2;
        if (StringUtils.isNotBlank(member1.getCancelCompletionDate()) &&
                StringUtils.isNotBlank(member2.getCancelCompletionDate())) {
            cancelDate1 = dateFormatter.parse(member1.getCancelCompletionDate());
            cancelDate2 = dateFormatter.parse(member2.getCancelCompletionDate());
        } else {
            cancelDate1 = dateFormatter.parse(member1.getCancelRequestDate());
            cancelDate2 = dateFormatter.parse(member2.getCancelRequestDate());
        }
        return cancelDate1.after(cancelDate2) ? member1 : member2;
    }

    /**
     * Method to Extract List of MembershipInfo from responseEntity.
     *
     * @param partyId - partyId of customer
     * @return - list of membership info
     */
    public List<MembershipListResponse> fetchMemberships(String partyId)
            throws ActionItpException, MembershipException {
        Map<String, String> headerMap = itpUtil.restClientHeader();
        MembershipListRequest request = MembershipListRequest.builder()
                .identifier(partyId)
                .identifierType(ActionItpConstants.PARTY_ID_IDENTIFIER)
                .productTypeCodes(Arrays.asList(
                        ActionItpConstants.ITB_PRODUCT_TYPE_CODE,
                        ActionItpConstants.ITF_PRODUCT_TYPE_CODE))
                .build();

        ResponseEntity<List<MembershipListResponse>> membershipInfoResponseEntity = productService
                .fetchMemberships(headerMap, request);
        if (membershipInfoResponseEntity.getStatusCode().is2xxSuccessful()) {
            return membershipInfoResponseEntity.getBody();
        }
        throw new MembershipException(MembershipConstants.MEMBERSHIP_ERROR);
    }

    public ResponseEntity<Void> cancelMembership(Map<String, String> headerMap, Long membershipId,
                                                 CancelRequest cancelRequest) throws CancelException {
        if (cloudPropertiesConfiguration.isNewCancelApiEnabled()) {
            return cancelClient.cancelMembership(headerMap, "MEMBERSHIPID", membershipId, cancelRequest);
        } else {
            return membershipAccessClient.cancelMembership(headerMap, membershipId, cancelRequest);
        }
    }
}
