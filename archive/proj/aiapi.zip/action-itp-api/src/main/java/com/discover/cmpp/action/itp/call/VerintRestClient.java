package com.discover.cmpp.action.itp.call;

import com.discover.cmpp.action.itp.call.model.TagCallRequest;
import com.discover.cmpp.action.itp.call.model.TagCallResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.Map;

@FeignClient(name = "verintApi", url = "${verintApi.service.baseUrl}")
public interface VerintRestClient {

    @GetMapping(value = "${verintApi.service.contact}")
    ResponseEntity<Void> contact(@RequestHeader Map<String, String> headerMap,
                                 @PathVariable("ext") String ext);

    @PostMapping(value = "${verintApi.service.tagCall}")
    ResponseEntity<TagCallResponse> tagCall(@RequestHeader Map<String, String> headerMap, TagCallRequest request);
}