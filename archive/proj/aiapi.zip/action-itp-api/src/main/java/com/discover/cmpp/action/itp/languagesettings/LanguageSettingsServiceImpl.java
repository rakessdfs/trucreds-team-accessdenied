package com.discover.cmpp.action.itp.languagesettings;

import com.discover.cmpp.action.itp.accountactivity.AccountActivityException;
import com.discover.cmpp.action.itp.accountactivity.AccountActivityService;
import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.ActionItpUtil;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.flux.schema.AccountActivityPayload;
import com.discover.cmpp.action.itp.languagesettings.model.LanguageSettingsEntity;
import com.discover.cmpp.action.itp.languagesettings.model.LanguageSettingsRequest;
import com.discover.cmpp.action.itp.languagesettings.model.LanguageSettingsResponse;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.Objects;

import static com.discover.cmpp.action.itp.languagesettings.LanguageSettingsConstants.FETCH_LANGUAGE_EXCEPTION;
import static com.discover.cmpp.action.itp.languagesettings.LanguageSettingsConstants.SAVE_LANGUAGE_EXCEPTION;
import static java.time.ZoneOffset.UTC;

@Service
public class LanguageSettingsServiceImpl implements LanguageSettingsService {

    private final LanguageSettingsRepository languageSettingsRepository;

    private final AccountActivityService accountActivityService;

    private final ActionItpUtil actionItpUtil;

    public LanguageSettingsServiceImpl(LanguageSettingsRepository languageSettingsRepository,
                                       AccountActivityService accountActivityService,
                                       ActionItpUtil actionItpUtil) {
        this.languageSettingsRepository = languageSettingsRepository;
        this.accountActivityService = accountActivityService;
        this.actionItpUtil = actionItpUtil;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void saveLanguageSettings(LanguageSettingsRequest request, String agentId) throws LanguageSettingsException {
        try {
            String langPrefActivityCode = LanguageSettingsConstants.BLANKSTRING;
            String previousLanguagePrefData = LanguageSettingsConstants.BLANKSTRING;

            LanguageSettingsEntity languageSettingsEntity = this.languageSettingsRepository
                    .findByProductEnrollmentId(request.getProductEnrollmentId());

            if (Objects.nonNull(languageSettingsEntity)) {
                updateLanguagePreference(request, agentId, languageSettingsEntity);
            } else {
                this.languageSettingsRepository.save(createLanguageSettingsEntity(request, agentId));

                if (null != ActionItpConstants.getLanguagePreferenceMap().get(request.getLanguageCode())) {
                    langPrefActivityCode = ActionItpConstants.getLanguagePreferenceMap()
                            .get(request.getLanguageCode());
                }
                languagePrefAccountActivity(request, agentId,
                        langPrefActivityCode, previousLanguagePrefData);
            }
        } catch (Exception ex) {
            throw new LanguageSettingsException(SAVE_LANGUAGE_EXCEPTION + ExceptionUtils.getStackTrace(ex));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public LanguageSettingsResponse fetchLanguageSettings(String productEnrollmentId) throws LanguageSettingsException {
        LanguageSettingsResponse languageSettingsResponse;
        try {
            LanguageSettingsEntity getLanguageSettingsEntity = this.languageSettingsRepository
                    .findByProductEnrollmentId(productEnrollmentId);
            if (Objects.nonNull(getLanguageSettingsEntity)) {
                languageSettingsResponse = convertLanguageSettingsEntity(getLanguageSettingsEntity);
            } else {
                throw new LanguageSettingsException(ValidationConstants.PEID_NO_CONTENT_EC);
            }
        } catch (Exception ex) {
            throw new LanguageSettingsException(FETCH_LANGUAGE_EXCEPTION + ExceptionUtils.getStackTrace(ex));
        }
        return languageSettingsResponse;
    }

    /**
     * Method: This method will create the account activity in database.
     */
    private void createAccountActivity(LanguageSettingsRequest request,
                                       String activityCode, String previousDate,
                                       String newData, String agentId) throws AccountActivityException {
        AccountActivityPayload accountActivityPayloadRequest = new AccountActivityPayload();
        accountActivityPayloadRequest.setProductEnrollmentId(request.getProductEnrollmentId());
        accountActivityPayloadRequest.setActivityCode(activityCode);
        accountActivityPayloadRequest.setPreviousData(previousDate);
        accountActivityPayloadRequest.setNewData(newData);
        accountActivityPayloadRequest.setOperator(agentId);
        accountActivityPayloadRequest.setRequestDate(actionItpUtil.getFormatedRequestDateTime());
        accountActivityService.createActivity(accountActivityPayloadRequest);
    }

    /**
     * Method: This method will create language preference database object.
     */
    private LanguageSettingsEntity createLanguageSettingsEntity(
            LanguageSettingsRequest request, String agentId) throws LanguageSettingsException {
        LocalDateTime timestamp = OffsetDateTime.now(UTC).toLocalDateTime();
        if (StringUtils.isBlank(request.getLanguageCode())) {
            throw new LanguageSettingsException(ValidationConstants.ERROR_LANGUAGE_CODE_EC);
        }
        return LanguageSettingsEntity.builder()
                .productEnrollmentId(request.getProductEnrollmentId())
                .languageCode(request.getLanguageCode())
                .createBy(agentId)
                .createTs(timestamp)
                .updateBy(agentId)
                .updateTs(timestamp)
                .build();
    }

    /**
     * Method: This method will convert the database entity to rest response object.
     */
    private LanguageSettingsResponse convertLanguageSettingsEntity(LanguageSettingsEntity languageSettingsEntity) {
        LanguageSettingsResponse languageSettingsResponse = new LanguageSettingsResponse();
        languageSettingsResponse.setProductEnrollmentId(languageSettingsEntity.getProductEnrollmentId());
        languageSettingsResponse.setLanguageCode(languageSettingsEntity.getLanguageCode());
        return languageSettingsResponse;
    }

    /**
     * Method: This method will process logic for
     * language preference updates and prepare the database object.
     */
    private void updateLanguagePreference(LanguageSettingsRequest request, String agentId,
                                          LanguageSettingsEntity languageSettingsEntity)
            throws LanguageSettingsException, AccountActivityException {
        String langPrefActivityCode = LanguageSettingsConstants.BLANKSTRING;
        String previousLanguagePrefData = LanguageSettingsConstants.BLANKSTRING;
        boolean languagePreferenceUpdated = false;

        if (StringUtils.isNoneBlank(request.getLanguageCode()) &&
                !languageSettingsEntity.getLanguageCode().equalsIgnoreCase(
                        request.getLanguageCode())) {
            langPrefActivityCode = LanguageSettingsConstants.ACCOUNT_ACTIVITY_CODE_CLP;
            previousLanguagePrefData = languageSettingsEntity.getLanguageCode();
            languageSettingsEntity.setLanguageCode(request.getLanguageCode());
            languagePreferenceUpdated = true;
        }

        if (languagePreferenceUpdated) {
            languageSettingsEntity.setUpdateBy(agentId);
            languageSettingsEntity.setUpdateTs(OffsetDateTime.now(UTC).toLocalDateTime());
            this.languageSettingsRepository.save(languageSettingsEntity);
        } else {
            throw new LanguageSettingsException(ValidationConstants.LANGUAGE_NO_DATA_UPDATE_EM);
        }

        languagePrefAccountActivity(request, agentId, langPrefActivityCode, previousLanguagePrefData);
    }

    /**
     * Method: This method will add the activity for create or
     * update language preference changes.
     */
    private void languagePrefAccountActivity(LanguageSettingsRequest request, String agentId,
                                             String langPrefActivityCode,
                                             String previousLanguagePrefData)
            throws AccountActivityException {
        if (StringUtils.isNotBlank(langPrefActivityCode)) {
            createAccountActivity(request, langPrefActivityCode,
                    previousLanguagePrefData, request.getLanguageCode(), agentId);
        }
    }
}
