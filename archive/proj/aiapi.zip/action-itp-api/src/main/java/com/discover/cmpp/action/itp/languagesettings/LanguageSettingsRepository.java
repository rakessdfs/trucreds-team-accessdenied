package com.discover.cmpp.action.itp.languagesettings;

import com.discover.cmpp.action.itp.languagesettings.model.LanguageSettingsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LanguageSettingsRepository extends JpaRepository<LanguageSettingsEntity, Long> {

    /**
     * Fetch Language Settings by Product Enrollment Id.
     *
     * @param productEnrollmentId product enrollment id
     * @return {@link LanguageSettingsEntity}
     */
    LanguageSettingsEntity findByProductEnrollmentId(String productEnrollmentId);
}
