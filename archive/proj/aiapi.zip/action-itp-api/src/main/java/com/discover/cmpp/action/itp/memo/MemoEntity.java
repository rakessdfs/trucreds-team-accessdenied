package com.discover.cmpp.action.itp.memo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;

import static java.time.ZoneOffset.UTC;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "MEMO")
public class MemoEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MEMO_ID")
    private Long memoId;

    @Column(name = "PRODUCT_ENROLLMENT_ID")
    private String productEnrollmentId;

    @Column(name = "MEMO_TEXT")
    private String memoText;

    @Column(name = "CREATE_AGENT_ID")
    private String createAgentId;

    @Column(name = "CREATE_TS")
    private LocalDateTime createTs;

    @Column(name = "UPDATE_AGENT_ID")
    private String updateAgentId;

    @Column(name = "UPDATE_TS")
    private LocalDateTime updateTs;

    @PrePersist
    public void prePersist() {
        createTs = OffsetDateTime.now(UTC).toLocalDateTime();
    }

    @PreUpdate
    public void preUpdate() {
        updateTs = OffsetDateTime.now(UTC).toLocalDateTime();
    }
}
