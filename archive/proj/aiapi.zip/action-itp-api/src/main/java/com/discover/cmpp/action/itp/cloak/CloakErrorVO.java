package com.discover.cmpp.action.itp.cloak;

import lombok.Data;

@Data
public class CloakErrorVO {

    private String errorCode;
    private String errorText;
}
