package com.discover.cmpp.action.itp.custlookup;

public class CustLookUpException extends Exception {

    private static final long serialVersionUID = -7137924831698067982L;

    public CustLookUpException(String message) {
        super(message);
    }
}
