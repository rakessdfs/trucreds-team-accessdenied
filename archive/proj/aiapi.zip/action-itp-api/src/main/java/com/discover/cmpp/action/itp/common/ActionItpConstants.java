package com.discover.cmpp.action.itp.common;

import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ActionItpConstants {

    private ActionItpConstants() {
    }

    public static final String HTTP_AUTH_TOKEN = "HTTP_AUTH_TOKEN";
    public static final String JWT_SESSION_TOKEN = "Authorization";
    public static final String STRING = "string";
    public static final String HEADER = "header";
    public static final String JWT_V2_TOKEN = "JWT v2 token";
    public static final String BASE_PACKAGE = "com.discover.cmpp.action.itp";
    public static final String HEALTH_CHECK_API = "Health check";
    public static final String HEALTH_CHECK_API_NOTES =
            "This API is to check the status and install version on Action ITP application.";
    public static final String HEALTH_CHECK_URL = "/healthcheck";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String ACCEPT = "Accept";
    public static final String CONTENT_TYPE_APP_JSON = "application/json";
    public static final String API_BAD_REQUEST = "Invalid Request Parameters";
    public static final String API_OK = "Api has successfully completed.";
    public static final String API_CREATE = "Api has successfully created.";
    public static final String API_INTERNAL_SERVER_ERROR =
            "Api has encountered an error. Please try again aftersome or contact the Support Team";
    public static final String API_UNAUTHORITZED = "Authentication failed";
    public static final String API_NOT_AUTHORITZED_ACCESS = "Not Authorized to access the resource";
    public static final String API_NOT_FOUND = "Resource not Found";
    public static final String SPACE = " ";

    public static final String JWT_TOKEN_VALIDATE_URL = "/agent/token/validate";
    public static final String JWT_TOKEN_VALIDATE_NOTES = "This api is used for validating a JWT token.";
    public static final String AGENT_ID = "X-DFSUSER-USER-ID";
    public static final String AGENT_ID_VALUE = "Login user Id (RACF) of the Agent";
    public static final String PARTY_ID_HEADER = "X-DFSUSER-PARTY-ID";
    public static final String X_DFSUSER_PEID = "X-DFSUSER-PRODUCT-ID";
    //Product codes
    public static final String ITF_PRODUCT_TYPE_CODE = "ITF";
    public static final String ITB_PRODUCT_TYPE_CODE = "ITB";
    public static final String ITP_PRODUCT_TYPE_CODE = "ITP";
    public static final String BLANK_STRING = "";
    public static final Integer INDEX_ZERO = 0;
    public static final String CAN_PROCESS_REQ_CODE = "CAN";
    public static final String INP_PROCESS_STATUS_CODE = "INP";
    public static final String CMP_PROCESS_STATUS_CODE = "CMP";
    public static final String PEN_PROCESS_STATUS_CODE = "PEN";
    public static final String CAN_PROCESS_STATUS_CODE = "CAN";

    // CDS personal Info header
    public static final String X_USER_ID = "X-USER-ID";
    public static final String X_USER_ID_VALUE = "ITP";
    public static final String X_REQUEST_ID = "X-REQUEST-ID";

    // Billing
    public static final String CUSTOMER_ROLE_CODE = "P";

    // Response headers
    public static final String CACHE_CONTROL = "Cache-Control";
    public static final String CACHE_CONTROL_VALUE = "no-store, max-age=1800";
    public static final String PRAGMA = "Pragma";
    public static final String PRAGMA_VALUE = "no-cache";
    public static final String EXPIRES = "Expires";
    public static final String EXPIRES_VALUE = "Wed, 21 Oct 2015 07:28:00 GMT";

    //OOB Service
    public static final String OOB_SERVICE_CONNECT_TIMEOUT = "${oobService.connectTimeout}";
    public static final String OOB_SERVICE_RECEIVE_TIMEOUT = "${oobService.receiveTimeout}";
    public static final String OOB_SERVICE_URL = "${oobService.url}";
    public static final String RACF = "FCMSCCS";

    //Pearl Server Config
    public static final String PEARL_SERVER_CONNECT_TIMEOUT = "${pearlServer.connectTimeout}";
    public static final String PEARL_SERVER_RECEIVE_TIMEOUT = "${pearlServer.receiveTimeout}";
    public static final String PEARL_SERVER_URL = "${pearlServer.url}";

    public static final String MEMO_EVENT_LOGGER_TEMPLATE = "Peid: {} - Memo Text: {} - AgentId: {} - TimeStamp: {}";
    public static final String MEMO_EVENT_LOGGER_EXCEPTION_TEMPLATE = "Peid: {} - Memo Text: {} - AgentId: {} " +
            "- TimeStamp: {} - Exception: {}";
    public static final String FLUX_PUBLISH_ERROR = "Error publishing message";

    public static final String ACCOUNT_ACTIVITY_REQUEST_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String PARTY_ID_IDENTIFIER = "partyId";

    public static final String ACTIVITY_TO_ANALYTICS_EVENT_LOGGER_TEMPLATE = "Peid: {} - CustomerType: {} - " +
            "CustomerLevel: {} - Activity Code: {} - Previous Data: {} - New Data: {}";
    public static final String ACTIVITY_TO_ANALYTICS_ERROR_LOGGER_TEMPLATE = "Peid: {} - CustomerType: {} - " +
            "CustomerLevel: {} - Activity Code: {} - Previous Data: {} - New Data: {} - Exception: {}";

    protected static final List<ActionItpError> OOB_ACTION_ITP_ERROR_MAP = new ArrayList<>(
            Arrays.asList(ActionItpError.builder().description(ValidationConstants.ERROR_OOB_SERVICE_CUST_KEY_EMPTY_EM)
                            .code(ValidationConstants.ERROR_OOB_SERVICE_CUST_KEY_EMPTY_EC)
                            .status(HttpStatus.BAD_REQUEST).build(),
                    ActionItpError.builder().description(ValidationConstants.ERROR_OOB_SERVICE_USER_NOT_FOUND_EM)
                            .code(ValidationConstants.ERROR_OOB_SERVICE_USER_NOT_FOUND_EC)
                            .status(HttpStatus.BAD_REQUEST).build(),
                    ActionItpError.builder().description(ValidationConstants.ERROR_OOB_SERVICE_CUST_KEY_LONG_EM)
                            .code(ValidationConstants.ERROR_OOB_SERVICE_CUST_KEY_LONG_EC)
                            .status(HttpStatus.BAD_REQUEST).build(),
                    ActionItpError.builder().description(ValidationConstants.ERROR_OOB_SERVICE_PASSCODE_INVALID_EM)
                            .code(ValidationConstants.ERROR_OOB_SERVICE_PASSCODE_INVALID_EC)
                            .status(HttpStatus.BAD_REQUEST).build(),
                    ActionItpError.builder().description(ValidationConstants.ERROR_OOB_SERVICE_PASSCODE_EXPIRED_EM)
                            .code(ValidationConstants.ERROR_OOB_SERVICE_PASSCODE_EXPIRED_EC)
                            .status(HttpStatus.BAD_REQUEST).build(),
                    ActionItpError.builder().description(ValidationConstants.ERROR_OOB_SERVICE_USER_LOCKED_EM)
                            .code(ValidationConstants.ERROR_OOB_SERVICE_USER_LOCKED_EC)
                            .status(HttpStatus.BAD_REQUEST).build(),
                    ActionItpError.builder().description(ValidationConstants.CHANNEL_VALUE_INVALID_EM)
                            .code(ValidationConstants.CHANNEL_VALUE_INVALID_EC)
                            .status(HttpStatus.BAD_REQUEST).build(),
                    ActionItpError.builder().description(ValidationConstants.CHANNEL_CODE_INVALID_EM)
                            .code(ValidationConstants.CHANNEL_CODE_INVALID_EC)
                            .status(HttpStatus.BAD_REQUEST).build(),
                    ActionItpError.builder().description(ValidationConstants.CODE_GENERATION_ERROR_EM)
                            .code(ValidationConstants.CODE_GENERATION_ERROR_EC)
                            .status(HttpStatus.BAD_REQUEST).build(),
                    ActionItpError.builder().description(ValidationConstants.ERROR_OOB_SERVICE_CHANNEL_VALUE_EMPTY_EM)
                            .code(ValidationConstants.ERROR_OOB_SERVICE_CHANNEL_VALUE_EMPTY_EC)
                            .status(HttpStatus.BAD_REQUEST).build(),
                    ActionItpError.builder().description(ValidationConstants.ERROR_OOB_SERVICE_NOT_ENROLLED_EM)
                            .code(ValidationConstants.ERROR_OOB_SERVICE_NOT_ENROLLED_EC)
                            .status(HttpStatus.BAD_REQUEST).build(),
                    ActionItpError.builder().description(ValidationConstants.ERROR_OOB_SERVICE_FAILED_TO_LOCK_EM)
                            .code(ValidationConstants.ERROR_OOB_SERVICE_FAILED_TO_LOCK_EC)
                            .status(HttpStatus.INTERNAL_SERVER_ERROR).build(),
                    ActionItpError.builder().description(ValidationConstants.ERROR_OOB_SERVICE_EM)
                            .code(ValidationConstants.ERROR_OOB_SERVICE_EC)
                            .status(HttpStatus.INTERNAL_SERVER_ERROR).build())
    );

    protected static final Map<String, String> languagePreferenceMap = new HashMap<>();

    static {
        languagePreferenceMap.put("EN", "ELP");
        languagePreferenceMap.put("SP", "SLP");
    }

    public static Map<String, String> getLanguagePreferenceMap() {
        return languagePreferenceMap;
    }
}
