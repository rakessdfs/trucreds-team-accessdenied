package com.discover.cmpp.action.itp.accountactivity;

import lombok.Data;

@Data
public class ItpCsidAlertPkData {

    private String alertId;
    private String eventDate;  // example: yyyy-MM-dd HH:mm:ss.SSSSSS
}
