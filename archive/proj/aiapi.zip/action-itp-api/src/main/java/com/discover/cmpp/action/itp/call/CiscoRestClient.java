package com.discover.cmpp.action.itp.call;

import com.discover.cmpp.action.itp.call.model.CiscoRestApiResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "CiscoRestApi", url = "${ciscoRestApi.service.baseUrl}")
public interface CiscoRestClient {

    @GetMapping(value = "${ciscoRestApi.service.getAgent}")
    ResponseEntity<CiscoRestApiResponse> getAgentPhoneExtension(@RequestParam(value = "racf") String racf,
                                                                @RequestParam(value = "sys") String sys,
                                                                @RequestParam(value = "match") String match);
}