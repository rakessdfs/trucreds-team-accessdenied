package com.discover.cmpp.action.itp.call;

public class CallConstants {

    private CallConstants() {
    }

    public static final String RECORD_CALL_URL = "/recordCall";
    public static final String RECORD_CALL_API = "API to record call by getting agent extension and tagging in Verint.";
    public static final String RECORD_CALL_API_NOTES =
            "API accepts the request and gets the agent extension. For the customer's PEID and level number, " +
                    "API tags the call in Verint to start recording";

    public static final String SYS_TYPE = "ucce";
    public static final String MATCH_TYPE = "exact";
    public static final String ERROR_MSG_AGENT_EXTENSION_NOT_FOUND = "Error while fetching agent phone extension";
    public static final String ERROR_MSG_TAG_CALL = "Error while tagging call in Verint";

    public static final String VERINT_MEMO_SUCCESS = "Call Tagging Successful, Verint Contact ID: ";
    public static final String VERINT_MEMO_FAILURE = "Call Tagging Failure, Verint Contact ID: N/A";
}
