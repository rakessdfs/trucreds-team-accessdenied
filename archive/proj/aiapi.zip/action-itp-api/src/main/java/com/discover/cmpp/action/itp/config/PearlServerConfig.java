package com.discover.cmpp.action.itp.config;

import com.dfs.pearl.ao.PearlAOBean;
import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.oob.SoapInterceptor;
import com.discover.cmpp.action.itp.pearlServer.PearlServerSoapInterceptor;
import com.discover.internet.service.oob.ao.OOBServiceAOBean;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Profile("!test")
@Configuration
public class PearlServerConfig {

    @Value(ActionItpConstants.PEARL_SERVER_CONNECT_TIMEOUT)
    private String pearlServerConnectTimeout;

    @Value(ActionItpConstants.PEARL_SERVER_RECEIVE_TIMEOUT)
    private String pearlServerReceiveTimeout;

    @Value(ActionItpConstants.PEARL_SERVER_URL)
    private String pearlServerUrl;

    private PearlServerSoapInterceptor soapInterceptor;

    public PearlServerConfig(PearlServerSoapInterceptor soapInterceptor) {
        this.soapInterceptor = soapInterceptor;
    }

    @Bean
    @Qualifier("pearlAOBean")
    public PearlAOBean pearlAOBean() {
        JaxWsProxyFactoryBean jaxWsProxyFactoryBean = getJaxWsProxyFactoryBean(PearlAOBean.class, pearlServerUrl);
        jaxWsProxyFactoryBean.getOutInterceptors().add(soapInterceptor);
        PearlAOBean pearlAoBean = (PearlAOBean) jaxWsProxyFactoryBean.create();
        Client client = ClientProxy.getClient(pearlAoBean);
        setSoapTimeout(client, pearlServerConnectTimeout, pearlServerReceiveTimeout);
        return pearlAoBean;
    }

    private <T> JaxWsProxyFactoryBean getJaxWsProxyFactoryBean(Class<T> beanClass, String url) {
        JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
        jaxWsProxyFactoryBean.setServiceClass(beanClass);
        jaxWsProxyFactoryBean.setAddress(url);
        return jaxWsProxyFactoryBean;
    }

    private void setSoapTimeout(Client client, String connTimeout, String receiveTimeout) {
        try {
            HTTPConduit http = (HTTPConduit) client.getConduit();
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(Long.parseLong(connTimeout));
            httpClientPolicy.setReceiveTimeout(Long.parseLong(receiveTimeout));
            http.setClient(httpClientPolicy);
        } catch (NumberFormatException ne) {
            ne.getStackTrace();
        }
    }
}