package com.discover.cmpp.action.itp.cloak;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.Map;

@FeignClient(name = "Cloak", url = "${cloak.service.baseUrl}")
public interface CloakClient {

    @PostMapping(value = "${cloak.service.tokenization}")
    ResponseEntity<CloakTokenizeResponse> tokenize(@RequestHeader Map<String, String> headerMap, CloakRequest request);

    @PostMapping(value = "${cloak.service.detokenization}")
    ResponseEntity<CloakDetokenizeResponse> detokenize(@RequestHeader Map<String, String> headerMap,
                                                       CloakRequest request);
}
