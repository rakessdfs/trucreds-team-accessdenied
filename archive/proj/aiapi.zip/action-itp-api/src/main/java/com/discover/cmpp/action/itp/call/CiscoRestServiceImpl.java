package com.discover.cmpp.action.itp.call;

import com.discover.cmpp.action.itp.call.model.CiscoRestApiResponse;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class CiscoRestServiceImpl implements CiscoRestService {

    private CiscoRestClient ciscoRestClient;

    public CiscoRestServiceImpl(CiscoRestClient ciscoRestClient) {
        this.ciscoRestClient = ciscoRestClient;
    }

    @LogAround
    @LogExecutionTime
    @Override
    /**
     * {@inheritDoc}
     *
     */
    public ResponseEntity<CiscoRestApiResponse> getAgentPhoneExtension(String racf, String sys, String match) {
        return ciscoRestClient.getAgentPhoneExtension(racf, sys, match);
    }
}
