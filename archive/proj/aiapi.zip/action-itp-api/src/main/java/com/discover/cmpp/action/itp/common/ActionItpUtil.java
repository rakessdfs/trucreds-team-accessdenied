package com.discover.cmpp.action.itp.common;

import com.dfs.ws.jwt.generator.WSJWTException;
import com.dfs.ws.jwt.generator.WSJWTGenerator;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.action.itp.custlookup.CdsService;
import com.discover.cmpp.action.itp.custlookup.CustLookUpConstants;
import com.discover.cmpp.action.itp.custlookup.CustLookUpException;
import com.discover.cmpp.action.itp.custlookup.model.cdspersonal.CdsPersonalInfoRequest;
import com.discover.cmpp.action.itp.custlookup.model.cdspersonal.CdsPersonalInfoResponse;
import com.discover.cmpp.action.itp.membership.MembershipConstants;
import com.discover.cmpp.action.itp.membership.model.MembershipListResponse;
import com.discover.cmpp.logging.LogAround;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Component
public class ActionItpUtil {

    @Autowired
    WSJWTGenerator jwtGenerator;

    @Autowired
    CdsService cdsService;

    /**
     * Generate Token and create Action ITP API rest client Header.
     *
     * @return Map of headers
     * @throws ActionItpException when map operation fails
     */
    @LogAround
    public Map<String, String> restClientHeader() throws ActionItpException {
        Map<String, String> map = new HashMap<>();
        try {
            map.put(ActionItpConstants.HTTP_AUTH_TOKEN, jwtGenerator.getJWTToken());
            map.put(ActionItpConstants.CONTENT_TYPE, ActionItpConstants.CONTENT_TYPE_APP_JSON);
        } catch (WSJWTException e) {
            throw new ActionItpException("Error Fetching jwt Token : " + ExceptionUtils.getStackTrace(e));
        }
        return map;
    }

    /**
     * Generate Token and create ITP Account Center API rest client Header CDS.
     *
     * @return Map of headers
     * @throws ActionItpException when map operation fails
     */
    @LogAround
    public Map<String, String> restClientCdsHeader(String agentId) throws ActionItpException {
        if (StringUtils.isEmpty(agentId)) {
            throw new ActionItpException(ValidationConstants.AGENT_ID_INVALID_EC);
        }
        Map<String, String> cdsHeadeMap = restClientHeader();
        cdsHeadeMap.put(ActionItpConstants.X_USER_ID, ActionItpConstants.X_USER_ID_VALUE);
        cdsHeadeMap.put(ActionItpConstants.X_REQUEST_ID, agentId);
        return cdsHeadeMap;
    }

    /**
     * Method to format date to the cloak api acceptable date format.
     *
     * @param unformatedDate unformatted date
     * @return formatedDate formatted date
     * @throws CustLookUpException when parsing fails
     */
    public String convertDateFormat(String unformatedDate, String fromDateFormat, String toDateFormat)
            throws CustLookUpException {
        SimpleDateFormat dateFormat = new SimpleDateFormat(fromDateFormat);
        Date inputDate;
        try {
            inputDate = dateFormat.parse(unformatedDate);
        } catch (ParseException e) {
            throw new CustLookUpException(
                    "Error while formatting input dob to cloak format " + ExceptionUtils.getStackTrace(e));
        }
        SimpleDateFormat clockDateFormat = new SimpleDateFormat(toDateFormat);
        return clockDateFormat.format(inputDate);
    }

    /**
     * This method with extract the peid from Customer partyId.
     *
     * @param headerMap cds header map
     * @param partyId   customer party
     * @return String product enrollment id - peid.
     */
    public String getProductEnrollmentId(Map<String, String> headerMap, String partyId)
            throws CustLookUpException {
        return Optional.ofNullable(cdsService.getCustomerPersonalInfo(headerMap,
                CdsPersonalInfoRequest.builder()
                        .identifierType(CustLookUpConstants.PARTY_ID).identifier(partyId).build()).getBody())
                .map(this::getProductEnrollmentIdentifier)
                .orElseThrow(() -> new CustLookUpException(CustLookUpConstants.PEID_NOT_FOUND));
    }

    /**
     * This method with extract the peid from Customer partyId.
     *
     * @param cdsPersonalInfoResponse Customer Personal Info Response
     * @return String product enrollment id - peid.
     */
    private String getProductEnrollmentIdentifier(CdsPersonalInfoResponse cdsPersonalInfoResponse) {
        String peId = null;
        CdsPersonalInfoResponse.PartyToSourceIdAssociation[] partyToSourceIdAssociations
                = cdsPersonalInfoResponse.getPersonalInfo().get(0).getPartyToSourceIdAssociation();
        Optional<CdsPersonalInfoResponse.PartyToSourceIdAssociation> association
                = Optional.ofNullable(Arrays.asList(partyToSourceIdAssociations).stream()
                .filter(x -> (
                        x.getExpiryTimestamp() == null ||
                                x.getExpiryTimestamp().compareTo(Instant.now()) >= 0) &&
                        x.getRequestSourceCode().equalsIgnoreCase(MembershipConstants.REQ_SRC_CODE_PD))
                .findAny()
                .orElse(null));

        if (association.isPresent()) {
            peId = association.get().getAlternatePartyId();
        }
        return peId;
    }

    /**
     * Return formated request date requesired for request activity.
     *
     * @return @{@link String} object.
     */
    public String getFormatedRequestDateTime() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(
                ActionItpConstants.ACCOUNT_ACTIVITY_REQUEST_DATE_FORMAT);
        return LocalDateTime.now().format(formatter);
    }

    /**
     * Determines if a given membership is equal to a cancelled membership code.
     *
     * @param member member to check cancellation status
     * @return true if cancelled or pending cancellation, else false
     */
    public boolean isMemberCancelled(MembershipListResponse member) {
        return member.getStandingCode().equalsIgnoreCase(MembershipConstants.StandingCode.PCN.name()) ||
                member.getStandingCode().equalsIgnoreCase(MembershipConstants.StandingCode.CAN.name());
    }
}
