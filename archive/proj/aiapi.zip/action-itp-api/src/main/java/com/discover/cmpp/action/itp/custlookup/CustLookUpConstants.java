package com.discover.cmpp.action.itp.custlookup;

public class CustLookUpConstants {

    private CustLookUpConstants() {
    }

    public static final String API_CUST_NOT_FOUND_ERROR = "Customer not found in CDS. contact the Support Team";
    public static final String ERROR_MSG_CDS_CUST_NOT_FOUND = "Error customer not found in CDS";
    public static final String ERROR_MSG_CDS_CUST_LOCATION_NOT_FOUND = "Error customer location info not found in CDS";
    public static final String ERROR_MSG_CDS_CUST_PERSONAL_NOT_FOUND = "Error customer personal info not found in CDS";
    public static final String ERROR_MSG_PRODUCT_ENROLLMENT = "Error while fetching peid from Product Enrollment API";

    public static final String ERROR_MSG_CDS_CUST_SEARCH = "Error in While searching customers in CDS";
    public static final String ERROR_MSG_CDS_CUST_LOCATION_INFO =
            "Error in While fetching customer location info from CDS";
    public static final String ERROR_MSG_CDS_CUST_PERSONAL_INFO =
            "Error in While fetching customer personal info from CDS";
    public static final String NOT_FOUND = "not found";
    public static final String PARTY_ID = "partyId";
    public static final String SOURCE_CDE = "PD";
    public static final String UPDATE_USER_IDENTIFIER = "ITP";

    public static final String BLANKSTRING = "";
    public static final Integer INDX_0 = 0;
    public static final String HOME_IDENTIFIER = "001";

    public static final String CUST_PII_LOOK_UP_URL = "/customer/search";
    public static final String CUST_PII_LOOK_UP_API = "API for getting matching customers from cds";
    public static final String CUST_PII_LOOK_UP_API_NOTES =
            "API for getting customers pii query info from CDS based on DOB, First and Last name";
    public static final String API_CUST_PII_NOT_FOUND_ERROR = "No customers found in CDS. Contact the Support Team";

    public static final String CUST_PII_INFO_URL = "/customer/pii";
    public static final String CUST_PII_INFO_API = "API for getting customer pii infomation from cds";
    public static final String CUST_PII_INFO_API_NOTES =
            "API for getting customers pii information from CDS based partyId";
    public static final String CUST_PII_INFO_NOT_FOUND_ERROR = "No customer pii info found in CDS. " +
            "Contact the Support Team";
    public static final String PII_INFO_PARTY_ID = "party-id";
    public static final String INVALID_SUBSCRIBER_ID = "Invalid Subscriber ID";
    public static final String MEMBER_NOT_FOUND = "Member Not Found";
    public static final String ERROR_MSG_CDS_TRANSLATION_API_V2 = "is not a ITP FnF Customer.";
    public static final String PEID_NOT_FOUND = "Peid not found";
}
