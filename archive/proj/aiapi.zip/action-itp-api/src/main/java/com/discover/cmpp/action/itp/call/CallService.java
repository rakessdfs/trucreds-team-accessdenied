package com.discover.cmpp.action.itp.call;

import com.discover.cmpp.action.itp.call.model.RecordCallRequest;
import com.discover.cmpp.action.itp.common.ActionItpException;

public interface CallService {

    /**
     * This method is used to get the agent extension and record the call.
     *
     * @param recordCallRequest input request with customer details.
     * @param agentId           of the agent.
     * @throws CallException      when exception occurred starting call recording.
     * @throws ActionItpException when exception occurred getting rest client header.
     */
    void recordCall(RecordCallRequest recordCallRequest, String agentId) throws CallException, ActionItpException;
}
