package com.discover.cmpp.action.itp.membership;

import com.discover.cmpp.action.itp.membership.model.CsidApiResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.Map;

@FeignClient(name = "csidSubscriberApi", url = "${csidSubscriberApi.service.baseUrl}")
public interface CsidSubscriberClient {

    @PostMapping(value = "${csidSubscriberApi.service.billingStatus}")
    ResponseEntity<CsidApiResponse> getBillingStatus(@RequestHeader Map<String, String> headerMap,
                        @PathVariable(MembershipConstants.SUBSCRIBER_ID_PARAM) String subscriberNumber);
}