package com.discover.cmpp.action.itp.membership;

public class MembershipConstants {

    private MembershipConstants() {
        //to keep sonar happy
    }

    public static final String FETCH_MEMBERSHIP_URL = "/membership";
    public static final String FETCH_MEMBERSHIP_API = "API to Fetch Membership " +
            "information for the customer based on party Id and the Product";
    public static final String FETCH_MEMBERSHIP_API_NOTES =
            "API accepts the Party Id and fetches the " +
                    "membership information from Products API";
    public static final String PARTY_ID_PARAM = "partyId";
    public static final String MEMBERSHIP_NOT_FOUND = "Membership not found or not active";
    public static final String MEMBERSHIP_ERROR = "Error in fetching Product Membership";
    public static final String MEMBERSHIP_PROCESS_REQUEST_NOT_FOUND = "Membership Process Request " +
            "not found or not active";

    public enum StandingCode { PCN, CAN }

    public static final String E11_CLOSED_ACCOUNT = "E11-CLOSED ACCOUNT";
    public static final String E10_DENIED_DUE_TO_OVERLIMIT = "E10-DENIED DUE TO OVERLIMIT";
    public static final String E18_INVALID_ACCOUNT_STATUS = "E18-INVALID ACCOUNT STATUS";
    public static final String A01_NOT_APPROVED = "A01-NOT APPROVED";
    public static final String E08_NOT_ENROLD_IN_PROD = "E08-NOT ENROLD IN PROD";
    public static final String SUBSCRIBER_NUMBER_NOT_FOUND = "Subscriber number not found";
    public static final String PRODUCTS_CDS_DATA_SRC_CODE = "PD";

    // Billing
    public static final String FETCH_BILLING_DETAILS_API = "API to Fetch Billing " +
            "information for the customer based on PEID";
    public static final String FETCH_BILLING_API_NOTES =
            "API accepts the PEID and fetches the " +
                    "billing information from Card Customer Data API";
    public static final String FETCH_BILLING_URL = "/membership/billing";
    public static final String PEID_PARAM = "peid";
    public static final String BILLING_ERROR = "Error in fetching billing information";
    public static final String REQ_SRC_CODE_PD = "PD";
    public static final String SUBSCRIBER_ID_PARAM = "subscriberId";
    public static final String CUSTOMER_TYPE_PARAM = "customerType";

    // Fetch request reason codes
    public static final String FETCH_REQUEST_REASONS_URL = "/requestreasons/query";
    public static final String FETCH_REQUEST_REASONS_API = "API to Fetch Request " +
            "reasons for the customer based on customer type";
    public static final String FETCH_REQUEST_REASONS_API_NOTES =
            "API accepts the customer type and fetches the " +
                    "request reasons from Products API";
    public static final String REQUEST_REASONS_NOT_FOUND = "Request reasons not found ";
    public static final String REQUEST_REASONS_ERROR = "Error in fetching Product Membership ";
    public static final String CENTER_CODE = "HQ";
    public static final String PROCESS_REQUEST_SOURCE_CODE = "ACT";
    public static final String PRODUCT_PROCESS_CODE = "CAN";
    public static final String PRODUCT_TYPE_CODE_ITF = "ITF";
    public static final String PRODUCT_TYPE_CODE_ITB = "ITB";
}
