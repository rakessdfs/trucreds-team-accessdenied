package com.discover.cmpp.action.itp.accountcenter;

import com.discover.cmpp.action.itp.accountcenter.model.ApplicantLocationResponse;
import com.discover.cmpp.action.itp.accountcenter.model.UpdatePiiRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.Map;

import static com.discover.cmpp.action.itp.common.ActionItpConstants.PARTY_ID_HEADER;
import static com.discover.cmpp.action.itp.common.ActionItpConstants.X_DFSUSER_PEID;

public interface ItpAccountCenterService {

    /**
     * To Update the Customer Profile info(address, phone, email).
     *
     * @param headerMap - Request Header map
     * @param partyId   - Request customer's partyId
     * @param peId      - Request customer's peId
     * @return - Application Location
     */
    ResponseEntity<ApplicantLocationResponse> updateCustomerProfileInfo(
            @RequestHeader Map<String, String> headerMap,
            @RequestHeader(PARTY_ID_HEADER) String partyId,
            @RequestHeader(X_DFSUSER_PEID) String peId,
            UpdatePiiRequest request) throws ItpAccountCenterException;
}
