package com.discover.cmpp.action.itp.cloak;

public class CloakException extends Exception {

    private static final long serialVersionUID = -7137924831698067982L;

    public CloakException(String message) {
        super(message);
    }
}
