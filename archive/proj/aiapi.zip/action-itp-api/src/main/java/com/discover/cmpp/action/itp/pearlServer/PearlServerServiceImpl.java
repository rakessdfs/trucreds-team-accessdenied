package com.discover.cmpp.action.itp.pearlServer;

import com.dfs.pearl.ao.*;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PearlServerServiceImpl implements PearlServerService {

    private final PearlAOBean pearlAOBean;

    public PearlServerServiceImpl(PearlAOBean pearlAOBean) {
        this.pearlAOBean = pearlAOBean;
    }

    @LogAround
    @LogExecutionTime
    @Override
    /**
     * {@inheritDoc}
     *
     */
    public List<NotesListVO> getPcmMemos(String membershipId) throws PearlServerException_Exception {
        NotesListOutputVO output = pearlAOBean.getProductNotesList(createGetMemosInputVo(membershipId));
        return output.getNotesListVO();
    }

    @LogAround
    @LogExecutionTime
    @Override
    /**
     * {@inheritDoc}
     *
     */
    public List<RequestActivityVO> getPcmAccountActivity(String membershipId) throws PearlServerException_Exception {
        ProcessRequestActivityListOutputVO output =
                pearlAOBean.getRequestActivityList(createProcessRequestActivityInputVo(membershipId));
        return output.getRequestActivityVOs();
    }

    @LogAround
    @LogExecutionTime
    @Override
    /**
     * {@inheritDoc}
     *
     */
    public MembershipDetailOutputVO getMembershipDetail(String membershipId) throws PearlServerException_Exception {
        return pearlAOBean.getMembershipDetail(createMembershipInputVo(membershipId));
    }

    // ASYS example: membership ID 2734400
    private NotesListInputVO createGetMemosInputVo(String membershipId) {
        NotesListInputVO inputVo = new NotesListInputVO();
        inputVo.setCenterCode("HQ");
        inputVo.setConsumerApplicationName("test");
        inputVo.setRacf("bfronk1");
        inputVo.setEndDate("2022-09-01");
        inputVo.setMajorTraceId((short)0);
        inputVo.setMaxNumberRequested((short)10);
        inputVo.setMembershipId(Long.parseLong(membershipId));
        inputVo.setMembershipNoteTimeStamp("2022-06-24-17.14.13.174834");
        inputVo.setMinorTraceId((short)0);
        inputVo.setNoteTypeCode("EPM");
        inputVo.setOnlineDate("2022-09-01");
        inputVo.setStartDate("2022-05-01");
        return inputVo;
    }

    private ProcessRequestActivityListInputVO createProcessRequestActivityInputVo(String membershipId) {
        ProcessRequestActivityListInputVO inputVo = new ProcessRequestActivityListInputVO();
        inputVo.setCenterCode("HQ");
        inputVo.setConsumerApplicationName("test");
        inputVo.setRacf("bfronk1");
        inputVo.setEndDate("2022-09-01");
        inputVo.setMajorTraceId((short)0);
        inputVo.setMaxNumberRequested((short)10);
        inputVo.setMembershipId(Long.parseLong(membershipId));
        inputVo.setMinorTraceId((short)0);
        inputVo.setOnlineDate("2022-09-01");
        inputVo.setStartDate("2008-05-01");
        inputVo.setProductProcessCode("CSP");
        return inputVo;
    }

    private MembershipDetailInputVO createMembershipInputVo(String membershipId) {
        MembershipDetailInputVO inputVo = new MembershipDetailInputVO();
        inputVo.setCenterCode("HQ");
        inputVo.setConsumerApplicationName("test");
        inputVo.setRacf("bfronk1");
        inputVo.setMajorTraceId((short)0);
        inputVo.setMembershipId(Long.parseLong(membershipId));
        inputVo.setMinorTraceId((short)0);
        inputVo.setOnlineDate("2022-09-01");
        return inputVo;
    }
}
