package com.discover.cmpp.action.itp.accountactivity.model;

import com.discover.cmpp.action.itp.accountactivity.ItpCsidAlertData;
import lombok.Data;

import java.util.List;

@Data
public class CsidReportingAlertsResponse {

    List<ItpCsidAlertData> accountAlertsList;
}
