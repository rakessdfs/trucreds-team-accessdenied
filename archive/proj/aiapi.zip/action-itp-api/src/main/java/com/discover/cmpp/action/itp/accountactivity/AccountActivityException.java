package com.discover.cmpp.action.itp.accountactivity;

public class AccountActivityException extends Exception {

    private static final long serialVersionUID = -7137924831698067983L;

    public AccountActivityException(String message) {
        super(message);
    }
}
