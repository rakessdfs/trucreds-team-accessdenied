package com.discover.cmpp.action.itp.accountactivity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AccountActivityRepository extends JpaRepository<AccountActivityEntity, Long> {

    /**
     * Fetch account activity by Product Enrollment Id.
     *
     * @param productEnrollmentId product enrollment id
     * @return {@link AccountActivityEntity}
     */
    List<AccountActivityEntity> findAllByProductEnrollmentIdOrderByRequestDateDesc(String productEnrollmentId);

    /**
     * Fetch account activity by  AccountActivityCodeEntity.
     *
     * @param activityCode AccountActivityCodeEntity
     * @return {@link AccountActivityEntity}
     */
    List<AccountActivityEntity> findAllByActivityCodeOrderByRequestDateDesc(AccountActivityCodeEntity activityCode);

    /**
     * Fetch account activity by AccountActivityCodeEntity within a specific date range.
     *
     * @param activityCode AccountActivityCodeEntity
     * @param startDate    LocalDateTime
     * @param endDate      LocalDateTime
     * @return {@link AccountActivityEntity}
     */
    List<AccountActivityEntity> findAllByActivityCodeAndRequestDateBetweenOrderByRequestDateDesc(
            AccountActivityCodeEntity activityCode, LocalDateTime startDate, LocalDateTime endDate);
}
