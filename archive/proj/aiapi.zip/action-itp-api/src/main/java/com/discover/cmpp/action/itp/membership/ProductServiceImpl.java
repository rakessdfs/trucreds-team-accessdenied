package com.discover.cmpp.action.itp.membership;

import com.discover.cmpp.action.itp.membership.model.EnrollmentLookupResponse;
import com.discover.cmpp.action.itp.membership.model.MembershipInfo;
import com.discover.cmpp.action.itp.membership.model.MembershipListRequest;
import com.discover.cmpp.action.itp.membership.model.MembershipListResponse;
import com.discover.cmpp.action.itp.membership.model.ProcessRequestResponse;
import com.discover.cmpp.action.itp.membership.model.ProcessRequestSearchCriteria;
import com.discover.cmpp.action.itp.membership.model.RequestReasonResponseEntity;
import com.discover.cmpp.action.itp.membership.model.RequestReasonSearchCriteria;
import com.discover.cmpp.action.itp.membership.model.billing.ReferralEntity;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class ProductServiceImpl implements ProductService {

    private ProductReferralClient productReferralClient;
    private ProductEnrollmentClient productEnrollmentClient;
    private MembershipAccessClient membershipAccessClient;

    public ProductServiceImpl(ProductReferralClient productReferralClient,
                              ProductEnrollmentClient productEnrollmentClient,
                              MembershipAccessClient membershipAccessClient) {
        this.productReferralClient = productReferralClient;
        this.productEnrollmentClient = productEnrollmentClient;
        this.membershipAccessClient = membershipAccessClient;
    }

    @Override
    @LogAround
    @LogExecutionTime
    /**
     * {@inheritDoc}
     */
    public ResponseEntity<ReferralEntity> getReferrals(Map<String, String> headerMap, String peId) {
        return productReferralClient.getReferrals(headerMap, peId);
    }

    @Override
    @LogAround
    @LogExecutionTime
    /**
     * {@inheritDoc}
     */
    public ResponseEntity<EnrollmentLookupResponse> getEnrollmentInfo(Map<String, String> headerMap, String peId) {
        return productEnrollmentClient.getEnrollmentInfo(headerMap, peId);
    }

    @Override
    @LogAround
    @LogExecutionTime
    /**
     * {@inheritDoc}
     */
    public ResponseEntity<List<ProcessRequestResponse>> fetchProcessRequests(Map<String, String> headerMap,
                        ProcessRequestSearchCriteria requestSearchCriteria) {
        return membershipAccessClient.fetchProcessRequests(headerMap, requestSearchCriteria);
    }

    @Override
    @LogAround
    @LogExecutionTime
    /**
     * {@inheritDoc}
     */
    public ResponseEntity<MembershipInfo> getMembershipByPartyId(Map<String, String> headerMap, String partyId,
                                                                 String productCode) {
        return membershipAccessClient.getMembershipByPartyId(headerMap, partyId, productCode);
    }

    @Override
    @LogAround
    @LogExecutionTime
    /**
     * {@inheritDoc}
     */
    public ResponseEntity<List<MembershipListResponse>> fetchMemberships(Map<String, String> headerMap,
                                                                         MembershipListRequest membershipListRequest) {
        return membershipAccessClient.fetchMemberships(headerMap, membershipListRequest);
    }

    @LogAround
    @LogExecutionTime
    @Override
    /**
     * {@inheritDoc}
     *
     */
    public ResponseEntity<EnrollmentLookupResponse> getPeid(Map<String, String> headerMap,
                                                            String subscriberNumber) {
        return productEnrollmentClient.getPeid(headerMap, subscriberNumber);
    }

    @LogAround
    @LogExecutionTime
    @Override
    /**
     * {@inheritDoc}
     *
     */
    public ResponseEntity<List<RequestReasonResponseEntity>> getRequestReasonCodes(Map<String, String> headerMap,
                        RequestReasonSearchCriteria requestReasonSearchCriteria) {
        return membershipAccessClient.fetchRequestReasonCodes(headerMap, requestReasonSearchCriteria);
    }
}
