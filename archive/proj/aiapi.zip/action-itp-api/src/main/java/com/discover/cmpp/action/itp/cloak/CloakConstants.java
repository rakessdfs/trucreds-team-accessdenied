package com.discover.cmpp.action.itp.cloak;

public class CloakConstants {

    private CloakConstants() {
    }

    public static final String CLOAK_INPUT_ELEMENT_TYPE = "string";
    public static final String CLOAK_INPUT_ELEMENT_NAME_SSN = "DE_SSN23";
    public static final String CLOAK_INPUT_ELEMENT_NAME_DOB = "DE_DOB23";
}
