package com.discover.cmpp.action.itp.accountactivity;

public class AccountActivityConstants {

    private AccountActivityConstants() {
    }

    // create account activity
    public static final String CREATE_ACTIVITY_URL = "/accountActivity";
    public static final String CREATE_ACTIVITY_API = "API to create new activity and store it in backend";
    public static final String CREATE_ACTIVITY_API_NOTES =
            "API accepts the request and creates new Activity in the backend DB " +
                    "for the requested Product Enrollment ID.";

    // create account activity code
    public static final String CREATE_ACCOUNT_ACTIVITY_CODE_URL = "/accountActivityCode";
    public static final String CREATE_ACCOUNT_ACTIVITY_CODE_API = "API to create new account activity code " +
            "and store it in backend";
    public static final String CREATE_ACCOUNT_ACTIVITY_CODE_API_NOTES =
            "API accepts the request and creates new account activity code in the backend DB.";

    //fetch account activity by product Enrollment Id
    public static final String FETCH_ACCOUNT_ACTIVITY_URL = "/accountActivity/{product-enrollment-id}";
    public static final String FETCH_ACCOUNT_ACTIVITY_API =
            "API to fetch account activity based on the product enrollment id";
    public static final String FETCH_ACCOUNT_ACTIVITY_API_NOTES =
            "API accepts the request and fetches account activity from DB to send to frontend";
    public static final String PRODUCT_ENROLLMENT_ID = "product-enrollment-id";

    //fetch account activity constants from cache/db
    public static final String FETCH_ACCOUNT_ACTIVITY_CODES_URL = "/accountActivity/fetchCodes";
    public static final String FETCH_ACCOUNT_ACTIVITY_CODES_API =
            "API to fetch account activity codes from cache/db";
    public static final String FETCH_ACCOUNT_ACTIVITY_CODES_API_NOTES =
            "API retrieves account activity code info from the cache/db. Can retrieve for a specific code, " +
                    "a specific category, or can return all info from ACCOUNT_ACTIVITY_CODE table if no parameters";
    public static final String ACTIVITY_CODE_CACHE_NAME = "activityCodeCache";

    // Publishes old account activity from the database to analytics
    public static final String OLD_ACTIVITY_TO_ANALYTICS_URL = "/accountActivity/publishToAnalytics";
    public static final String OLD_ACTIVITY_TO_ANALYTICS_API =
            "API to publish old account activity to analytics";
    public static final String OLD_ACTIVITY_TO_ANALYTICS_NOTES =
            "API fetches activity from the DB for the given code(s) and date range (or for all days if no " +
                    "dates provided) and publishes them to analytics";

    //fetch account alerts by product Subscriber Id
    public static final String FETCH_ACCOUNT_ALERTS_URL = "/accountActivity/alerts/{subscriber-number}";
    public static final String FETCH_ACCOUNT_ALERTS_API =
            "API to fetch account activity based on the product enrollment id";
    public static final String FETCH_ACCOUNT_ALERTS_API_NOTES =
            "API accepts the request and fetches account alerts from itp-csid-reporting-api to send to frontend";
    public static final String SUBSCRIBER_NUMBER = "subscriber-number";

    public static final String CREDIT_SUMMARY_FORM_CODE = "BTITPBACREDSUM";
    public static final String CREDIT_SUMMARY_ACTIVITY_DESC = "Monthly Credit Summary";
}
