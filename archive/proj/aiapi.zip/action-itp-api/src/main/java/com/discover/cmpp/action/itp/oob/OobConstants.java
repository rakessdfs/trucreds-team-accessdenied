package com.discover.cmpp.action.itp.oob;

public class OobConstants {

    private OobConstants() {
    }

    // OOB send code
    public static final String SEND_CODE_URL = "/sendCode";
    public static final String SEND_CODE_API = "API to trigger sending notification with code to customer";
    public static final String SEND_CODE_API_NOTES =
            "API accepts the request and sends OOB Soap Request for Product Enrollment ID.";
    public static final String CUST_USER_GROUP_CODE = "ITFB";
    public static final String FINANCIAL_AGREEMENT_NUMBER_VALUE = "FAN1234567";
    public static final String ACCOUNT_NUMBER_VALUE = "1234567890123456";

    // OOB get status
    public static final String GET_STATUS_URL = "/getStatus/{product-enrollment-id}";
    public static final String GET_STATUS_API = "API to fetch current status of the user";
    public static final String GET_STATUS_API_NOTES =
            "API accepts the request and sends OOB Soap Request for Product Enrollment ID";
    public static final String PRODUCT_ENROLLMENT_ID = "product-enrollment-id";
    public static final Integer SUCCESS = 0;
    public static final String NOT_ENROLLED = "Not Enrolled";

    public static final String OOB_SEND_CODE_REQUEST_FAILED = "OOB Send Code Request failed Code:";

    // OOB validate code
    public static final String VALIDATE_CODE_URL = "/validateCode";
    public static final String VALIDATE_CODE_API = "Endpoint to validate the code the customer was provided.";
    public static final String VALIDATE_CODE_API_NOTES =
            "API accepts the request and sends OOB Soap Request to validate code.";
    public static final String LOCKED_USER_STATUS_CODE = "LK";

    // OOB unlock user
    public static final String UNLOCK_USER_URL = "/unlockUser";
    public static final String UNLOCK_USER_API = "API to trigger unlock user";
    public static final String OOB_UNLOCK_USER_REQUEST_FAILED = "OOB Unlock User Request failed";

    // Fields for Morse and OOB
    public static final String TEMPLATE_FIELD_ACCOUNT_NUMBER = "AccountNumber";
    public static final String TEMPLATE_FIELD_FINANCIAL_AGREEMENT_NUMBER = "FinancialAgreementNumber";
    public static final String TEMPLATE_FIELD_NAME_ON_CARD = "NameOnCard";
    public static final String DESCRIPTION = " Description: ";
}
