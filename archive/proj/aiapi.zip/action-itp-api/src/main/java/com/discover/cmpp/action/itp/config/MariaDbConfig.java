package com.discover.cmpp.action.itp.config;

import javax.annotation.PreDestroy;

import ch.vorburger.mariadb4j.springframework.MariaDB4jSpringService;
import lombok.Getter;

@Getter
class MariaDbConfig {

    private MariaDB4jSpringService mariaDbSpringService;

    MariaDbConfig(String baseDir) {
        mariaDbSpringService = new MariaDB4jSpringService();
        mariaDbSpringService.setDefaultBaseDir(baseDir);
        mariaDbSpringService.setDefaultIsUnpackingFromClasspath(true);
        mariaDbSpringService.start();
    }

    @PreDestroy
    void destructor() {
        mariaDbSpringService.stop();
    }
}