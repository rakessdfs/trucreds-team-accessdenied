package com.discover.cmpp.action.itp.accountactivity.model;

import lombok.Data;

@Data
public class ActivityToAnalyticsResponse {

    private int databaseActivitiesCount;
    private int publishedActivitiesCount;
}
