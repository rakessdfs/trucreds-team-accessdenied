package com.discover.cmpp.action.itp.cancel;

import com.discover.cmpp.action.itp.cancel.model.CancelRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

@FeignClient(name = "cancelApi", url = "${cancelApi.service.baseUrl}")
public interface CancelClient {

    @PostMapping(value = "${cancelApi.service.cancelMembership}")
    ResponseEntity<Void> cancelMembership(@RequestHeader Map<String, String> headerMap,
                                          @RequestParam("identifierType") String identifierType,
                                          @RequestParam("identifier") Long identifier, CancelRequest request)
            throws CancelException;
}
