package com.discover.cmpp.action.itp.cancel;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.common.ActionItpException;
import com.discover.cmpp.action.itp.common.ErrorResponse;
import com.discover.cmpp.action.itp.common.validation.ValidationConstants;
import com.discover.cmpp.logging.LogAround;
import com.discover.cmpp.logging.LogExecutionTime;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotBlank;

@RequestMapping(value = "${api.context-path}")
@RestController
@Validated
public class CancelController {

    private CancelService cancelService;

    public CancelController(CancelService cancelService) {
        this.cancelService = cancelService;
    }

    @LogAround
    @LogExecutionTime
    @ApiOperation(value = CancelConstants.CANCEL_REQUEST_API,
            notes = CancelConstants.CANCEL_REQUEST_API_NOTES)
    @ApiResponses(value = {
            @ApiResponse(code = HttpServletResponse.SC_OK, message = ActionItpConstants.API_OK),
            @ApiResponse(code = HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    message = ActionItpConstants.API_INTERNAL_SERVER_ERROR, response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, message = ActionItpConstants.API_BAD_REQUEST,
                    response = ErrorResponse.class),
            @ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, message = ActionItpConstants.API_UNAUTHORITZED),
            @ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
                    message = ActionItpConstants.API_NOT_AUTHORITZED_ACCESS),
            @ApiResponse(code = HttpServletResponse.SC_NOT_FOUND, message = ActionItpConstants.API_NOT_FOUND)})
    @ApiImplicitParams({@ApiImplicitParam(name = ActionItpConstants.HTTP_AUTH_TOKEN,
            required = true,
            dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
            value = ActionItpConstants.JWT_V2_TOKEN),
            @ApiImplicitParam(name = ActionItpConstants.AGENT_ID, required = true,
                    dataType = ActionItpConstants.STRING, paramType = ActionItpConstants.HEADER,
                    value = ActionItpConstants.AGENT_ID_VALUE)})
    @PostMapping(value = CancelConstants.CANCEL_REQUEST_API_URL)
    public ResponseEntity<Object> customerCancelMembership(
            @RequestHeader(ActionItpConstants.AGENT_ID) @NotBlank(
                    message = ValidationConstants.AGENT_ID_INVALID_EC) String agentId,
            @RequestParam(value = CancelConstants.PRODUCT_ENROLLMENT_ID, required = true)
            @NotBlank(message = ValidationConstants.PEID_INVALID_EC) String peid,
            @RequestParam(value = CancelConstants.CANCEL_RSN_CDE, required = true)
            @NotBlank(message = ValidationConstants.CANCEL_REASON_CODE_EC)
                    String cancelReasonCode) throws CancelException, ActionItpException {
        cancelService.cancelRequest(agentId, peid, cancelReasonCode);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
