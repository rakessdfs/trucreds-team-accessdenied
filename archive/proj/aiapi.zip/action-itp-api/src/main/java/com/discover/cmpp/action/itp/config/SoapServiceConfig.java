package com.discover.cmpp.action.itp.config;

import com.discover.cmpp.action.itp.common.ActionItpConstants;
import com.discover.cmpp.action.itp.oob.SoapInterceptor;
import com.discover.internet.service.oob.ao.OOBServiceAOBean;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Profile("!test")
@Configuration
public class SoapServiceConfig {

    @Value(ActionItpConstants.OOB_SERVICE_CONNECT_TIMEOUT)
    private String oobServiceConnectTimeout;

    @Value(ActionItpConstants.OOB_SERVICE_RECEIVE_TIMEOUT)
    private String oobServiceReceiveTimeout;

    @Value(ActionItpConstants.OOB_SERVICE_URL)
    private String oobServiceUrl;

    private SoapInterceptor soapInterceptor;

    public SoapServiceConfig(SoapInterceptor soapInterceptor) {
        this.soapInterceptor = soapInterceptor;
    }

    @Bean
    @Qualifier("oobServiceAoBean")
    public OOBServiceAOBean oobServiceAoBean() {
        JaxWsProxyFactoryBean jaxWsProxyFactoryBean = getJaxWsProxyFactoryBean(OOBServiceAOBean.class, oobServiceUrl);
        jaxWsProxyFactoryBean.getOutInterceptors().add(soapInterceptor);
        OOBServiceAOBean oobServiceAoBean = (OOBServiceAOBean) jaxWsProxyFactoryBean.create();
        Client client = ClientProxy.getClient(oobServiceAoBean);
        setSoapTimeout(client, oobServiceConnectTimeout, oobServiceReceiveTimeout);
        return oobServiceAoBean;
    }

    private <T> JaxWsProxyFactoryBean getJaxWsProxyFactoryBean(Class<T> beanClass, String url) {
        JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
        jaxWsProxyFactoryBean.setServiceClass(beanClass);
        jaxWsProxyFactoryBean.setAddress(url);
        return jaxWsProxyFactoryBean;
    }

    private void setSoapTimeout(Client client, String connTimeout, String receiveTimeout) {
        try {
            HTTPConduit http = (HTTPConduit) client.getConduit();
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(Long.parseLong(connTimeout));
            httpClientPolicy.setReceiveTimeout(Long.parseLong(receiveTimeout));
            http.setClient(httpClientPolicy);
        } catch (NumberFormatException ne) {
            ne.getStackTrace();
        }
    }
}