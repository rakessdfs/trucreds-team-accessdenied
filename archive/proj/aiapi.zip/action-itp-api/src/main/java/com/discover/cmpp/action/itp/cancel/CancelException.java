package com.discover.cmpp.action.itp.cancel;

public class CancelException extends Exception {

    private static final long serialVersionUID = -7137924831698067982L;

    public CancelException(String message) {
        super(message);
    }
}
