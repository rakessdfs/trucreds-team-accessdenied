package com.discover.cmpp.action.itp.pearlServer;

import com.dfs.pearl.ao.GetProductNotesListResponse;
import com.dfs.pearl.ao.MembershipDetailOutputVO;
import com.dfs.pearl.ao.NotesListVO;
import com.dfs.pearl.ao.PearlServerException_Exception;
import com.dfs.pearl.ao.RequestActivityVO;

import java.util.List;

public interface PearlServerService {

    /**
     * Test getting memos from pearl server.
     *
     * @param membershipId id to search by.
     */
    List<NotesListVO> getPcmMemos(String membershipId) throws PearlServerException_Exception;

    /**
     * Test getting account activity from pearl server.
     *
     * @param membershipId id to search by.
     */
    List<RequestActivityVO> getPcmAccountActivity(String membershipId) throws PearlServerException_Exception;

    /**
     * Test getting account activity from pearl server.
     *
     * @param membershipId id to search by.
     */
    MembershipDetailOutputVO getMembershipDetail(String membershipId) throws PearlServerException_Exception;
}
