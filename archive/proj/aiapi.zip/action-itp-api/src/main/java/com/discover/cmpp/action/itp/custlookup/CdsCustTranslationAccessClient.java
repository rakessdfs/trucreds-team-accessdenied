package com.discover.cmpp.action.itp.custlookup;

import com.discover.cmpp.action.itp.custlookup.model.cdstranslation.CdsTranslationAlternateIdResponse;
import com.discover.cmpp.action.itp.custlookup.model.cdstranslation.CdsTranslationReqSrcCodeResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.List;
import java.util.Map;

@FeignClient(name = "CdsCustTranslationAccess", url = "${cdsTranslationalAccess.service.baseUrl}")
public interface CdsCustTranslationAccessClient {

    /**
     * Fetch Party ID by Alternate Party ID.
     *
     * @param headerMap        header map
     * @param alternatePartyId peid id
     * @return ResponseEntity list
     */
    @GetMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE,
            value = "${cdsTranslationalAccess.service.partyId}")
    ResponseEntity<List<CdsTranslationAlternateIdResponse>> getPartyId(
            @RequestHeader Map<String, String> headerMap,
            @PathVariable("alternatepartyid") String alternatePartyId);

    @GetMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE,
            value = "${cdsTranslationalAccess.service.reqSrcCode}")
    ResponseEntity<List<CdsTranslationReqSrcCodeResponse>> getIsItpUser(
            @RequestHeader Map<String, String> headerMap,
            @PathVariable("prtyId") String prtyId);
}
