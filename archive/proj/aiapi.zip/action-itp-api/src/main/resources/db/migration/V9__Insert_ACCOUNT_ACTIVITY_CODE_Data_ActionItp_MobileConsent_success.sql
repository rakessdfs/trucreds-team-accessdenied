INSERT INTO ACCOUNT_ACTIVITY_CODE (ACTIVITY_CODE,ACTIVITY_DESC,CATEGORY,CREATE_TS) VALUES('AMC', 'Customer accepted mobile consent.', 'Action ITP', current_time);
INSERT INTO ACCOUNT_ACTIVITY_CODE (ACTIVITY_CODE,ACTIVITY_DESC,CATEGORY,CREATE_TS) VALUES('DMC', 'Customer declined mobile consent.', 'Action ITP', current_time);
INSERT INTO ACCOUNT_ACTIVITY_CODE (ACTIVITY_CODE,ACTIVITY_DESC,CATEGORY,CREATE_TS) VALUES('CMC', 'Customer changed the mobile consent.', 'Action ITP', current_time);
INSERT INTO ACCOUNT_ACTIVITY_CODE (ACTIVITY_CODE,ACTIVITY_DESC,CATEGORY,CREATE_TS) VALUES('ELP', 'Customer requested language preference to be English.', 'Action ITP', current_time);
INSERT INTO ACCOUNT_ACTIVITY_CODE (ACTIVITY_CODE,ACTIVITY_DESC,CATEGORY,CREATE_TS) VALUES('SLP', 'Customer requested language preference to be Spanish.', 'Action ITP', current_time);
INSERT INTO ACCOUNT_ACTIVITY_CODE (ACTIVITY_CODE,ACTIVITY_DESC,CATEGORY,CREATE_TS) VALUES('CLP', 'Customer changed the language preference.', 'Action ITP', current_time);
