CREATE OR REPLACE TABLE MEMO
(
    MEMO_ID                     BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	PRODUCT_ENROLLMENT_ID       VARCHAR(255)                                NOT NULL,
	MEMO_TEXT                   VARCHAR(255)                                NOT NULL,
	CREATE_AGENT_ID             VARCHAR(255)                                NOT NULL,
	CREATE_TS                   DATETIME DEFAULT CURRENT_TIMESTAMP          NOT NULL,
	UPDATE_AGENT_ID             VARCHAR(255),
	UPDATE_TS                   DATETIME DEFAULT CURRENT_TIMESTAMP
)
    CHARACTER SET utf8
    COLLATE utf8_unicode_ci;
