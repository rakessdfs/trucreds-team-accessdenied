CREATE OR REPLACE TABLE ACCOUNT_ACTIVITY_CODE
(
    ACCOUNT_ACTIVITY_CODE_ID         BIGINT                                      NOT NULL AUTO_INCREMENT PRIMARY KEY,
	ACTIVITY_CODE                    VARCHAR(20)                                 NOT NULL UNIQUE,
	ACTIVITY_DESC                    VARCHAR(500)                                NOT NULL,
	CATEGORY                         VARCHAR(100)                                NOT NULL,
	CREATE_TS                        DATETIME DEFAULT CURRENT_TIMESTAMP          NOT NULL,
	UPDATE_TS                        DATETIME DEFAULT CURRENT_TIMESTAMP
)
    ENGINE InnoDB
    CHARACTER SET utf8
    COLLATE utf8_unicode_ci;