CREATE OR REPLACE TABLE LANGUAGE
(
    LANGUAGE_ID         BIGINT                                      NOT NULL AUTO_INCREMENT PRIMARY KEY,
	LANGUAGE_CODE                    VARCHAR(10)                                 NOT NULL UNIQUE,
	LANGUAGE_DESC                    VARCHAR(255),
	CREATE_TS                        DATETIME DEFAULT CURRENT_TIMESTAMP,
	CREATE_BY						 VARCHAR(255),
	UPDATE_TS                        DATETIME DEFAULT CURRENT_TIMESTAMP,
	UPDATE_BY						 VARCHAR(255)
)
    ENGINE InnoDB
    CHARACTER SET utf8
    COLLATE utf8_unicode_ci;
