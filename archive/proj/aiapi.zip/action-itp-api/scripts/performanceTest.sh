#!/usr/bin/env bash
echo "Inside performanceTest.sh. executing Performance Tests"

ls -al

cd performance-testing
sh run_load_test.sh

cd ../chaos-testing
sh run_chaos_test.sh

pwd
ls -al build/reports/gatling
