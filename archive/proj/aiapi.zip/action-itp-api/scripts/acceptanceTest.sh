#!/usr/bin/env bash
echo "Inside acceptanceTest.sh. executing Acceptance Tests"

./gradlew acceptanceTest