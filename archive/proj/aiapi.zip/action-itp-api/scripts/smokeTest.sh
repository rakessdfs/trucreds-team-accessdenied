#!/usr/bin/env bash
echo "Inside smokeTest.sh. executing Smoke Tests"

if [ -z ${CUSTOM_AUTH_HEADER} ] || [ ${CUSTOM_AUTH_HEADER} == "N/A" ]; then
  echo "CUSTOM_AUTH_HEADER is unset. Fetching token...";
  CUSTOM_AUTH_HEADER=$(curl -X POST -k -u ********:******** https://internalapicallalter-development.cf-ssb-z3-dev.discoverfinancial.com/dfs/internal/jtpapi/v2/apikey/l7fb3b832840d54fcd8e522d51dfbfc778/token)
  sleep 10
  else echo "CUSTOM_AUTH_HEADER is set. Using provided token...";
fi

./gradlew smokeTest -DbaseUrl="${APP_BASE_URL}" -DhttpAuthToken="${CUSTOM_AUTH_HEADER}"
