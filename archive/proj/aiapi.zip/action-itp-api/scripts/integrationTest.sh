#!/usr/bin/env bash
echo "Inside integrationTest.sh. executing Integration Tests"

./gradlew integrationTest