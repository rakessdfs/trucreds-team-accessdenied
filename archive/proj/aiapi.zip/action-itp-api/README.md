# action-itp-api
This is the backend api for Action ITP and Action Servicing (ITP features) Applications

## Application Wiki Page 
https://github.discoverfinancial.com/cad-cmpp-org/action-itp-api/wiki

## Prerequisites / Require Access / IDMs
Developers need to have access to thr ldap group in PA to access ITP servicing

## Running Locally

### Set local vm arguments
https://github.discoverfinancial.com/cad-cmpp-org/action-itp-api/wiki/local-vm-args

### Set Application Profile
Set the active profile to `local`

### MariaDB (for Mac)<br>
#### Local setup:
https://github.discoverfinancial.com/cad-cmpp-org/action-itp-api/wiki/Local-setup-for-Mariadb4j
#### More information can be found in cookbook:
https://enterpriseprograms-modernization-cookbook.cf-ssb-z3-dev.discoverfinancial.com/recipes/database/mariadb4j-setup/

### Local Keystore and Certificate Setup
Follow directions in cookbook: https://enterpriseprograms-modernization-cookbook.cf-ssb-z3-dev.discoverfinancial.com/recipes/onboarding/laptop-setup/

### Building

```shell
# Build from Intellij gradle window, click on Task->build->build
OR
# Build from terminal/command line:
./gradlew clean build --refresh-dependencies

# Start Application from Intellij:
1. In Intellij, add new SpringBoot config in Run/Debug Configurations with Main Class: com.discover.cmpp.action.itp.ActionItpApplication
2. Set local VM arguments in Environment VM options
3. Click OK
4. Run new configuration

OR
# Stat application from terminal/command line
./gradlew bootRun --args="--javax.net.ssl.keyStore="/Users/rgrove3/Documents/ctbkeys.jks" --javax.net.ssl.keyStorePassword="letmein" 
--javax.net.ssl.trustStore="/Library/Java/JavaVirtualMachines/jdk1.8.0_261.jdk/Contents/Home/jre/lib/security/cacerts" 
--jwt_client_environment="DEV" --jwt_client_requireDynamicallyUpdate="false" 
 --jwt_client_gatewayConnectionTimeout="1000" 
--jwt_client_gatewayResponseTimeout="5000" 
--jwt_client_cacheOffsetOfExpTime="86400" 
--jwt_client_tokenTimeToLive="129600" 
--jwt_client_continueWithTimeoutCachedToken="true" 
--jwt_client_issuer="apisdev.discoverfinancial.com" 
--jwt_client_apiKey="l7a477b9096088428f853e79e7e322eff5" 
--jwt_client_requireGatewayAuthentication="true" 
--jwt_client_tokenEndpointURL="https://intapistest.discoverfinancial.com/dfs/auth/jwt/v2/token" 
--jwt_client_timerInterval="7" 
--jwt_client_timerIntervalUnit="DAYS" 
--jwt_client_timerShutdownWaitTime="2000" --jwt_client_gatewayResponseTimeout="5000" 
--jwt_client_apiSecret="EiFqyewdM4A/7hgPJe04K2i3nVkS36Y8pVF+av24WTYAA98JxDZ3FVm4mQ8Z4rEN" 
--jwt_client_consumerAppCertificate="6kAEyFHJMGIu7P1Q7KpFAFWfpZkuKhXjYhY6JDXRqWH3dI2+RxqQrMl7dChBCnQ9ZMuzYXF+eu3/5OtwTzJ5Mg==" 
--action-itp-api.jwt.secret="action-itp-api-jwt.super.secret.string.flowers" 
--spring.profiles.active=local 
--ssl.keystore.password=changeit"
```
### Swagger for localhost:
http://localhost:8080/swagger-ui.html#

