
package com.discover.internet.service.oob.vo;

import java.io.Serializable;
import javax.annotation.Generated;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getUserHistoryInputVO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getUserHistoryInputVO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://vo.oob.service.internet.discover.com/}inputVO"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="retrieveVoiceHistory" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="retrieveSMSHistory" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="retrieveEmailHistory" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getUserHistoryInputVO", propOrder = {
    "retrieveVoiceHistory",
    "retrieveSMSHistory",
    "retrieveEmailHistory"
})
@Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
public class GetUserHistoryInputVO
    extends InputVO
    implements Serializable
{

    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    protected boolean retrieveVoiceHistory;
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    protected boolean retrieveSMSHistory;
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    protected boolean retrieveEmailHistory;

    /**
     * Gets the value of the retrieveVoiceHistory property.
     * 
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public boolean isRetrieveVoiceHistory() {
        return retrieveVoiceHistory;
    }

    /**
     * Sets the value of the retrieveVoiceHistory property.
     * 
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public void setRetrieveVoiceHistory(boolean value) {
        this.retrieveVoiceHistory = value;
    }

    /**
     * Gets the value of the retrieveSMSHistory property.
     * 
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public boolean isRetrieveSMSHistory() {
        return retrieveSMSHistory;
    }

    /**
     * Sets the value of the retrieveSMSHistory property.
     * 
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public void setRetrieveSMSHistory(boolean value) {
        this.retrieveSMSHistory = value;
    }

    /**
     * Gets the value of the retrieveEmailHistory property.
     * 
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public boolean isRetrieveEmailHistory() {
        return retrieveEmailHistory;
    }

    /**
     * Sets the value of the retrieveEmailHistory property.
     * 
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public void setRetrieveEmailHistory(boolean value) {
        this.retrieveEmailHistory = value;
    }

}
