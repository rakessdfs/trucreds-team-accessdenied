@javax.xml.bind.annotation.XmlSchema(namespace = "http://vo.oob.service.internet.discover.com/")
package com.discover.internet.service.oob.vo;
