
package com.discover.internet.service.oob.vo;

import java.io.Serializable;
import javax.annotation.Generated;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for userVO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="userVO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="failedSubmissionCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="generationCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="lastSubmissionFailureDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="lastSubmissionSuccessDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="remainingGenerationCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="remainingSubmissionCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="userStatusCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="userStatusCodeDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "userVO", propOrder = {
    "failedSubmissionCount",
    "generationCount",
    "lastSubmissionFailureDate",
    "lastSubmissionSuccessDate",
    "remainingGenerationCount",
    "remainingSubmissionCount",
    "userStatusCode",
    "userStatusCodeDesc"
})
@Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
public class UserVO
    implements Serializable
{

    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    protected int failedSubmissionCount;
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    protected int generationCount;
    @XmlSchemaType(name = "dateTime")
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    protected XMLGregorianCalendar lastSubmissionFailureDate;
    @XmlSchemaType(name = "dateTime")
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    protected XMLGregorianCalendar lastSubmissionSuccessDate;
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    protected int remainingGenerationCount;
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    protected int remainingSubmissionCount;
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    protected String userStatusCode;
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    protected String userStatusCodeDesc;

    /**
     * Gets the value of the failedSubmissionCount property.
     * 
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public int getFailedSubmissionCount() {
        return failedSubmissionCount;
    }

    /**
     * Sets the value of the failedSubmissionCount property.
     * 
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public void setFailedSubmissionCount(int value) {
        this.failedSubmissionCount = value;
    }

    /**
     * Gets the value of the generationCount property.
     * 
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public int getGenerationCount() {
        return generationCount;
    }

    /**
     * Sets the value of the generationCount property.
     * 
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public void setGenerationCount(int value) {
        this.generationCount = value;
    }

    /**
     * Gets the value of the lastSubmissionFailureDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public XMLGregorianCalendar getLastSubmissionFailureDate() {
        return lastSubmissionFailureDate;
    }

    /**
     * Sets the value of the lastSubmissionFailureDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public void setLastSubmissionFailureDate(XMLGregorianCalendar value) {
        this.lastSubmissionFailureDate = value;
    }

    /**
     * Gets the value of the lastSubmissionSuccessDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public XMLGregorianCalendar getLastSubmissionSuccessDate() {
        return lastSubmissionSuccessDate;
    }

    /**
     * Sets the value of the lastSubmissionSuccessDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public void setLastSubmissionSuccessDate(XMLGregorianCalendar value) {
        this.lastSubmissionSuccessDate = value;
    }

    /**
     * Gets the value of the remainingGenerationCount property.
     * 
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public int getRemainingGenerationCount() {
        return remainingGenerationCount;
    }

    /**
     * Sets the value of the remainingGenerationCount property.
     * 
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public void setRemainingGenerationCount(int value) {
        this.remainingGenerationCount = value;
    }

    /**
     * Gets the value of the remainingSubmissionCount property.
     * 
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public int getRemainingSubmissionCount() {
        return remainingSubmissionCount;
    }

    /**
     * Sets the value of the remainingSubmissionCount property.
     * 
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public void setRemainingSubmissionCount(int value) {
        this.remainingSubmissionCount = value;
    }

    /**
     * Gets the value of the userStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public String getUserStatusCode() {
        return userStatusCode;
    }

    /**
     * Sets the value of the userStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public void setUserStatusCode(String value) {
        this.userStatusCode = value;
    }

    /**
     * Gets the value of the userStatusCodeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public String getUserStatusCodeDesc() {
        return userStatusCodeDesc;
    }

    /**
     * Sets the value of the userStatusCodeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public void setUserStatusCodeDesc(String value) {
        this.userStatusCodeDesc = value;
    }

}
