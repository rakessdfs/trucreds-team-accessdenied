
package com.discover.internet.service.oob.vo;

import javax.annotation.Generated;
import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.discover.internet.service.oob.vo package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
@Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.discover.internet.service.oob.vo
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link UserCancelInputVO }
     * 
     */
    public UserCancelInputVO createUserCancelInputVO() {
        return new UserCancelInputVO();
    }

    /**
     * Create an instance of {@link InputVO }
     * 
     */
    public InputVO createInputVO() {
        return new InputVO();
    }

    /**
     * Create an instance of {@link UserCancelOutputVO }
     * 
     */
    public UserCancelOutputVO createUserCancelOutputVO() {
        return new UserCancelOutputVO();
    }

    /**
     * Create an instance of {@link ReturnStatusVO }
     * 
     */
    public ReturnStatusVO createReturnStatusVO() {
        return new ReturnStatusVO();
    }

    /**
     * Create an instance of {@link SendCodeInputVO }
     * 
     */
    public SendCodeInputVO createSendCodeInputVO() {
        return new SendCodeInputVO();
    }

    /**
     * Create an instance of {@link SupplementalField }
     * 
     */
    public SupplementalField createSupplementalField() {
        return new SupplementalField();
    }

    /**
     * Create an instance of {@link SendCodeOutputVO }
     * 
     */
    public SendCodeOutputVO createSendCodeOutputVO() {
        return new SendCodeOutputVO();
    }

    /**
     * Create an instance of {@link UserVO }
     * 
     */
    public UserVO createUserVO() {
        return new UserVO();
    }

    /**
     * Create an instance of {@link GetUserHistoryInputVO }
     * 
     */
    public GetUserHistoryInputVO createGetUserHistoryInputVO() {
        return new GetUserHistoryInputVO();
    }

    /**
     * Create an instance of {@link GetUserHistoryOutputVO }
     * 
     */
    public GetUserHistoryOutputVO createGetUserHistoryOutputVO() {
        return new GetUserHistoryOutputVO();
    }

    /**
     * Create an instance of {@link SentCodeVO }
     * 
     */
    public SentCodeVO createSentCodeVO() {
        return new SentCodeVO();
    }

    /**
     * Create an instance of {@link ValidateCodeInputVO }
     * 
     */
    public ValidateCodeInputVO createValidateCodeInputVO() {
        return new ValidateCodeInputVO();
    }

    /**
     * Create an instance of {@link ValidateCodeOutputVO }
     * 
     */
    public ValidateCodeOutputVO createValidateCodeOutputVO() {
        return new ValidateCodeOutputVO();
    }

    /**
     * Create an instance of {@link UnlockUserInputVO }
     * 
     */
    public UnlockUserInputVO createUnlockUserInputVO() {
        return new UnlockUserInputVO();
    }

    /**
     * Create an instance of {@link UnlockUserOutputVO }
     * 
     */
    public UnlockUserOutputVO createUnlockUserOutputVO() {
        return new UnlockUserOutputVO();
    }

    /**
     * Create an instance of {@link HeartBeatInputVO }
     * 
     */
    public HeartBeatInputVO createHeartBeatInputVO() {
        return new HeartBeatInputVO();
    }

    /**
     * Create an instance of {@link HeartBeatOutputVO }
     * 
     */
    public HeartBeatOutputVO createHeartBeatOutputVO() {
        return new HeartBeatOutputVO();
    }

    /**
     * Create an instance of {@link SetImpressionInputVO }
     * 
     */
    public SetImpressionInputVO createSetImpressionInputVO() {
        return new SetImpressionInputVO();
    }

    /**
     * Create an instance of {@link SetImpressionOutputVO }
     * 
     */
    public SetImpressionOutputVO createSetImpressionOutputVO() {
        return new SetImpressionOutputVO();
    }

    /**
     * Create an instance of {@link GetStatusInputVO }
     * 
     */
    public GetStatusInputVO createGetStatusInputVO() {
        return new GetStatusInputVO();
    }

    /**
     * Create an instance of {@link GetStatusOutputVO }
     * 
     */
    public GetStatusOutputVO createGetStatusOutputVO() {
        return new GetStatusOutputVO();
    }

}
