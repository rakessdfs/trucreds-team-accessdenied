
package com.discover.internet.service.oob.vo;

import java.io.Serializable;
import javax.annotation.Generated;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for userCancelOutputVO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="userCancelOutputVO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="returnStatus" type="{http://vo.oob.service.internet.discover.com/}returnStatusVO" minOccurs="0"/&gt;
 *         &lt;element name="userStatusCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="userStatusCodeDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "userCancelOutputVO", propOrder = {
    "returnStatus",
    "userStatusCode",
    "userStatusCodeDesc"
})
@Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
public class UserCancelOutputVO
    implements Serializable
{

    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    protected ReturnStatusVO returnStatus;
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    protected String userStatusCode;
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    protected String userStatusCodeDesc;

    /**
     * Gets the value of the returnStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ReturnStatusVO }
     *     
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public ReturnStatusVO getReturnStatus() {
        return returnStatus;
    }

    /**
     * Sets the value of the returnStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReturnStatusVO }
     *     
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public void setReturnStatus(ReturnStatusVO value) {
        this.returnStatus = value;
    }

    /**
     * Gets the value of the userStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public String getUserStatusCode() {
        return userStatusCode;
    }

    /**
     * Sets the value of the userStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public void setUserStatusCode(String value) {
        this.userStatusCode = value;
    }

    /**
     * Gets the value of the userStatusCodeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public String getUserStatusCodeDesc() {
        return userStatusCodeDesc;
    }

    /**
     * Sets the value of the userStatusCodeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    @Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
    public void setUserStatusCodeDesc(String value) {
        this.userStatusCodeDesc = value;
    }

}
