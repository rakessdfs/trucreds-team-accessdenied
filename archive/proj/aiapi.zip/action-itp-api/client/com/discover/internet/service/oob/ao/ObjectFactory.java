
package com.discover.internet.service.oob.ao;

import javax.annotation.Generated;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.discover.internet.service.oob.ao package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
@Generated(value = "com.sun.tools.xjc.Driver", comments = "JAXB RI v2.3.5", date = "2022-05-31T16:12:29-05:00")
public class ObjectFactory {

    private final static QName _OOBServiceException_QNAME = new QName("http://ao.oob.service.internet.discover.com/", "OOBServiceException");
    private final static QName _GetStatus_QNAME = new QName("http://ao.oob.service.internet.discover.com/", "getStatus");
    private final static QName _GetStatusResponse_QNAME = new QName("http://ao.oob.service.internet.discover.com/", "getStatusResponse");
    private final static QName _GetUserHistory_QNAME = new QName("http://ao.oob.service.internet.discover.com/", "getUserHistory");
    private final static QName _GetUserHistoryResponse_QNAME = new QName("http://ao.oob.service.internet.discover.com/", "getUserHistoryResponse");
    private final static QName _HeartBeat_QNAME = new QName("http://ao.oob.service.internet.discover.com/", "heartBeat");
    private final static QName _HeartBeatResponse_QNAME = new QName("http://ao.oob.service.internet.discover.com/", "heartBeatResponse");
    private final static QName _SendCode_QNAME = new QName("http://ao.oob.service.internet.discover.com/", "sendCode");
    private final static QName _SendCodeResponse_QNAME = new QName("http://ao.oob.service.internet.discover.com/", "sendCodeResponse");
    private final static QName _SetImpression_QNAME = new QName("http://ao.oob.service.internet.discover.com/", "setImpression");
    private final static QName _SetImpressionResponse_QNAME = new QName("http://ao.oob.service.internet.discover.com/", "setImpressionResponse");
    private final static QName _UnlockUser_QNAME = new QName("http://ao.oob.service.internet.discover.com/", "unlockUser");
    private final static QName _UnlockUserResponse_QNAME = new QName("http://ao.oob.service.internet.discover.com/", "unlockUserResponse");
    private final static QName _UserCancel_QNAME = new QName("http://ao.oob.service.internet.discover.com/", "userCancel");
    private final static QName _UserCancelResponse_QNAME = new QName("http://ao.oob.service.internet.discover.com/", "userCancelResponse");
    private final static QName _ValidateCode_QNAME = new QName("http://ao.oob.service.internet.discover.com/", "validateCode");
    private final static QName _ValidateCodeResponse_QNAME = new QName("http://ao.oob.service.internet.discover.com/", "validateCodeResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.discover.internet.service.oob.ao
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link OOBServiceException }
     * 
     */
    public OOBServiceException createOOBServiceException() {
        return new OOBServiceException();
    }

    /**
     * Create an instance of {@link GetStatus }
     * 
     */
    public GetStatus createGetStatus() {
        return new GetStatus();
    }

    /**
     * Create an instance of {@link GetStatusResponse }
     * 
     */
    public GetStatusResponse createGetStatusResponse() {
        return new GetStatusResponse();
    }

    /**
     * Create an instance of {@link GetUserHistory }
     * 
     */
    public GetUserHistory createGetUserHistory() {
        return new GetUserHistory();
    }

    /**
     * Create an instance of {@link GetUserHistoryResponse }
     * 
     */
    public GetUserHistoryResponse createGetUserHistoryResponse() {
        return new GetUserHistoryResponse();
    }

    /**
     * Create an instance of {@link HeartBeat }
     * 
     */
    public HeartBeat createHeartBeat() {
        return new HeartBeat();
    }

    /**
     * Create an instance of {@link HeartBeatResponse }
     * 
     */
    public HeartBeatResponse createHeartBeatResponse() {
        return new HeartBeatResponse();
    }

    /**
     * Create an instance of {@link SendCode }
     * 
     */
    public SendCode createSendCode() {
        return new SendCode();
    }

    /**
     * Create an instance of {@link SendCodeResponse }
     * 
     */
    public SendCodeResponse createSendCodeResponse() {
        return new SendCodeResponse();
    }

    /**
     * Create an instance of {@link SetImpression }
     * 
     */
    public SetImpression createSetImpression() {
        return new SetImpression();
    }

    /**
     * Create an instance of {@link SetImpressionResponse }
     * 
     */
    public SetImpressionResponse createSetImpressionResponse() {
        return new SetImpressionResponse();
    }

    /**
     * Create an instance of {@link UnlockUser }
     * 
     */
    public UnlockUser createUnlockUser() {
        return new UnlockUser();
    }

    /**
     * Create an instance of {@link UnlockUserResponse }
     * 
     */
    public UnlockUserResponse createUnlockUserResponse() {
        return new UnlockUserResponse();
    }

    /**
     * Create an instance of {@link UserCancel }
     * 
     */
    public UserCancel createUserCancel() {
        return new UserCancel();
    }

    /**
     * Create an instance of {@link UserCancelResponse }
     * 
     */
    public UserCancelResponse createUserCancelResponse() {
        return new UserCancelResponse();
    }

    /**
     * Create an instance of {@link ValidateCode }
     * 
     */
    public ValidateCode createValidateCode() {
        return new ValidateCode();
    }

    /**
     * Create an instance of {@link ValidateCodeResponse }
     * 
     */
    public ValidateCodeResponse createValidateCodeResponse() {
        return new ValidateCodeResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OOBServiceException }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link OOBServiceException }{@code >}
     */
    @XmlElementDecl(namespace = "http://ao.oob.service.internet.discover.com/", name = "OOBServiceException")
    public JAXBElement<OOBServiceException> createOOBServiceException(OOBServiceException value) {
        return new JAXBElement<OOBServiceException>(_OOBServiceException_QNAME, OOBServiceException.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStatus }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetStatus }{@code >}
     */
    @XmlElementDecl(namespace = "http://ao.oob.service.internet.discover.com/", name = "getStatus")
    public JAXBElement<GetStatus> createGetStatus(GetStatus value) {
        return new JAXBElement<GetStatus>(_GetStatus_QNAME, GetStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStatusResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetStatusResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://ao.oob.service.internet.discover.com/", name = "getStatusResponse")
    public JAXBElement<GetStatusResponse> createGetStatusResponse(GetStatusResponse value) {
        return new JAXBElement<GetStatusResponse>(_GetStatusResponse_QNAME, GetStatusResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetUserHistory }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetUserHistory }{@code >}
     */
    @XmlElementDecl(namespace = "http://ao.oob.service.internet.discover.com/", name = "getUserHistory")
    public JAXBElement<GetUserHistory> createGetUserHistory(GetUserHistory value) {
        return new JAXBElement<GetUserHistory>(_GetUserHistory_QNAME, GetUserHistory.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetUserHistoryResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetUserHistoryResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://ao.oob.service.internet.discover.com/", name = "getUserHistoryResponse")
    public JAXBElement<GetUserHistoryResponse> createGetUserHistoryResponse(GetUserHistoryResponse value) {
        return new JAXBElement<GetUserHistoryResponse>(_GetUserHistoryResponse_QNAME, GetUserHistoryResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link HeartBeat }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link HeartBeat }{@code >}
     */
    @XmlElementDecl(namespace = "http://ao.oob.service.internet.discover.com/", name = "heartBeat")
    public JAXBElement<HeartBeat> createHeartBeat(HeartBeat value) {
        return new JAXBElement<HeartBeat>(_HeartBeat_QNAME, HeartBeat.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link HeartBeatResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link HeartBeatResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://ao.oob.service.internet.discover.com/", name = "heartBeatResponse")
    public JAXBElement<HeartBeatResponse> createHeartBeatResponse(HeartBeatResponse value) {
        return new JAXBElement<HeartBeatResponse>(_HeartBeatResponse_QNAME, HeartBeatResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SendCode }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SendCode }{@code >}
     */
    @XmlElementDecl(namespace = "http://ao.oob.service.internet.discover.com/", name = "sendCode")
    public JAXBElement<SendCode> createSendCode(SendCode value) {
        return new JAXBElement<SendCode>(_SendCode_QNAME, SendCode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SendCodeResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SendCodeResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://ao.oob.service.internet.discover.com/", name = "sendCodeResponse")
    public JAXBElement<SendCodeResponse> createSendCodeResponse(SendCodeResponse value) {
        return new JAXBElement<SendCodeResponse>(_SendCodeResponse_QNAME, SendCodeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetImpression }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetImpression }{@code >}
     */
    @XmlElementDecl(namespace = "http://ao.oob.service.internet.discover.com/", name = "setImpression")
    public JAXBElement<SetImpression> createSetImpression(SetImpression value) {
        return new JAXBElement<SetImpression>(_SetImpression_QNAME, SetImpression.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetImpressionResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetImpressionResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://ao.oob.service.internet.discover.com/", name = "setImpressionResponse")
    public JAXBElement<SetImpressionResponse> createSetImpressionResponse(SetImpressionResponse value) {
        return new JAXBElement<SetImpressionResponse>(_SetImpressionResponse_QNAME, SetImpressionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UnlockUser }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UnlockUser }{@code >}
     */
    @XmlElementDecl(namespace = "http://ao.oob.service.internet.discover.com/", name = "unlockUser")
    public JAXBElement<UnlockUser> createUnlockUser(UnlockUser value) {
        return new JAXBElement<UnlockUser>(_UnlockUser_QNAME, UnlockUser.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UnlockUserResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UnlockUserResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://ao.oob.service.internet.discover.com/", name = "unlockUserResponse")
    public JAXBElement<UnlockUserResponse> createUnlockUserResponse(UnlockUserResponse value) {
        return new JAXBElement<UnlockUserResponse>(_UnlockUserResponse_QNAME, UnlockUserResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserCancel }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UserCancel }{@code >}
     */
    @XmlElementDecl(namespace = "http://ao.oob.service.internet.discover.com/", name = "userCancel")
    public JAXBElement<UserCancel> createUserCancel(UserCancel value) {
        return new JAXBElement<UserCancel>(_UserCancel_QNAME, UserCancel.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserCancelResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UserCancelResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://ao.oob.service.internet.discover.com/", name = "userCancelResponse")
    public JAXBElement<UserCancelResponse> createUserCancelResponse(UserCancelResponse value) {
        return new JAXBElement<UserCancelResponse>(_UserCancelResponse_QNAME, UserCancelResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ValidateCode }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ValidateCode }{@code >}
     */
    @XmlElementDecl(namespace = "http://ao.oob.service.internet.discover.com/", name = "validateCode")
    public JAXBElement<ValidateCode> createValidateCode(ValidateCode value) {
        return new JAXBElement<ValidateCode>(_ValidateCode_QNAME, ValidateCode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ValidateCodeResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ValidateCodeResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://ao.oob.service.internet.discover.com/", name = "validateCodeResponse")
    public JAXBElement<ValidateCodeResponse> createValidateCodeResponse(ValidateCodeResponse value) {
        return new JAXBElement<ValidateCodeResponse>(_ValidateCodeResponse_QNAME, ValidateCodeResponse.class, null, value);
    }

}
