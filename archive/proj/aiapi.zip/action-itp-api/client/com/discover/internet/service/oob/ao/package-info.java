@javax.xml.bind.annotation.XmlSchema(namespace = "http://ao.oob.service.internet.discover.com/")
package com.discover.internet.service.oob.ao;
