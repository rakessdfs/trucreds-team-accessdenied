#!/usr/bin/env bash

mkdir tmp-chaos-test
TMPDIR="$(pwd)/tmp-chaos-test"
export TMPDIR
#
export GRADLE_OPTS="-Djava.io.tmpdir=$TMPDIR"

../gradlew clean gatlingRun -DactionITPUrl="${APP_BASE_URL}"
#../gradlew clean gatlingRun -DactionITPUrl="http://localhost:8080"
#../gradlew clean gatlingRun -DactionITPUrl="https://action-itp-api-load-test.cf-ssb-z3-dev.discoverfinancial.com" --warning-mode all
