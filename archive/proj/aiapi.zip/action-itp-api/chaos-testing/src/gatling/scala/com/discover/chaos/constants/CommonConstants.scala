package com.discover.chaos.constants

import com.discover.chaos.assaultprofile.{ExceptionAssaultProfile, KillApplicationAssaultProfile, LatencyAssaultProfile, MemoryAssaultProfile}
import io.gatling.core.Predef._
import io.gatling.http.Predef.{http}
import io.gatling.http.protocol.HttpProtocolBuilder

import scala.concurrent.duration.{FiniteDuration, _}
import scala.util.Properties

object CommonConstants {

  def totalSubmissions = 30
  def duration: FiniteDuration = 100 seconds
  def itpUrl: String = Properties.propOrElse(
    "actionITPUrl",
    "http://localhost:9001")

  def headers = Map(
    "HTTP_AUTH_TOKEN" -> "893842924",
    "X-DFSUSER-USER-ID" -> "testuser",
    "Content-Type" -> "application/json"
  )

  def httpProtocol: HttpProtocolBuilder = http
    .baseUrl(itpUrl + "/enterprise/products/action/itp/v1").disableWarmUp

  def actuatorUrl = itpUrl + "/actuator/chaosmonkey"
  def latencyAssaultProfile = new LatencyAssaultProfile(actuatorUrl)
  def exceptionAssaultProfile = new ExceptionAssaultProfile(actuatorUrl)
  def killApplicationAssaultProfile = new KillApplicationAssaultProfile(actuatorUrl)
  def memoryAssaultProfile = new MemoryAssaultProfile(actuatorUrl)
  def assaultProfileWatcherPayload: String =
    "{\n  \"controller\": true,\n  \"restController\": true,\n  \"service\": false,\n  \"repository\": false,\n  \"component\": false\n}"
  def unapplyAssaultProfileWatcherPayload: String =
    "{\n  \"controller\": false,\n  \"restController\": false,\n  \"service\": false,\n  \"repository\": false,\n  \"component\": false\n}"
  def unapplyAssaultProfileAssaultPayload: String =
    "{\n  \"level\": 10,\n  \"latencyRangeStart\": 10000,\n  \"latencyRangeEnd\": 10000,\n  \"latencyActive\": false,\n  \"exceptionsActive\": false,\n  \"killApplicationActive\": false,\n  \"memoryActive\": false,\n  \"runtimeAssaultCronExpression\": \"OFF\"\n}"
}
