package com.discover.chaos.constants

import com.discover.chaos.constants.CommonConstants.headers
import io.gatling.core.Predef.{StringBody, scenario, _}
import io.gatling.core.structure.ScenarioBuilder
import io.gatling.http.Predef.{http, status, _}

object AccountActivityConstants {
  def createActivityRequest(productEnrollmentId: String): String = {
    "{\n" +
      "  \"productEnrollmentId\": \"" + productEnrollmentId + "\",\n" +
      "  \"activityCode\": \"EUR\",\n" +
      "  \"newData\": \"foo@bar.com\",\n" +
      "  \"previousData\": \"test\",\n" +
      "  \"operator\": \"test\",\n" +
      "  \"requestDate\": \"" + "2021-02-16 20:34:59" + "\"\n" +
      "}"
  }

  val productEnrollmentId: String = "457821487"

  def getAccountActivity(name: String): ScenarioBuilder = scenario("GetActivity")
    .exec(http(name)
      .get("/accountActivity/" + productEnrollmentId)
      .headers(headers)
      .check(status.is(200)))

  def postAccountActivity(name: String): ScenarioBuilder = scenario("CreateActivity")
    .exec(http(name)
      .post("/accountActivity")
      .body(StringBody(createActivityRequest(productEnrollmentId)))
      .headers(headers)
      .check(status.is(201)))

}
