package com.discover.chaos.simulations

import com.discover.chaos.constants.AccountActivityConstants._
import com.discover.chaos.constants.CallConstants.postRecordCall
import com.discover.chaos.constants.CancelConstants.postCancelCall
import com.discover.chaos.constants.CommonConstants._
import com.discover.chaos.constants.CustLookupConstants.{getCustomerInfo, postCustomerSearch}
import com.discover.chaos.constants.MembershipConstants.{getBillingDetails, getMembershipInfo, getRequestReasons}
import com.discover.chaos.constants.MemoConstants.{getMemos, postMemos}
import io.gatling.core.Predef.{details, _}

class LatencyAssaultSimulation extends Simulation {
  var getAccountActivityTestName = "Get Account Activity Latency Chaos Test"
  var postAccountActivityTestName = "Post Account Activity Latency Chaos Test"
  var postRecordCallTestName = "Post Record Call Latency Chaos Test"
  var postCancelCallTestName = "Post Cancel Call Latency Chaos Test"
  var getCustomerInfoTestName = "Get V1 Customer Info Latency Chaos Test"
  var postCustomerSearchTestName = "Post V1 Customer Search Latency Chaos Test"
  var getMembershipTestName = "Get Membership Info Latency Chaos Test"
  var getBillingTestName = "Get Billing Details Latency Chaos Test"
  var getRequestTestName = "Get Request Reason Info Latency Chaos Test"
  var getMemosTestName = "Get Memos Latency Chaos Test"
  var postMemosTestName = "Post Memos Latency Chaos Test"
  var getStatusTestName = "Get Status Latency Chaos Test"
  var postValidateCodeTestName = "Post Validate Code Latency Chaos Test"
  var postSendCodeTestName = "Post Send Code Latency Chaos Test"
  var postUnlockUserTestName = "Post Unlock User Latency Chaos Test"

  before {
    latencyAssaultProfile.applyLatencyAssaultProfileController()
    Thread.sleep(2000)
  }

  setUp(
    getAccountActivity(getAccountActivityTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postAccountActivity(postAccountActivityTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postRecordCall(postRecordCallTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postCancelCall(postCancelCallTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getCustomerInfo(getCustomerInfoTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postCustomerSearch(postCustomerSearchTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getMembershipInfo(getMembershipTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getBillingDetails(getBillingTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getRequestReasons(getRequestTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getMemos(getMemosTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postMemos(postMemosTestName)
      .inject(heavisideUsers(totalSubmissions) during duration)

  ).protocols(httpProtocol)
    .assertions(
      details(getAccountActivityTestName).successfulRequests.percent.gte(37),
      details(getAccountActivityTestName).responseTime.max.lt(17000),
      details(postAccountActivityTestName).successfulRequests.percent.gte(50),
      details(postAccountActivityTestName).responseTime.max.lt(14000),
      details(postRecordCallTestName).successfulRequests.percent.gte(50),
      details(postRecordCallTestName).responseTime.max.lt(14000),
      details(postCancelCallTestName).successfulRequests.percent.gte(50),
      details(postCancelCallTestName).responseTime.max.lt(14000),
      details(getCustomerInfoTestName).successfulRequests.percent.gte(50),
      details(getCustomerInfoTestName).responseTime.max.lt(17000),
      details(postCustomerSearchTestName).successfulRequests.percent.gte(50),
      details(postCustomerSearchTestName).responseTime.max.lt(14000),
      details(getMembershipTestName).successfulRequests.percent.gte(50),
      details(getMembershipTestName).responseTime.max.lt(17000),
      details(getBillingTestName).successfulRequests.percent.gte(50),
      details(getBillingTestName).responseTime.max.lt(17000),
      details(getRequestTestName).successfulRequests.percent.gte(50),
      details(getRequestTestName).responseTime.max.lt(17000),
      details(getMemosTestName).successfulRequests.percent.gte(50),
      details(getMemosTestName).responseTime.max.lt(17000),
      details(postMemosTestName).successfulRequests.percent.gte(50),
      details(postMemosTestName).responseTime.max.lt(14000)
    )

  after {
    latencyAssaultProfile.unapplyLatencyAssaultProfile()
    Thread.sleep(2000)
  }
}
