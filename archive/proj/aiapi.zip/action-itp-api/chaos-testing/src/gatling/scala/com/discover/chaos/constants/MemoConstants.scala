package com.discover.chaos.constants

import com.discover.chaos.constants.CommonConstants.headers
import io.gatling.core.Predef.{StringBody, scenario, _}
import io.gatling.core.structure.ScenarioBuilder
import io.gatling.http.Predef.{http, status, _}

object MemoConstants {
  def createMemoRequest(productEnrollmentId: String): String = {
    "{\n" +
      "  \"memoText\": \"Enrolled into ITP\",\n" +
      "  \"productEnrollmentId\": \"" + productEnrollmentId + "\"\n" +
      "}"
  }

  def productEnrollmentId: String = "90901234567890"

  def getMemos(name: String): ScenarioBuilder = scenario("GetMemos")
    .exec(http(name)
      .get("/memo/" + productEnrollmentId)
      .headers(headers)
      .check(status.is(200)))

  def postMemos(name: String): ScenarioBuilder = scenario("CreateMemos")
    .exec(http(name)
      .post("/memo")
      .body(StringBody(createMemoRequest(productEnrollmentId)))
      .headers(headers)
      .check(status.is(201)))

}
