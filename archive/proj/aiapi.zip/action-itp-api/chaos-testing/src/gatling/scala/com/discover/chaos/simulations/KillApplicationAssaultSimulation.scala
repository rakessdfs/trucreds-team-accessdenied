package com.discover.chaos.simulations

import com.discover.chaos.constants.AccountActivityConstants._
import com.discover.chaos.constants.CallConstants.postRecordCall
import com.discover.chaos.constants.CancelConstants.postCancelCall
import com.discover.chaos.constants.CommonConstants._
import com.discover.chaos.constants.CustLookupConstants.{getCustomerInfo, postCustomerSearch}
import com.discover.chaos.constants.MembershipConstants.{getBillingDetails, getMembershipInfo, getRequestReasons}
import com.discover.chaos.constants.MemoConstants.{getMemos, postMemos}
import io.gatling.core.Predef.{details, _}

class KillApplicationAssaultSimulation extends Simulation {
  var getAccountActivityTestName = "Get Account Activity Kill Application Chaos Test"
  var postAccountActivityTestName = "Post Account Activity Kill Application Chaos Test"
  var postRecordCallTestName = "Post Record Call Kill Application Chaos Test"
  var postCancelCallTestName = "Post Cancel Call Kill Application Chaos Test"
  var getCustomerInfoTestName = "Get V1 Customer Info Kill Application Chaos Test"
  var postCustomerSearchTestName = "Post V1 Customer Search Kill Application Chaos Test"
  var getMembershipTestName = "Get Membership Info Kill Application Chaos Test"
  var getBillingTestName = "Get Billing Details Kill Application Chaos Test"
  var getRequestTestName = "Get Request Reason Info Kill Application Chaos Test"
  var getMemoTestName = "Get Memos Kill Application Chaos Test"
  var postMemosTestName = "Post Memos Kill Application Chaos Test"

  before {
    killApplicationAssaultProfile.applyKillApplicationAssaultProfileController()
    Thread.sleep(2000)
  }

  setUp(
    getAccountActivity(getAccountActivityTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postAccountActivity(postAccountActivityTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postRecordCall(postRecordCallTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postCancelCall(postCancelCallTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getCustomerInfo(getCustomerInfoTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postCustomerSearch(postCustomerSearchTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getMembershipInfo(getMembershipTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getBillingDetails(getBillingTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getRequestReasons(getRequestTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getMemos(getMemoTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postMemos(postMemosTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
  ).protocols(httpProtocol)
    .assertions(
      details(getAccountActivityTestName).successfulRequests.percent.gte(10),
      details(getAccountActivityTestName).responseTime.max.lt(7200),
      details(postAccountActivityTestName).successfulRequests.percent.gte(10),
      details(postAccountActivityTestName).responseTime.max.lt(12000),
      details(postRecordCallTestName).successfulRequests.percent.gte(10),
      details(postRecordCallTestName).responseTime.max.lt(12000),
      details(postCancelCallTestName).successfulRequests.percent.gte(10),
      details(postCancelCallTestName).responseTime.max.lt(12000),
      details(getCustomerInfoTestName).successfulRequests.percent.gte(16),
      details(getCustomerInfoTestName).responseTime.max.lt(7200),
      details(postCustomerSearchTestName).successfulRequests.percent.gte(10),
      details(postCustomerSearchTestName).responseTime.max.lt(12000),
      details(getMembershipTestName).successfulRequests.percent.gte(16),
      details(getMembershipTestName).responseTime.max.lt(7200),
      details(getBillingTestName).successfulRequests.percent.gte(16),
      details(getBillingTestName).responseTime.max.lt(7200),
      details(getRequestTestName).successfulRequests.percent.gte(16),
      details(getRequestTestName).responseTime.max.lt(7200),
      details(getMemoTestName).successfulRequests.percent.gte(16),
      details(getMemoTestName).responseTime.max.lt(7200),
      details(postMemosTestName).successfulRequests.percent.gte(10),
      details(postMemosTestName).responseTime.max.lt(12000)
    )

  after {
    killApplicationAssaultProfile.unapplyKillApplicationAssaultProfile()
    Thread.sleep(2000)
  }
}
