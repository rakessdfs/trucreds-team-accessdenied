package com.discover.chaos.simulations

import com.discover.chaos.constants.AccountActivityConstants._
import com.discover.chaos.constants.CallConstants.postRecordCall
import com.discover.chaos.constants.CancelConstants.postCancelCall
import com.discover.chaos.constants.CommonConstants._
import com.discover.chaos.constants.CustLookupConstants.{getCustomerInfo, postCustomerSearch}
import com.discover.chaos.constants.MembershipConstants.{getBillingDetails, getMembershipInfo, getRequestReasons}
import com.discover.chaos.constants.MemoConstants.{getMemos, postMemos}
import io.gatling.core.Predef.{details, _}

class MemoryAssaultSimulation extends Simulation {
  var getAccountActivityTestName = "Get Account Activity Memory Chaos Test"
  var postAccountActivityTestName = "Post Account Activity Memory Chaos Test"
  var postRecordCallTestName = "Post Record Call Memory Chaos Test"
  var postCancelCallTestName = "Post Cancel Call Memory Chaos Test"
  var getCustomerInfoTestName = "Get V1 Customer Info Memory Chaos Test"
  var postCustomerSearchTestName = "Post V1 Customer Search Memory Chaos Test"
  var getMembershipTestName = "Get Membership Info Memory Chaos Test"
  var getBillingTestName = "Get Billing Details Memory Chaos Test"
  var getRequestTestName = "Get Request Reason Info Memory Chaos Test"
  var getMemosTestName = "Get Memos Memory Chaos Test"
  var postMemosTestName = "Post Memos Memory Chaos Test"
  var getStatusTestName = "Get Status Memory Chaos Test"
  var postValidateCodeTestName = "Post Validate Code Memory Chaos Test"
  var postSendCodeTestName = "Post Send Code Memory Chaos Test"
  var postUnlockUserTestName = "Post Unlock User Memory Chaos Test"

  before {
    memoryAssaultProfile.applyMemoryAssaultProfileController()
    Thread.sleep(2000)
  }

  setUp(
    getAccountActivity(getAccountActivityTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postAccountActivity(postAccountActivityTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postRecordCall(postRecordCallTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postCancelCall(postCancelCallTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getCustomerInfo(getCustomerInfoTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postCustomerSearch(postCustomerSearchTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getMembershipInfo(getMembershipTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getBillingDetails(getBillingTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getRequestReasons(getRequestTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getMemos(getMemosTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postMemos(postMemosTestName)
      .inject(heavisideUsers(totalSubmissions) during duration)

  ).protocols(httpProtocol)
    .assertions(
      details(getAccountActivityTestName).successfulRequests.percent.gte(20),
      details(getAccountActivityTestName).responseTime.max.lt(10000),
      details(postAccountActivityTestName).successfulRequests.percent.gte(85),
      details(postAccountActivityTestName).responseTime.max.lt(12000),
      details(postRecordCallTestName).successfulRequests.percent.gte(85),
      details(postRecordCallTestName).responseTime.max.lt(12000),
      details(postCancelCallTestName).successfulRequests.percent.gte(85),
      details(postCancelCallTestName).responseTime.max.lt(12000),
      details(getCustomerInfoTestName).successfulRequests.percent.gte(49),
      details(getCustomerInfoTestName).responseTime.max.lt(10000),
      details(postCustomerSearchTestName).successfulRequests.percent.gte(85),
      details(postCustomerSearchTestName).responseTime.max.lt(12000),
      details(getMembershipTestName).successfulRequests.percent.gte(49),
      details(getMembershipTestName).responseTime.max.lt(10000),
      details(getBillingTestName).successfulRequests.percent.gte(49),
      details(getBillingTestName).responseTime.max.lt(10000),
      details(getRequestTestName).successfulRequests.percent.gte(49),
      details(getRequestTestName).responseTime.max.lt(10000),
      details(getMemosTestName).successfulRequests.percent.gte(49),
      details(getMemosTestName).responseTime.max.lt(10000),
      details(postMemosTestName).successfulRequests.percent.gte(85),
      details(postMemosTestName).responseTime.max.lt(12000)
    )

  after {
    memoryAssaultProfile.unapplyMemoryAssaultProfile()
    Thread.sleep(2000)
  }
}
