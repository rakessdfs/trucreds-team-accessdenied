package com.discover.chaos.constants

import com.discover.chaos.constants.CommonConstants.headers
import io.gatling.core.Predef.{StringBody, scenario, _}
import io.gatling.core.structure.ScenarioBuilder
import io.gatling.http.Predef.{http, status, _}

object MembershipConstants {

  def partyId: String = "909090"

  def peid: String = "12345"

  def customerType: String = "ITP_BM"

  def subscriberId: String = "7856562"

  def getMembershipInfo(name: String): ScenarioBuilder = scenario("getMembershipInfo")
    .exec(http(name)
      .get("/membership?partyId=" + partyId)
      .headers(headers)
      .check(status.is(200)))

  def getBillingDetails(name: String): ScenarioBuilder = scenario("getBillingDetails")
    .exec(http(name)
      .get("/membership/billing?customerType=" + customerType + "&partyId=" + partyId + "&peid=" + peid +
        "&subscriberId=" + subscriberId)
      .headers(headers)
      .check(status.is(200)))

  def getRequestReasons(name: String): ScenarioBuilder = scenario("getRequestReasons")
    .exec(http(name)
      .get("/requestreasons/query?customerType=" + customerType)
      .headers(headers)
      .check(status.is(200)))

}
