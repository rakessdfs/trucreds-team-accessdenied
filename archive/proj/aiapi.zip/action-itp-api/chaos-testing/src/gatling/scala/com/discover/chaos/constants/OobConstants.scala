package com.discover.chaos.constants

import com.discover.chaos.constants.CommonConstants.headers
import io.gatling.core.Predef.{StringBody, scenario, _}
import io.gatling.core.structure.ScenarioBuilder
import io.gatling.http.Predef.{http, status, _}

object OobConstants {
  def createUnlockUserRequest(productEnrollmentId: String): String = {
    "{\n" +
      "  \"custUserKey\": \"" + productEnrollmentId + "\"\n" +
      "}"
  }

  def createSendCodeRequest(channelCode: String, channelValue: String, peid: String, firstName: String, lastName: String): String = {
    "{\n" +
      "  \"channelCode\": \"" + channelCode + "\",\n" +
      "  \"channelValue\": \"" + channelValue + "\",\n" +
      "  \"custUserKey\": \"" + peid + "\",\n" +
      "  \"customerFirstName\": \"" + firstName + "\",\n" +
      "  \"customerLastName\": \"" + lastName + "\"\n" +
      "}"
  }

  def createValidateCodeRequest(peid: String, inputCode: String, lockCustomer: Boolean): String = {
    "{\n" +
      "  \"custUserKey\": \"" + peid + "\",\n" +
      "  \"inputCode\": \"" + inputCode + "\",\n" +
      "  \"lockCustomer\": \"" + lockCustomer + "\"\n" +
      "}"
  }

  def productEnrollmentId: String = "90901234567890"

  def channelCode: String = "EM"

  def channelValue: String = "foo@bar.com"

  def firstName: String = "Hello"

  def lastName: String = "World"

  def inputCode: String = "12345"

  def getStatus(name: String): ScenarioBuilder = scenario("GetStatus")
    .exec(http(name)
      .get("/getStatus/" + productEnrollmentId)
      .headers(headers)
      .check(status.is(200)))

  def postUnlockUser(name: String): ScenarioBuilder = scenario("UnlockUser")
    .exec(http(name)
      .post("/unlockUser")
      .body(StringBody(createUnlockUserRequest(productEnrollmentId)))
      .headers(headers)
      .check(status.is(200)))

  def postSendCode(name: String): ScenarioBuilder = scenario("SendCode")
    .exec(http(name)
      .post("/sendCode")
      .body(StringBody(createSendCodeRequest(channelCode, channelValue, productEnrollmentId, firstName, lastName)))
      .headers(headers)
      .check(status.is(200)))

  def postValidateCode(name: String): ScenarioBuilder = scenario("ValidateCode")
    .exec(http(name)
      .post("/validateCode")
      .body(StringBody(createValidateCodeRequest(productEnrollmentId, inputCode, lockCustomer = false)))
      .headers(headers)
      .check(status.is(200)))

}
