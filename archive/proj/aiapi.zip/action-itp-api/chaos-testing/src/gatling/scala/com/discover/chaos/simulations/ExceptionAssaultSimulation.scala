package com.discover.chaos.simulations

import com.discover.chaos.constants.AccountActivityConstants._
import com.discover.chaos.constants.CallConstants.postRecordCall
import com.discover.chaos.constants.CancelConstants.postCancelCall
import com.discover.chaos.constants.CommonConstants._
import com.discover.chaos.constants.CustLookupConstants.{getCustomerInfo, postCustomerSearch}
import com.discover.chaos.constants.MembershipConstants.{getBillingDetails, getMembershipInfo, getRequestReasons}
import com.discover.chaos.constants.MemoConstants.{getMemos, postMemos}
import com.discover.chaos.constants.OobConstants.{getStatus, postSendCode, postUnlockUser, postValidateCode}
import io.gatling.core.Predef.{details, _}

class ExceptionAssaultSimulation extends Simulation {
  var getAccountActivityTestName = "Get Account Activity Exception Chaos Test"
  var postAccountActivityTestName = "Post Account Activity Exception Chaos Test"
  var postRecordCallTestName = "Post Record Call Exception Chaos Test"
  var postCancelCallTestName = "Post Cancel Call Exception Chaos Test"
  var getCustomerInfoTestName = "Get V1 Customer Info Exception Chaos Test"
  var postCustomerSearchTestName = "Post V1 Customer Search Exception Chaos Test"
  var getMembershipTestName = "Get Membership Info Exception Chaos Test"
  var getBillingTestName = "Get Billing Details Exception Chaos Test"
  var getRequestTestName = "Get Request Reason Info Exception Chaos Test"
  var getMemosTestName = "Get Memos Exception Chaos Test"
  var postMemosTestName = "Post Memos Exception Chaos Test"
  var getStatusTestName = "Get Status Exception Chaos Test"
  var postValidateCodeTestName = "Post Validate Code Exception Chaos Test"
  var postSendCodeTestName = "Post Send Code Exception Chaos Test"
  var postUnlockUserTestName = "Post Unlock User Exception Chaos Test"

  before {
    exceptionAssaultProfile.applyExceptionAssaultProfileController()
    Thread.sleep(2000)
  }

  setUp(
    getAccountActivity(getAccountActivityTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postAccountActivity(postAccountActivityTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postRecordCall(postRecordCallTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postCancelCall(postCancelCallTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getCustomerInfo(getCustomerInfoTestName)
    .inject(heavisideUsers(totalSubmissions) during duration),
    postCustomerSearch(postCustomerSearchTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getMembershipInfo(getMembershipTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getBillingDetails(getBillingTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getRequestReasons(getRequestTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getMemos(getMemosTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postMemos(postMemosTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    getStatus(getStatusTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postValidateCode(postValidateCodeTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postSendCode(postSendCodeTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
    postUnlockUser(postUnlockUserTestName)
      .inject(heavisideUsers(totalSubmissions) during duration),
  ).protocols(httpProtocol)
    .assertions(
      details(getAccountActivityTestName).successfulRequests.percent.gte(40),
      details(getAccountActivityTestName).responseTime.max.lt(6500),
      details(postAccountActivityTestName).successfulRequests.percent.gte(83),
      details(postAccountActivityTestName).responseTime.max.lt(11000),
      details(postRecordCallTestName).successfulRequests.percent.gte(83),
      details(postRecordCallTestName).responseTime.max.lt(11000),
      details(postCancelCallTestName).successfulRequests.percent.gte(83),
      details(postCancelCallTestName).responseTime.max.lt(11000),
      details(getCustomerInfoTestName).successfulRequests.percent.gte(83),
      details(getCustomerInfoTestName).responseTime.max.lt(11000),
      details(postCustomerSearchTestName).successfulRequests.percent.gte(83),
      details(postCustomerSearchTestName).responseTime.max.lt(11000),
      details(getMembershipTestName).successfulRequests.percent.gte(83),
      details(getMembershipTestName).responseTime.max.lt(6500),
      details(getBillingTestName).successfulRequests.percent.gte(83),
      details(getBillingTestName).responseTime.max.lt(6500),
      details(getRequestTestName).successfulRequests.percent.gte(83),
      details(getRequestTestName).responseTime.max.lt(6500),
      details(getMemosTestName).successfulRequests.percent.gte(83),
      details(getMemosTestName).responseTime.max.lt(6500),
      details(postMemosTestName).successfulRequests.percent.gte(83),
      details(postMemosTestName).responseTime.max.lt(11000),
      details(getStatusTestName).successfulRequests.percent.gte(83),
      details(getStatusTestName).responseTime.max.lt(6500),
      details(postValidateCodeTestName).successfulRequests.percent.gte(83),
      details(postValidateCodeTestName).responseTime.max.lt(11000),
      details(postSendCodeTestName).successfulRequests.percent.gte(83),
      details(postSendCodeTestName).responseTime.max.lt(11000),
      details(postUnlockUserTestName).successfulRequests.percent.gte(83),
      details(postUnlockUserTestName).responseTime.max.lt(11000)
    )

  after {
    exceptionAssaultProfile.unapplyExceptionAssaultProfile()
    Thread.sleep(2000)
  }
}
