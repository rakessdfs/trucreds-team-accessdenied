package com.discover.chaos.assaultprofile
import com.discover.chaos.constants.CommonConstants._

import scalaj.http.{Http, HttpOptions}

class KillApplicationAssaultProfile(serviceUrl: String) {

  private val headers: Map[String, String] = Map(
    "Content-Type" -> "application/json",
    "HTTP_AUTH_TOKEN" -> "893842924")

  val killApplicationAssaultProfileAssaultPayload: String =
    "{\n  \"level\": 10,\n  \"latencyRangeStart\": 10000,\n  \"latencyRangeEnd\": 10000,\n  \"latencyActive\": false,\n  \"exceptionsActive\": false,\n  \"killApplicationActive\": true,\n  \"runtimeAssaultCronExpression\": \" 0 * * * * ? \"\n}"

  def  applyKillApplicationAssaultProfileController(): Boolean = {

    val applyWatcherStatusCode: Int = Http(s"$serviceUrl/watchers")
      .postData(assaultProfileWatcherPayload)
      .headers(headers)
      .option(HttpOptions.allowUnsafeSSL)
      .asString.code
    Thread.sleep(1000)

    val applyAssaultProfileStatusCode: Int = Http(s"$serviceUrl/assaults")
      .postData(killApplicationAssaultProfileAssaultPayload)
      .headers(headers)
      .option(HttpOptions.allowUnsafeSSL)
      .asString.code
    Thread.sleep(1000)

    applyWatcherStatusCode == 200 && applyAssaultProfileStatusCode == 200
  }

  def  unapplyKillApplicationAssaultProfile(): Boolean = {

    val unapplyWatcherStatusCode: Int = Http(s"$serviceUrl/watchers")
      .postData(unapplyAssaultProfileWatcherPayload)
      .headers(headers)
      .option(HttpOptions.allowUnsafeSSL)
      .asString.code
    Thread.sleep(1000)

    val unapplyAssaultProfileStatusCode: Int = Http(s"$serviceUrl/assaults")
      .postData(unapplyAssaultProfileAssaultPayload)
      .headers(headers)
      .option(HttpOptions.allowUnsafeSSL)
      .asString.code
    Thread.sleep(1000)

    unapplyWatcherStatusCode == 200 && unapplyAssaultProfileStatusCode == 200
  }
}
