package com.discover.chaos.constants

import com.discover.chaos.constants.CommonConstants.headers
import io.gatling.core.Predef.{StringBody, scenario, _}
import io.gatling.core.structure.ScenarioBuilder
import io.gatling.http.Predef.{http, status, _}

object CancelConstants {

  def postCancelCall(name: String): ScenarioBuilder = scenario("CancelCall")
    .exec(http(name)
      .post("/cancel/membership")
      .queryParam("cancelReasonCode", "P")
      .queryParam("productEnrollmentId", "457821487")
      .headers(headers)
      .check(status.is(200)))

}
