package com.discover.chaos.constants

import com.discover.chaos.constants.CommonConstants.headers
import io.gatling.core.Predef.{StringBody, scenario, _}
import io.gatling.core.structure.ScenarioBuilder
import io.gatling.http.Predef.{http, status, _}

object CustLookupConstants {
  def customerSearchRequest(): String = {
    "{\n" +
      "  \"firstName\": \"TestUser\",\n" +
      "  \"lastName\": \"LastName\",\n" +
      "  \"dateOfBirth\": \"11/22/1950\",\n" +
      "  \"peidOrSubscriberId\": \"\"\n" +
      "}"
  }

  def partyId: String = "100007975"

  def getCustomerInfo(name: String): ScenarioBuilder = scenario("CustomerInfo")
    .exec(http(name)
      .get("/customer/pii?party-id=" + partyId)
      .headers(headers)
      .check(status.is(200)))

  def postCustomerSearch(name: String): ScenarioBuilder = scenario("CustomerSearch")
    .exec(http(name)
      .post("/customer/search")
      .body(StringBody(customerSearchRequest()))
      .headers(headers)
      .check(status.is(200)))
}
