package com.discover.cmpp.action.itp;

import com.discover.cmpp.action.itp.controller.CreateMemoClient;
import com.discover.cmpp.action.itp.domain.CreateMemoRequest;
import feign.Response;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.HttpClientErrorException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureStubRunner
public class CreateMemoContractTest {

    @Autowired
    private CreateMemoClient createMemoClient;

    @Test
    public void createMemoSuccessTest() {
        CreateMemoRequest createMemoRequest = new CreateMemoRequest();
        createMemoRequest.setMemoText("Enrolled into ITP F&F");
        createMemoRequest.setProductEnrollmentId("457821487");
        Response response = createMemoClient.createMemo("testRACF", createMemoRequest);
        assertEquals(response.status(), 201);
    }

    @Test
    public void createMemoFailureInvalidAgentIdTest() {
        CreateMemoRequest createMemoRequest = new CreateMemoRequest();
        createMemoRequest.setMemoText("Enrolled into ITP F&F");
        createMemoRequest.setProductEnrollmentId("23456789");
        Response response = createMemoClient.createMemoAgentId("invalidID", createMemoRequest);
        assertEquals(400, response.status());
        assertEquals("{\"errors\":{\"1010\":\"Invalid agentId can't be null or blank\"}}", response.body().toString());
    }

    @Test
    public void createMemoFailureInvalidPEIDTest() {
        CreateMemoRequest createMemoRequest = new CreateMemoRequest();
        createMemoRequest.setMemoText("Enrolled into ITP F&F");
        createMemoRequest.setProductEnrollmentId(" ");
        Response response = createMemoClient.createMemoPEID("5", createMemoRequest);
        assertEquals(400, response.status());
        assertEquals("{\"errors\":{\"1012\":\"Invalid productEnrollmentId can't be null or blank\"}}", response.body().toString());
    }

    @Test
    public void createMemoFailureInvalidMemoTextTest() {
        CreateMemoRequest createMemoRequest = new CreateMemoRequest();
        createMemoRequest.setMemoText(" ");
        createMemoRequest.setProductEnrollmentId("23456789");
        Response response = createMemoClient.createMemoTextError("6", createMemoRequest);
        assertEquals(400, response.status());
        assertEquals("{\"errors\":{\"1011\":\"Invalid memoText can't be null or blank\"}}", response.body().toString());
    }

    @Test
    public void createMemoFailure404Test() {
        CreateMemoRequest createMemoRequest = new CreateMemoRequest();
        createMemoRequest.setMemoText("Enrolled into ITP F&F");
        createMemoRequest.setProductEnrollmentId("457821487");

        Response response = createMemoClient.createMemo404("testRACF", createMemoRequest);
        assertEquals(404, response.status());
    }

    @Test
    public void createMemoFailure500Test() throws JSONException {
        CreateMemoRequest createMemoRequest = new CreateMemoRequest();
        createMemoRequest.setMemoText("Enrolled into ITP F&F");
        createMemoRequest.setProductEnrollmentId("23456789");

        Response response = createMemoClient.createMemo500("testRACF500", createMemoRequest);
        assertEquals(500, response.status());
        assertEquals("{\"errors\":{\"5006\":\"Internal server error\"}}", response.body().toString());
    }

    private String responseParser(HttpClientErrorException ex, String id) throws JSONException {
        String split[] = ex.getMessage().split(" ",2);
        return new JSONObject(split[1]).getString(id);
    }

}
