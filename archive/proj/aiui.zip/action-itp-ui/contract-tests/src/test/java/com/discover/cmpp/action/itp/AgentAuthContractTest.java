package com.discover.cmpp.action.itp;

import com.discover.cmpp.action.itp.controller.AgentAuthClient;
import com.discover.cmpp.action.itp.domain.AgentAuthInputVO;
import com.discover.cmpp.action.itp.domain.AgentAuthOutputVO;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.HttpClientErrorException;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureStubRunner
public class AgentAuthContractTest {

    @Autowired
    private AgentAuthClient agentAuthClient;

    @Test
    public void agentAuthSuccessTest() {
        ResponseEntity<AgentAuthOutputVO> agentAuthResponse = agentAuthClient
                .agentAuthResp(getAgentAuthInputVoBuild("testagent", "test"));

        AgentAuthOutputVO agentAuthOutputVO = agentAuthResponse.getBody();

        List<String> authHeader = agentAuthResponse.getHeaders().get("Authorization");
        assertEquals("testagent@test.com", agentAuthOutputVO.getEmail());
        assertEquals("testagent@test.com", agentAuthOutputVO.getEmail());
        assertEquals("Test Agent", agentAuthOutputVO.getFullName());
        assertEquals("testagent", agentAuthOutputVO.getUserName());

        assertNotNull(authHeader);
        assertEquals("dummyToken", authHeader.get(0));
    }

    @Test
    public void agentAuthFailure400Test() {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                agentAuthClient.agentAuthResp(getAgentAuthInputVoBuild("invparams", null)));

        assertEquals("400 Bad Request", ex.getMessage());
    }

    @Test
    public void agentAuthFailure401Test() throws JSONException {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
            agentAuthClient.agentAuthResp(getAgentAuthInputVoBuild("failagent", "invalid")));

        assertEquals("401 Unauthorized", ex.getMessage());
    }

    @Test
    public void agentAuthFailure404Test() {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
            agentAuthClient.agentAuthWrongAuthenticateResp(getAgentAuthInputVoBuild("resourcenotfound", "invalid")));

        assertEquals("404 Not Found", ex.getMessage());
    }

    @Test
    public void agentAuthFailure500Test() throws JSONException {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
            agentAuthClient.agentAuthResp(getAgentAuthInputVoBuild("erroragent", "error")));

        assertEquals("{\"5005\":\"LDAP Issues\"}", responseParser(ex, "errors"));
    }

    private AgentAuthInputVO getAgentAuthInputVoBuild(String racf, String psswd) {
        return AgentAuthInputVO.builder()
                .psswd(psswd)
                .racf(racf)
                .build();
    }

    private String responseParser(HttpClientErrorException ex, String id) throws JSONException {
        String split[] = ex.getMessage().split(" ",2);
        return new JSONObject(split[1]).getString(id);
    }

}
