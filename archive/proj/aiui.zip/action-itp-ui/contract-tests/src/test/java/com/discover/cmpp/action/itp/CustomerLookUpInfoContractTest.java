package com.discover.cmpp.action.itp;

import com.discover.cmpp.action.itp.controller.CustomerLookUpInfoClient;
import com.discover.cmpp.action.itp.domain.CustomerInfoResponse;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.HttpClientErrorException;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureStubRunner
public class CustomerLookUpInfoContractTest {

    @Autowired
    private CustomerLookUpInfoClient customerLookUpInfoClient;

    @Test
    public void customerInfoSuccessTest() {
        CustomerInfoResponse customerInfo = customerLookUpInfoClient.customerInfo("testRACF", "111111");

        assertEquals("TWANEY", customerInfo.getFirstName());
        assertEquals("AZARIYA", customerInfo.getLastName());
        assertEquals("user123@user.com", customerInfo.getEmail());
        assertEquals("0987654321", customerInfo.getPrimaryPhone());
        assertEquals("1234", customerInfo.getSsn());
        assertEquals("line 1", customerInfo.getAddress().getAddressLine1());
    }

    @Test
    public void customerInfo400Test() throws JSONException {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                customerLookUpInfoClient.customerInfo400("nullAgentID", "222222"));

        assertEquals("400 Bad Request", ex.getMessage());
    }

    @Test
    public void customerInfo404Test() {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                customerLookUpInfoClient.customerInfo404());

        assertEquals("404 Not Found", ex.getMessage());
    }

    @Test
    public void customerInfo500Test() throws JSONException {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                customerLookUpInfoClient.customerInfo500("testRACF500", "444444"));

        assertEquals("{\"5006\":\"Internal server error\"}", responseParser(ex, "errors"));
    }

    private String responseParser(HttpClientErrorException ex, String id) throws JSONException {
        String split[] = ex.getMessage().split(" ",2);
        return new JSONObject(split[1]).getString(id);
    }

}
