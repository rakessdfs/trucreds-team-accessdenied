package com.discover.cmpp.action.itp;

import com.discover.cmpp.action.itp.controller.FetchAccountActivityClient;
import com.discover.cmpp.action.itp.domain.AccountActivityDto;
import com.discover.cmpp.action.itp.domain.AccountActivityResponse;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.HttpClientErrorException;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureStubRunner
public class FetchAccountActivityContractTest {

    @Autowired
    private FetchAccountActivityClient fetchAccountActivityClient;

    @Test
    public void fetchAccountActivitySuccessTest() {
        LocalDateTime dateTime1 = LocalDateTime.of(2021, 1, 31, 20, 28, 57);
        LocalDateTime dateTime2 = LocalDateTime.of(2021, 5, 30, 20, 28, 57);

        AccountActivityResponse response = fetchAccountActivityClient.fetchAccountActivity("200");
        AccountActivityDto activity1 = response.getAccountActivityList().get(0);
        AccountActivityDto activity2 = response.getAccountActivityList().get(1);

        assertEquals(Long.valueOf(12), activity1.getAccountActivityId());
        assertEquals("200", activity1.getProductEnrollmentId());
        assertEquals("activityTestDesc1", activity1.getActivityDesc());
        assertEquals("previousTestData1", activity1.getPreviousData());
        assertEquals("newTestData1", activity1.getNewData());
        assertEquals("operator1", activity1.getOperator());
        assertEquals(dateTime1, activity1.getRequestDate());

        assertEquals(Long.valueOf(13), activity2.getAccountActivityId());
        assertEquals("200", activity2.getProductEnrollmentId());
        assertEquals("activityTestDesc2", activity2.getActivityDesc());
        assertEquals("previousTestData2", activity2.getPreviousData());
        assertEquals("newTestData2", activity2.getNewData());
        assertEquals("operator2", activity2.getOperator());
        assertEquals(dateTime2, activity2.getRequestDate());
    }

    @Test
    public void fetchAccountActivity_NoActivityTest() {
        AccountActivityResponse response = fetchAccountActivityClient.fetchAccountActivity("204");
        assertNull(response);
    }

    @Test
    public void fetchAccountActivity_404Test() {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                fetchAccountActivityClient.fetchAccountActivity404("404"));

        assertEquals("404 Not Found", ex.getMessage());
    }

    @Test
    public void fetchAccountActivity_500Test() throws JSONException {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                fetchAccountActivityClient.fetchAccountActivity("500"));

            assertEquals("{\"5006\":\"Internal server error\"}", responseParser(ex));
    }

    private String responseParser(HttpClientErrorException ex) throws JSONException {
        String[] split = ex.getMessage().split(" ",2);
        return new JSONObject(split[1]).getString("errors");
    }

}
