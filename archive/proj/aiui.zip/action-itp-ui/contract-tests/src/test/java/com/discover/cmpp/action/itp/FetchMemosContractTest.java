package com.discover.cmpp.action.itp;

import com.discover.cmpp.action.itp.controller.FetchMemosClient;
import com.discover.cmpp.action.itp.domain.MemoDto;
import com.discover.cmpp.action.itp.domain.MemoResponse;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.HttpClientErrorException;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureStubRunner
public class FetchMemosContractTest {

    @Autowired
    private FetchMemosClient fetchMemosClient;

    @Test
    public void fetchMemosSuccessTest() {
        MemoResponse memoResponse = fetchMemosClient.fetchMemos("1");
        MemoDto memoDto = memoResponse.getMemosList().get(0);
        MemoDto memoDto2 = memoResponse.getMemosList().get(1);

        LocalDateTime localDateTime = LocalDateTime.of(2020, 8, 31, 20, 28, 57);
        LocalDateTime localDateTime2 = LocalDateTime.of(2020, 8, 31, 20, 29, 57);

        assertEquals(Long.valueOf(12), memoDto.getMemoId());
        assertEquals("1", memoDto.getProductEnrollmentId());
        assertEquals("Enrolled into ITP F&F", memoDto.getMemoText());
        assertEquals("Peter", memoDto.getCreateAgentId());
        assertEquals(localDateTime, memoDto.getCreateTs());
        assertEquals(null, memoDto.getUpdateAgentId());
        assertEquals(null, memoDto.getUpdateTs());
        assertEquals(Long.valueOf(13), memoDto2.getMemoId());
        assertEquals("1", memoDto2.getProductEnrollmentId());
        assertEquals("Enrolled into ITP F&F", memoDto2.getMemoText());
        assertEquals("Peter", memoDto2.getCreateAgentId());
        assertEquals(localDateTime, memoDto2.getCreateTs());
        assertEquals("Peter2", memoDto2.getUpdateAgentId());
        assertEquals(localDateTime2, memoDto2.getUpdateTs());
    }

    @Test
    public void agentAuthFailure400Test() {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
            fetchMemosClient.fetchMemos("2"));

        assertEquals("400 Bad Request", ex.getMessage());
    }

    @Test
    public void agentAuthFailure404Test() {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                fetchMemosClient.fetchMemos404("3"));

        assertEquals("404 Not Found", ex.getMessage());
    }

    @Test
    public void agentAuthFailure500Test() throws JSONException {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                fetchMemosClient.fetchMemos("4"));

        assertEquals("{\"5006\":\"Internal server error\"}", responseParser(ex, "errors"));
    }

    private String responseParser(HttpClientErrorException ex, String id) throws JSONException {
        String split[] = ex.getMessage().split(" ",2);
        return new JSONObject(split[1]).getString(id);
    }

}
