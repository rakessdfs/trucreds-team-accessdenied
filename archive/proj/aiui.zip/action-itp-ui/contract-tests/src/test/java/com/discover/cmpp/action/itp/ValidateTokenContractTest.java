package com.discover.cmpp.action.itp;

import com.discover.cmpp.action.itp.controller.ValidateTokenClient;
import com.discover.cmpp.action.itp.domain.ValidateTokenInputVO;
import com.discover.cmpp.action.itp.domain.ValidateTokenOutputVO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.HttpClientErrorException;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureStubRunner
public class ValidateTokenContractTest {

    @Autowired
    private ValidateTokenClient validateTokenClient;

    @Test
    public void validateTokenSuccessTest() {
        ValidateTokenOutputVO validateTokenOutputVO = validateTokenClient
                .validateTokenResp(getValidateTokenInputVO("valid-jwt-token"));

        assertEquals("testagent", validateTokenOutputVO.getUsername());
    }

    @Test
    public void validateTokenFailure400Test() {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                validateTokenClient.validateTokenResp(getValidateTokenInputVO(null)));

        assertEquals("400 Bad Request", ex.getMessage());
    }

    @Test
    public void agentAuthFailure401Test() {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                validateTokenClient.validateTokenResp(getValidateTokenInputVO("invalid-jwt-token")));

        assertEquals("401 Unauthorized", ex.getMessage());
    }

    @Test
    public void agentAuthFailure404Test() {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                validateTokenClient.validateTokenWrongEndpointResp(getValidateTokenInputVO("invalid")));

        assertEquals("404 Not Found", ex.getMessage());
    }

    private ValidateTokenInputVO getValidateTokenInputVO(String jwtToken) {
        return ValidateTokenInputVO.builder().jwtToken(jwtToken).build();
    }
}
