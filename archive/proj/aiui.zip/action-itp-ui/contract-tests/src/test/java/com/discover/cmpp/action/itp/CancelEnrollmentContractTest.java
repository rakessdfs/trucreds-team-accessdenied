package com.discover.cmpp.action.itp;

import com.discover.cmpp.action.itp.controller.CancelEnrollmentClient;
import feign.Response;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureStubRunner
public class CancelEnrollmentContractTest {

    @Autowired
    private CancelEnrollmentClient cancelEnrollmentClient;

    @Test
    public void cancelEnrollmentSuccessTest() {
        Response response = cancelEnrollmentClient.cancelEnrollment("testRACF", "DNW",
                "9090210762045412345");
        assertEquals(200, response.status());
    }

    @Test
    public void cancelEnrollmentBadRequestTest() {
        Response response = cancelEnrollmentClient.cancelEnrollment("testRACF", "XYZ",
                "9090210762045412346");
        assertEquals(400, response.status());
    }

    @Test
    public void cancelEnrollmentServerErrorTest() {
        Response response = cancelEnrollmentClient.cancelEnrollment("testRACF", "DNW",
                "9090210762045412347");
        assertEquals(500, response.status());
    }
}
