package com.discover.cmpp.action.itp;

import com.discover.cmpp.action.itp.controller.FetchMembershipClient;
import com.discover.cmpp.action.itp.domain.BillingResponse;
import com.discover.cmpp.action.itp.domain.MembershipResponse;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.HttpClientErrorException;

import java.math.BigDecimal;
import java.sql.Date;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureStubRunner
public class FetchMembershipContractTest {

    @Autowired
    private FetchMembershipClient fetchMembershipClient;

    @Test
    public void fetchMembershipSuccessTestCustomerTypeFF() {
        MembershipResponse membershipResponse = fetchMembershipClient.fetchMembership("1111");

        Date cancellationDate = new Date(0);
        Date cancellationRequestDate = new Date(0);
        Date enrollmentDate = new Date(123456789);
        assertEquals(cancellationDate, membershipResponse.getCancellationDate());
        assertEquals(cancellationRequestDate, membershipResponse.getCancellationRequestDate());
        assertEquals(enrollmentDate, membershipResponse.getEnrollmentDate());
        assertEquals("Enrolled", membershipResponse.getEnrollmentStatus());
        assertEquals("", membershipResponse.getEnrollmentFailedReason());
        assertEquals("11", membershipResponse.getSubscriberNumber());
        assertEquals(BigDecimal.valueOf(1), membershipResponse.getProductEnrollmentId());
        assertEquals("ITP_FF", membershipResponse.getCustomerType());
    }

    @Test
    public void fetchMembershipSuccessTestCustomerTypeBM() {
        MembershipResponse membershipResponse = fetchMembershipClient.fetchMembership("1112");

        Date cancellationDate = new Date(0);
        Date cancellationRequestDate = new Date(0);
        Date enrollmentDate = new Date(123456789);
        assertEquals(cancellationDate, membershipResponse.getCancellationDate());
        assertEquals(cancellationRequestDate, membershipResponse.getCancellationRequestDate());
        assertEquals(enrollmentDate, membershipResponse.getEnrollmentDate());
        assertEquals("Enrolled", membershipResponse.getEnrollmentStatus());
        assertEquals("", membershipResponse.getEnrollmentFailedReason());
        assertEquals("11", membershipResponse.getSubscriberNumber());
        assertEquals(BigDecimal.valueOf(1), membershipResponse.getProductEnrollmentId());
        assertEquals("ITP_BM", membershipResponse.getCustomerType());
    }

    @Test
    public void fetchMembershipFailure400Test() {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                fetchMembershipClient.fetchMembership400("1212"));

        assertEquals("400 Bad Request", ex.getMessage());
    }

    @Test
    public void fetchMembershipFailure404Test() {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                fetchMembershipClient.fetchMembership404());

        assertEquals("404 Not Found", ex.getMessage());
    }

    @Test
    public void fetchMembership500Test() throws JSONException {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                fetchMembershipClient.fetchMembership("3333"));

         assertEquals("{\"5006\":\"Internal server error\"}", responseParser(ex, "errors"));
    }

    @Test
    public void fetchBillingSuccessTest_FfCustomer() {
        BillingResponse billingResponse = fetchMembershipClient.fetchBilling(new BigDecimal(1), "2", "ITP_FF", "12345");
        assertEquals("Jamal", billingResponse.getPcmFirstName());
        assertEquals("Murray", billingResponse.getPcmLastName());
        assertEquals("123456789", billingResponse.getPcmAccountNumber());
        assertEquals("No", billingResponse.getPresenceOfSecondary());
    }

    @Test
    public void fetchBillingSuccessTest_BmCustomer() {
        BillingResponse billingResponse = fetchMembershipClient.fetchBilling(new BigDecimal(1), "2", "ITP_BM", "12345");
        assertEquals("20210222", billingResponse.getNextBillingDate());
    }

    @Test
    public void fetchBillingFailure400Test() {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
            fetchMembershipClient.fetchBilling(new BigDecimal(2), "2","ITP_BM", "12345"));

        assertEquals("400 Bad Request", ex.getMessage());
    }

    @Test
    public void fetchBillingFailure404Test() {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                fetchMembershipClient.fetchBilling404());

        assertEquals("404 Not Found", ex.getMessage());
    }

    @Test
    public void fetchBilling500Test() throws JSONException {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                fetchMembershipClient.fetchBilling(new BigDecimal(4), "2", "ITP_BM", "12345"));

        assertEquals("{\"5006\":\"Internal server error\"}", responseParser(ex, "errors"));
    }

    private String responseParser(HttpClientErrorException ex, String id) throws JSONException {
        String split[] = ex.getMessage().split(" ",2);
        return new JSONObject(split[1]).getString(id);
    }
}
