package com.discover.cmpp.action.itp;

import com.discover.cmpp.action.itp.controller.CustomerLookUpSearchClient;
import com.discover.cmpp.action.itp.domain.CustomerSearchRequest;
import com.discover.cmpp.action.itp.domain.CustomerSearchResponse;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.HttpClientErrorException;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureStubRunner
public class CustomerLookUpSearchContractTest {

    @Autowired
    private CustomerLookUpSearchClient customerLookUpSearchClient;

    @Test
    public void customerSearchSuccessTest() {
        CustomerSearchResponse customerSearch = customerLookUpSearchClient.customerSearch("testRACF",
                new CustomerSearchRequest("05/04/2019", "ACTION", "ITP", null));

        assertEquals("ACTION", customerSearch.getCustomers().get(0).getFirstName());
        assertEquals("ITP", customerSearch.getCustomers().get(0).getLastName());
        assertEquals("1234", customerSearch.getCustomers().get(0).getSsn());
        assertEquals("123456", customerSearch.getCustomers().get(0).getPartyId());
    }

    @Test
    public void customerSearchWithPEIDSuccessTest() {
        CustomerSearchResponse customerSearch = customerLookUpSearchClient.customerSearch("testRACF",
                new CustomerSearchRequest("", "", "", "9090203091733124810"));

        assertEquals("ACTION", customerSearch.getCustomers().get(0).getFirstName());
        assertEquals("ITP", customerSearch.getCustomers().get(0).getLastName());
        assertEquals("1234", customerSearch.getCustomers().get(0).getSsn());
        assertEquals("123456", customerSearch.getCustomers().get(0).getPartyId());
    }

    @Test
    public void customerSearch400NullAgentIDTest() throws JSONException {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
            customerLookUpSearchClient.customerSearch400NullAgentID("nullAgentID",
                    new CustomerSearchRequest("05/04/2019", "ACTION", "ITP", null)));

        assertEquals("400 Bad Request", ex.getMessage());
    }

    @Test
    public void customerSearch400InvalidReqTest() throws JSONException {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                customerLookUpSearchClient.customerSearch400InvalidReq("invalidReq",
                    new CustomerSearchRequest("", "", "", null)));

        assertEquals("400 Bad Request", ex.getMessage());
    }

    @Test
    public void customerSearch404Test() {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                customerLookUpSearchClient.customerSearch404("testRACF", new CustomerSearchRequest("05/04/2019", "ACTION", "ITP", null)));

        assertEquals("404 Not Found", ex.getMessage());
    }

    @Test
    public void customerSearch500Test() throws JSONException {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
                customerLookUpSearchClient.customerSearch500("testRACF500", new CustomerSearchRequest("05/04/2019", "ACTION", "ITP", null)));

        assertEquals("{\"5006\":\"Internal server error\"}", responseParser(ex, "errors"));
    }

    private String responseParser(HttpClientErrorException ex, String id) throws JSONException {
        String split[] = ex.getMessage().split(" ",2);
        return new JSONObject(split[1]).getString(id);
    }

}