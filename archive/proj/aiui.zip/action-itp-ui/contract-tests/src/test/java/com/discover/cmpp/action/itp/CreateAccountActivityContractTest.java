package com.discover.cmpp.action.itp;

import com.discover.cmpp.action.itp.controller.CreateAccountActivityClient;
import com.discover.cmpp.action.itp.domain.CreateActivityRequest;
import feign.Response;
import org.json.JSONException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.HttpClientErrorException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureStubRunner
public class CreateAccountActivityContractTest {

    @Autowired
    private CreateAccountActivityClient createAccountActivityClient;

    @Test
    public void createAccountActivitySuccessTest() {
        Response response = createAccountActivityClient.createAccountActivity(getCreateActivityRequest(
                "WMF", "ONLINE", "457821487", "2021-02-16 20:34:59"));
        assertEquals(201, response.status());
    }

    @Test
    public void createAccountActivity_400Test() throws JSONException {
        CreateActivityRequest createActivityRequest = new CreateActivityRequest();
        createActivityRequest.setActivityCode("WMF");
        createActivityRequest.setOperator("ONLINE");
        createActivityRequest.setProductEnrollmentId("457821487");

        Response response = createAccountActivityClient.createAccountActivity(getCreateActivityRequest(
                "WMF", "ONLINE", "457821487", null));
        assertEquals(400, response.status());
        assertEquals("{\"errors\":{\"1023\":\"Invalid Request Date\"}}", response.body().toString());
    }

    @Test
    public void createAccountActivity_404Test() {
        final HttpClientErrorException ex = assertThrows(HttpClientErrorException.class, () ->
            createAccountActivityClient.createAccountActivity404(getCreateActivityRequest(
                    "WMF", "ONLINE", "457821487", "2021-02-16 20:34:59")));

        assertEquals("404 Not Found", ex.getMessage());
    }

    @Test
    public void createAccountActivity_500Test() {
        Response response = createAccountActivityClient.createAccountActivity(getCreateActivityRequest(
                "500", "ONLINE", "457821487", "2021-02-16 20:34:59"));
        assertEquals(500, response.status());
        assertEquals("{\"errors\":{\"1022\":\"Error while inserting record in Account Activity Database\"}}", response.body().toString());
    }

    CreateActivityRequest getCreateActivityRequest(String activityCode, String operator, String peid, String requestDate) {
        CreateActivityRequest createActivityRequest = new CreateActivityRequest();
        createActivityRequest.setActivityCode(activityCode);
        createActivityRequest.setOperator(operator);
        createActivityRequest.setProductEnrollmentId(peid);
        createActivityRequest.setRequestDate(requestDate);
        return createActivityRequest;
    }
}
