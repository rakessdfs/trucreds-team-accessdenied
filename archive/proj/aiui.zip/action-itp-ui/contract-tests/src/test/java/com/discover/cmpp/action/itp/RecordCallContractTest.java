package com.discover.cmpp.action.itp;

import com.discover.cmpp.action.itp.controller.RecordCallClient;
import com.discover.cmpp.action.itp.domain.RecordCallRequest;
import feign.Response;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureStubRunner
public class RecordCallContractTest {

    @Autowired
    private RecordCallClient recordCallClient;

    @Test
    public void recordCallSuccessTest() {

        RecordCallRequest recordCallRequest = new RecordCallRequest();
        recordCallRequest.setCustomerType("ITP_BM");
        recordCallRequest.setProductEnrollmentId("200");
        recordCallRequest.setTagType("servicing");
        Response response = recordCallClient.recordCall("testRACF", recordCallRequest);
        assertEquals(response.status(), 200);
    }

    @Test
    public void recordCallBadRequestTest() {

        RecordCallRequest recordCallRequest = new RecordCallRequest();
        recordCallRequest.setCustomerType("ITP_BM");
        Response response = recordCallClient.recordCall("testRACF", recordCallRequest);
        assertEquals(response.status(), 400);
        assertEquals("{\"errors\":{\"1012\":\"Invalid productEnrollmentId can't be null or blank\"}}", response.body().toString());
    }

    @Test
    public void recordCallInternalServerErrorTest() {

        RecordCallRequest recordCallRequest = new RecordCallRequest();
        recordCallRequest.setCustomerType("ITP_BM");
        recordCallRequest.setProductEnrollmentId("500");
        recordCallRequest.setTagType("servicing");
        Response response = recordCallClient.recordCall("testRACF", recordCallRequest);
        assertEquals(response.status(), 500);
        assertEquals("{\"errors\":{\"1026\":\"Error while starting call recording\"}}", response.body().toString());
    }
}
