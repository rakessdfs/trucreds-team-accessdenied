package com.discover.cmpp.action.itp.controller;

import com.discover.cmpp.action.itp.domain.CreateActivityRequest;
import feign.Headers;
import feign.Response;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Headers({"Content-Type: application/json", "Accept: application/json"})
public interface CreateAccountActivityClient {

    @RequestMapping(
            headers = "HTTP_AUTH_TOKEN=WTv2token",
            method = RequestMethod.POST,
            path = "/enterprise/products/action/itp/v1/accountActivity",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    Response createAccountActivity(@RequestBody CreateActivityRequest request);

    @RequestMapping(
            headers = "HTTP_AUTH_TOKEN=WTv2token",
            method = RequestMethod.POST,
            path = "/enterprise/products/action/itp/v1/accountActivityZZZ",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    void createAccountActivity404(@RequestBody CreateActivityRequest request);
}
