package com.discover.cmpp.action.itp.controller;

import com.discover.cmpp.action.itp.domain.BillingResponse;
import com.discover.cmpp.action.itp.domain.MembershipResponse;
import feign.Headers;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Headers({"Content-Type: application/json", "Accept: application/json"})
public interface FetchMembershipClient {

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=testRACF"},
            method = RequestMethod.GET,
            path = "/enterprise/products/action/itp/v1/membership",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    MembershipResponse fetchMembership(@RequestParam("partyId") String partyId);

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=testRACF"},
            method = RequestMethod.GET,
            path = "/enterprise/products/action/itp/v1/membership",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    MembershipResponse fetchMembership400(@RequestParam("partyId") String partyId);

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=ITP"},
            method = RequestMethod.GET,
            path = "/enterprise/products/action/itp/v1/notfound/membership?partyId=2222",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    MembershipResponse fetchMembership404();

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=testRACF"},
            method = RequestMethod.GET,
            path = "/enterprise/products/action/itp/v1/membership/billing",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    BillingResponse fetchBilling(@RequestParam("peid")BigDecimal peid, @RequestParam("subscriberId")String subscriberId,@RequestParam("customerType")String customerType, @RequestParam("partyId")String partyId);

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=ITP"},
            method = RequestMethod.GET,
            path = "/enterprise/products/action/itp/v1/notfound/membership/billing?peid=3&subscriberId=2&customerType=ITP_BM&partyId=12345",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    BillingResponse fetchBilling404();
}
