package com.discover.cmpp.action.itp.controller;

import com.discover.cmpp.action.itp.domain.AgentAuthInputVO;
import com.discover.cmpp.action.itp.domain.AgentAuthOutputVO;
import feign.Headers;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Headers({"Content-Type: application/json", "Accept: application/json"})
public interface AgentAuthClient {

    @RequestMapping(headers = "HTTP_AUTH_TOKEN=WTv2token", method = RequestMethod.POST, path = "/enterprise/products/action/itp/v1/agent/authenticate", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
    ResponseEntity<AgentAuthOutputVO> agentAuthResp(@RequestBody AgentAuthInputVO agentAuthInputVO);

    @RequestMapping(headers = "HTTP_AUTH_TOKEN=WTv2token", method = RequestMethod.POST, path = "/enterprise/products/action/itp/v1/agent/wrongauthenticate", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
    ResponseEntity<AgentAuthOutputVO> agentAuthWrongAuthenticateResp(@RequestBody AgentAuthInputVO agentAuthInputVO);
}
