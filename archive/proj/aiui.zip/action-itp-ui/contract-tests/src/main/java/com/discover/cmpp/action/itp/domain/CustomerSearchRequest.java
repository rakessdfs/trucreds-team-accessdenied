package com.discover.cmpp.action.itp.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerSearchRequest {
    private String dateOfBirth;
    private String firstName;
    private String lastName;
    private String peidOrSubscriberId;
}
