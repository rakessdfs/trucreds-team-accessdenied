package com.discover.cmpp.action.itp.controller;

import com.discover.cmpp.action.itp.domain.MemoResponse;
import feign.Headers;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Headers({"Content-Type: application/json", "Accept: application/json"})
public interface FetchMemosClient {

    @RequestMapping(
            headers = "HTTP_AUTH_TOKEN=WTv2token",
            method = RequestMethod.GET,
            path = "/enterprise/products/action/itp/v1/memo/{productEnrollmentId}",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    MemoResponse fetchMemos(@PathVariable String productEnrollmentId);

    @RequestMapping(
            headers = "HTTP_AUTH_TOKEN=WTv2token",
            method = RequestMethod.GET,
            path = "/enterprise/products/action/itp/v1/notfound/memo/{productEnrollmentId}",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    MemoResponse fetchMemos404(@PathVariable String productEnrollmentId);
}
