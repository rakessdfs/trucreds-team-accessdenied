package com.discover.cmpp.action.itp.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.sql.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MembershipResponse {

    private String subscriberNumber;
    private Date enrollmentDate;
    private String enrollmentStatus;
    private String enrollmentFailedReason;
    private Date cancellationDate;
    private Date cancellationRequestDate;
    private BigDecimal productEnrollmentId;
    private String customerType;
    private String partyId;
}
