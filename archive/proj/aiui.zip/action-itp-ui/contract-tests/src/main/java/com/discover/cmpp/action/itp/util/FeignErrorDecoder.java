package com.discover.cmpp.action.itp.util;

import feign.Response;
import feign.codec.ErrorDecoder;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpClientErrorException;

public class FeignErrorDecoder  implements ErrorDecoder {

    @Override
    public Exception decode(String methodKey, Response response) {

        if (response.status() == 400 || response.status() == 401) {
            HttpClientErrorException httpClientErrorException = new HttpClientErrorException(HttpStatus.valueOf(response.status()),
                    "");
            return httpClientErrorException;
        }

        if (response.status() > 401 && response.status() <= 599) {
            return new HttpClientErrorException(HttpStatus.valueOf(response.status()),
                    response.body().toString());
        }
        return new Exception(response.reason());
    }
}