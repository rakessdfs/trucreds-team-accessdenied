package com.discover.cmpp.action.itp.controller;

import com.discover.cmpp.action.itp.domain.RecordCallRequest;
import feign.Headers;
import feign.Response;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Headers({"Content-Type: application/json", "Accept: application/json"})
public interface RecordCallClient {

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=testRACF"},
            method = RequestMethod.GET,
            path = "/enterprise/products/action/itp/v1/recordCall",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    Response recordCall(@RequestHeader String agentId, @RequestBody RecordCallRequest request);
}
