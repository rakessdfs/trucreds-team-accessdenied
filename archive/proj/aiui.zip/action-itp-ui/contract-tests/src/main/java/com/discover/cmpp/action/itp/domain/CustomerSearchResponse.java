package com.discover.cmpp.action.itp.domain;

import lombok.Data;

import java.util.List;

@Data
public class CustomerSearchResponse {

    private List<CustomerPii> customers;
}
