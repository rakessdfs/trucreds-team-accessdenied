package com.discover.cmpp.action.itp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@SpringBootApplication
@EnableAspectJAutoProxy
@EnableFeignClients
public class ActionITPApplication {

    public static void main(String[] args) {
        SpringApplication.run(ActionITPApplication.class, args);
    }
}
