package com.discover.cmpp.action.itp.domain;

import lombok.Data;

@Data
public class CreateMemoRequest {

    private String memoText;
    private String productEnrollmentId;
}
