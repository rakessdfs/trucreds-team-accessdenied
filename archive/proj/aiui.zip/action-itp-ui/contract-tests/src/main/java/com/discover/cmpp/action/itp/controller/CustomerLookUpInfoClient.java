package com.discover.cmpp.action.itp.controller;

import com.discover.cmpp.action.itp.domain.AgentAuthOutputVO;
import com.discover.cmpp.action.itp.domain.BillingResponse;
import com.discover.cmpp.action.itp.domain.CustomerInfoResponse;
import com.discover.cmpp.action.itp.domain.MembershipResponse;
import feign.Headers;
import feign.Response;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Headers({"Content-Type: application/json", "Accept: application/json"})
public interface CustomerLookUpInfoClient {

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=testRACF"},
            method = RequestMethod.GET,
            path = "/enterprise/products/action/itp/v1/customer/pii",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    CustomerInfoResponse customerInfo(@RequestHeader String agentId, @RequestParam("party-id") String partyId);

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=nullAgentID"},
            method = RequestMethod.GET,
            path = "/enterprise/products/action/itp/v1/customer/pii",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    CustomerInfoResponse customerInfo400(@RequestHeader String agentId, @RequestParam("party-id") String partyId);

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token"},
            method = RequestMethod.GET,
            path = "/enterprise/products/action/itp/v1/notfound/pii",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    CustomerInfoResponse customerInfo404();

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=testRACF500"},
            method = RequestMethod.GET,
            path = "/enterprise/products/action/itp/v1/customer/pii",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    CustomerInfoResponse customerInfo500(@RequestHeader String agentId, @RequestParam("party-id") String partyId);
}
