package com.discover.cmpp.action.itp.controller;

import feign.Headers;
import feign.Response;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Headers({"Content-Type: application/json", "Accept: application/json"})
public interface CancelEnrollmentClient {

    @PostMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=testRACF"},
            path = "/enterprise/products/action/itp/v1/cancel/membership",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    Response cancelEnrollment(@RequestHeader String agentId, @RequestParam("cancelReasonCode") String reasonCode,
                              @RequestParam("productEnrollmentId") String peid);
}
