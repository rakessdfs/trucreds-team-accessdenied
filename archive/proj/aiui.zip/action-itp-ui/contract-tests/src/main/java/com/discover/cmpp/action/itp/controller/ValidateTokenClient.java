package com.discover.cmpp.action.itp.controller;

import com.discover.cmpp.action.itp.domain.ValidateTokenInputVO;
import com.discover.cmpp.action.itp.domain.ValidateTokenOutputVO;
import feign.Headers;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Headers({"Content-Type: application/json", "Accept: application/json"})
public interface ValidateTokenClient {

    @RequestMapping(headers = "HTTP_AUTH_TOKEN=WTv2token",
            method = RequestMethod.POST,
            path = "/enterprise/products/action/itp/v1/agent/token/validate",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE)
    ValidateTokenOutputVO validateTokenResp(@RequestBody ValidateTokenInputVO validateTokenInputVO);

    @RequestMapping(headers = "HTTP_AUTH_TOKEN=WTv2token",
            method = RequestMethod.POST,
            path = "/enterprise/products/action/itp/v1/agent/token/wrong-validate-endpoint",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE)
    ValidateTokenOutputVO validateTokenWrongEndpointResp(@RequestBody ValidateTokenInputVO validateTokenInputVO);
}
