package com.discover.cmpp.action.itp.controller;

import com.discover.cmpp.action.itp.domain.CreateMemoRequest;
import feign.Headers;
import feign.Response;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Headers({"Content-Type: application/json", "Accept: application/json"})
public interface CreateMemoClient {

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=testRACF"},
            method = RequestMethod.POST,
            path = "/enterprise/products/action/itp/v1/memo",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    Response createMemo(@RequestHeader String agentId, @RequestBody CreateMemoRequest request);

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=invalidID"},
            method = RequestMethod.POST,
            path = "/enterprise/products/action/itp/v1/memo",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    Response createMemoAgentId(@RequestHeader String agentId, @RequestBody CreateMemoRequest request);

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=5"},
            method = RequestMethod.POST,
            path = "/enterprise/products/action/itp/v1/memo",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    Response createMemoPEID(@RequestHeader String agentId, @RequestBody CreateMemoRequest request);

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=6"},
            method = RequestMethod.POST,
            path = "/enterprise/products/action/itp/v1/memo",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    Response createMemoTextError(@RequestHeader String agentId, @RequestBody CreateMemoRequest request);

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=testRACF500"},
            method = RequestMethod.POST,
            path = "/enterprise/products/action/itp/v1/memo",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    Response createMemo500(@RequestHeader String agentId, @RequestBody CreateMemoRequest request);

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=testRACF"},
            method = RequestMethod.POST,
            path = "/enterprise/products/action/itp/v1/notfound/memo",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    Response createMemo404(@RequestHeader String agentId, @RequestBody CreateMemoRequest request);
}
