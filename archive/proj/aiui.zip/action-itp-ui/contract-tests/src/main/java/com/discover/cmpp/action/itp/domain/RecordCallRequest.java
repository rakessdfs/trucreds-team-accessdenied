package com.discover.cmpp.action.itp.domain;

import lombok.Data;

@Data
public class RecordCallRequest {

    private String productEnrollmentId;
    private String customerType;
    private String tagType;
}