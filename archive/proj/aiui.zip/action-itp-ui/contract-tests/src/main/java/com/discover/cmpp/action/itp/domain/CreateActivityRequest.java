package com.discover.cmpp.action.itp.domain;

import lombok.Data;

@Data
public class CreateActivityRequest {

    private String productEnrollmentId;
    private String activityCode;
    private String previousData;
    private String newData;
    private String operator;
    private String requestDate;
}
