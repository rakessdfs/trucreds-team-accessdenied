package com.discover.cmpp.action.itp.domain;

import lombok.Data;

@Data
public class BillingResponse {

    private String pcmFirstName;
    private String pcmLastName;
    private String pcmAccountNumber;
    private String presenceOfSecondary;
    private String nextBillingDate;
}
