package com.discover.cmpp.action.itp.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Address {

    private String barCode;
    private String cityName;
    private String countryCode;
    private String postalCode;
    private String addressLine1;
    private String addressLine2;
    private String stateOrSectionCode;
    private boolean forbidAutoFormatting;
}
