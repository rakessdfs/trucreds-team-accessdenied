package com.discover.cmpp.action.itp.domain;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MemoDto {

    private Long memoId;
    private String productEnrollmentId;
    private String memoText;
    private String createAgentId;
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime createTs;
    private String updateAgentId;
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime updateTs;
}
