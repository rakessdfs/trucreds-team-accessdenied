package com.discover.cmpp.action.itp.controller;

import com.discover.cmpp.action.itp.domain.AccountActivityResponse;
import feign.Headers;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Headers({"Content-Type: application/json", "Accept: application/json"})
public interface FetchAccountActivityClient {

    @RequestMapping(
            headers = "HTTP_AUTH_TOKEN=WTv2token",
            method = RequestMethod.GET,
            path = "/enterprise/products/action/itp/v1/accountActivity/{productEnrollmentId}",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    AccountActivityResponse fetchAccountActivity(@PathVariable String productEnrollmentId);

    @RequestMapping(
            headers = "HTTP_AUTH_TOKEN=WTv2token",
            method = RequestMethod.GET,
            path = "/enterprise/products/action/itp/v1/notfound/accountActivity/{productEnrollmentId}",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    AccountActivityResponse fetchAccountActivity404(@PathVariable String productEnrollmentId);
}
