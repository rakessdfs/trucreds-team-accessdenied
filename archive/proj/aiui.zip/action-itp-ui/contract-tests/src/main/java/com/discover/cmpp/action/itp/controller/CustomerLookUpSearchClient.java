package com.discover.cmpp.action.itp.controller;

import com.discover.cmpp.action.itp.domain.CustomerSearchRequest;
import com.discover.cmpp.action.itp.domain.CustomerSearchResponse;
import feign.Headers;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Headers({"Content-Type: application/json", "Accept: application/json"})
public interface CustomerLookUpSearchClient {

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=testRACF"},
            method = RequestMethod.POST,
            path = "/enterprise/products/action/itp/v1/customer/search",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    CustomerSearchResponse customerSearch(@RequestHeader String agentId, @RequestBody CustomerSearchRequest request);

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=nullAgentID"},
            method = RequestMethod.POST,
            path = "/enterprise/products/action/itp/v1/customer/search",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    CustomerSearchResponse customerSearch400NullAgentID(@RequestHeader String agentId, @RequestBody CustomerSearchRequest request);

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=invalidReq"},
            method = RequestMethod.POST,
            path = "/enterprise/products/action/itp/v1/customer/search",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    CustomerSearchResponse customerSearch400InvalidReq(@RequestHeader String agentId, @RequestBody CustomerSearchRequest request);

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=testRACF"},
            method = RequestMethod.POST,
            path = "/enterprise/products/action/itp/v1/notfound/search",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    CustomerSearchResponse customerSearch404(@RequestHeader String agentId, @RequestBody CustomerSearchRequest request);

    @RequestMapping(
            headers = {"HTTP_AUTH_TOKEN=WTv2token", "X-DFSUSER-USER-ID=testRACF500"},
            method = RequestMethod.POST,
            path = "/enterprise/products/action/itp/v1/customer/search",
            consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE
    )
    CustomerSearchResponse customerSearch500(@RequestHeader String agentId, @RequestBody CustomerSearchRequest request);
}
