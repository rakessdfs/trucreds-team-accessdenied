package com.discover.cmpp.action.itp.config;

import com.discover.cmpp.action.itp.controller.*;
import com.discover.cmpp.action.itp.util.FeignErrorDecoder;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.Feign;
import feign.Retryer;
import feign.jackson.JacksonDecoder;
import feign.jackson.JacksonEncoder;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
import org.springframework.cloud.openfeign.support.SpringDecoder;
import org.springframework.cloud.openfeign.support.SpringMvcContract;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@RefreshScope
public class FeignClientConfig {

    private ObjectFactory<HttpMessageConverters> messageConverters;

    private static final String LOCALHOST = "http://localhost:";

    public FeignClientConfig(ObjectFactory<HttpMessageConverters> messageConverters) {
        this.messageConverters = messageConverters;
    }

    @Bean
    public AgentAuthClient authenticateAgentActionItpClient(
            @Value("${stubrunner.runningstubs.action-itp-api.port}") String url) {
        return Feign.builder()
                .contract(new SpringMvcContract())
                .retryer(Retryer.NEVER_RETRY)
                .encoder(new JacksonEncoder())
                .decoder(new ResponseEntityDecoder(new SpringDecoder(messageConverters)))
                .errorDecoder(new FeignErrorDecoder())
                .target(AgentAuthClient.class, LOCALHOST + url);
    }

    @Bean
    public ValidateTokenClient validateTokenActionItpClient(
            @Value("${stubrunner.runningstubs.action-itp-api.port}") String url) {
        return Feign.builder()
                .contract(new SpringMvcContract())
                .retryer(Retryer.NEVER_RETRY)
                .encoder(new JacksonEncoder(new ObjectMapper().setSerializationInclusion(JsonInclude.Include.ALWAYS)))
                .decoder(new JacksonDecoder())
                .errorDecoder(new FeignErrorDecoder())
                .target(ValidateTokenClient.class, LOCALHOST + url);
    }

    @Bean
    public FetchMemosClient fetchMemosClient(
            @Value("${stubrunner.runningstubs.action-itp-api.port}") String url) {
        return Feign.builder()
                .contract(new SpringMvcContract())
                .retryer(Retryer.NEVER_RETRY)
                .encoder(new JacksonEncoder())
                .decoder(new JacksonDecoder())
                .errorDecoder(new FeignErrorDecoder())
                .target(FetchMemosClient.class, LOCALHOST + url);
    }

    @Bean
    public CreateMemoClient createMemoClient(
            @Value("${stubrunner.runningstubs.action-itp-api.port}") String url) {
        return Feign.builder()
                .contract(new SpringMvcContract())
                .retryer(Retryer.NEVER_RETRY)
                .encoder(new JacksonEncoder())
                .decoder(new JacksonDecoder())
                .errorDecoder(new FeignErrorDecoder())
                .target(CreateMemoClient.class, LOCALHOST + url);
    }

    @Bean
    public FetchAccountActivityClient fetchAccountActivityClient(
            @Value("${stubrunner.runningstubs.action-itp-api.port}") String url) {
        return Feign.builder()
                .contract(new SpringMvcContract())
                .retryer(Retryer.NEVER_RETRY)
                .encoder(new JacksonEncoder())
                .decoder(new JacksonDecoder())
                .errorDecoder(new FeignErrorDecoder())
                .target(FetchAccountActivityClient.class, LOCALHOST + url);
    }

    @Bean
    public CreateAccountActivityClient createAccountActivityClient(
            @Value("${stubrunner.runningstubs.action-itp-api.port}") String url) {
        return Feign.builder()
                .contract(new SpringMvcContract())
                .retryer(Retryer.NEVER_RETRY)
                .encoder(new JacksonEncoder())
                .decoder(new JacksonDecoder())
                .errorDecoder(new FeignErrorDecoder())
                .target(CreateAccountActivityClient.class, LOCALHOST + url);
    }

    @Bean
    public FetchMembershipClient fetchMembershipClient(
            @Value("${stubrunner.runningstubs.action-itp-api.port}") String url) {
        return Feign.builder()
                .contract(new SpringMvcContract())
                .retryer(Retryer.NEVER_RETRY)
                .encoder(new JacksonEncoder())
                .decoder(new JacksonDecoder())
                .errorDecoder(new FeignErrorDecoder())
                .target(FetchMembershipClient.class, LOCALHOST + url);
    }

    @Bean
    public CustomerLookUpInfoClient customerLookUpInfoClient(
            @Value("${stubrunner.runningstubs.action-itp-api.port}") String url) {
        return Feign.builder()
                .contract(new SpringMvcContract())
                .retryer(Retryer.NEVER_RETRY)
                .encoder(new JacksonEncoder())
                .decoder(new JacksonDecoder())
                .errorDecoder(new FeignErrorDecoder())
                .target(CustomerLookUpInfoClient.class, LOCALHOST + url);
    }

    @Bean
    public CustomerLookUpSearchClient customerLookUpSearchClient(
            @Value("${stubrunner.runningstubs.action-itp-api.port}") String url) {
        return Feign.builder()
                .contract(new SpringMvcContract())
                .retryer(Retryer.NEVER_RETRY)
                .encoder(new JacksonEncoder(new ObjectMapper().setSerializationInclusion(JsonInclude.Include.ALWAYS)))
                .decoder(new JacksonDecoder())
                .errorDecoder(new FeignErrorDecoder())
                .target(CustomerLookUpSearchClient.class, LOCALHOST + url);
    }

    @Bean
    public RecordCallClient recordCallClient(
            @Value("${stubrunner.runningstubs.action-itp-api.port}") String url) {
        return Feign.builder()
                .contract(new SpringMvcContract())
                .retryer(Retryer.NEVER_RETRY)
                .encoder(new JacksonEncoder(new ObjectMapper().setSerializationInclusion(JsonInclude.Include.ALWAYS)))
                .decoder(new JacksonDecoder())
                .errorDecoder(new FeignErrorDecoder())
                .target(RecordCallClient.class, LOCALHOST + url);
    }

    @Bean
    public CancelEnrollmentClient cancelEnrollmentClient(
            @Value("${stubrunner.runningstubs.action-itp-api.port}") String url) {
        return Feign.builder()
                .contract(new SpringMvcContract())
                .retryer(Retryer.NEVER_RETRY)
                .encoder(new JacksonEncoder(new ObjectMapper().setSerializationInclusion(JsonInclude.Include.ALWAYS)))
                .decoder(new JacksonDecoder())
                .errorDecoder(new FeignErrorDecoder())
                .target(CancelEnrollmentClient.class, LOCALHOST + url);
    }
}
