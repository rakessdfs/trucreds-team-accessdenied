package com.discover.cmpp.action.itp.domain;

import lombok.Data;

@Data
public class CustomerPii {
    private String firstName;
    private String lastName;
    private String partyId;
    private String ssn;
}
