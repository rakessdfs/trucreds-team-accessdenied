package com.discover.cmpp.action.itp.domain;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ValidateTokenInputVO {
    String jwtToken;
}
