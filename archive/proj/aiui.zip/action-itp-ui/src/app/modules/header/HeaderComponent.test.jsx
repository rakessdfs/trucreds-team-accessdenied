import React from 'react';
import { screen, fireEvent } from '@testing-library/react';
import { renderContainer } from 'src/app/common/utils/test-utils';
import thunk from 'redux-thunk';
import createMockStore from 'redux-mock-store';
import userEvent from '@testing-library/user-event';
import { getAuthCookie, setAuthCookie } from '../login/LoginUtils';
import { HeaderComponent } from './HeaderComponent';

describe('HeaderComponent', () => {
    let initialState, store, dashboardState, onBackToSearchClickMock;

    beforeEach(() => {
        initialState = {
            user: {
                data: {
                    isAuthenticated: true,
                    userName: 'SOME_USERNAME',
                    fullName: 'Some FullName',
                    email: 'someEmail'
                }
            }
        };
        dashboardState = 'verifyInfo';
        onBackToSearchClickMock = jest.fn();
    });

    const setupRTL = () => {
        store = createMockStore([thunk])(initialState);
        return renderContainer(
            <HeaderComponent
                dashboardState={dashboardState}
                onBackToSearchClick={onBackToSearchClickMock}
            />, {
                store
            });
    };

    test('Cookies are cleared when sign out button is clicked', () => {
        setupRTL();
        const headers = { authorization: 'jwtToken' };
        setAuthCookie(headers);

        const button = screen.getByText('Sign Out');

        expect(getAuthCookie()).toEqual('jwtToken');
        fireEvent.click(button);
        expect(getAuthCookie()).toBeUndefined();
    });

    test('Cookies are cleared when window is closed', () => {
        setupRTL();
        const headers = { authorization: 'jwtToken' };
        setAuthCookie(headers);

        expect(getAuthCookie()).toEqual('jwtToken');
        window.dispatchEvent(new Event('beforeunload'));
        expect(getAuthCookie()).toBeUndefined();
    });

    test('HeaderComponent renders text Identity Theft Protection', () => {
        setupRTL();
        expect(screen.getByText('Identity Theft Protection')).toBeInTheDocument();
    });

    test('HeaderComponent renders text \'Welcome {user}\' ', () => {
        setupRTL();

        expect(screen.getByText('Welcome, Some FullName')).toBeInTheDocument();
    });

    describe('Back to Search Button', () => {
        test('is not rendered if dashboardState is customerSearch', () => {
            dashboardState = 'customerSearch';

            setupRTL();

            expect(screen.queryByRole('button', { name: 'Back to Search' })).not.toBeInTheDocument();
        });

        test('is rendered when dashboardState is anything else', () => {
            dashboardState = 'verifyInfo';

            setupRTL();

            userEvent.click(screen.getByRole('button', { name: 'Back to Search' }));

            expect(onBackToSearchClickMock).toHaveBeenCalled();
        });
    });

    test('HeaderComponent renders Sign Out button', () => {
        setupRTL();

        expect(screen.getByRole('button', { name: 'Sign Out' })).toBeInTheDocument();
    });
});