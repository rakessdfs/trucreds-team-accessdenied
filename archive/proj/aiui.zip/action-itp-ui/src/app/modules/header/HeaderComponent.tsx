import React, { ReactElement } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { StateValue } from 'xstate';
import { IReduxState } from '../../store/Store.types';
import Logo from '../../assets/Action_LOGO_black.svg';
import { attemptLogout } from '../login/Login.actions';
import { removeAuthCookie } from '../login/LoginUtils';
import styles from './Header.module.scss';

interface IHeaderComponentProps {
    onBackToSearchClick: () => void;
    dashboardState: StateValue;
}

export const HeaderComponent = ({ onBackToSearchClick, dashboardState }: IHeaderComponentProps): ReactElement => {
    const { data } = useSelector((state: IReduxState) => state.user);
    const dispatch = useDispatch();

    const logoutHandler = (event: React.FormEvent): void => {
        event.preventDefault();
        dispatch(attemptLogout({
            message: [],
            cause: []
        }));
    };

    const useUnload = (fn: (event: BeforeUnloadEvent) => void): void => {
        const cb = React.useRef(fn);

        React.useEffect(() => {
            const windowCloseHandler = cb.current;
            window.addEventListener('beforeunload', windowCloseHandler);
            return (): void => window.removeEventListener('beforeunload', windowCloseHandler);
        }, [cb]);
    };

    useUnload((event: BeforeUnloadEvent): void => {
        event.preventDefault();
        removeAuthCookie();
    });

    return (
        <div className={styles.headerContainer}>
            <div className={styles.logoContainer}>
                <img
                    src={Logo}
                    alt=''
                />
                <p>Identity Theft Protection</p>
            </div>
            <div className={styles.welcomeContainer}>
                <p>Welcome, {data?.fullName}</p>
                {dashboardState !== 'customerSearch' && (
                    <button
                        onClick={(): void => onBackToSearchClick()}
                        className={styles.backToSearchButton}
                    >
                        Back to Search
                    </button>
                )}
                <button
                    data-testid='signout-button'
                    onClick={logoutHandler}
                >
                    Sign Out
                </button>
            </div>
        </div>
    );
};