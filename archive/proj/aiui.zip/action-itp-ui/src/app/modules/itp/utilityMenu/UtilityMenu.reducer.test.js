import { buildReduxError } from '../../../common/utils/ITPUtils';
import { resetData } from '../account-lookup/AccountLookup/CustomerPII.actions';
import { createMemoReducer } from './UtilityMenu.reducer';
import { createMemoFailure, createMemoRequest, createMemoSuccess } from './UtilityMenu.actions';

describe('createMemoReducer', () => {
    let initialState;

    beforeEach(() => {
        initialState = {
            error: null,
            isFetching: false,
            data: {
                memoText: '',
                productEnrollmentId: '',
                createdSuccessfully: false
            }
        };
    });

    describe('createMemoRequest', () => {
        test('set data correctly', () => {
            const requestData = {
                memoText: 'test memo',
                productEnrollmentId: '123456778',
                createdSuccessfully: false
            };

            expect(createMemoReducer(initialState, createMemoRequest(requestData))).toEqual({
                ...initialState,
                isFetching: true,
                data: {
                    ...initialState.data,
                    memoText: 'test memo',
                    productEnrollmentId: '123456778',
                    createdSuccessfully: false
                }
            }
            );
        });
    });

    describe('createMemoSuccess', () => {
        beforeEach(() => {
            initialState = {
                ...initialState,
                data: {
                    ...initialState.data,
                    memoText: '',
                    productEnrollmentId: '',
                    createdSuccessfully: true
                }
            };
        });

        test('create the memo successfully', () => {
            expect(createMemoReducer(initialState, createMemoSuccess())).toEqual({
                ...initialState,
                data: {
                    memoText: '',
                    productEnrollmentId: '',
                    createdSuccessfully: true
                }
            });
        });
    });

    describe('createMemoFailure', () => {
        test('Error creating memo', () => {
            expect(createMemoReducer(initialState, createMemoFailure(buildReduxError('some custom error', '')))).toEqual({
                ...initialState,
                isFetching: false,
                error: {
                    cause: [''],
                    message: ['some custom error']
                },
                data: null
            });
        });
    });

    describe('resetData', () => {
        test('sets the state correctly', () => {
            expect(createMemoReducer(initialState, resetData())).toEqual({
                ...initialState,
                data: null,
                isFetching: false,
                error: null
            });
        });
    });
});