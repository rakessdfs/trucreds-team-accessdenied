import React, { ReactElement } from 'react';
import { buildClasses } from '../../../../common/utils/ITPUtils';
import styles from './AccountLookup.module.scss';

interface IErrorSectionProps {
    errors: string[];
    className?: string;
}

export const ErrorSection = ({ errors, className }: IErrorSectionProps): ReactElement => {
    const errorContent: ReactElement[] = [];

    errors.forEach((error: string) => {
        const temp = (
            <p
                key={error}
                className={styles.mandatory}
            >{error}<br /></p>
        );
        errorContent.push(temp);
    });

    return (
        <div
            data-testid='error-container'
            className={buildClasses([styles.errorContainer, className])}
        >
            {errorContent}
        </div>
    );
};