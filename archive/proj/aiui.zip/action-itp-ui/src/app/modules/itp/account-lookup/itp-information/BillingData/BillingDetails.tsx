import React, { ReactElement, useEffect } from 'react';
import './ItpDataComponent.scss';
import { useDispatch, useSelector } from 'react-redux';
import ReactTooltip from 'react-tooltip';
import CopyToClipboard from 'react-copy-to-clipboard';
import * as ItpInformationConstants from '../ItpInformationConstants';
import { IReduxState } from '../../../../../store/Store.types';
import { CircularSpinner } from '../../../../../common/Components/CircularSpinner/CircularSpinner';
import { ErrorSection } from '../../AccountLookup/ErrorSection';
import * as CONSTANTS from '../../../../../common/constants/ITPConstants';
import { toggles } from '../../../../../common/toggle/toggles';
import { toggleNames } from '../../../../../common/toggle/toggleNames';
import { FeatureToggle, FeatureToggleProvider } from '../../../../../common/toggle';
import { errorHandling, formatDate } from '../../../../../common/utils/ITPUtils';
import { IBillingState } from './BillingState.types';
import { fetchBillingData } from './BillingData.actions';

export const BillingDetails = (): ReactElement | null => {
    const dispatch = useDispatch();
    const { data, error, isFetching } = useSelector((state: IReduxState) => state.billingData);
    const { isFetching: isItpDataFetching } = useSelector((state: IReduxState) => state.itpEnrollmentData);
    const standingCode = useSelector((state: IReduxState) => state.itpEnrollmentData.data?.standingCode);
    const customerType = useSelector((state: IReduxState) => state.itpEnrollmentData.data?.customerType);
    const isBmCustomer = (customerType === CONSTANTS.ITP_BM || customerType === CONSTANTS.ITP_BM_FREE);

    useEffect(() => {
        if (!isItpDataFetching) {
            dispatch(fetchBillingData());
        }
    }, [dispatch, isItpDataFetching]);

    if (isFetching || isItpDataFetching) {
        return <CircularSpinner isButton={false} />;
    } else if (error) {
        return (
            <ErrorSection errors={errorHandling(undefined, false, false,
                false, [error])}
            />
        );
    } else if (isBmCustomer && data?.nextBillingDate === null &&
        (standingCode === CONSTANTS.PENDING_CANCELLATION_CODE || standingCode === CONSTANTS.CANCELLATION_CODE)) {
        return (
            <div className='enrollmentDetailsSection'>
                <ErrorSection
                    className='billingMessage'
                    errors={errorHandling(undefined, false, false,
                        false,
                        [{
                            cause: ['5001'],
                            message: [CONSTANTS.BILLING_INFORMATION_WARNING]
                        }])}
                />
            </div>
        );
    } else if (!data) {
        return null;
    } else {
        const { pcmFirstName, pcmLastName, pcmAccountNumber, presenceOfSecondary, nextBillingDate } = (data as IBillingState);

        return (
            <div className='enrollmentDetailsSection'>
                <h3 className='enrollmentDetailsHeader'>{ItpInformationConstants.BILLING_DETAILS}</h3>
                <section>
                    <div className='enrollmentDetailsRow'>
                        <p className='enrollmentDetailsHData'>{ItpInformationConstants.PCM_FIRST_NAME}</p>
                        <p className='enrollmentDetailsData'>{isBmCustomer ? CONSTANTS.NOT_AVAILABLE_ACRONYM : pcmFirstName}</p>
                    </div>
                    <div className='enrollmentDetailsRow'>
                        <p className='enrollmentDetailsHData'>{ItpInformationConstants.PCM_LAST_NAME}</p>
                        <p className='enrollmentDetailsData'>{isBmCustomer ? CONSTANTS.NOT_AVAILABLE_ACRONYM : pcmLastName}</p>
                    </div>
                    <div className='enrollmentDetailsRow'>
                        <p className='enrollmentDetailsHData'>{ItpInformationConstants.PCM_ACCOUNT}</p>
                        { isBmCustomer && <p className='enrollmentDetailsData'>{CONSTANTS.NOT_AVAILABLE_ACRONYM}</p> }
                        { customerType === CONSTANTS.ITP_FF && pcmAccountNumber &&
                            <CopyToClipboard
                                text={pcmAccountNumber || ItpInformationConstants.NO_ACCOUNT_TO_COPY}
                                data-testid='clipboard-testid'
                            >
                                <div data-tip='Copy to clipboard'>
                                    <ReactTooltip
                                        type='info'
                                        effect='solid'
                                        place='bottom'
                                    />
                                    <u><p className='enrollmentDetailsData'>{pcmAccountNumber}</p></u>
                                </div>
                            </CopyToClipboard>
                        }
                    </div>
                    <div className='enrollmentDetailsRow'>
                        <p className='enrollmentDetailsHData'>{ItpInformationConstants.SCM_AU_ON_ACCOUNT}</p>
                        <p className='enrollmentDetailsData'>{isBmCustomer ? CONSTANTS.NOT_AVAILABLE_ACRONYM : presenceOfSecondary}</p>
                    </div>
                    { isBmCustomer &&
                    <FeatureToggleProvider featureToggleList={toggles}>
                        <FeatureToggle featureName={toggleNames.SHOW_LAST_AND_NEXT_BILLING_DATE}>
                            <div className='enrollmentDetailsRow'>
                                <p className='enrollmentDetailsHData'>{ItpInformationConstants.NEXT_BILLING_DATE}</p>
                                <p className='enrollmentDetailsData'>{(customerType === CONSTANTS.ITP_BM && nextBillingDate) ? formatDate(nextBillingDate) : CONSTANTS.NOT_AVAILABLE }</p>
                            </div>
                        </FeatureToggle>
                    </FeatureToggleProvider>
                    }
                </section>
            </div>
        );
    }
};