import axios from 'axios';
import { ThunkDispatch } from 'redux-thunk';
import { IReduxState } from 'src/app/store/Store.types';
import Moment from 'moment';
import {
    URL_ACTION_ITP_API_HOSTNAME,
    URL_ACTION_ITP_API_HOSTNAME_LOCAL,
    URL_ACTION_ITP_FETCH_MEMO_CONTEXT
} from '../../../../../../common/constants/ITPConstants';
import { IReduxError } from '../../../../../../common/types';
import { formatDateInEST, validateResponse } from '../../../../../../common/utils/ITPUtils';
import { getAuthCookie } from '../../../../../login/LoginUtils';
import { attemptLogout } from '../../../../../login/Login.actions';
import {
    IFetchMemoFailureAction,
    IFetchMemoRequest,
    IFetchMemoRequestAction,
    IFetchMemoSuccessAction,
    IMemo,
    IMemoData,
    IMemoGroup,
    IMemoResponse
} from './MemoPreview.types';
import {
    DATE_FORMAT,
    FETCH_MEMO_FAILURE,
    FETCH_MEMO_REQUEST,
    FETCH_MEMO_SUCCESS,
    HOUR_FORMAT, MONTH_YEAR_FORMAT
} from './MemoPreviewConstants';

export const fetchMemoSuccess = (response: IMemoData): IFetchMemoSuccessAction => ({
    type: FETCH_MEMO_SUCCESS,
    payload: response
});

export const fetchMemoFailure = (error: IReduxError): IFetchMemoFailureAction => ({
    type: FETCH_MEMO_FAILURE,
    payload: error
});

export const fetchMemoRequest = ({ productEnrollmentId }: IFetchMemoRequest): IFetchMemoRequestAction => ({
    type: FETCH_MEMO_REQUEST,
    payload: {
        productEnrollmentId
    }
});

export const buildIMemo = (createAgentId: string, memoText: string, createDate: string, createTime: string, createMonth: string): IMemo => ({
    MEMO_TEXT: memoText,
    CREATE_AGENT_ID: createAgentId,
    CREATE_DATE: createDate,
    CREATE_TIME: createTime,
    CREATE_MONTH: createMonth
});

export const buildIMemoGroup = (month: string, memos: IMemo[]): IMemoGroup => ({
    month: month,
    memos: memos
});

export const buildIMemoData = (allMemos: IMemoGroup[]): IMemoData => ({
    allMemos: allMemos
});

export const extractMemos = (response: IMemoResponse): IMemoData => {
    const memoList: IMemo[] = [];
    const months: string[] = [];
    const memoGroupList: IMemoGroup[] = [];
    response.memosList.forEach((memo) => {
        memo.createTs = formatDateInEST(memo.createTs);
        memoList.push(buildIMemo(memo.createAgentId, memo.memoText, Moment(memo.createTs).format(DATE_FORMAT), Moment(memo.createTs).format(HOUR_FORMAT), Moment(memo.createTs).format(MONTH_YEAR_FORMAT)));
        if (months.indexOf(Moment(memo.createTs).format(MONTH_YEAR_FORMAT)) === -1) {
            months.push(Moment(memo.createTs).format(MONTH_YEAR_FORMAT));
        }
    });
    months.forEach((month) => {
        memoGroupList.push(buildIMemoGroup(month, memoList.filter((memo) => memo.CREATE_MONTH === month)));
    });
    return buildIMemoData(memoGroupList);
};

export const attemptFetchMemoRequest = (productEnrollmentId: string | number) => {
    return async (dispatch: ThunkDispatch<IReduxState, unknown, IFetchMemoRequestAction | IFetchMemoFailureAction | IFetchMemoSuccessAction>): Promise<void> => {
        dispatch(fetchMemoRequest({
            productEnrollmentId
        }));
        let response;

        try {
            response = await axios({
                method: 'get',
                url: `${(URL_ACTION_ITP_API_HOSTNAME || URL_ACTION_ITP_API_HOSTNAME_LOCAL)}${URL_ACTION_ITP_FETCH_MEMO_CONTEXT}${productEnrollmentId}`,
                headers: {
                    Authorization: `Bearer ${getAuthCookie()}`
                }
            });

            const error = validateResponse(response, 'memo');

            if (error) {
                dispatch(fetchMemoFailure(error));
                return;
            }
        } catch (e) {
            if (e.response?.status === 401) {
                dispatch(attemptLogout((validateResponse(e.response, 'memo') as IReduxError)));
                return;
            }
            dispatch(fetchMemoFailure((validateResponse(e.response, 'memo') as IReduxError)));
            return;
        }
        dispatch(fetchMemoSuccess(extractMemos(response?.data)));
    };
};