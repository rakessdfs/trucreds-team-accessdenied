import { buildReduxError } from '../../../../../common/utils/ITPUtils';
import { resetData } from '../../AccountLookup/CustomerPII.actions';
import { itpRecordCallFailure, itpRecordCallRequest, itpRecordCallSuccess } from './RecordCall.actions';
import { itpRecordCallReducer } from './RecordCall.reducer';

describe('itpRecordReducer', () => {
    let initialState;

    beforeEach(() => {
        initialState = {
            error: null,
            isFetching: true,
            data: null
        };
    });

    describe('itpRecordCallRequest', () => {
        test('sets the state correctly', () => {
            const itpRequestData = {
                customerType: '',
                productEnrollmentId: '',
                tagType: ''
            };

            expect(itpRecordCallReducer(initialState, itpRecordCallRequest(itpRequestData))).toEqual({
                ...initialState,
                isFetching: true,
                error: null
            });
        });
    });

    describe('itpRecordCallSuccess', () => {
        beforeEach(() => {
            initialState = {
                ...initialState,
                data: {
                    ...initialState.data
                }
            };
        });

        test('Call  Recording Success', () => {
            expect(itpRecordCallReducer(initialState, itpRecordCallSuccess())).toEqual({
                ...initialState,
                isFetching: false,
                error: null,
                data: {}
            });
        });
    });

    describe('itpRecordCallFailure', () => {
        test('Error recording call', () => {
            expect(itpRecordCallReducer(initialState, itpRecordCallFailure(buildReduxError('some custom error', '')))).toEqual({
                ...initialState,
                isFetching: false,
                error: {
                    cause: [''],
                    message: ['some custom error']
                },
                data: null
            });
        });
    });

    describe('resetData', () => {
        test('sets the state correctly', () => {
            expect(itpRecordCallReducer(initialState, resetData())).toEqual({
                ...initialState,
                data: null,
                isFetching: false,
                error: null
            });
        });
    });
});