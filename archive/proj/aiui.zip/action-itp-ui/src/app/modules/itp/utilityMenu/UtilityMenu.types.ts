import { IReduxError } from '../../../common/types';
export interface ICreateMemoRequest {
    memoText: string;
    productEnrollmentId: string | number;
}

export interface ICreateMemoRequestAction {
    type: 'CREATE_MEMO_REQUEST';
    payload: ICreateMemoRequest;
}

export interface ICreateMemoSuccessAction {
    type: 'CREATE_MEMO_SUCCESS';
    payload: null;
}

export interface ICreateMemoFailureAction {
    type: 'CREATE_MEMO_FAILURE';
    payload: IReduxError;
}

export interface ICreateMemoState {
    memoText: string | null;
    productEnrollmentId: string | null | number;
    createdSuccessfully: boolean;
}

export interface IResetData {
    type: 'RESET_DATA';
}

export type TCreateMemoAction = ICreateMemoRequestAction | ICreateMemoFailureAction | ICreateMemoSuccessAction | IResetData;