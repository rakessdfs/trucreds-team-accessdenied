import { screen } from '@testing-library/react';
import React from 'react';
import createMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import userEvent from '@testing-library/user-event';
import { renderContainer } from '../../../../common/utils/test-utils';
import { RETRIEVING_DATA_ERROR } from '../../../../common/constants/ITPConstants';
import {
    TAGGING_ERROR_HEADER_SERVICING,
    TAGGING_ERROR_SUB_HEADER
} from '../itp-information/cancel/CancelConstants';
import { Verification } from './Verification';
import * as VerificationConstants from './VerificationConstants';

describe('Test Verification component', () => {
    let initialState, store, onSkipMock, onConfirmMock;

    beforeEach(() => {
        onSkipMock = jest.fn();
        onConfirmMock = jest.fn();
        initialState = {
            user: {
                data: {
                    username: 'test'
                }
            },
            pii: {
                data: {
                    ssn: '2345'
                }
            },
            itpEnrollmentData: {
                data: {
                    productEnrollmentId: 'testing123'
                }
            },
            recordCall: {
                data: {
                },
                error: null
            }
        };
    });

    const setupRTL = () => {
        store = createMockStore([thunk])(initialState);
        return renderContainer(
            <Verification
                onSkip={onSkipMock}
                onConfirm={onConfirmMock}
            />, {
                store
            });
    };

    describe('Happy Path', () => {
        test('Render verification static content', () => {
            setupRTL();
            expect(screen.getByText(VerificationConstants.VERIFYING_SECURITY)).toBeInTheDocument();
            expect(screen.getByText(VerificationConstants.VERIFICATION_MESSAGE)).toBeInTheDocument();
            expect(screen.getByText(`${VerificationConstants.VERIFICATION_SSN}: 2345`)).toBeInTheDocument();
            expect(screen.getByText(VerificationConstants.VERIFICATION_SKIP_BTN)).toBeInTheDocument();
            expect(screen.getByText(VerificationConstants.VERIFICATION_VERIFY_BTN)).toBeInTheDocument();
            expect(screen.queryByText(TAGGING_ERROR_HEADER_SERVICING)).not.toBeInTheDocument();
            expect(screen.queryByText(TAGGING_ERROR_SUB_HEADER)).not.toBeInTheDocument();
        });

        test('Render skip button click', () => {
            setupRTL();
            const skipButton = screen.getByRole('button', { name: VerificationConstants.VERIFICATION_SKIP_BTN });

            userEvent.click(skipButton);

            expect(onSkipMock).toHaveBeenCalled();
        });

        test('Render verify button click', () => {
            setupRTL();
            const verifyButton = screen.getByRole('button', { name: VerificationConstants.VERIFICATION_VERIFY_BTN });

            userEvent.click(verifyButton);

            expect(onConfirmMock).toHaveBeenCalled();
        });
    });

    describe('Error State', () => {
        beforeEach(() => {
            initialState = {
                pii: {
                    data: null,
                    isFetching: false
                },
                user: {
                    data: {
                        username: 'test'
                    }
                },
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'testing123'
                    },
                    error: {
                        cause: ['5003']
                    }
                },
                recordCall: {
                    data: {},
                    error: null
                }
            };
        });

        test('Renders loading message', () => {
            setupRTL();
            expect(screen.getByText(RETRIEVING_DATA_ERROR)).toBeInTheDocument();
        });

        test('Renders NonCriticalError when recordCall fails', () => {
            initialState.itpEnrollmentData.error = null;
            initialState.recordCall.error = {
                cause: ['5003']
            };

            setupRTL();
            expect(screen.getByText(TAGGING_ERROR_HEADER_SERVICING)).toBeInTheDocument();
            expect(screen.getByText(TAGGING_ERROR_SUB_HEADER)).toBeInTheDocument();
        });
    });

    describe('Loading State', () => {
        beforeEach(() => {
            initialState = {
                pii: {
                    data: null,
                    isFetching: true
                },
                user: {
                    data: {
                        username: 'test'
                    }
                },
                itpEnrollmentData: {
                    data: null,
                    isFetching: true
                },
                recordCall: {
                    data: {},
                    error: null,
                    isFetching: false
                }
            };
        });

        test('Renders loading when itpEnrollment is fetching', () => {
            setupRTL();
            expect(screen.getByTestId('circularSpinner')).toBeInTheDocument();
        });

        test('Renders loading when itpEnrollment is done and recordCall is fetching', () => {
            initialState.itpEnrollmentData.isFetching = false;
            initialState.recordCall.isFetching = true;
            setupRTL();
            expect(screen.getByTestId('circularSpinner')).toBeInTheDocument();
        });
    });
});