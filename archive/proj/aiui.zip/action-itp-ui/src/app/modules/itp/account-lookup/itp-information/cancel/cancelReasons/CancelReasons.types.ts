import { IReduxError } from '../../../../../../common/types';

export interface ICancelReasonsRequest {
    customerType: string | undefined;
}

export interface ICancelReason {
    code: string;
    description: string;
}

export interface ICancelReasonsResponse {
    requestReasons: ICancelReason[];
}

export interface ICancelReasonsRequestAction {
    type: 'ITP_CANCEL_REASONS_REQUEST';
    payload: ICancelReasonsRequest;
}

export interface ICancelReasonsSuccessAction {
    type: 'ITP_CANCEL_REASONS_SUCCESS';
    payload: ICancelReasonsResponse;
}

export interface ICancelReasonsFailureAction {
    type: 'ITP_CANCEL_REASONS_FAILURE';
    payload: IReduxError;
}

export interface IResetData {
    type: 'RESET_DATA';
}

export interface ICancelReasonsState {
    requestReasons: ICancelReason[];
}

export type TCancelReasonsAction = ICancelReasonsRequestAction | ICancelReasonsFailureAction | ICancelReasonsSuccessAction | IResetData;