import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { piiLookupSuccess } from '../../../../../msw/responses/customerPIILookup/piiLookupSuccess';
import { logout } from '../../../login/Login.actions';
import { INTERNAL_SERVER_ERROR } from '../../../../common/constants/ITPConstants';
import { PII_FAILURE, PII_REQUEST, PII_SUCCESS } from './AccountLookupConstants';
import { attemptCustomerPiiRequest, piiFailure, piiRequest, piiSuccess } from './CustomerPII.actions';

describe('CustomerPIIActions', () => {
    test('piiSuccess', () => {
        const data = {
            ...piiLookupSuccess
        };

        const result = piiSuccess(data);
        expect(result).toEqual({
            type: PII_SUCCESS,
            payload: {
                ...data
            }
        });
    });

    test('piiRequest', () => {
        const data = {
            partyId: '1234'
        };

        expect(piiRequest(data)).toEqual({
            type: PII_REQUEST,
            payload: {
                ...data
            }
        });
    });

    test('piiFailure', () => {
        const error = {
            message: ['error'],
            cause: ['unknown']
        };
        expect(piiFailure(error)).toEqual({
            type: PII_FAILURE,
            payload: error
        });
    });

    describe('attemptPiiRequest', () => {
        const middleware = [thunk];
        const mockStore = configureMockStore(middleware);
        let store, data;

        beforeEach(() => {
            store = mockStore({
                user: {
                    data: {
                        userName: 'testUser123'
                    }
                }
            });
            jest.resetAllMocks();
            data = {
                partyId: '1234'
            };
            document.cookie = 'auth-token=jwt-token';
        });

        test('handles 200 success path', async () => {
            await store.dispatch(attemptCustomerPiiRequest(data.partyId));
            const actions = store.getActions();

            expect(actions[0]).toEqual(piiRequest({
                ...data
            }));
            expect(actions[1]).toEqual(piiSuccess(piiLookupSuccess));
        });

        test('handles 204 invalid user', async () => {
            await store.dispatch(attemptCustomerPiiRequest('notFound'));
            const actions = store.getActions();

            expect(actions[0]).toEqual(piiRequest({
                partyId: 'notFound'
            }));
            expect(actions[1]).toEqual(piiFailure({
                cause: [],
                message: ['No Customer Available.']
            }));
        });

        test('handles 401 unauthenticated user', async () => {
            document.cookie = 'auth-token=';
            await store.dispatch(attemptCustomerPiiRequest(data.partyId));
            const actions = store.getActions();

            expect(actions[0]).toEqual(piiRequest({
                ...data
            }));
            expect(actions[2]).toEqual(logout({
                cause: ['1009'],
                message: []
            }));
        });

        test('handles failure path', async () => {
            await store.dispatch(attemptCustomerPiiRequest('mockFailure'));
            const actions = store.getActions();

            expect(actions[0]).toEqual(piiRequest({
                partyId: 'mockFailure'
            }));
            expect(actions[1]).toEqual(piiFailure({
                cause: [INTERNAL_SERVER_ERROR],
                message: [INTERNAL_SERVER_ERROR]
            }));
        });
    });
});