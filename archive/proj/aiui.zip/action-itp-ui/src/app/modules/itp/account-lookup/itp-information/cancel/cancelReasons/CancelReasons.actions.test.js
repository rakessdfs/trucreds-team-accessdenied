import thunk from 'redux-thunk';
import configureMockStore from 'redux-mock-store';
import { cancelReasonsSuccess } from '../../../../../../../msw/responses/cancelReasons/responses';
import {
    ITP_CANCEL_REASONS_FAILURE,
    ITP_CANCEL_REASONS_REQUEST,
    ITP_CANCEL_REASONS_SUCCESS
} from '../CancelConstants';
import { resetData } from '../../../AccountLookup/CustomerPII.actions';
import {
    itpCancelReasons,
    itpCancelReasonsFailure,
    itpCancelReasonsRequest,
    itpCancelReasonsSuccess
} from './CancelReasons.actions';

describe('itpCancelReasonsActions', () => {
    test('itpCancelReasonsSuccess', () => {
        const data = {
            ...cancelReasonsSuccess
        };

        const result = itpCancelReasonsSuccess(data);
        expect(result).toEqual({
            type: ITP_CANCEL_REASONS_SUCCESS,
            payload: {
                ...data
            }
        });
    });

    test('itpCancelReasonsRequest', () => {
        const data = {
            customerType: 'ITP_FF'
        };
        expect(itpCancelReasonsRequest(data)).toEqual({
            type: ITP_CANCEL_REASONS_REQUEST,
            payload: {
                ...data
            }
        });
    });

    test('itpCancelReasonsFailure', () => {
        const error = {
            message: ['error'],
            cause: ['unknown']
        };
        expect(itpCancelReasonsFailure(error)).toEqual({
            type: ITP_CANCEL_REASONS_FAILURE,
            payload: error
        });
    });

    describe('itpCancelReasons test', () => {
        const middleware = [thunk];
        const mockStore = configureMockStore(middleware);
        let store, initialState, data;

        beforeEach(() => {
            initialState = {
                user: {
                    data: {
                        userName: 'testUser123'
                    }
                },
                itpEnrollmentData: {
                    data: {
                        customerType: 'ITP_FF'
                    }
                }
            };
            store = mockStore(initialState);
            jest.resetAllMocks();
            document.cookie = 'auth-token=jwt-token';
        });

        test('handles 200 success path', async () => {
            data = {
                customerType: 'ITP_FF'
            };
            await store.dispatch(itpCancelReasons());
            const actions = store.getActions();
            expect(actions[0]).toEqual(itpCancelReasonsRequest({
                ...data
            }));
            expect(actions[1]).toEqual(itpCancelReasonsSuccess(cancelReasonsSuccess));
        });

        test('handles failure path', async () => {
            initialState = {
                ...initialState,
                itpEnrollmentData: {
                    data: {
                        customerType: 'ITP_TEST_400'
                    }
                }
            };
            store = mockStore(initialState);
            await store.dispatch(itpCancelReasons());
            const actions = store.getActions();
            expect(actions[1]).toEqual(itpCancelReasonsFailure({
                cause: ['1028'],
                message: ['Invalid request. Please resolve and try again.']
            }));
        });

        test('CancelReasonsFailure', () => {
            const error = {
                errorCode: '1',
                message: ['some message']
            };
            const result = itpCancelReasonsFailure(error);
            expect(result).toEqual({
                type: ITP_CANCEL_REASONS_FAILURE,
                payload: error
            });
        });

        test('handles failure when 200 with errors', async () => {
            initialState = {
                ...initialState,
                itpEnrollmentData: {
                    data: {
                        customerType: 'ITP_TEST_200_ERRORS'
                    }
                }
            };
            store = mockStore(initialState);
            await store.dispatch(itpCancelReasons());
            const actions = store.getActions();
            expect(actions[1]).toEqual(itpCancelReasonsFailure({
                cause: ['Service is currently unavailable. Please retry or open a ticket with the command center.'],
                message: []
            }));
        });

        test('handles failure when 401 error', async () => {
            initialState = {
                ...initialState,
                itpEnrollmentData: {
                    data: {
                        customerType: 'ITP_TEST_401ERROR'
                    }
                }
            };
            store = mockStore(initialState);
            await store.dispatch(itpCancelReasons());
            const actions = store.getActions();
            expect(actions[1]).toEqual(resetData());
        });
    });
});