import { screen } from '@testing-library/react';
import React from 'react';
import createMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { renderContainer } from 'src/app/common/utils/test-utils';
import * as CONSTANTS from '../../../common/constants/ITPConstants';
import { CustomerPII } from './CustomerPIIComponent';

describe('CustomerInfo', () => {
    let initialState, store;

    const setupRTL = () => {
        store = createMockStore([thunk])(initialState);
        return renderContainer(<CustomerPII />, {
            store
        });
    };

    beforeEach(() => {
        initialState = {
            user: {
                data: null,
                error: null,
                isFetching: false
            },
            pii: {
                data: null,
                error: null,
                isFetching: false
            },
            itpEnrollmentData: {
                data: null,
                error: null,
                isFetching: false
            }
        };
    });

    describe('Loading State', () => {
        beforeEach(() => {
            initialState = {
                ...initialState,
                pii: {
                    ...initialState.pii,
                    isFetching: true,
                    error: null
                }
            };
        });

        test('Shows loading message when loading', () => {
            setupRTL();
            expect(screen.getByTestId('circularSpinner')).toBeInTheDocument();
        });
    });

    describe('Error State', () => {
        beforeEach(() => {
            initialState = {
                ...initialState,
                pii: {
                    ...initialState.pii,
                    error: {
                        message: ['test message'],
                        cause: ['test cause']
                    },
                    isFetching: false,
                    data: null
                }
            };
        });

        test('Shows error message if present', () => {
            setupRTL();
            expect(screen.getByText('test message')).toBeInTheDocument();
        });
    });

    describe('Happy Path with empty address', () => {
        beforeEach(() => {
            initialState = {
                ...initialState,
                user: {
                    data: {
                        isAuthenticated: true,
                        userName: 'SOME_USERNAME',
                        fullName: 'Some FullName',
                        email: 'someEmail'
                    },
                    error: null,
                    isFetching: false
                },
                pii: {
                    data: {
                        firstName: 'JEANNE',
                        lastName: 'RUDMAN',
                        dateOfBirth: '1/1/1970',
                        ssn: '2435',
                        addressLine1: '  ',
                        addressLine2: '  ',
                        primaryPhone: '  ',
                        email: '  '
                    },
                    error: null,
                    isFetching: false
                },
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: '90901234567890',
                        enrollmentDate: '2020-10-29'
                    }
                }
            };
        });

        test('CustomerInfo renders customer\'s address line when empty', () => {
            const { getByTestId } = setupRTL();
            expect(getByTestId('address-text').textContent).toBe(CONSTANTS.NOT_AVAILABLE);
            expect(getByTestId('phone-text').textContent).toBe(CONSTANTS.NOT_AVAILABLE);
            expect(getByTestId('email-text').textContent).toBe(CONSTANTS.NOT_AVAILABLE);
        });
    });

    describe('Happy Path for BM', () => {
        beforeEach(() => {
            initialState = {
                ...initialState,
                user: {
                    data: {
                        isAuthenticated: true,
                        userName: 'SOME_USERNAME',
                        fullName: 'Some FullName',
                        email: 'someEmail'
                    },
                    error: null,
                    isFetching: false
                },
                pii: {
                    data: {
                        firstName: 'JEANNE',
                        lastName: 'RUDMAN',
                        dateOfBirth: '1/1/1970',
                        ssn: '2435',
                        addressLine1: '510440 Discover Way',
                        addressLine2: 'RIVERWOODS IL 1234567',
                        primaryPhone: '(123) 456-7899',
                        email: 'test@discover.com'
                    },
                    error: null,
                    isFetching: false
                },
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: '90901234567890',
                        enrollmentDate: '2020-10-29',
                        customerType: 'ITP_BM'
                    }
                }
            };
        });

        test('Validate BM Text in PII', () => {
            const { getByText } = setupRTL();
            expect(getByText(CONSTANTS.BM_CUSTOMER_TEXT)).toBeInTheDocument();
        });
    });

    describe('Happy Path for BM FREE', () => {
        beforeEach(() => {
            initialState = {
                ...initialState,
                user: {
                    data: {
                        isAuthenticated: true,
                        userName: 'SOME_USERNAME',
                        fullName: 'Some FullName',
                        email: 'someEmail'
                    },
                    error: null,
                    isFetching: false
                },
                pii: {
                    data: {
                        firstName: 'JEANNE',
                        lastName: 'RUDMAN',
                        dateOfBirth: '1/1/1970',
                        ssn: '2435',
                        addressLine1: '510440 Discover Way',
                        addressLine2: 'RIVERWOODS IL 1234567',
                        primaryPhone: '(123) 456-7899',
                        email: 'test@discover.com'
                    },
                    error: null,
                    isFetching: false
                },
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: '90901234567890',
                        enrollmentDate: '2020-10-29',
                        customerType: 'ITP_BM_FREE'
                    }
                }
            };
        });

        test('Validate BM Text in PII', () => {
            const { getByText } = setupRTL();
            expect(getByText(CONSTANTS.BM_CUSTOMER_TEXT)).toBeInTheDocument();
        });

        test('Validate BM Text in PII for PEN standing code', () => {
            initialState = {
                ...initialState,
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: '90901234567890',
                        enrollmentDate: '2020-10-29',
                        customerType: 'ITP_BM_FREE',
                        standingCode: 'PEN'
                    }
                }
            };
            const { getByText } = setupRTL();
            expect(getByText(CONSTANTS.BM_CUSTOMER_PENDING_PAYMENT)).toBeInTheDocument();
        });

        test('Validate FnF Text in PII', () => {
            initialState = {
                ...initialState,
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: '90901234567890',
                        enrollmentDate: '2020-10-29',
                        customerType: 'ITP_FF',
                        standingCode: 'ENR'
                    }
                }
            };
            const { queryByText } = setupRTL();
            expect(queryByText(CONSTANTS.BM_CUSTOMER_TEXT)).not.toBeInTheDocument();
        });
    });

    describe('Happy Path', () => {
        beforeEach(() => {
            initialState = {
                ...initialState,
                user: {
                    data: {
                        isAuthenticated: true,
                        userName: 'SOME_USERNAME',
                        fullName: 'Some FullName',
                        email: 'someEmail'
                    },
                    error: null,
                    isFetching: false
                },
                pii: {
                    data: {
                        firstName: 'JEANNE',
                        lastName: 'RUDMAN',
                        dateOfBirth: '1/1/1970',
                        ssn: '2435',
                        addressLine1: '510440 Discover Way',
                        addressLine2: 'RIVERWOODS IL 1234567',
                        primaryPhone: '(123) 456-7899',
                        email: 'test@discover.com'
                    },
                    error: null,
                    isFetching: false
                },
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: '90901234567890',
                        enrollmentDate: '2020-10-29'
                    }
                }
            };
        });

        test('CustomerInfo renders customer\'s peid', () => {
            const { getByText } = setupRTL();

            expect(getByText('90901234567890')).toBeInTheDocument();
        });

        test('CustomerInfo renders customer\'s enrollment date and BM Capabilities', () => {
            const { getByText } = setupRTL();
            expect(getByText('Opened: 2020-10-29')).toBeInTheDocument();
        });

        test('CustomerInfo renders customer\'s first name', () => {
            const { getByText } = setupRTL();

            expect(getByText('JEANNE')).toBeInTheDocument();
        });

        test('CustomerInfo renders customer\'s last name', () => {
            const { getByText } = setupRTL();

            expect(getByText('RUDMAN')).toBeInTheDocument();
        });

        test('CustomerInfo renders address label', () => {
            const { getByText } = setupRTL();

            expect(getByText('ADDRESS')).toBeInTheDocument();
        });

        test('CustomerInfo renders customer\'s address line 1', () => {
            const { getByText } = setupRTL();
            expect(getByText('510440 Discover Way')).toBeInTheDocument();
        });

        test('CustomerInfo renders customer\'s address line 2', () => {
            const { getByText } = setupRTL();

            expect(getByText('RIVERWOODS IL 1234567')).toBeInTheDocument();
        });

        test('CustomerInfo renders primary phone label', () => {
            const { getByText } = setupRTL();

            expect(getByText('PRIMARY PHONE')).toBeInTheDocument();
        });

        test('CustomerInfo renders customer\'s primary phone number', () => {
            const { getByText } = setupRTL();

            expect(getByText('(123) 456-7899')).toBeInTheDocument();
        });

        test('CustomerInfo renders email label', () => {
            const { getByText } = setupRTL();

            expect(getByText('EMAIL')).toBeInTheDocument();
        });

        test('CustomerInfo renders customer\'s email', () => {
            const { getByText } = setupRTL();

            expect(getByText('test@discover.com')).toBeInTheDocument();
        });

        test('CustomerInfo renders date of birth label', () => {
            const { getByText } = setupRTL();

            expect(getByText('1/1/1970')).toBeInTheDocument();
        });

        test('CustomerInfo renders ssn label', () => {
            const { getByText } = setupRTL();

            expect(getByText('SSN')).toBeInTheDocument();
        });

        test('CustomerInfo renders customer\'s ssn', () => {
            const { getByText } = setupRTL();

            expect(getByText('2435')).toBeInTheDocument();
        });
    });
});