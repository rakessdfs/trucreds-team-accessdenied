import axios from 'axios';
import { ThunkDispatch } from 'redux-thunk';
import { IReduxState } from 'src/app/store/Store.types';
import {
    URL_ACTION_ITP_API_HOSTNAME,
    URL_ACTION_ITP_API_HOSTNAME_LOCAL,
    URL_ACTION_ITP_FETCH_REQUEST_ACTIVITY_CONTEXT
} from '../../../../../common/constants/ITPConstants';
import { IReduxError } from '../../../../../common/types';
import { validateResponse } from '../../../../../common/utils/ITPUtils';
import { getAuthCookie } from '../../../../login/LoginUtils';
import { attemptLogout } from '../../../../login/Login.actions';
import {
    IAccountActivityRequest, IAccountActivityResponse,
    IFetchAccountActivityFailureAction, IFetchAccountActivityRequestAction,
    IFetchAccountActivitySuccessAction
} from './AccountActivity.types';
import { FETCH_ACCOUNT_ACTIVITY_REQUEST,
    FETCH_ACCOUNT_ACTIVITY_SUCCESS,
    FETCH_ACCOUNT_ACTIVITY_FAILURE,
    ACCOUNT_ACTIVITY_ENTITY_NAME } from './AccountActivityConstants';

export const fetchAccountActivitySuccess = (response: IAccountActivityResponse): IFetchAccountActivitySuccessAction => ({
    type: FETCH_ACCOUNT_ACTIVITY_SUCCESS,
    payload: response
});

export const fetchAccountActivityFailure = (error: IReduxError): IFetchAccountActivityFailureAction => ({
    type: FETCH_ACCOUNT_ACTIVITY_FAILURE,
    payload: error
});

export const fetchAccountActivityRequest = ({ productEnrollmentId }: IAccountActivityRequest): IFetchAccountActivityRequestAction => ({
    type: FETCH_ACCOUNT_ACTIVITY_REQUEST,
    payload: {
        productEnrollmentId
    }
});

export const prepareActivities = (response: IAccountActivityResponse): IAccountActivityResponse => {
    response.accountActivityList.forEach((activity) => {
        if (activity.previousData !== null && activity.previousData.trim() !== '') {
            activity.previousData = ` PREV: ${activity.previousData}`;
        }
        if (activity.newData !== null && activity.newData.trim() !== '') {
            activity.newData = ` NEW: ${activity.newData}`;
        }
    });
    return response;
};

export const fetchRequestActivities = (productEnrollmentId: string | number) => {
    return async (dispatch: ThunkDispatch<IReduxState, unknown, IFetchAccountActivityRequestAction | IFetchAccountActivityFailureAction | IFetchAccountActivitySuccessAction>): Promise<void> => {
        dispatch(fetchAccountActivityRequest({
            productEnrollmentId
        }));
        let response;

        try {
            response = await axios({
                method: 'get',
                url: `${(URL_ACTION_ITP_API_HOSTNAME || URL_ACTION_ITP_API_HOSTNAME_LOCAL)}${URL_ACTION_ITP_FETCH_REQUEST_ACTIVITY_CONTEXT}${productEnrollmentId}`,
                headers: {
                    Authorization: `Bearer ${getAuthCookie()}`
                }
            });

            const error = validateResponse(response, ACCOUNT_ACTIVITY_ENTITY_NAME);

            if (error) {
                dispatch(fetchAccountActivityFailure(error));
                return;
            }
        } catch (e) {
            if (typeof (e.response) !== 'undefined' && e.response?.status === 401) {
                dispatch(attemptLogout((validateResponse(e.response, ACCOUNT_ACTIVITY_ENTITY_NAME) as IReduxError)));
                return;
            } else {
                dispatch(fetchAccountActivityFailure((validateResponse(e.response, ACCOUNT_ACTIVITY_ENTITY_NAME) as IReduxError)));
                return;
            }
        }
        dispatch(fetchAccountActivitySuccess(prepareActivities(response?.data)));
    };
};