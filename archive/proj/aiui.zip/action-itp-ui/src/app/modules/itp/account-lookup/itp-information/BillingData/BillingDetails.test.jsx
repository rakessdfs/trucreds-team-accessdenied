import React from 'react';
import { screen } from '@testing-library/react';
import createMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { renderContainer } from '../../../../../common/utils/test-utils';
import * as ItpInformationConstants from '../ItpInformationConstants';
import * as CONSTANTS from '../../../../../common/constants/ITPConstants';
import * as allToggles from '../../../../../common/toggle/toggles';
import { toggleNames } from '../../../../../common/toggle/toggleNames';
import { BillingDetails } from './BillingDetails';

describe('BillingDetails', () => {
    let initialState, store;

    beforeEach(() => {
        jest.clearAllMocks();
        initialState = {
            billingData: {
                data: {
                    pcmFirstName: 'first name',
                    pcmLastName: 'last name',
                    pcmAccountNumber: 'acc number',
                    presenceOfSecondary: 'yes',
                    nextBillingDate: null
                },
                error: null,
                isFetching: false
            },
            itpEnrollmentData: {
                data: {
                    productEnrollmentId: 'testing123',
                    customerType: 'ITP_FF'
                }
            },
            user: {
                data: {
                    userName: 'test'
                }
            }
        };
    });

    const setupRTL = () => {
        store = createMockStore([thunk])(initialState);
        return renderContainer(<BillingDetails />, {
            store
        });
    };

    describe('billing details section', () => {
        test('Render billing details sections', () => {
            setupRTL();
            expect(screen.getByText(ItpInformationConstants.BILLING_DETAILS)).toBeInTheDocument();
            expect(screen.getByText(ItpInformationConstants.PCM_FIRST_NAME)).toBeInTheDocument();
            expect(screen.getByText(ItpInformationConstants.PCM_LAST_NAME)).toBeInTheDocument();
            expect(screen.getByText(ItpInformationConstants.PCM_ACCOUNT)).toBeInTheDocument();
            expect(screen.getByText(ItpInformationConstants.SCM_AU_ON_ACCOUNT)).toBeInTheDocument();
            expect(screen.getByTestId('clipboard-testid')).toBeInTheDocument();
        });
    });

    describe('billing details section while fetching', () => {
        beforeEach(() => {
            jest.clearAllMocks();
            initialState = {
                billingData: {
                    data: null,
                    error: null,
                    isFetching: true
                },
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'testing123',
                        subscriberNumber: '12345'
                    }
                },
                user: {
                    data: {
                        userName: 'test'
                    }
                }
            };
        });

        test('Renders Fetching', () => {
            setupRTL();
            expect(screen.getByTestId('circularSpinner')).toBeInTheDocument();
        });
    });

    describe('billing details section while error', () => {
        beforeEach(() => {
            jest.clearAllMocks();
            initialState = {
                billingData: {
                    data: null,
                    error: {
                        cause: [CONSTANTS.INTERNAL_SERVER_ERROR],
                        message: []
                    },
                    isFetching: false
                },
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'testing123',
                        subscriberNumber: '12345'
                    }
                },
                user: {
                    data: {
                        userName: 'test'
                    }
                }
            };
        });

        test('Renders Fetching', () => {
            setupRTL();
            expect(screen.getByTestId('error-container')).toBeInTheDocument();
        });
    });

    describe('Validate BM Changes', () => {
        beforeEach(() => {
            jest.clearAllMocks();
            initialState = {
                billingData: {
                    data: {
                        pcmFirstName: 'first name',
                        pcmLastName: 'last name',
                        pcmAccountNumber: 'acc number',
                        presenceOfSecondary: 'yes',
                        nextBillingDate: null
                    },
                    error: null,
                    isFetching: false
                },
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'testing123',
                        customerType: 'ITP_BM',
                        standingCode: 'PCN'
                    }
                },
                user: {
                    data: {
                        userName: 'test'
                    }
                }
            };
        });

        test('Renders PCN/CAN scenarios', () => {
            setupRTL();
            const response = screen.getByText(CONSTANTS.BILLING_INFORMATION_WARNING);
            expect(response).toBeInTheDocument();
        });

        test('Renders ENR scenario', () => {
            initialState = {
                ...initialState,
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'testing123',
                        customerType: 'ITP_BM',
                        standingCode: 'ENR'
                    }
                }
            };
            setupRTL();
            expect(screen.queryByText(CONSTANTS.BILLING_INFORMATION_WARNING)).toBeNull();
            expect(screen.queryByText(CONSTANTS.NOT_AVAILABLE)).toBeInTheDocument();
        });

        test('Enable feature toggle to renders Next Billing Date for BM customer', () => {
            initialState = {
                billingData: {
                    data: {
                        pcmFirstName: 'first name',
                        pcmLastName: 'last name',
                        pcmAccountNumber: 'acc number',
                        presenceOfSecondary: 'yes',
                        nextBillingDate: '20200115'
                    },
                    error: null,
                    isFetching: false
                },
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'testing123',
                        customerType: 'ITP_BM'
                    }
                },
                user: {
                    data: {
                        userName: 'test'
                    }
                }
            };
            Object.defineProperty(allToggles, 'toggles', {
                value: {
                    [toggleNames.SHOW_LAST_AND_NEXT_BILLING_DATE]: true
                }
            });
            setupRTL();
            expect(screen.getByText(ItpInformationConstants.NEXT_BILLING_DATE)).toBeInTheDocument();
        });

        test('Disable Feature toggle to remove Next Billing Date for BM customer', () => {
            initialState = {
                billingData: {
                    data: {
                        pcmFirstName: 'first name',
                        pcmLastName: 'last name',
                        pcmAccountNumber: 'acc number',
                        presenceOfSecondary: 'yes',
                        nextBillingDate: null
                    },
                    error: null,
                    isFetching: false
                },
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'testing123',
                        customerType: 'ITP_FF'
                    }
                },
                user: {
                    data: {
                        userName: 'test'
                    }
                }
            };
            Object.defineProperty(allToggles, 'toggles', {
                value: {
                    [toggleNames.SHOW_LAST_AND_NEXT_BILLING_DATE]: false
                }
            });
            setupRTL();
            expect(screen.queryByText(ItpInformationConstants.NEXT_BILLING_DATE)).toBeNull();
        });

        test('Last and Next Billing Date not rendered for FF customer', () => {
            Object.defineProperty(allToggles, 'toggles', {
                value: {
                    [toggleNames.SHOW_LAST_AND_NEXT_BILLING_DATE]: true
                }
            });
            initialState = {
                billingData: {
                    data: {
                        pcmFirstName: 'first name',
                        pcmLastName: 'last name',
                        pcmAccountNumber: 'acc number',
                        presenceOfSecondary: 'yes',
                        nextBillingDate: null
                    },
                    error: null,
                    isFetching: false
                },
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'testing123',
                        subscriberNumber: '12345',
                        customerType: 'ITP_FF'
                    }
                },
                user: {
                    data: {
                        userName: 'test'
                    }
                }
            };
            setupRTL();
            expect(screen.queryByText(ItpInformationConstants.NEXT_BILLING_DATE)).toBeNull();
        });
    });

    describe('Validate BM FREE Changes', () => {
        beforeEach(() => {
            jest.clearAllMocks();
            initialState = {
                billingData: {
                    data: {
                        pcmFirstName: 'free first name',
                        pcmLastName: ' free last name',
                        pcmAccountNumber: 'free acc number',
                        presenceOfSecondary: 'yes',
                        nextBillingDate: null
                    },
                    error: null,
                    isFetching: false
                },
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'testing123Free',
                        subscriberNumber: '12345',
                        customerType: 'ITP_BM_FREE',
                        partyId: '12345'
                    }
                },
                user: {
                    data: {
                        userName: 'test'
                    }
                }
            };
        });
    });
});