import {
    CANCELLATION,
    ENROLLMENT,
    GENERAL_SERVICING,
    SPACED_COMMA_DELIMITER,
    TRANSFER_TO_ECS
} from '../../../common/constants/ITPConstants';
import { MEMO_TEXT_LENGTH } from './UtilityMenuContants';

interface IFinalMemoText {
    isEnrollmentCheck?: boolean;
    isCancellationCheck?: boolean;
    isTransferToEcsCheck?: boolean;
    isCommentsCheck?: boolean;
    isGeneralServicingCheck?: boolean;
    manualMemoText?: string;
}
export const overAllMemoText = ({
    isEnrollmentCheck,
    isCancellationCheck,
    isGeneralServicingCheck,
    isTransferToEcsCheck,
    isCommentsCheck,
    manualMemoText
}: IFinalMemoText): string => {
    return [
        isEnrollmentCheck && ENROLLMENT,
        isCancellationCheck && CANCELLATION,
        isGeneralServicingCheck && GENERAL_SERVICING,
        isTransferToEcsCheck && TRANSFER_TO_ECS,
        isCommentsCheck && manualMemoText
    ].filter(Boolean).join(SPACED_COMMA_DELIMITER);
};

export const validateMemoTextLength = (memoText: string): boolean => {
    if (memoText.length > 0 && memoText.length <= MEMO_TEXT_LENGTH) {
        return true;
    }
    return false;
};