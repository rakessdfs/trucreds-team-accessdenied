export const CREATE_MEMO_SUCCESS = 'CREATE_MEMO_SUCCESS';
export const CREATE_MEMO_REQUEST = 'CREATE_MEMO_REQUEST';
export const CREATE_MEMO_FAILURE = 'CREATE_MEMO_FAILURE';
export const MEMO_TEXT_LENGTH = 250;
export const MEMO_SUCCESS = 'Memo posted successfully';
export const MEMO_POSTING_ERROR = 'Error creating new memo. Please try again';
export const PEID_UNDEFINED = 'Please select checkbox (also enter text in case of Manual memo) to Post Memo.';
export const NEW_MEMO_TITLE = 'New Memo';