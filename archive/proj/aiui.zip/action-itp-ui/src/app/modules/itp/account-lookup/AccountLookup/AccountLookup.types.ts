import { IReduxError } from '../../../../common/types';
export interface IPiiResponse {
  dateOfBirth: string;
  firstName: string;
  lastName: string;
  ssn: string;
  address: {
    barCode: string;
    cityName: string;
    countryCode: string;
    postalCode: string;
    addressLine1: string;
    addressLine2: string;
    stateOrSectionCode: string;
    forbidAutoFormatting: boolean;
  } | null;
  primaryPhone: string;
  email: string;
  partyId: string;
}

export interface IPiiRequest {
  partyId: string;
}

export interface IPiiRequestAction {
    type: 'PII_REQUEST';
    payload: IPiiRequest;
}

export interface IPiiSuccessAction {
    type: 'PII_SUCCESS';
    payload: IPiiResponse;
  }

export interface IPiiFailureAction {
    type: 'PII_FAILURE';
    payload: IReduxError;
  }

export interface IResetData {
    type: 'RESET_DATA';
}

export interface IPiiState {
    firstName: string | null;
    lastName: string | null;
    addressLine1: string | null;
    addressLine2: string | null;
    primaryPhone: string | null;
    email: string | null;
    dateOfBirth: string | null;
    ssn: string | null;
    partyId: string | null;
  }

export type TPiiAction = IPiiRequestAction | IPiiFailureAction | IPiiSuccessAction | IResetData;