import { IReduxError } from '../../../../../common/types';

export interface IRecordCallRequest {
    customerType: string | undefined;
    productEnrollmentId: string | number;
    tagType: string;
}

export interface IRecordCallRequestAction {
    type: 'ITP_RECORD_CALL_REQUEST';
    payload: IRecordCallRequest;
}

export interface IRecordCallSuccessAction {
    type: 'ITP_RECORD_CALL_SUCCESS';
}

export interface IRecordCallFailureAction {
    type: 'ITP_RECORD_CALL_FAILURE';
    payload: IReduxError;
}

export interface IResetData {
    type: 'RESET_DATA';
}

export type TRecordCallAction = IRecordCallRequestAction | IRecordCallFailureAction | IRecordCallSuccessAction | IResetData;