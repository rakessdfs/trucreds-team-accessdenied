import { ThunkDispatch } from 'redux-thunk';
import axios from 'axios';
import { IReduxState } from '../../../../../store/Store.types';
import { IReduxError } from '../../../../../common/types';
import {
    URL_ACTION_ITP_API_HOSTNAME,
    URL_ACTION_ITP_API_HOSTNAME_LOCAL, URL_ACTION_ITP_CANCEL_ENROLLMENT
} from '../../../../../common/constants/ITPConstants';
import { getAuthCookie } from '../../../../login/LoginUtils';
import { validateResponse } from '../../../../../common/utils/ITPUtils';
import { attemptLogout } from '../../../../login/Login.actions';
import {
    ICancelEnrollmentFailureAction,
    ICancelEnrollmentResetAction,
    ICancelEnrollmentSuccessAction
} from './CancelEnrollment.types';
import {
    CANCEL_ENROLLMENT_FAILURE, CANCEL_ENROLLMENT_RESET_DATA,
    CANCEL_ENROLLMENT_SUCCESS
} from './CancelConstants';

export const cancelEnrollmentSuccess = (): ICancelEnrollmentSuccessAction => ({
    type: CANCEL_ENROLLMENT_SUCCESS
});

export const cancelEnrollmentFailure = (error: IReduxError): ICancelEnrollmentFailureAction => ({
    type: CANCEL_ENROLLMENT_FAILURE,
    payload: error
});

export const cancelEnrollmentReset = (): ICancelEnrollmentResetAction => ({
    type: CANCEL_ENROLLMENT_RESET_DATA
});

export const cancelEnrollment = (cancelReasonCode: string) => {
    return async (dispatch: ThunkDispatch<IReduxState, unknown, ICancelEnrollmentSuccessAction | ICancelEnrollmentFailureAction>, getState: () => IReduxState): Promise<void> => {
        const peid = getState().itpEnrollmentData.data?.productEnrollmentId;
        const agentName = getState().user.data?.userName;

        let response;

        try {
            response = await axios({
                method: 'post',
                url: `${(URL_ACTION_ITP_API_HOSTNAME || URL_ACTION_ITP_API_HOSTNAME_LOCAL)}${URL_ACTION_ITP_CANCEL_ENROLLMENT}${peid}&cancelReasonCode=${cancelReasonCode}`,
                headers: {
                    'X-DFSUSER-USER-ID': agentName,
                    Authorization: `Bearer ${getAuthCookie()}`
                }
            });

            const error = validateResponse(response, 'customer');

            if (error) {
                dispatch(cancelEnrollmentFailure(error));
                return;
            }
        } catch (e) {
            if (e.response?.status === 401) {
                dispatch(attemptLogout((validateResponse(e.response, 'customer') as IReduxError)));
                return;
            }
            dispatch(cancelEnrollmentFailure((validateResponse(e.response, 'customer') as IReduxError)));
            return;
        }
        dispatch(cancelEnrollmentSuccess());
    };
};