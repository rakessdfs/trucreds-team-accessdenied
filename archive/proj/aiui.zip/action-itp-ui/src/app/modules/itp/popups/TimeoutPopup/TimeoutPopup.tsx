import React, { ReactElement } from 'react';
import { useDispatch } from 'react-redux';
import { PopupModal } from '../../../../common/Components/PopupModal/PopupModal';
import { Button } from '../../../../common/Components/Buttons/Button';
import {
    STAY_LOGGED_IN_BUTTON,
    LOGOUT_BUTTON,
    TIMEOUT_POPUP_MESSAGE,
    TIMEOUT_POPUP_TITLE
} from '../../../../common/constants/ITPConstants';
import { attemptLogout } from '../../../login/Login.actions';
import styles from './TimeoutPopup.module.scss';

type Props = {
    closeModal: () => void;
    reset: () => void;
}

export const TimeoutPopup = (({ reset, closeModal }: Props): ReactElement => {
    const dispatch = useDispatch();

    const logoutHandler = ((): void => {
        closeModal();
        dispatch(attemptLogout({
            message: [],
            cause: []
        }));
    });

    return (
        <PopupModal>
            <>
                <div className={styles.timeoutTitle}>{TIMEOUT_POPUP_TITLE}</div>
                <div className={styles.timeoutMessage}>{TIMEOUT_POPUP_MESSAGE}</div>
                <div
                    className={styles.buttonContainer}
                >
                    <Button
                        type='button'
                        primary={false}
                        name='logout'
                        onClick={logoutHandler}
                    >
                        {LOGOUT_BUTTON}
                    </Button>
                    <Button
                        type='button'
                        primary={true}
                        name='extend'
                        onClick={(): void => {
                            closeModal();
                            reset();
                        }}
                    >
                        {STAY_LOGGED_IN_BUTTON}
                    </Button>
                </div>
            </>
        </PopupModal>
    );
});