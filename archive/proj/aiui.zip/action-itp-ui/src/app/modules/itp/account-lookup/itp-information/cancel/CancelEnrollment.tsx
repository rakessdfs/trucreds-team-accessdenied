import React, { ReactElement, useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { CircularSpinner } from '../../../../../common/Components/CircularSpinner/CircularSpinner';
import { Button } from '../../../../../common/Components/Buttons/Button';
import { Select } from '../../../../../common/Components/Inputs/Select';
import { IReduxState } from '../../../../../store/Store.types';
import { fetchITPData } from '../BillingData/ItpData.actions';
import * as CONSTANTS from '../../../../../common/constants/ITPConstants';
import { IMembershipResponse } from '../BillingData/MembershipState.types';
import {
    ITP_CANCEL_REASON,
    ITP_CANCEL,
    ITP_END_PROCESS,
    ITP_TRANSFER_TO_VENDOR_MESSAGE,
    ITP_PRODUCT_CANCELLATION,
    ITP_SUBMIT_CANCEL,
    BM_CANCEL_MESSAGE,
    TAGGING_ERROR_HEADER_CANCELLATION,
    TAGGING_ERROR_SUB_HEADER,
    ITP_SELECT_OPTION,
    ITP_CANCEL_REASONS_TALKING_POINT,
    FF_CANCEL_MESSAGE,
    FF_CANCEL_SUB_MESSAGE,
    ALREADY_CANCELLED,
    PRODUCT_SERVICE_CONCERN,
    ALLEGED_UNAUTHORIZED_ENROLLMENT
} from './CancelConstants';
import { cancelEnrollment, cancelEnrollmentReset } from './CancelEnrollment.actions';
import { CancelEnrollmentErrorComponent } from './CancelEnrollmentErrorComponent';
import { NonCriticalError } from './NonCriticalError';
import styles from './CancelEnrollment.module.scss';
import { TalkingPoint } from './TalkingPoint';

interface IItpCancelProps {
    onBack: () => void;
}

export let selectedCode = '';

export const CancelEnrollment = ({ onBack }: IItpCancelProps): ReactElement => {
    const dispatch = useDispatch();
    const { error, isFetching } = useSelector((state: IReduxState) => state.recordCall);
    const { data: enrollmentData } = useSelector((state: IReduxState) => state.itpEnrollmentData);
    const { data: cancelData, error: cancelError } = useSelector((state: IReduxState) => state.cancelEnrollment);
    const { data: cancelReasons, error: cancelReasonsError, isFetching: isFetchingCancelReasons } =
        useSelector((state: IReduxState) => state.cancelReasons);
    const [isShowTalkingPoint, setIsShowTalkingPoint] = useState(false);
    const [cancelReason, setCancelReason] = useState('');
    const [hasAttemptedSubmission, setHasAttemptedSubmission] = useState(false);
    const [isSuccessfulSubmission, setIsSuccessfulSubmission] = useState(false);
    const [isShowNonCriticalError, setIsShowNonCriticalError] = useState(false);
    const [cancelReasonOptions, setCancelReasonOptions] = useState(['']);
    const customerType = useSelector((state: IReduxState) => state.itpEnrollmentData.data?.customerType);
    const isBmCustomer = (customerType === CONSTANTS.ITP_BM || customerType === CONSTANTS.ITP_BM_FREE);
    const isValidCancelReason = cancelReasonOptions.includes(cancelReason) && !cancelReasonsError;
    const [showErrorTalkingPoint, setShowErrorTalkingPoint] = useState('');

    useEffect(() => {
        let reasons: string[] = [];
        if (cancelReasons?.requestReasons) {
            reasons = cancelReasons?.requestReasons?.map((i) => i.description);
            setCancelReasonOptions(reasons);
        }
    }, [cancelReasons]);

    useEffect(() => {
        if (error) {
            setIsShowNonCriticalError(true);
        }
        if (cancelReasonsError || cancelError) {
            setShowErrorTalkingPoint(ITP_CANCEL_REASONS_TALKING_POINT);
        }
    }, [error, cancelReasonsError, cancelError]);

    useEffect(() => {
        if (cancelData !== null) {
            setIsSuccessfulSubmission(true);
            setIsShowTalkingPoint(true);
        }
    }, [cancelData]);

    const onSubmitCancel = (): void => {
        setHasAttemptedSubmission(true);
        if (isValidCancelReason) {
            selectedCode = cancelReasons?.requestReasons?.find(
                (i) => i.description === cancelReason)?.code as string;
            dispatch(cancelEnrollment(selectedCode));
        }
    };

    const onEndProcess = (): void => {
        onBack();
        dispatch(cancelEnrollmentReset());
        setIsSuccessfulSubmission(false);
        setIsShowTalkingPoint(false);
        setCancelReasonOptions([]);
    };

    if (isFetching || isFetchingCancelReasons) {
        return <CircularSpinner isButton={false} />;
    } else {
        return (
            <>
                <div className={styles.cancelSection}>
                    <p className={styles.cancelTitle}>{ITP_PRODUCT_CANCELLATION}</p>
                    <Select
                        label={ITP_CANCEL_REASON}
                        onChange={
                            (event): void => {
                                setCancelReason(event.target.value);
                                setHasAttemptedSubmission(false);
                            }
                        }
                        onBlur={
                            (event): void => {
                                setCancelReason(event.target.value);
                            }
                        }
                        value={cancelReason}
                        options={cancelReasonOptions}
                        disabled={isSuccessfulSubmission}
                        defaultOption={ITP_SELECT_OPTION}
                        shouldShowError= {hasAttemptedSubmission && !isValidCancelReason}
                        shouldShowWarning={!hasAttemptedSubmission && !isValidCancelReason}
                        warningMessage='Cancel Reason is required'
                        errorMessage='Cancel Reason is required'
                    />
                    <div className={styles.cancelButtons}>
                        <Button
                            className={styles.backButton}
                            onClick={onEndProcess}
                            primary={false}
                            disabled={isSuccessfulSubmission}
                        >
                            {ITP_CANCEL}
                        </Button>
                        <Button
                            className={styles.cancelButton}
                            onClick={onSubmitCancel}
                            disabled={!isValidCancelReason || isSuccessfulSubmission}
                        >
                            {ITP_SUBMIT_CANCEL}
                        </Button>
                    </div>
                    {isShowNonCriticalError &&
                        <NonCriticalError
                            header={TAGGING_ERROR_HEADER_CANCELLATION}
                            subHeader={TAGGING_ERROR_SUB_HEADER}
                            onXButtonClick={(): void => setIsShowNonCriticalError(false)}
                        />
                    }
                </div>
                {(cancelError || cancelReasonsError) &&
                    <div>
                        <TalkingPoint
                            message={showErrorTalkingPoint}
                            subMessage={null}
                        />
                        <CancelEnrollmentErrorComponent onEndProcess={onEndProcess} />
                    </div>
                }
                {isShowTalkingPoint ?
                    isBmCustomer ?
                        <TalkingPoint
                            message={BM_CANCEL_MESSAGE}
                            subMessage={null}
                        /> :
                        <TalkingPoint
                            message={FF_CANCEL_MESSAGE}
                            subMessage={FF_CANCEL_SUB_MESSAGE}
                        /> :
                    null
                }
                {isShowTalkingPoint &&
                    <div className={styles.cancelSection}>
                        <p className={styles.cancelTitle}>{ITP_END_PROCESS}</p>
                        {((ALREADY_CANCELLED === cancelReason) || (PRODUCT_SERVICE_CONCERN === cancelReason) ||
                            (ALLEGED_UNAUTHORIZED_ENROLLMENT === cancelReason)) &&
                        isBmCustomer &&
                        <p className={styles.verificationMessage}>{ITP_TRANSFER_TO_VENDOR_MESSAGE}</p>}
                        <div className={styles.cancelButtons}>
                            <Button
                                className={styles.cancelButton}
                                onClick={(): void => {
                                    const { partyId } = enrollmentData as IMembershipResponse;
                                    dispatch(fetchITPData(partyId));
                                    onEndProcess();
                                }}
                            >
                                {ITP_END_PROCESS}
                            </Button>
                        </div>
                    </div>
                }
            </>
        );
    }
};