import { buildReduxError } from '../../../../../common/utils/ITPUtils';
import { resetData } from '../../AccountLookup/CustomerPII.actions';
import { itpDataFailure, itpDataRequest, itpDataSuccess } from './ItpData.actions';
import { itpDataReducer } from './ItpData.reducer';

describe('itpDataReducer', () => {
    let initialState;

    beforeEach(() => {
        initialState = {
            error: null,
            isFetching: true,
            data: null
        };
    });

    describe('itpDataRequest', () => {
        test('sets the state correctly', () => {
            const itpRequestData = {
                partyId: 'partyId'
            };

            expect(itpDataReducer(initialState, itpDataRequest(itpRequestData))).toEqual({
                ...initialState,
                isFetching: true,
                error: null
            });
        });
    });

    describe('successResponse', () => {
        test('sets the new state correctly', () => {
            const successData = {
                subscriberNumber: 'subscriber',
                enrollmentDate: 'enroll date',
                enrollmentStatus: 'status',
                enrollmentFailedReason: 'failed reason',
                cancellationDate: 'cancel date',
                cancellationRequestDate: 'cancel request date',
                productEnrollmentId: 'PEID'
            };
            expect(
                itpDataReducer(initialState, itpDataSuccess(successData))
            ).toEqual({
                data: {
                    ...successData
                },
                isFetching: false,
                error: null
            });
        });
    });

    describe('itpDataFailure', () => {
        test('sets the state correctly', () => {
            expect(itpDataReducer(initialState, itpDataFailure(buildReduxError('some custom error', '')))).toEqual({
                ...initialState,
                error: {
                    cause: [''],
                    message: ['some custom error']
                },
                isFetching: false
            });
        });
    });

    describe('resetData', () => {
        test('sets the state correctly', () => {
            expect(itpDataReducer(initialState, resetData())).toEqual({
                ...initialState,
                data: null,
                isFetching: false,
                error: null
            });
        });
    });
});