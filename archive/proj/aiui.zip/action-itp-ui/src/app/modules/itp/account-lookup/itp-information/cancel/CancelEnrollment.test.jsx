import { screen } from '@testing-library/react';
import React from 'react';
import createMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import userEvent from '@testing-library/user-event';
import { renderContainer } from '../../../../../common/utils/test-utils';
import {
    CANCELLATION_HEADER, CANCELLATION_SUB_HEADER,
    FF_CANCEL_MESSAGE,
    FF_CANCEL_SUB_MESSAGE,
    ITP_CANCEL_REASON,
    ITP_END_PROCESS,
    ITP_TRANSFER_TO_VENDOR_MESSAGE,
    ITP_PRODUCT_CANCELLATION,
    ITP_SELECT_OPTION,
    ITP_SUBMIT_CANCEL,
    ITP_TALKING_POINT,
    BM_CANCEL_MESSAGE,
    TAGGING_ERROR_HEADER_CANCELLATION,
    TAGGING_ERROR_SUB_HEADER,
    X_BUTTON, ALREADY_CANCELLED,
    ALLEGED_UNAUTHORIZED_ENROLLMENT,
    PRODUCT_SERVICE_CONCERN
} from './CancelConstants';
import { CancelEnrollment } from './CancelEnrollment';

describe('Test Cancel Enrollment component', () => {
    let initialState, store, onEndProcessMock, onBackMock;

    beforeEach(() => {
        jest.clearAllMocks();
        onEndProcessMock = jest.fn();
        onBackMock = jest.fn();
        initialState = {
            user: {
                data: {
                    userName: 'test'
                }
            },
            cancelReasons: {
                data: {
                    requestReasons: []
                },
                error: null
            },
            pii: {
                data: {
                }
            },
            itpEnrollmentData: {
                data: {
                    customerType: 'ITP_BM'
                }
            },
            recordCall: {
                data: {
                }
            },
            cancelEnrollment: {
                data: {},
                error: null
            }
        };
    });

    const setupRTL = () => {
        store = createMockStore([thunk])(initialState);
        return renderContainer(
            <CancelEnrollment
                onEndProcess={onEndProcessMock}
                onBack={onBackMock}
            />, {
                store
            });
    };

    describe('Happy Path', () => {
        // eslint-disable-next-line sonarjs/no-identical-functions
        beforeEach(() => {
            jest.clearAllMocks();
            onEndProcessMock = jest.fn();
            onBackMock = jest.fn();
            initialState = {
                ...initialState,
                cancelReasons: {
                    data: {
                        requestReasons: [
                            {
                                code: 'DNW',
                                description: 'No Longer Wants/Needs'
                            },
                            {
                                code: 'DAL',
                                description: ALLEGED_UNAUTHORIZED_ENROLLMENT
                            },
                            {
                                code: 'DSP',
                                description: ALREADY_CANCELLED
                            },
                            {
                                code: 'PSC',
                                description: PRODUCT_SERVICE_CONCERN
                            }
                        ]
                    }
                },
                pii: {
                    error: null,
                    data: {}
                },
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'testing123',
                        customerType: 'ITP_BM'
                    }
                },
                recordCall: {
                    error: null,
                    data: {}
                },
                user: {
                    data: {
                        userName: 'test'
                    }
                }
            };
        });

        test('Render Cancel Enrollment screen', () => {
            setupRTL();
            expect(screen.getByText(ITP_PRODUCT_CANCELLATION)).toBeInTheDocument();
            expect(screen.getByText(ITP_CANCEL_REASON)).toBeInTheDocument();
            expect(screen.getByText(ITP_SUBMIT_CANCEL)).toBeInTheDocument();
        });

        test('Render Spinner when still fetching data', () => {
            initialState = {
                ...initialState,
                recordCall: {
                    error: null,
                    data: {},
                    isFetching: true
                }
            };
            setupRTL();
            expect(screen.getByTestId('circularSpinner')).toBeInTheDocument();
        });

        test('Render Talking Point and End Process for No Longer Wants/Needs Reason', () => {
            setupRTL();

            expect(screen.queryByText('Cancel Reason is required')).not.toBeInTheDocument();

            userEvent.selectOptions(screen.getByRole('combobox'), ['No Longer Wants/Needs']);

            userEvent.click(screen.getByRole('button', { name: 'Submit' }));

            expect(screen.getByText(ITP_TALKING_POINT)).toBeInTheDocument();
            expect(screen.getByText(BM_CANCEL_MESSAGE)).toBeInTheDocument();
            expect(screen.getAllByText(ITP_END_PROCESS)).toHaveLength(2);
            expect(screen.queryByText(ITP_TRANSFER_TO_VENDOR_MESSAGE)).not.toBeInTheDocument();
            expect(screen.queryByText('Cancel Reason is required')).not.toBeInTheDocument();

            userEvent.click(screen.getByRole('button', { name: 'End Process' }));
            expect(screen.queryByText(ITP_TALKING_POINT)).not.toBeInTheDocument();
        });

        test('Render Talking Point and End Process for Alleged Unauthorized Enrollment', () => {
            setupRTL();

            expect(screen.queryByText('Cancel Reason is required')).not.toBeInTheDocument();

            userEvent.selectOptions(screen.getByRole('combobox'), [ALLEGED_UNAUTHORIZED_ENROLLMENT]);

            userEvent.click(screen.getByRole('button', { name: 'Submit' }));

            expect(screen.getByText(ITP_TALKING_POINT)).toBeInTheDocument();
            expect(screen.getByText(BM_CANCEL_MESSAGE, false)).toBeInTheDocument();
            expect(screen.getAllByText(ITP_END_PROCESS)).toHaveLength(2);
            expect(screen.queryByText(ITP_TRANSFER_TO_VENDOR_MESSAGE)).toBeInTheDocument();
            expect(screen.queryByText('Cancel Reason is required')).not.toBeInTheDocument();
        });

        test('Render Talking Point and End Process for Already Canceled Still Billing', () => {
            setupRTL();

            expect(screen.queryByText('Cancel Reason is required')).not.toBeInTheDocument();

            userEvent.selectOptions(screen.getByRole('combobox'), [ALREADY_CANCELLED]);

            userEvent.click(screen.getByRole('button', { name: 'Submit' }));

            expect(screen.queryByText(ITP_TRANSFER_TO_VENDOR_MESSAGE)).toBeInTheDocument();
        });

        test('Render Talking Point and End Process for Product/Service Concern', () => {
            setupRTL();

            expect(screen.queryByText('Cancel Reason is required')).not.toBeInTheDocument();

            userEvent.selectOptions(screen.getByRole('combobox'), [PRODUCT_SERVICE_CONCERN]);

            userEvent.click(screen.getByRole('button', { name: 'Submit' }));

            expect(screen.getByText(ITP_TALKING_POINT)).toBeInTheDocument();
            expect(screen.getByText(BM_CANCEL_MESSAGE, false)).toBeInTheDocument();
            expect(screen.getAllByText(ITP_END_PROCESS)).toHaveLength(2);
            expect(screen.queryByText(ITP_TRANSFER_TO_VENDOR_MESSAGE)).toBeInTheDocument();
            expect(screen.queryByText('Cancel Reason is required')).not.toBeInTheDocument();
        });

        test('Render F&F talking point when member is F&F', () => {
            initialState.itpEnrollmentData.data.customerType = 'ITP_FF';
            setupRTL();

            userEvent.selectOptions(screen.getByRole('combobox'), ['No Longer Wants/Needs']);

            userEvent.click(screen.getByRole('button', { name: 'Submit' }));

            expect(screen.getByText(ITP_TALKING_POINT)).toBeInTheDocument();
            expect(screen.getByText(FF_CANCEL_MESSAGE)).toBeInTheDocument();
            expect(screen.getByText(FF_CANCEL_SUB_MESSAGE)).toBeInTheDocument();
            expect(screen.queryByText(ITP_TRANSFER_TO_VENDOR_MESSAGE)).not.toBeInTheDocument();
        });
    });

    describe('Cancel Reason', () => {
        test('input is rendered', () => {
            setupRTL();

            const input = screen.getByRole('combobox');
            expect(input).toBeInTheDocument();
            expect(input.required).toBeTruthy();
        });

        test('Blank input will result in disabled button', () => {
            initialState = {
                ...initialState,
                cancelReasons: {
                    data: null,
                    error: null
                }
            };

            setupRTL();
            expect(screen.queryByText('Cancel Reason is required')).not.toBeInTheDocument();
            userEvent.selectOptions(screen.getByRole('combobox'), [ITP_SELECT_OPTION]);
            expect(screen.getByRole('button', { name: 'Submit' })).toBeDisabled();
        });
    });

    describe('Non Critical Error - Record Call Failure', () => {
        beforeEach(() => {
            onEndProcessMock = jest.fn();
            onBackMock = jest.fn();
            initialState = {
                ...initialState,
                recordCall: {
                    data: {},
                    error: {
                        cause: [''],
                        message: ['Test error']
                    }
                }
            };
        });

        test('Render Error Text for Call Recording Failure', () => {
            setupRTL();
            expect(screen.getByText(TAGGING_ERROR_HEADER_CANCELLATION)).toBeInTheDocument();
            expect(screen.getByText(TAGGING_ERROR_SUB_HEADER)).toBeInTheDocument();
            expect(screen.getByText('X')).toBeInTheDocument();
        });

        test('Error TextBox closes when clicking X', () => {
            initialState = {
                ...initialState,
                cancelReasons: {
                    data: {},
                    error: null
                }
            };
            setupRTL();
            userEvent.click(screen.getByTestId('x-button', { name: X_BUTTON }));
            expect(screen.queryByText(TAGGING_ERROR_HEADER_CANCELLATION)).not.toBeInTheDocument();
            expect(screen.queryByText(TAGGING_ERROR_SUB_HEADER)).not.toBeInTheDocument();
            expect(screen.queryByText('X')).not.toBeInTheDocument();
        });
    });

    describe('Critical Error - Cancellation Failure', () => {
        beforeEach(() => {
            onEndProcessMock = jest.fn();
            onBackMock = jest.fn();
            initialState = {
                ...initialState,
                cancelEnrollment: {
                    data: null,
                    error: {
                        cause: [''],
                        message: ['Test error']
                    }
                }
            };
        });

        test('Render Talking Point and Error Popup for Call Recording Failure', () => {
            setupRTL();
            expect(screen.queryByText(ITP_TALKING_POINT)).toBeInTheDocument();
            expect(screen.getByText(CANCELLATION_HEADER)).toBeInTheDocument();
            expect(screen.getByText(CANCELLATION_SUB_HEADER)).toBeInTheDocument();
            expect(screen.getByText(ITP_END_PROCESS)).toBeInTheDocument();
        });
    });

    describe('Critical Error - Fetching Cancel Reasons Failure', () => {
        beforeEach(() => {
            onEndProcessMock = jest.fn();
            onBackMock = jest.fn();
            initialState = {
                ...initialState,
                cancelEnrollment: {
                    data: null,
                    error: null
                },
                cancelReasons: {
                    data: null,
                    error: {
                        cause: [''],
                        message: ['Test error']
                    }
                }
            };
        });

        test('Render Talking Point and Error Popup for Call Recording Failure', () => {
            setupRTL();
            expect(screen.getByText(CANCELLATION_HEADER)).toBeInTheDocument();
            expect(screen.queryByText(ITP_TALKING_POINT)).toBeInTheDocument();
            expect(screen.getByText(CANCELLATION_SUB_HEADER)).toBeInTheDocument();
            expect(screen.getByText(ITP_END_PROCESS)).toBeInTheDocument();
        });
    });
});