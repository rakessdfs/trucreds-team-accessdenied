import { IApiState } from '../../../../../common/types';
import { RESET_DATA } from '../../AccountLookup/AccountLookupConstants';
import { IBillingState, TBillingAction } from './BillingState.types';
import {
    ITP_BILLING_FAILURE,
    ITP_BILLING_REQUEST,
    ITP_BILLING_SUCCESS
} from './ItpDataConstants';

export const initialState: IApiState<IBillingState> = {
    error: null,
    isFetching: false,
    data: null
};

export const billingDataReducer = (state = initialState, action: TBillingAction): IApiState<IBillingState> => {
    switch (action.type) {
        case ITP_BILLING_REQUEST:
            return {
                ...state,
                isFetching: true,
                data: null,
                error: null
            };
        case ITP_BILLING_SUCCESS:
            return {
                ...state,
                isFetching: false,
                data: {
                    ...action.payload
                },
                error: null
            };
        case ITP_BILLING_FAILURE:
            return {
                ...state,
                isFetching: false,
                data: null,
                error: action.payload
            };
        case RESET_DATA:
            return {
                ...state,
                data: null,
                isFetching: false,
                error: null
            };
        default:
            return state;
    }
};