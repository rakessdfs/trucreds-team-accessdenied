import { IApiState } from '../../../../../../common/types';
import { RESET_DATA } from '../../../AccountLookup/AccountLookupConstants';
import { IFetchMemoState, TFetchMemoAction } from './MemoPreview.types';
import { FETCH_MEMO_FAILURE, FETCH_MEMO_REQUEST, FETCH_MEMO_SUCCESS } from './MemoPreviewConstants';

export const initialState: IApiState<IFetchMemoState> = {
    error: null,
    isFetching: false,
    data: null
};

export const memoPreviewReducer = (state = initialState, action: TFetchMemoAction): IApiState<IFetchMemoState> => {
    switch (action.type) {
        case FETCH_MEMO_REQUEST:
            return {
                ...state,
                isFetching: true,
                data: {
                    memoData: null
                },
                error: null
            };
        case FETCH_MEMO_SUCCESS:
            return {
                ...state,
                isFetching: false,
                data: {
                    memoData: action.payload
                },
                error: null
            };
        case FETCH_MEMO_FAILURE:
            return {
                ...state,
                isFetching: false,
                data: null,
                error: action.payload
            };
        case RESET_DATA:
            return {
                ...state,
                data: null,
                isFetching: false,
                error: null
            };
        default:
            return state;
    }
};