import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import {
    customerSearchNoResults,
    customerSearchSuccessResponse
} from '../../../../../../msw/responses/customerSearch/responses';
import { logout } from '../../../../login/Login.actions';
import { CUSTOMER_SEARCH_FAILURE, CUSTOMER_SEARCH_REQUEST, CUSTOMER_SEARCH_SUCCESS } from '../AccountLookupConstants';
import { INTERNAL_SERVER_ERROR } from '../../../../../common/constants/ITPConstants';
import {
    attemptCustomerSearchRequest,
    customerSearchFailure,
    customerSearchRequest,
    customerSearchSuccess
} from './CustomerSearch.actions';

describe('CustomerSearchActions', () => {
    test('customerSearchSuccess', () => {
        const data = {
            ...customerSearchSuccessResponse
        };

        expect(customerSearchSuccess(data)).toEqual({
            type: CUSTOMER_SEARCH_SUCCESS,
            payload: {
                ...data
            }
        });
    });

    test('customerSearchRequest', () => {
        const data = {
            firstName: 'bat',
            lastName: 'man',
            dateOfBirth: '05/01/1990'
        };

        expect(customerSearchRequest(data)).toEqual({
            type: CUSTOMER_SEARCH_REQUEST,
            payload: {
                ...data
            }
        });
    });

    test('customerSearchFailure', () => {
        const error = {
            message: ['error'],
            cause: ['unknown']
        };
        expect(customerSearchFailure(error)).toEqual({
            type: CUSTOMER_SEARCH_FAILURE,
            payload: error
        });
    });

    describe('attemptCustomerSearchRequest', () => {
        const middleware = [thunk];
        const mockStore = configureMockStore(middleware);
        let store, data;

        beforeEach(() => {
            store = mockStore({
                user: {
                    data: {
                        userName: 'testUser123'
                    }
                }
            });
            jest.resetAllMocks();
            data = {
                firstName: 'Super',
                lastName: 'Man',
                dateOfBirth: '02/02/85'
            };
            document.cookie = 'auth-token=jwt-token';
        });

        test('handles 200 success path', async () => {
            await store.dispatch(attemptCustomerSearchRequest(data.firstName, data.lastName, data.dateOfBirth));
            const actions = store.getActions();

            expect(actions[0]).toEqual(customerSearchRequest({
                ...data
            }));
            expect(actions[1]).toEqual(customerSearchSuccess(customerSearchSuccessResponse));
        });

        test('handles no results', async () => {
            await store.dispatch(attemptCustomerSearchRequest('noResults', data.lastName, data.dateOfBirth));
            const actions = store.getActions();

            expect(actions[0]).toEqual(customerSearchRequest({
                ...data,
                firstName: 'noResults'
            }));
            expect(actions[1]).toEqual(customerSearchSuccess(customerSearchNoResults));
        });

        test('handles invalid first name', async () => {
            await store.dispatch(attemptCustomerSearchRequest('invalidFirstName', data.lastName, data.dateOfBirth));
            const actions = store.getActions();

            expect(actions[0]).toEqual(customerSearchRequest({
                ...data,
                firstName: 'invalidFirstName'
            }));

            expect(actions[1]).toEqual(customerSearchFailure({
                cause: ['1003'],
                message: ['Invalid request. Please resolve and try again.']
            }));
        });

        test('handles invalid last name', async () => {
            await store.dispatch(attemptCustomerSearchRequest('invalidLastName', data.lastName, data.dateOfBirth));
            const actions = store.getActions();

            expect(actions[0]).toEqual(customerSearchRequest({
                ...data,
                firstName: 'invalidLastName'
            }));

            expect(actions[1]).toEqual(customerSearchFailure({
                cause: ['1004'],
                message: ['Invalid request. Please resolve and try again.']
            }));
        });

        test('handles invalid dob', async () => {
            await store.dispatch(attemptCustomerSearchRequest('invalidDOB', data.lastName, data.dateOfBirth));
            const actions = store.getActions();

            expect(actions[0]).toEqual(customerSearchRequest({
                ...data,
                firstName: 'invalidDOB'
            }));

            expect(actions[1]).toEqual(customerSearchFailure({
                cause: ['1002'],
                message: ['Invalid request. Please resolve and try again.']
            }));
        });

        test('handles 401 unauthenticated user', async () => {
            document.cookie = 'auth-token=';
            await store.dispatch(attemptCustomerSearchRequest(data.firstName, data.lastName, data.dateOfBirth));
            const actions = store.getActions();

            expect(actions[0]).toEqual(customerSearchRequest({
                ...data
            }));
            expect(actions[2]).toEqual(logout({
                cause: ['1009'],
                message: []
            }));
        });

        test('handles 500 error', async () => {
            await store.dispatch(attemptCustomerSearchRequest('500error', data.lastName, data.dateOfBirth));
            const actions = store.getActions();

            expect(actions[0]).toEqual(customerSearchRequest({
                ...data,
                firstName: '500error'
            }));
            expect(actions[1]).toEqual(customerSearchFailure({
                cause: [INTERNAL_SERVER_ERROR],
                message: [INTERNAL_SERVER_ERROR]
            }));
        });
    });
});