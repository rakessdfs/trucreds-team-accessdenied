import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { createMemoSuccess, createMemoRequest, createMemoFailure, attemptCreateMemoRequest } from './UtilityMenu.actions';
import { CREATE_MEMO_SUCCESS, CREATE_MEMO_REQUEST, CREATE_MEMO_FAILURE } from './UtilityMenuContants';

describe('MemoActions', () => {
    test('createMemoSuccess', () => {
        const result = createMemoSuccess();
        expect(result).toEqual({
            type: CREATE_MEMO_SUCCESS,
            payload: null
        });
    });

    test('createMemoRequest', () => {
        const data = {
            productEnrollmentId: '13578'
        };

        expect(createMemoRequest(data)).toEqual({
            type: CREATE_MEMO_REQUEST,
            payload: {
                ...data
            }
        });
    });

    test('createMemoFailure', () => {
        const error = {
            message: ['error'],
            cause: ['unknown']
        };
        expect(createMemoFailure(error)).toEqual({
            type: CREATE_MEMO_FAILURE,
            payload: error
        });
    });

    describe('attemptCreateMemoRequest', () => {
        const middleware = [thunk];
        const mockStore = configureMockStore(middleware);
        let store, initialState;

        beforeEach(() => {
            initialState = {
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'testing123'
                    }
                }
            };
            store = mockStore(initialState);
            jest.resetAllMocks();
        });

        test('handles 201 success path', async () => {
            await store.dispatch(attemptCreateMemoRequest('Enrolled'));
            const actions = store.getActions();
            expect(actions[1]).toEqual(createMemoSuccess());
        });

        test('handles 400 response code', async () => {
            await store.dispatch(attemptCreateMemoRequest('memo400'));
            const actions = store.getActions();

            expect(actions[1]).toEqual(createMemoFailure({
                cause: ['1012'],
                message: ['Invalid request. Please resolve and try again.']
            }));
        });

        test('handles failure path', async () => {
            await store.dispatch(attemptCreateMemoRequest('memo500'));
            const actions = store.getActions();
            expect(actions[1]).toEqual(createMemoFailure({
                cause: ['5006'],
                message: ['Unable to load Create Memo at this time. Please try again.']
            }));
        });
    });

    test('createMemoFailure', () => {
        const error = {
            errorCode: '1',
            message: ['some message']
        };
        const result = createMemoFailure(error);
        expect(result).toEqual({
            type: CREATE_MEMO_FAILURE,
            payload: error
        });
    });
});