import { IApiState } from '../../../../../common/types';
import {
    CUSTOMER_SEARCH_REQUEST,
    CUSTOMER_SEARCH_SUCCESS,
    CUSTOMER_SEARCH_FAILURE,
    RESET_DATA
} from '../AccountLookupConstants';
import { ICustomerSearchResponse, TCustomerSearchAction } from './CustomerSearch.types';

export const initialState: IApiState<ICustomerSearchResponse> = {
    error: null,
    isFetching: false,
    data: null
};

export const customerSearchReducer = (state = initialState, action: TCustomerSearchAction): IApiState<ICustomerSearchResponse> => {
    switch (action.type) {
        case CUSTOMER_SEARCH_REQUEST:
            return {
                ...state,
                isFetching: true,
                data: null,
                error: null
            };
        case CUSTOMER_SEARCH_SUCCESS:
            return {
                ...state,
                isFetching: false,
                data: action.payload,
                error: null
            };
        case CUSTOMER_SEARCH_FAILURE:
            return {
                ...state,
                isFetching: false,
                data: null,
                error: action.payload
            };
        case RESET_DATA:
            return {
                ...state,
                data: null,
                isFetching: false,
                error: null
            };
        default:
            return state;
    }
};