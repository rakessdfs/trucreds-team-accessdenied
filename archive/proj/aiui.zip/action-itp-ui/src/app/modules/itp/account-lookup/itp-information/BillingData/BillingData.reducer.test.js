import { buildReduxError } from '../../../../../common/utils/ITPUtils';
import { resetData } from '../../AccountLookup/CustomerPII.actions';
import { billingDataFailure, billingDataRequest, billingDataSuccess } from './BillingData.actions';
import { billingDataReducer } from './BillingData.reducer';

describe('billingDataReducer', () => {
    let initialState;

    beforeEach(() => {
        initialState = {
            error: null,
            isFetching: true,
            data: null
        };
    });

    describe('billingDataRequest', () => {
        test('sets the state correctly', () => {
            const billingRequestData = {
                productEnrollmentId: 'peid'
            };

            expect(billingDataReducer(initialState, billingDataRequest(billingRequestData))).toEqual({
                ...initialState,
                isFetching: true,
                error: null
            });
        });
    });

    describe('successResponse', () => {
        test('sets the new state correctly', () => {
            const successData = {
                pcmFirstName: 'first name',
                pcmLastName: 'last date',
                pcmAccountNumber: 'acc number',
                presenceOfSecondary: 'yes'
            };
            expect(
                billingDataReducer(initialState, billingDataSuccess(successData))
            ).toEqual({
                data: {
                    ...successData
                },
                isFetching: false,
                error: null
            });
        });
    });

    describe('billingDataFailure', () => {
        test('sets the state correctly', () => {
            expect(billingDataReducer(initialState, billingDataFailure(buildReduxError('some custom error', '')))).toEqual({
                ...initialState,
                error: {
                    cause: [''],
                    message: ['some custom error']
                },
                isFetching: false
            });
        });
    });

    describe('resetData', () => {
        test('sets the state correctly', () => {
            expect(billingDataReducer(initialState, resetData())).toEqual({
                ...initialState,
                data: null,
                isFetching: false,
                error: null
            });
        });
    });
});