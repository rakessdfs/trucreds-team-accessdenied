import React from 'react';
import { screen } from '@testing-library/react';
import { renderContainer } from '../../../../../../common/utils/test-utils';
import { MemoPreview } from './MemoPreview';

describe('MemoPreview', () => {
    const memo = {
        CREATE_DATE: '01/01/1990',
        CREATE_TIME: '12:00:00 AM',
        CREATE_AGENT_ID: 'Batman',
        MEMO_TEXT: 'some memo text'
    };

    const setupRTL = () => {
        renderContainer(<MemoPreview memo={memo} />);
    };

    test('Renders memo creation date, time, and agent id', () => {
        setupRTL();
        expect(screen.getByText(`${memo.CREATE_DATE}, ${memo.CREATE_TIME} | ${memo.CREATE_AGENT_ID}`)).toBeInTheDocument();
    });

    test('Renders memo text', () => {
        setupRTL();
        expect(screen.getByText(memo.MEMO_TEXT)).toBeInTheDocument();
    });
});