import React, { ReactElement, useEffect } from 'react';
import './AccountActivity.scss';
import { faSortDown } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { useDispatch, useSelector } from 'react-redux';
import Moment from 'moment';
import * as constants from '../../../../../common/constants/ITPConstants';
import { IReduxState } from '../../../../../store/Store.types';
import { CircularSpinner } from '../../../../../common/Components/CircularSpinner/CircularSpinner';
import { formatDateInEST } from '../../../../../common/utils/ITPUtils';
import { DATE_FORMAT } from './AccountActivityConstants';
import { fetchRequestActivities } from './AccountActivity.actions';

export const AccountActivity = (): ReactElement => {
    const reduxDispatch = useDispatch();
    const { data: enrollmentData } = useSelector((state: IReduxState) => state.itpEnrollmentData);
    const peid = enrollmentData?.productEnrollmentId;
    const { data: accountActivitiesData, error: accountActivitiesError, isFetching } = useSelector((state: IReduxState) => state.accountActivity);
    useEffect(() => {
        if (peid) {
            reduxDispatch(fetchRequestActivities(`${peid}`));
        }
    }, [reduxDispatch, peid]);

    if (isFetching) {
        return <CircularSpinner isButton={false} />;
    } else if (accountActivitiesError) {
        return (
            <div className='noDataMessage'>
                {accountActivitiesError?.message.length > 0 && accountActivitiesError?.message }
                {accountActivitiesError?.cause.length > 0 &&
                    <div className='redMessage'>{accountActivitiesError?.cause}</div>
                }
            </div>
        );
    } else {
        return (
            <div className='masterDiv'>
                <section>
                    <header className='section'>
                        <div className='col header'>{constants.COL_HEADER_REQ_DATE}
                            <FontAwesomeIcon
                                icon={faSortDown}
                                className='login-icon'
                                data-testid='sort-icon'
                            />
                        </div>
                        <div className='col header'>{constants.COL_HEADER_REQ_ACTIVITY}</div>
                        <div className='col header'>{constants.COL_HEADER_COM_DATE}
                        </div>
                        <div className='col header'>{constants.COL_HEADER_OPERATOR}</div>
                        <div className='col header'>{constants.COL_HEADER_STATUS}</div>
                    </header>
                    <div className='line-break'></div>
                    <div className='container'>
                        {accountActivitiesData?.accountActivityData?.accountActivityList.map((activity) => (
                            <div className='section'>
                                <div className='col'>{Moment(formatDateInEST(activity.requestDate)).format(DATE_FORMAT)}</div>
                                <div className='col'>{activity.activityDesc.toUpperCase()}{activity.previousData} {activity.newData}
                                </div>
                                <div className='col'>{Moment(formatDateInEST(activity.requestDate)).format(DATE_FORMAT)}</div>
                                <div className='col'>{activity.operator.toUpperCase()}</div>
                                <div className='col'>{constants.REQUEST_COMPLETE}</div>
                            </div>
                        ))}
                    </div>
                </section>
            </div>
        );
    }
};