import React, { ReactElement } from 'react';
import { useMachine } from '@xstate/react';
import { AnyEventObject, State, StateValue } from 'xstate';
import { useDispatch } from 'react-redux';
import { HeaderComponent } from '../../header/HeaderComponent';
import { CustomerPII } from '../pii/CustomerPIIComponent';
import './DashboardComponent.scss';
import { UtilityMenu } from '../utilityMenu/UtilityMenu';
import { Verification } from '../account-lookup/verification/Verification';
import { ItpInformation } from '../account-lookup/itp-information/ItpInformation';
import { AccountLookup } from '../account-lookup/AccountLookup/AccountLookup';
import { attemptCreateMemoRequest } from '../utilityMenu/UtilityMenu.actions';
import { resetData } from '../account-lookup/AccountLookup/CustomerPII.actions';
import { Timer } from '../../../common/Components/Timer/Timer';
import { CancelEnrollment } from '../account-lookup/itp-information/cancel/CancelEnrollment';
import { serviceCustomerFlowMachine } from './servicingStateMachine';

export const DashboardComponent = (): ReactElement | null => {
    const dispatch = useDispatch();

    const [currentState, sendStateUpdate] = useMachine(serviceCustomerFlowMachine({
        onSkip: () => dispatch(attemptCreateMemoRequest('Customer Verification Skipped')),
        onVerify: () => dispatch(attemptCreateMemoRequest('Customer Verification Completed'))
    }));

    const handleBackToSearchClick = (): void => {
        dispatch(resetData());
        sendStateUpdate('BACK_TO_SEARCH');
    };

    if (currentState.matches('customerSearch')) {
        return (
            <>
                <HeaderComponent
                    onBackToSearchClick={handleBackToSearchClick}
                    dashboardState={currentState.value}
                />
                <AccountLookup onViewAccount={(): State<unknown, AnyEventObject> => sendStateUpdate('VIEW_ACCOUNT')} />
                <Timer showModal={false} />
            </>
        );
    } else {
        return (
            <>
                <HeaderComponent
                    onBackToSearchClick={handleBackToSearchClick}
                    dashboardState={currentState.value}
                />
                <div className='membership-pane'>
                    <div
                        id='pii-data'
                        className='left-pane box-shadows-style'
                    >
                        <CustomerPII />
                    </div>
                    <CustomerDetails
                        currentState={currentState.value}
                        onSkipValidation={(): State<unknown, AnyEventObject> => sendStateUpdate('SKIP')}
                        onConfirmValidation={(): State<unknown, AnyEventObject> => sendStateUpdate('VERIFY')}
                        onCancelEnrollment={(): State<unknown, AnyEventObject> => sendStateUpdate('CANCEL_ENROLLMENT')}
                        onBack={(): State<unknown, AnyEventObject> => sendStateUpdate('BACK_TO_DASHBOARD')}
                    />
                </div>
                <Timer showModal={false} />
            </>
        );
    }
};

interface ICustomerDetailsProps {
    currentState: StateValue;
    onSkipValidation: () => void;
    onConfirmValidation: () => void;
    onCancelEnrollment: () => void;
    onBack: () => void;
}

const CustomerDetails = ({ currentState, onSkipValidation, onConfirmValidation,
    onCancelEnrollment, onBack }: ICustomerDetailsProps): ReactElement | null => {
    if (currentState === 'verifyInfo') {
        return (
            <div
                id='membership-data'
                className='center-pane box-shadows-style '
            >
                <Verification
                    onSkip={onSkipValidation}
                    onConfirm={onConfirmValidation}
                />
            </div>
        );
    } else if (currentState === 'cancelEnrollment') {
        return (
            <>
                <div
                    id='membership-data'
                    className='center-pane box-shadows-style '
                >
                    <CancelEnrollment
                        onBack={onBack}
                    />
                </div>
                <div
                    id='utility-data'
                    className='right-pane box-shadows-style '
                >
                    <UtilityMenu />
                </div>
            </>
        );
    } else {
        return (
            <>
                <div
                    id='membership-data'
                    className='center-pane box-shadows-style '
                >
                    <ItpInformation
                        onCancel={onCancelEnrollment}
                    />
                </div>
                <div
                    id='utility-data'
                    className='right-pane box-shadows-style '
                >
                    <UtilityMenu />
                </div>
            </>
        );
    }
};