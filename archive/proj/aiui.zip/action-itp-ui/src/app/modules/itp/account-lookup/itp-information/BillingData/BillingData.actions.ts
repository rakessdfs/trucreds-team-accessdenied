import axios from 'axios';
import { ThunkDispatch } from 'redux-thunk';
import { IReduxState } from 'src/app/store/Store.types';
import { IReduxError } from '../../../../../common/types';
import { validateResponse } from '../../../../../common/utils/ITPUtils';
import { getAuthCookie } from '../../../../login/LoginUtils';
import {
    URL_ACTION_BILLING_DATA_CONTEXT,
    URL_ACTION_ITP_API_HOSTNAME, URL_ACTION_ITP_API_HOSTNAME_LOCAL
} from '../../../../../common/constants/ITPConstants';
import { attemptLogout } from '../../../../login/Login.actions';
import {
    IBillingFailureAction,
    IBillingRequest,
    IBillingRequestAction,
    IBillingResponse,
    IBillingSuccessAction
} from './BillingState.types';
import {
    ITP_BILLING_FAILURE,
    ITP_BILLING_REQUEST,
    ITP_BILLING_SUCCESS
} from './ItpDataConstants';

export const billingDataSuccess = (response: IBillingResponse): IBillingSuccessAction => ({
    type: ITP_BILLING_SUCCESS,
    payload: response
});

export const billingDataRequest = ({ productEnrollmentId }: IBillingRequest): IBillingRequestAction => ({
    type: ITP_BILLING_REQUEST,
    payload: {
        productEnrollmentId
    }
});

export const billingDataFailure = (error: IReduxError): IBillingFailureAction => ({
    type: ITP_BILLING_FAILURE,
    payload: error
});

export const fetchBillingData = () => {
    return async (dispatch: ThunkDispatch<IReduxState, unknown, IBillingRequestAction | IBillingFailureAction | IBillingSuccessAction>, getState: () => IReduxState): Promise<void> => {
        const productEnrollmentId = getState().itpEnrollmentData.data?.productEnrollmentId || '';
        const subscriberId = getState().itpEnrollmentData.data?.subscriberNumber || '';
        const partyId = getState().itpEnrollmentData.data?.partyId || '';
        const customerType = getState().itpEnrollmentData.data?.customerType || '';
        const agentName = getState().user.data?.userName || '';

        dispatch(billingDataRequest({
            productEnrollmentId
        }));

        let response;

        try {
            response = await axios({
                method: 'get',
                url: `${(URL_ACTION_ITP_API_HOSTNAME ||
                    URL_ACTION_ITP_API_HOSTNAME_LOCAL)}${URL_ACTION_BILLING_DATA_CONTEXT}${productEnrollmentId}&subscriberId=${subscriberId}&partyId=${partyId}&customerType=${customerType}`,
                headers: {
                    Authorization: `Bearer ${getAuthCookie()}`,
                    'X-DFSUSER-USER-ID': agentName
                }
            });

            const error = validateResponse(response, 'Primary Card Member');

            if (error) {
                dispatch(billingDataFailure(error));
                return;
            }
        } catch (e) {
            if (e.response?.status === 401) {
                dispatch(attemptLogout((validateResponse(e.response, 'Primary Card Member') as IReduxError)));
                return;
            }
            dispatch(billingDataFailure((validateResponse(e.response, 'Primary Card Member') as IReduxError)));
            return;
        }
        dispatch(billingDataSuccess(response?.data));
    };
};