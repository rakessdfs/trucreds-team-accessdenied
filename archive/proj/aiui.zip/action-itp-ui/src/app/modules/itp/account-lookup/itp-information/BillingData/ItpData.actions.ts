import axios from 'axios';
import { ThunkDispatch } from 'redux-thunk';
import { IReduxState } from 'src/app/store/Store.types';
import { IReduxError } from '../../../../../common/types';
import { validateResponse } from '../../../../../common/utils/ITPUtils';
import { getAuthCookie } from '../../../../login/LoginUtils';
import {
    URL_ACTION_ITP_API_HOSTNAME,
    URL_ACTION_ITP_API_HOSTNAME_LOCAL, URL_ACTION_ITP_DATA_CONTEXT
} from '../../../../../common/constants/ITPConstants';
import { attemptLogout } from '../../../../login/Login.actions';
import {
    IMembershipFailureAction,
    IMembershipRequest,
    IMembershipRequestAction,
    IMembershipResponse,
    IMembershipSuccessAction
} from './MembershipState.types';
import { ITP_ENROLLMENT_FAILURE, ITP_ENROLLMENT_REQUEST, ITP_ENROLLMENT_SUCCESS } from './ItpDataConstants';

export const itpDataSuccess = (response: IMembershipResponse): IMembershipSuccessAction => ({
    type: ITP_ENROLLMENT_SUCCESS,
    payload: response
});

export const itpDataRequest = ({ partyId }: IMembershipRequest): IMembershipRequestAction => ({
    type: ITP_ENROLLMENT_REQUEST,
    payload: {
        partyId
    }
});

export const itpDataFailure = (error: IReduxError): IMembershipFailureAction => ({
    type: ITP_ENROLLMENT_FAILURE,
    payload: error
});

export const fetchITPData = (partyId: string) => {
    return async (dispatch: ThunkDispatch<IReduxState, unknown, IMembershipRequestAction | IMembershipFailureAction | IMembershipSuccessAction>, getState: () => IReduxState): Promise<void> => {
        const agentName = getState().user.data?.userName;

        dispatch(itpDataRequest({
            partyId
        }));

        let response;

        try {
            response = await axios({
                method: 'get',
                url: `${(URL_ACTION_ITP_API_HOSTNAME || URL_ACTION_ITP_API_HOSTNAME_LOCAL)}${URL_ACTION_ITP_DATA_CONTEXT}${partyId}`,
                headers: {
                    Authorization: `Bearer ${getAuthCookie()}`,
                    'X-DFSUSER-USER-ID': agentName
                }
            });

            const error = validateResponse(response, 'customer');

            if (error) {
                dispatch(itpDataFailure(error));
                return;
            }
        } catch (e) {
            if (e.response?.status === 401) {
                dispatch(attemptLogout((validateResponse(e.response, 'customer') as IReduxError)));
                return;
            }
            dispatch(itpDataFailure((validateResponse(e.response, 'customer') as IReduxError)));
            return;
        }
        dispatch(itpDataSuccess(response?.data));
    };
};