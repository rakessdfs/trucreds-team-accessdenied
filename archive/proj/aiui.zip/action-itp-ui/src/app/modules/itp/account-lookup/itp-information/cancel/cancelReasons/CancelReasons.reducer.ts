import { IApiState } from '../../../../../../common/types';
import { RESET_DATA } from '../../../AccountLookup/AccountLookupConstants';
import {
    ITP_CANCEL_REASONS_FAILURE,
    ITP_CANCEL_REASONS_REQUEST,
    ITP_CANCEL_REASONS_SUCCESS
} from '../CancelConstants';
import { ICancelReasonsState, TCancelReasonsAction } from './CancelReasons.types';

export const initialState: IApiState<{}> = {
    error: null,
    isFetching: false,
    data: null
};

export const itpCancelReasonsReducer = (state = initialState, action: TCancelReasonsAction): IApiState<ICancelReasonsState> => {
    switch (action.type) {
        case ITP_CANCEL_REASONS_REQUEST:
            return {
                ...state,
                isFetching: true,
                data: null,
                error: null
            };
        case ITP_CANCEL_REASONS_SUCCESS:
            return {
                ...state,
                isFetching: false,
                data: {
                    ...action.payload
                },
                error: null
            };
        case ITP_CANCEL_REASONS_FAILURE:
            return {
                ...state,
                isFetching: false,
                data: null,
                error: action.payload
            };
        case RESET_DATA:
            return {
                ...state,
                data: null,
                isFetching: false,
                error: null
            };
        default:
            return state;
    }
};