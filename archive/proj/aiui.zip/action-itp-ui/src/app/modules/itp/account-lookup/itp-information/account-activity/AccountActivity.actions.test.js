import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { accountActivitySuccessResponse } from '../../../../../../msw/responses/accountactivity/AccountActivityResponses';
import { RESET_DATA } from '../../AccountLookup/AccountLookupConstants';
import {
    fetchAccountActivityFailure,
    fetchAccountActivitySuccess,
    fetchAccountActivityRequest,
    fetchRequestActivities
} from './AccountActivity.actions';
import { FETCH_ACCOUNT_ACTIVITY_REQUEST,
    FETCH_ACCOUNT_ACTIVITY_SUCCESS,
    FETCH_ACCOUNT_ACTIVITY_FAILURE } from './AccountActivityConstants';

describe('Account Activity Actions', () => {
    test('fetch acc act success', () => {
        const data = {
            ...accountActivitySuccessResponse
        };
        const result = fetchAccountActivitySuccess(data);
        expect(result).toEqual({
            type: FETCH_ACCOUNT_ACTIVITY_SUCCESS,
            payload: {
                ...data
            }
        });
    });

    test('fetch acc act', () => {
        const data = {
            productEnrollmentId: '13578'
        };

        expect(fetchAccountActivityRequest(data)).toEqual({
            type: FETCH_ACCOUNT_ACTIVITY_REQUEST,
            payload: {
                ...data
            }
        });
    });

    test('fetch acc act failure', () => {
        const error = {
            message: ['error'],
            cause: ['unknown']
        };
        expect(fetchAccountActivityFailure(error)).toEqual({
            type: FETCH_ACCOUNT_ACTIVITY_FAILURE,
            payload: error
        });
    });

    describe('fetch acc activity', () => {
        const middleware = [thunk];
        const mockStore = configureMockStore(middleware);
        let store, data;

        beforeEach(() => {
            store = mockStore({});
            jest.resetAllMocks();
            data = {
                productEnrollmentId: '111'
            };
        });

        test('handles 200 success path with Data', async () => {
            await store.dispatch(fetchRequestActivities(data.productEnrollmentId));
            const actions = store.getActions();
            expect(actions[1].type).toEqual(FETCH_ACCOUNT_ACTIVITY_SUCCESS);
            expect(actions[1].payload.accountActivityList.length).toEqual(1);
            expect(actions[1].payload.accountActivityList[0].operator).toEqual('INTERNET');
            expect(actions[1].payload.accountActivityList[0].accountActivityId).toEqual(0);
        });

        test('handles 200 success path with Data', async () => {
            await store.dispatch(fetchRequestActivities('222'));
            const actions = store.getActions();
            expect(actions[1].type).toEqual(FETCH_ACCOUNT_ACTIVITY_SUCCESS);
            expect(actions[1].payload.accountActivityList.length).toEqual(1);
            expect(actions[1].payload.accountActivityList[0].operator).toEqual('INTERNET');
            expect(actions[1].payload.accountActivityList[0].accountActivityId).toEqual(0);
        });

        test('handles response with No Data', async () => {
            await store.dispatch(fetchRequestActivities('213'));
            const actions = store.getActions();
            expect(actions[1].type).toEqual(FETCH_ACCOUNT_ACTIVITY_FAILURE);
        });

        test('handles 400 response code', async () => {
            await store.dispatch(fetchRequestActivities('123'));
            const actions = store.getActions();
            expect(actions[1]).toEqual(fetchAccountActivityFailure({
                cause: ['1012'],
                message: ['Invalid request. Please resolve and try again.']
            }));
        });

        test('handles 500 response code', async () => {
            await store.dispatch(fetchRequestActivities('000'));
            const actions = store.getActions();
            expect(actions[1]).toEqual(fetchAccountActivityFailure({
                cause: ['5006'],
                message: ['Unable to load Account Activity at this time. Please try again.']
            }));
        });

        test('handles 401 response code', async () => {
            await store.dispatch(fetchRequestActivities('401'));
            const actions = store.getActions();
            expect(actions[1].type).toEqual(RESET_DATA);
        });
    });
});