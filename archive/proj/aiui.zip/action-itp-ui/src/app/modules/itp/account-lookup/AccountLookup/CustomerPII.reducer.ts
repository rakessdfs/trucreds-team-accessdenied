import { formatPhoneNumber } from '../../../../common/utils/ITPUtils';
import { IApiState } from '../../../../common/types';
import {
    PII_SUCCESS,
    PII_REQUEST,
    PII_FAILURE,
    PII_SSN_PREFIX,
    RESET_DATA
} from './AccountLookupConstants';
import { TPiiAction, IPiiState } from './AccountLookup.types';

export const initialState: IApiState<IPiiState> = {
    error: null,
    isFetching: false,
    data: null
};

export const piiReducer = (state = initialState, action: TPiiAction): IApiState<IPiiState> => {
    switch (action.type) {
        case PII_REQUEST:
            return {
                ...state,
                isFetching: true,
                data: null,
                error: null
            };
        case PII_SUCCESS:
            return {
                ...state,
                isFetching: false,
                data: {
                    firstName: action.payload.firstName,
                    lastName: action.payload.lastName,
                    dateOfBirth: action.payload.dateOfBirth,
                    ssn: PII_SSN_PREFIX + action.payload.ssn,
                    addressLine1: `${action.payload.address === null ? '' : action.payload.address?.addressLine1} ${(action.payload.address === null ? '' : action.payload.address?.addressLine2 !== null) ? action.payload.address?.addressLine2 : ''}`,
                    addressLine2: `${action.payload.address === null ? '' : action.payload.address?.cityName.concat(',')} ${action.payload.address === null ? '' : action.payload.address?.stateOrSectionCode} ${action.payload.address === null ? '' : action.payload.address?.postalCode}`,
                    primaryPhone: formatPhoneNumber(action.payload.primaryPhone),
                    email: action.payload.email,
                    partyId: action.payload.partyId
                },
                error: null
            };
        case PII_FAILURE:
            return {
                ...state,
                isFetching: false,
                data: null,
                error: action.payload
            };
        case RESET_DATA:
            return {
                ...state,
                data: null,
                isFetching: false,
                error: null
            };
        default:
            return state;
    }
};