import React from 'react';
import { screen } from '@testing-library/react';
import createMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { renderContainer } from '../../../../../common/utils/test-utils';
import * as ItpInformationConstants from '../ItpInformationConstants';
import { INTERNAL_SERVER_ERROR } from '../../../../../common/constants/ITPConstants';
import { EnrollmentDetails } from './EnrollmentDetails';

describe('EnrollmentDetails', () => {
    let initialState, store;

    beforeEach(() => {
        jest.clearAllMocks();
        initialState = {
            itpEnrollmentData: {
                data: {
                    subscriberNumber: 'subscriber',
                    enrollmentDate: 'enroll date',
                    enrollmentStatus: 'status',
                    enrollmentFailedReason: 'failed reason',
                    cancellationDate: 'cancel date',
                    cancellationRequestDate: 'cancel request date',
                    cancellationReason: 'cancellation reason',
                    productEnrollmentId: 'PEID',
                    customerType: 'ITP_FF'
                },
                error: null,
                isFetching: false
            }
        };
    });

    const setupRTL = () => {
        store = createMockStore([thunk])(initialState);
        return renderContainer(<EnrollmentDetails />, {
            store
        });
    };

    describe('Happy path render enrollment details sections', () => {
        test('Render enrollment details sections F&F', () => {
            setupRTL();
            expect(screen.getByText(ItpInformationConstants.ENROLLMENT_DETAILS)).toBeInTheDocument();
            expect(screen.getByText(ItpInformationConstants.SUBSCRIBER_NUMBER)).toBeInTheDocument();
            expect(screen.getByText(ItpInformationConstants.ENROLLMENT_DATE)).toBeInTheDocument();
            expect(screen.getByText(ItpInformationConstants.STATUS)).toBeInTheDocument();
            expect(screen.getByText(ItpInformationConstants.ENROLLED_FAIL_REASON)).toBeInTheDocument();
            expect(screen.getByText(ItpInformationConstants.CANCELLATION_DATE)).toBeInTheDocument();
            expect(screen.getByText(ItpInformationConstants.CANCELLATION_REQUEST_DATE)).toBeInTheDocument();
        });

        test('Render enrollment details sections broad market', () => {
            initialState.itpEnrollmentData.data.customerType = 'ITP_BM';
            setupRTL();
            expect(screen.getByText(ItpInformationConstants.ENROLLMENT_DETAILS)).toBeInTheDocument();
            expect(screen.getByText(ItpInformationConstants.SUBSCRIBER_NUMBER)).toBeInTheDocument();
            expect(screen.getByText(ItpInformationConstants.ENROLLMENT_DATE)).toBeInTheDocument();
            expect(screen.getByText(ItpInformationConstants.STATUS)).toBeInTheDocument();
            expect(screen.getByText(ItpInformationConstants.CANCELLATION_DATE)).toBeInTheDocument();
            expect(screen.getByText(ItpInformationConstants.CANCELLATION_REQUEST_DATE)).toBeInTheDocument();
            expect(screen.getByText(ItpInformationConstants.CANCELLATION_REASON)).toBeInTheDocument();
        });
    });

    describe('Loading Cancellation Membership', () => {
        // eslint-disable-next-line sonarjs/no-identical-functions
        beforeEach(() => {
            jest.clearAllMocks();
            initialState = {
                ...initialState,
                ...initialState.itpEnrollmentData.data.enrollmentStatus = 'Cancelled',
                ...initialState.itpEnrollmentData.data.enrollmentFailedReason = ''
            };
        });

        // eslint-disable-next-line sonarjs/no-identical-functions
        test('Render and validate optional fields', () => {
            setupRTL();
            expect(screen.getByTestId('subscriber-data')).toHaveTextContent('subscriber');
            expect(screen.getByTestId('enrollment-date')).toHaveTextContent('enroll date');
            expect(screen.getByTestId('enrollment-status')).toHaveTextContent('Cancelled');
            expect(screen.getByTestId('enrollment-failreason')).toHaveTextContent('--');
            expect(screen.getByTestId('cancellation-date')).toHaveTextContent('cancel date');
            expect(screen.getByTestId('cancellation-request-date')).toHaveTextContent('cancel request date');
        });
    });

    describe('Loading Enrollment and pending enrollment Membership', () => {
        // eslint-disable-next-line sonarjs/no-identical-functions
        beforeEach(() => {
            jest.clearAllMocks();
            initialState = {
                ...initialState,
                ...initialState.itpEnrollmentData.data.enrollmentStatus = 'enrolled',
                ...initialState.itpEnrollmentData.data.enrollmentFailedReason = '',
                ...initialState.itpEnrollmentData.data.cancellationDate = '',
                ...initialState.itpEnrollmentData.data.cancellationRequestDate = ''
            };
        });

        // eslint-disable-next-line sonarjs/no-identical-functions
        test('Render and validate optional fields', () => {
            setupRTL();
            expect(screen.getByTestId('subscriber-data')).toHaveTextContent('subscriber');
            expect(screen.getByTestId('enrollment-date')).toHaveTextContent('enroll date');
            expect(screen.getByTestId('enrollment-status')).toHaveTextContent('enrolled');
            expect(screen.getByTestId('enrollment-failreason')).toHaveTextContent('--');
            expect(screen.getByTestId('cancellation-date')).toHaveTextContent('--');
            expect(screen.getByTestId('cancellation-request-date')).toHaveTextContent('--');
        });
    });

    describe('Loading Pending Cancellation Membership', () => {
        // eslint-disable-next-line sonarjs/no-identical-functions
        beforeEach(() => {
            jest.clearAllMocks();
            initialState = {
                itpEnrollmentData: {
                    data: {
                        subscriberNumber: 'subscriber',
                        enrollmentDate: 'enroll date',
                        enrollmentStatus: 'Pending Cancellation',
                        enrollmentFailedReason: 'enroll failure',
                        cancellationDate: '',
                        cancellationRequestDate: '',
                        productEnrollmentId: 'PEID',
                        customerType: 'ITP_FF'
                    },
                    error: null,
                    isFetching: false
                }
            };
        });

        // eslint-disable-next-line sonarjs/no-identical-functions
        test('Render and validate optional fields', () => {
            setupRTL();
            expect(screen.getByTestId('subscriber-data')).toHaveTextContent('subscriber');
            expect(screen.getByTestId('enrollment-date')).toHaveTextContent('enroll date');
            expect(screen.getByTestId('enrollment-status')).toHaveTextContent('Pending Cancellation');
            expect(screen.getByTestId('enrollment-failreason')).toHaveTextContent('enroll failure');
            expect(screen.getByTestId('cancellation-date')).toHaveTextContent('--');
            expect(screen.getByTestId('cancellation-request-date')).toHaveTextContent('--');
        });
    });

    describe('Fetching membership', () => {
        // eslint-disable-next-line sonarjs/no-identical-functions
        beforeEach(() => {
            jest.clearAllMocks();
            initialState = {
                itpEnrollmentData: {
                    data: null,
                    error: null,
                    isFetching: true
                }
            };
        });

        // eslint-disable-next-line sonarjs/no-identical-functions
        test('Fetching', () => {
            setupRTL();
            expect(screen.getByTestId('circularSpinner')).toBeInTheDocument();
        });
    });

    describe('Error in fetching membership', () => {
        // eslint-disable-next-line sonarjs/no-identical-functions
        beforeEach(() => {
            jest.clearAllMocks();
            initialState = {
                itpEnrollmentData: {
                    data: null,
                    error: {
                        cause: [INTERNAL_SERVER_ERROR],
                        message: []
                    },
                    isFetching: false
                }
            };
        });

        // eslint-disable-next-line sonarjs/no-identical-functions
        test('error in loading membership', () => {
            setupRTL();
            expect(screen.getByTestId('error-container')).toBeInTheDocument();
        });
    });
});