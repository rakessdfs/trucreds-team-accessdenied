import { screen } from '@testing-library/dom';
import React from 'react';
import createMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { renderContainer } from '../../../../../common/utils/test-utils';
import * as constants from '../../../../../common/constants/ITPConstants';
import * as allToggles from '../../../../../common/toggle/toggles';
import { toggleNames } from '../../../../../common/toggle/toggleNames';
import { AccountActivity } from './AccountActivity';

describe('account activity container', () => {
    let initialState, store, dataState, errorState;

    beforeEach(() => {
        jest.clearAllMocks();
        Object.defineProperty(allToggles, 'toggles', {
            value: {
                [toggleNames.SHOW_REQUEST_ACTIVITY]: true
            }
        });
        initialState = {
            itpEnrollmentData: {
                data: {
                    subscriberNumber: 'subscriber',
                    enrollmentDate: 'enroll date',
                    enrollmentStatus: 'status',
                    enrollmentFailedReason: 'failed reason',
                    cancellationDate: 'cancel date',
                    cancellationRequestDate: 'cancel request date',
                    productEnrollmentId: 'PEID',
                    customerType: 'ITP_FF'
                },
                error: null,
                isFetching: false
            },
            memo: {
                isFetching: false,
                error: null,
                data: null
            },
            billingData: {
                data: {
                    pcmFirstName: 'first name',
                    pcmLastName: 'last name',
                    pcmAccountNumber: 'acc number',
                    presenceOfSecondary: 'yes'
                },
                error: null,
                isFetching: false
            },
            user: {
                data: {
                    userName: 'test'
                }
            },
            accountActivity: {
                error: null,
                isFetching: false,
                data: {
                    accountActivityList: [
                        {
                            accountActivityId: 0,
                            activityDesc: 'test act desc',
                            createTs: '2021-02-17T18:53:30.029Z',
                            newData: 'this is new data',
                            operator: 'INTERNET',
                            previousData: 'this is old data',
                            productEnrollmentId: 'string',
                            requestDate: '2021-02-17T18:53:30.029Z',
                            updateTs: '2021-02-17T18:53:30.029Z'
                        }
                    ]
                }
            }
        };

        dataState = {
            itpEnrollmentData: {
                data: {
                    subscriberNumber: 'subscriber',
                    enrollmentDate: 'enroll date',
                    enrollmentStatus: 'status',
                    enrollmentFailedReason: 'failed reason',
                    cancellationDate: 'cancel date',
                    cancellationRequestDate: 'cancel request date',
                    productEnrollmentId: 'PEID',
                    customerType: 'ITP_FF'
                },
                error: null,
                isFetching: false
            },
            memo: {
                isFetching: false,
                error: null,
                data: null
            },
            billingData: {
                data: {
                    pcmFirstName: 'first name',
                    pcmLastName: 'last name',
                    pcmAccountNumber: 'acc number',
                    presenceOfSecondary: 'yes'
                },
                error: null,
                isFetching: false
            },
            user: {
                data: {
                    userName: 'test'
                }
            },
            accountActivity: {
                error: null,
                isFetching: true,
                data: null
            }
        };

        errorState = {
            itpEnrollmentData: {
                data: {
                    subscriberNumber: 'subscriber',
                    enrollmentDate: 'enroll date',
                    enrollmentStatus: 'status',
                    enrollmentFailedReason: 'failed reason',
                    cancellationDate: 'cancel date',
                    cancellationRequestDate: 'cancel request date',
                    productEnrollmentId: 'PEID',
                    customerType: 'ITP_FF'
                },
                error: null,
                isFetching: false
            },
            memo: {
                isFetching: false,
                error: null,
                data: null
            },
            billingData: {
                data: {
                    pcmFirstName: 'first name',
                    pcmLastName: 'last name',
                    pcmAccountNumber: 'acc number',
                    presenceOfSecondary: 'yes'
                },
                error: null,
                isFetching: false
            },
            user: {
                data: {
                    userName: 'test'
                }
            },
            accountActivity: {
                error: {
                    cause: [],
                    message: ['No Data Available.']
                },
                isFetching: false,
                data: null
            }
        };
    });

    const setupRTL = () => {
        store = createMockStore([thunk])(initialState);
        return renderContainer(<AccountActivity />, {
            store
        });
    };

    const setupRTLData = () => {
        store = createMockStore([thunk])(dataState);
        return renderContainer(<AccountActivity />, {
            store
        });
    };

    const setupRTLError = () => {
        store = createMockStore([thunk])(errorState);
        return renderContainer(<AccountActivity />, {
            store
        });
    };

    test('Renders all the headers correctly', () => {
        setupRTL();
        expect(screen.getByText(`${constants.COL_HEADER_REQ_DATE}`)).toBeInTheDocument();
        expect(screen.getByText(`${constants.COL_HEADER_OPERATOR}`)).toBeInTheDocument();
        expect(screen.getByText(`${constants.COL_HEADER_COM_DATE}`)).toBeInTheDocument();
        expect(screen.getByText(`${constants.COL_HEADER_STATUS}`)).toBeInTheDocument();
        expect(screen.getByText(`${constants.COL_HEADER_REQ_ACTIVITY}`)).toBeInTheDocument();
    });

    test('Renders the sort icon', () => {
        setupRTL();
        expect(screen.getByTestId('sort-icon')).toBeInTheDocument();
    });

    test('Renders the Spinner icon', () => {
        setupRTLData();
        expect(screen.getByTestId('circularSpinner')).toBeInTheDocument();
    });

    test('Renders the error section', () => {
        setupRTLError();
        expect(screen.getByText('No Data Available.')).toBeInTheDocument();
    });
});