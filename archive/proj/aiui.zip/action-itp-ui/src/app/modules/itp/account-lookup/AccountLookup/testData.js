export const successfulPiiResponse = {
    firstName: 'bat',
    lastName: 'man',
    ssn: '123-45-6789',
    dateOfBirth: '05/01/1990',
    address: {
        barCode: '000',
        cityName: 'Chicago',
        countryCode: 'USA',
        postalCode: '60060',
        addressLine1: '1234 Main Street',
        addressLine2: 'Unit 50000',
        stateOrSectionCode: 'IL',
        forbidAutoFormatting: true
    },
    primaryPhone: '123-456-7890',
    email: 'test@test.com'
};