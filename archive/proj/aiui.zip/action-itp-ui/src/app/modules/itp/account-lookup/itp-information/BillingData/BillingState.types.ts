import { IReduxError } from '../../../../../common/types';
export interface IBillingResponse {
    pcmFirstName: string;
    pcmLastName: string;
    pcmAccountNumber: string;
    presenceOfSecondary: string;
    nextBillingDate: string;
}

export interface IBillingRequest {
    productEnrollmentId: string | number;
}

export interface IBillingRequestAction {
    type: 'ITP_BILLING_REQUEST';
    payload: IBillingRequest;
}

export interface IBillingSuccessAction {
    type: 'ITP_BILLING_SUCCESS';
    payload: IBillingResponse;
}

export interface IBillingFailureAction {
    type: 'ITP_BILLING_FAILURE';
    payload: IReduxError;
}

export interface IResetData {
    type: 'RESET_DATA';
}

export interface IBillingState {
    pcmFirstName: string | null;
    pcmLastName: string | null;
    pcmAccountNumber: string | null;
    presenceOfSecondary: string | null;
    nextBillingDate: string | null;
}

export type TBillingAction = IBillingRequestAction | IBillingFailureAction | IBillingSuccessAction | IResetData;