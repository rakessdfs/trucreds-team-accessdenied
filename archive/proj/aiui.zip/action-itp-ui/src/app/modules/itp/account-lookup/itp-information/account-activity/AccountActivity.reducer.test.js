import { buildReduxError } from '../../../../../common/utils/ITPUtils';
import { resetData } from '../../AccountLookup/CustomerPII.actions';
import { fetchAccountActivityFailure, fetchAccountActivitySuccess, fetchAccountActivityRequest } from './AccountActivity.actions';
import { accountActivityReducer } from './AccountActivity.reducer';

describe('AccountActivityReducer', () => {
    let initialState;

    beforeEach(() => {
        initialState = {
            error: null,
            isFetching: true,
            data: null
        };
    });

    describe('AccountActivityRequest', () => {
        test('sets the state correctly', () => {
            const request = {
                productEnrollmentId: 'peid'
            };

            expect(accountActivityReducer(initialState, fetchAccountActivityRequest(request))).toEqual({
                ...initialState,
                isFetching: true,
                error: null
            });
        });
    });

    describe('successResponse', () => {
        test('sets the new state correctly', () => {
            const dataArr = [];
            const successData = {
                accountActivityId: 123,
                productEnrollmentId: '24332423',
                activityDesc: 'sdf sf',
                previousData: 'sdhfgdsf',
                newData: 'dhfsdf',
                operator: 'internet',
                requestDate: '12/12/2009',
                createTs: '12/12/2009',
                updateTs: '12/12/2009'
            };
            dataArr.push(successData);
            expect(
                accountActivityReducer(initialState, fetchAccountActivitySuccess(dataArr)).data.accountActivityData[0]
            ).toEqual({
                ...successData
            });
        });
    });

    describe('accountActivityFailure', () => {
        test('sets the state correctly', () => {
            expect(accountActivityReducer(initialState, fetchAccountActivityFailure(buildReduxError('some custom error', '')))).toEqual({
                ...initialState,
                error: {
                    cause: [''],
                    message: ['some custom error']
                },
                isFetching: false
            });
        });
    });

    describe('resetData', () => {
        test('sets the state correctly', () => {
            expect(accountActivityReducer(initialState, resetData())).toEqual({
                ...initialState,
                data: null,
                isFetching: false,
                error: null
            });
        });
    });
});