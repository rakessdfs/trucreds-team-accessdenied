import thunk from 'redux-thunk';
import configureMockStore from 'redux-mock-store';
import { billingDataSuccessResponse } from '../../../../../../msw/responses/itpData/billingDataSuccess';
import { logout } from '../../../../login/Login.actions';
import { INTERNAL_SERVER_ERROR } from '../../../../../common/constants/ITPConstants';
import { ITP_BILLING_FAILURE, ITP_BILLING_REQUEST, ITP_BILLING_SUCCESS } from './ItpDataConstants';
import { billingDataFailure, billingDataRequest, billingDataSuccess, fetchBillingData } from './BillingData.actions';

describe('billingDataActions', () => {
    test('billingDataRequest', () => {
        const peid = '1234';
        const data = {
            productEnrollmentId: peid
        };
        const result = billingDataRequest(data);
        expect(result).toEqual({
            type: ITP_BILLING_REQUEST,
            payload: {
                ...data
            }
        });
    });

    test('billingDataSuccess', () => {
        const data = {
            ...billingDataSuccessResponse
        };

        const result = billingDataSuccess(data);
        expect(result).toEqual({
            type: ITP_BILLING_SUCCESS,
            payload: {
                ...data
            }
        });
    });

    test('billingDataFailure', () => {
        const error = {
            message: ['error'],
            cause: ['unknown']
        };
        expect(billingDataFailure(error)).toEqual({
            type: ITP_BILLING_FAILURE,
            payload: error
        });
    });

    describe('fetchBillingData', () => {
        const middleware = [thunk];
        const mockStore = configureMockStore(middleware);
        let store, initialState;

        beforeEach(() => {
            initialState = {
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'testing123',
                        subscriberNumber: '12345'
                    }
                },
                user: {
                    data: {
                        userName: 'test'
                    }
                }
            };
            store = mockStore(initialState);
            jest.resetAllMocks();
            document.cookie = 'auth-token=jwt-token';
        });

        test('handles 200 success path', async () => {
            await store.dispatch(fetchBillingData());
            const actions = store.getActions();
            expect(actions[1]).toEqual(billingDataSuccess(billingDataSuccessResponse));
        });

        test('handles incorrect PEID', async () => {
            initialState = {
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'error',
                        subscriberNumber: '12345'
                    }
                },
                user: {
                    data: {
                        userName: 'test'
                    }
                }
            };
            store = mockStore(initialState);
            await store.dispatch(fetchBillingData());
            const actions = store.getActions();
            expect(actions[1]).toEqual(billingDataFailure({
                cause: [INTERNAL_SERVER_ERROR],
                message: [INTERNAL_SERVER_ERROR]
            }));
        });

        test('handles 401 unauthenticated user', async () => {
            document.cookie = 'auth-token=';
            await store.dispatch(fetchBillingData());
            const actions = store.getActions();

            expect(actions[2]).toEqual(logout({
                cause: ['1009'],
                message: []
            }));
        });

        test('handles empty PEID', async () => {
            initialState = {
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'emptyPeid',
                        subscriberNumber: '12345'
                    }
                },
                user: {
                    data: {
                        userName: 'test'
                    }
                }
            };
            store = mockStore(initialState);
            await store.dispatch(fetchBillingData());
            const actions = store.getActions();
            expect(actions[1]).toEqual(billingDataFailure({
                cause: ['1002'],
                message: ['Invalid request. Please resolve and try again.']
            }));
        });
    });
});