import { IApiState } from '../../../../../common/types';
import { RESET_DATA } from '../../AccountLookup/AccountLookupConstants';
import { IFetchAccountActivityState, TFetchAccountActivityAction } from './AccountActivity.types';
import { FETCH_ACCOUNT_ACTIVITY_REQUEST,
    FETCH_ACCOUNT_ACTIVITY_SUCCESS,
    FETCH_ACCOUNT_ACTIVITY_FAILURE } from './AccountActivityConstants';

export const initialState: IApiState<IFetchAccountActivityState> = {
    error: null,
    isFetching: false,
    data: null
};

export const accountActivityReducer = (state = initialState, action: TFetchAccountActivityAction): IApiState<IFetchAccountActivityState> => {
    switch (action.type) {
        case FETCH_ACCOUNT_ACTIVITY_REQUEST:
            return {
                ...state,
                isFetching: true,
                data: null,
                error: null
            };
        case FETCH_ACCOUNT_ACTIVITY_SUCCESS:
            return {
                ...state,
                isFetching: false,
                data: {
                    accountActivityData: action.payload
                },
                error: null
            };
        case FETCH_ACCOUNT_ACTIVITY_FAILURE:
            return {
                ...state,
                isFetching: false,
                data: null,
                error: action.payload
            };
        case RESET_DATA:
            return {
                ...state,
                data: null,
                isFetching: false,
                error: null
            };
        default:
            return state;
    }
};