export const memoData = {
    memoData: {
        allMemos: [
            {
                month: 'September 2020',
                memos: [
                    {
                        MEMO_TEXT: 'Enrolled into ITP F&F',
                        CREATE_AGENT_ID: 'test',
                        CREATE_DATE: '09/03/20',
                        CREATE_TIME: '07:32:56 pm',
                        CREATE_MONTH: 'September 2020'
                    }
                ]
            }
        ]
    }
};