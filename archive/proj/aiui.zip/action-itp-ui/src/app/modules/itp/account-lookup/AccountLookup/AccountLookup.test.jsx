import { screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import React from 'react';
import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { customerSearchSuccessResponse } from 'src/msw/responses/customerSearch/responses';
import { renderContainer } from '../../../../common/utils/test-utils';
import { INVALID_DOB, INVALID_FIRST_NAME, INVALID_LAST_NAME } from '../../../../common/constants/ITPConstants';
import * as allToggles from '../../../../common/toggle/toggles';
import { toggleNames } from '../../../../common/toggle/toggleNames';
import { AccountLookup } from './AccountLookup';
import {
    BTN_SEARCH,
    CUSTOMER_SEARCH, CUSTOMER_SEARCH_REQUEST_MSG,
    ERROR_MSG_ALL_FIELDS,
    LABEL_ASTERISK,
    LABEL_DOB,
    LABEL_FIRST_NAME,
    LABEL_LAST_NAME
} from './AccountLookupConstants';

describe('AccountLookup', () => {
    let initialState, store, onViewAccountMock;

    beforeEach(() => {
        onViewAccountMock = jest.fn();
        initialState = {
            customerSearch: {
                data: {
                    ...customerSearchSuccessResponse
                },
                error: null,
                isFetching: false
            },
            pii: {
                isFetching: false,
                error: null,
                data: {
                    firstName: '',
                    lastName: '',
                    dateOfBirth: '',
                    ssn: '',
                    address: '',
                    primaryPhone: '',
                    email: ''
                }
            },
            user: {
                data: {
                    userName: 'testUser123'
                }
            }
        };
        jest.resetAllMocks();
    });

    // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
    const setupRTL = () => {
        store = configureMockStore([thunk])(initialState);
        return renderContainer(<AccountLookup onViewAccount={onViewAccountMock} />, { store });
    };

    test('Renders section header', () => {
        setupRTL();
        expect(screen.getByRole('heading', { name: CUSTOMER_SEARCH })).toBeInTheDocument();
    });

    describe('Renders 3 input fields, a search button, and a clear button', () => {
        describe('renders input for first name, last name, ssn, and dob', () => {
            describe('first name input', () => {
                test('valid input does not cause invalid first name error', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: `${LABEL_FIRST_NAME} ${LABEL_ASTERISK}` });
                    const button = screen.getByRole('button', { name: BTN_SEARCH });

                    await userEvent.type(input, 'validFirstName');
                    userEvent.click(button);

                    expect(screen.queryByText(INVALID_FIRST_NAME)).toBeNull();

                    const error = await screen.findByText(ERROR_MSG_ALL_FIELDS);
                    expect(error).toBeInTheDocument();
                });

                test('invalid input regex causes an error to be displayed', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: `${LABEL_FIRST_NAME} ${LABEL_ASTERISK}` });
                    const button = screen.getByRole('button', { name: BTN_SEARCH });

                    await userEvent.type(input, '123');
                    userEvent.click(button);

                    await screen.findByText(INVALID_FIRST_NAME);

                    await screen.findByText(ERROR_MSG_ALL_FIELDS);
                });

                test('invalid first name length', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: `${LABEL_FIRST_NAME} ${LABEL_ASTERISK}` });
                    const button = screen.getByRole('button', { name: BTN_SEARCH });

                    await userEvent.type(input, 'abcdefabcdefabcdef');

                    userEvent.click(button);

                    await screen.findByText(INVALID_FIRST_NAME);
                    await screen.findByText(ERROR_MSG_ALL_FIELDS);
                });
            });

            describe('last name input', () => {
                test('valid input does not cause error', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: `${LABEL_LAST_NAME} ${LABEL_ASTERISK}` });
                    const button = screen.getByRole('button', { name: BTN_SEARCH });

                    await userEvent.type(input, 'validLastName');
                    userEvent.click(button);

                    expect(screen.queryByText(INVALID_LAST_NAME)).toBeNull();
                    await screen.findByText(ERROR_MSG_ALL_FIELDS);
                });

                test('invalid input causes an error to be displayed', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: `${LABEL_LAST_NAME} ${LABEL_ASTERISK}` });
                    const button = screen.getByRole('button', { name: BTN_SEARCH });

                    await userEvent.type(input, '1234');
                    userEvent.click(button);

                    await screen.findByText(INVALID_LAST_NAME);
                    await screen.findByText(ERROR_MSG_ALL_FIELDS);
                });

                test('invalid last name length', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: `${LABEL_LAST_NAME} ${LABEL_ASTERISK}` });
                    const button = screen.getByRole('button', { name: BTN_SEARCH });

                    await userEvent.type(input, 'abcdefabcdefabcdef');

                    userEvent.click(button);

                    await screen.findByText(INVALID_LAST_NAME);
                    await screen.findByText(ERROR_MSG_ALL_FIELDS);
                });
            });

            describe('date of birth input', () => {
                test('valid input does not cause error', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: `${LABEL_DOB} ${LABEL_ASTERISK}` });
                    const button = screen.getByRole('button', { name: BTN_SEARCH });

                    await userEvent.type(input, '01/01/1999');
                    userEvent.click(button);

                    expect(screen.queryByText(INVALID_DOB)).toBeNull();
                    await screen.findByText(ERROR_MSG_ALL_FIELDS);
                });

                test('invalid input causes an error to be displayed', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: `${LABEL_DOB} ${LABEL_ASTERISK}` });
                    const button = screen.getByRole('button', { name: BTN_SEARCH });

                    await userEvent.type(input, '11/11/1111');
                    userEvent.click(button);
                    await screen.findByText(INVALID_DOB);
                    await screen.findByText(ERROR_MSG_ALL_FIELDS);
                });
            });
        });

        describe('renders search button', () => {
            test('button triggers validation and does not clear if invalid user', async () => {
                setupRTL();
                const input = screen.getByRole('textbox', { name: `${LABEL_FIRST_NAME} ${LABEL_ASTERISK}` });
                const button = screen.getByRole('button', { name: BTN_SEARCH });
                await userEvent.type(input, '');
                userEvent.click(button);
                await screen.findByText(CUSTOMER_SEARCH_REQUEST_MSG);
            });

            test('Submitting form with valid user dispatches request', async () => {
                Object.defineProperty(allToggles, 'toggles', {
                    value: {
                        [toggleNames.SHOW_PEID_OR_SUBSCRIBERID]: true
                    }
                });
                setupRTL();
                const input1 = screen.getByRole('textbox', { name: `${LABEL_FIRST_NAME} ${LABEL_ASTERISK}` });
                const input2 = screen.getByRole('textbox', { name: `${LABEL_LAST_NAME} ${LABEL_ASTERISK}` });
                const input4 = screen.getByRole('textbox', { name: `${LABEL_DOB} ${LABEL_ASTERISK}` });

                await userEvent.type(input1, 'itp');
                await userEvent.type(input2, 'user');
                await userEvent.type(input4, '01/01/1999');

                const button = screen.getByRole('button', { name: BTN_SEARCH });

                userEvent.click(button);
                expect(screen.queryByText(ERROR_MSG_ALL_FIELDS)).toBeNull();
            });
        });
    });
});