import { interpret } from 'xstate';
import { serviceCustomerFlowMachine } from './servicingStateMachine';

describe('servicingStateMachine', () => {
    let onSkipMock, onVerifyMock;

    beforeEach(() => {
        onSkipMock = jest.fn();
        onVerifyMock = jest.fn();
    });

    test('State machine flow when CSA skips verification', () => {
        const servicingMachine = interpret(serviceCustomerFlowMachine({
            onSkip: onSkipMock,
            onVerify: onVerifyMock
        })).start();

        expect(servicingMachine.state.matches('customerSearch')).toBeTruthy();

        servicingMachine.send('VIEW_ACCOUNT');

        expect(servicingMachine.state.matches('verifyInfo')).toBeTruthy();

        servicingMachine.send('SKIP');

        expect(onSkipMock).toHaveBeenCalled();

        expect(servicingMachine.state.matches('servicingDashboard')).toBeTruthy();
    });

    test('State machine flow when CSA confirms verification', () => {
        const servicingMachine = interpret(serviceCustomerFlowMachine({
            onSkip: onSkipMock,
            onVerify: onVerifyMock
        })).start();

        expect(servicingMachine.state.matches('customerSearch')).toBeTruthy();

        servicingMachine.send('VIEW_ACCOUNT');

        expect(servicingMachine.state.matches('verifyInfo')).toBeTruthy();

        servicingMachine.send('VERIFY');

        expect(onVerifyMock).toHaveBeenCalled();

        expect(servicingMachine.state.matches('servicingDashboard')).toBeTruthy();
    });
});