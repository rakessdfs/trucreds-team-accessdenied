import {
    CANCELLATION,
    ENROLLMENT,
    GENERAL_SERVICING,
    TRANSFER_TO_ECS
} from '../../../common/constants/ITPConstants';
import { overAllMemoText, validateMemoTextLength } from './UtilityMenuUtils';

describe('UtilityMenuUtils', () => {
    describe('overAllMemoText', () => {
        test('Enrollment checkbox is checked', () => {
            expect(overAllMemoText({
                isEnrollmentCheck: true
            })).toBe(ENROLLMENT);
        });

        test('Cancellation checkbox is checked', () => {
            expect(overAllMemoText({
                isCancellationCheck: true
            })).toBe(CANCELLATION);
        });

        test('General Servicing checkbox is checked', () => {
            expect(overAllMemoText({
                isGeneralServicingCheck: true
            })).toBe(GENERAL_SERVICING);
        });

        test('Transfer to ECS checkbox is checked', () => {
            expect(overAllMemoText({
                isTransferToEcsCheck: true
            })).toBe(TRANSFER_TO_ECS);
        });

        test('Comments checkbox is checked', () => {
            expect(overAllMemoText({
                isCommentsCheck: true,
                manualMemoText: 'test memo'
            })).toBe('test memo');
        });

        test('Enrollment and Cancellation checkboxes are checked', () => {
            expect(overAllMemoText({
                isEnrollmentCheck: true,
                isCancellationCheck: true
            })).toBe(`${ENROLLMENT}, ${CANCELLATION}`);
        });

        test('General Servicing and Transfer to ECS checkboxes are checked', () => {
            expect(overAllMemoText({
                isGeneralServicingCheck: true,
                isTransferToEcsCheck: true
            })).toBe(`${GENERAL_SERVICING}, ${TRANSFER_TO_ECS}`);
        });

        test('Cancellation and ManualMemo checkboxes are checked', () => {
            expect(overAllMemoText({
                isCancellationCheck: true,
                isCommentsCheck: true,
                manualMemoText: 'test memo'
            })).toBe(`${CANCELLATION}, test memo`);
        });

        test('All checkboxes are checked', () => {
            expect(overAllMemoText({
                isEnrollmentCheck: true,
                isCancellationCheck: true,
                isGeneralServicingCheck: true,
                isTransferToEcsCheck: true,
                isCommentsCheck: true,
                manualMemoText: 'test memo'
            })).toBe(`${ENROLLMENT}, ${CANCELLATION}, ${GENERAL_SERVICING}, ${TRANSFER_TO_ECS}, test memo`);
        });
    });

    describe('validateMemoTextLength', () => {
        test('overall Memo text greater than 250 should return false', () => {
            expect(validateMemoTextLength('Enrollment, Cancellation, General Servicing, Transfer to ECS, ' +
                'test test test test test test test test test test test test test test test test test test test ' +
                'test test test test test test test test test test test test test test test test test ererererererer er erer er')).toBe(false);
        });

        test('overall Memo text less than 250 should return true', () => {
            expect(validateMemoTextLength('Enrollment, Cancellation, General Servicing, Transfer to ECS, ' +
                'test test test test test test test test test test test test test test test test test test test ' +
                'test test test')).toBe(true);
        });
    });
});