import thunk from 'redux-thunk';
import configureMockStore from 'redux-mock-store';
import { itpDataSuccessResponse } from '../../../../../../msw/responses/itpData/itpDataSucess';
import { logout } from '../../../../login/Login.actions';
import { INTERNAL_SERVER_ERROR } from '../../../../../common/constants/ITPConstants';
import { ITP_ENROLLMENT_FAILURE, ITP_ENROLLMENT_REQUEST, ITP_ENROLLMENT_SUCCESS } from './ItpDataConstants';
import { fetchITPData, itpDataFailure, itpDataRequest, itpDataSuccess } from './ItpData.actions';

describe('itpDataActions', () => {
    const partyId = '1234';

    test('itpDataRequest', () => {
        const data = {
            partyId: partyId
        };
        const result = itpDataRequest(data);
        expect(result).toEqual({
            type: ITP_ENROLLMENT_REQUEST,
            payload: {
                ...data
            }
        });
    });

    test('itpDataSuccess', () => {
        const data = {
            ...itpDataSuccessResponse
        };

        const result = itpDataSuccess(data);
        expect(result).toEqual({
            type: ITP_ENROLLMENT_SUCCESS,
            payload: {
                ...data
            }
        });
    });

    test('itpDataFailure', () => {
        const error = {
            message: ['error'],
            cause: ['unknown']
        };
        expect(itpDataFailure(error)).toEqual({
            type: ITP_ENROLLMENT_FAILURE,
            payload: error
        });
    });

    describe('fetchItpData', () => {
        const middleware = [thunk];
        const mockStore = configureMockStore(middleware);
        let store, data;

        beforeEach(() => {
            store = mockStore({
                user: {
                    data: {
                        userName: 'test'
                    }
                }
            });
            jest.resetAllMocks();
            data = {
                partyId: '1234'
            };
        });

        test('handles 200 success path', async () => {
            await store.dispatch(fetchITPData(data.partyId));
            const actions = store.getActions();
            expect(actions[1]).toEqual(itpDataSuccess(itpDataSuccessResponse));
        });

        test('error scenario', async () => {
            await store.dispatch(fetchITPData('error'));
            const actions = store.getActions();
            expect(actions[0]).toEqual(itpDataRequest({
                partyId: 'error'
            }));
            expect(actions[1]).toEqual(itpDataFailure({
                cause: [INTERNAL_SERVER_ERROR],
                message: [INTERNAL_SERVER_ERROR]
            }));
        });

        test('handles 401 unauthenticated user', async () => {
            document.cookie = 'auth-token=';
            await store.dispatch(fetchITPData());
            const actions = store.getActions();

            expect(actions[2]).toEqual(logout({
                cause: ['1009'],
                message: []
            }));
        });

        test('Empty party id', async () => {
            await store.dispatch(fetchITPData('emptyPartyId'));
            const actions = store.getActions();
            expect(actions[0]).toEqual(itpDataRequest({
                partyId: 'emptyPartyId'
            }));
            expect(actions[1]).toEqual(itpDataFailure({
                cause: ['1002'],
                message: ['Invalid request. Please resolve and try again.']
            }));
        });
    });
});