import { IApiState } from '../../../../../common/types';
import {
    CANCEL_ENROLLMENT_FAILURE, CANCEL_ENROLLMENT_RESET_DATA, CANCEL_ENROLLMENT_SUCCESS
} from './CancelConstants';
import { TCancelEnrollmentAction } from './CancelEnrollment.types';

export const initialState: IApiState<{}> = {
    error: null,
    isFetching: false,
    data: null
};

export const cancelEnrollmentReducer = (state = initialState, action: TCancelEnrollmentAction): IApiState<{}> => {
    switch (action.type) {
        case CANCEL_ENROLLMENT_SUCCESS:
            return {
                ...state,
                isFetching: false,
                data: {},
                error: null
            };
        case CANCEL_ENROLLMENT_FAILURE:
            return {
                ...state,
                isFetching: false,
                data: null,
                error: action.payload
            };
        case CANCEL_ENROLLMENT_RESET_DATA:
            return {
                ...state,
                data: null,
                isFetching: false,
                error: null
            };
        default:
            return state;
    }
};