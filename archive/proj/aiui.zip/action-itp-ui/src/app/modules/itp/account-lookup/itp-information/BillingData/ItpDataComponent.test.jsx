import React from 'react';
import { screen } from '@testing-library/react';
import createMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { renderContainer } from '../../../../../common/utils/test-utils';
import * as allToggles from '../../../../../common/toggle/toggles';
import { toggleNames } from '../../../../../common/toggle/toggleNames';
import { CANCEL_ENROLLMENT } from '../ItpInformationConstants';
import { ItpDataComponent } from './ItpDataComponent';

describe('Render ITP Data component', () => {
    let initialState, store, onCancelMock;

    beforeEach(() => {
        jest.clearAllMocks();
        onCancelMock = jest.fn();
        Object.defineProperty(allToggles, 'toggles', {
            value: {
                [toggleNames.CANCEL_ENROLLMENT]: true
            }
        });
        initialState = {
            itpEnrollmentData: {
                data: {
                    standingCode: 'ENR'
                }
            },
            billingData: {
                data: {}
            },
            user: {
                data: {
                    userName: 'test'
                }
            }
        };
    });

    const setupRTL = () => {
        store = createMockStore([thunk])(initialState);
        return renderContainer(<ItpDataComponent onCancel={onCancelMock} />, {
            store
        });
    };

    test('Cancel Enrollment Button enabled for enrolled customer', () => {
        setupRTL();

        expect(screen.getByRole('button', { name: CANCEL_ENROLLMENT })).toBeEnabled();
    });

    test('Cancel Enrollment Button disabled for cancelled customer', () => {
        initialState.itpEnrollmentData.data.standingCode = 'PCN';
        setupRTL();
        expect(screen.getByRole('button', { name: CANCEL_ENROLLMENT })).toBeDisabled();
    });
});