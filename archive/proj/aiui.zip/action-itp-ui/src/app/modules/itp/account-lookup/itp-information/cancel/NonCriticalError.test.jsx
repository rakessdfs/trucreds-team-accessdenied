import { screen } from '@testing-library/react';
import React from 'react';
import { renderContainer } from '../../../../../common/utils/test-utils';
import { NonCriticalError } from './NonCriticalError';
import { TAGGING_ERROR_HEADER_CANCELLATION, TAGGING_ERROR_SUB_HEADER } from './CancelConstants';

describe('Test Non Critical Error component', () => {
    let xButtonClickMock;

    beforeEach(() => {
        jest.resetAllMocks();
        xButtonClickMock = jest.fn();
    });

    const setupRTL = () => {
        return renderContainer(
            <NonCriticalError
                header={TAGGING_ERROR_HEADER_CANCELLATION}
                subHeader={TAGGING_ERROR_SUB_HEADER}
                onXButtonClick={xButtonClickMock}
            />
        );
    };

    describe('Happy Path', () => {
        test('Render Non Critical Error', () => {
            setupRTL();
            expect(screen.getByText('This call cannot be recorded however please proceed with product cancellation.')).toBeInTheDocument();
            expect(screen.getByText(TAGGING_ERROR_SUB_HEADER)).toBeInTheDocument();
            expect(screen.getByText('X')).toBeInTheDocument();
        });
    });
});