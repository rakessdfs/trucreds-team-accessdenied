export const PATTERN_NAME = /^[a-zA-Z.\-,' ]{1,15}$/i;
// eslint-disable-next-line max-len
export const PATTERN_DOB = /^02\/(?:[01]\d|2\d)\/(?:19|20)(?:0[048]|[13579][26]|[2468][048])|(?:0[13578]|10|12)\/(?:[0-2]\d|3[01])\/(?:19|20)[0-9][0-9]|(?:0[469]|11)\/(?:[0-2]\d|30)\/(?:19|20)[0-9][0-9]|02\/(?:[0-1]\d|2[0-8])\/(?:19|20)[0-9][0-9]$/i;

export const LENGTH_NAME = 30;
export const LENGTH_DOB = 10;

export const ERROR_MSG_ALL_FIELDS = 'All Fields are required';
export const ERROR_MSG_FIRST_NAME = 'Invalid First Name';
export const ERROR_MSG_LAST_NAME = 'Invalid Last Name';
export const ERROR_MSG_DOB = 'Invalid Date of Birth';

export const VALIDATION_REQUIRED = 'required';
export const VALIDATION_PATTERN = 'pattern';
export const VALIDATION_MSG_PEID_SUBSCRIBER_ID = 'Please enter PEID or Subscriber ID';

export const LABEL_ASTERISK = '*';
export const LABEL_FIRST_NAME = 'First Name';
export const LABEL_LAST_NAME = 'Last Name';
export const LABEL_DOB = 'Date of Birth';
export const LABEL_PEID_OR_SUBSCRIBER_ID = 'PEID or Subscriber ID';
export const LABEL_OR = 'OR';
export const BTN_SEARCH = 'Search';
export const BTN_CLEAR = 'Clear';

export const PH_FIRST_NAME = 'First Name';
export const PH_LAST_NAME = 'Last Name';
export const PH_DOB = 'MM/DD/YYYY';
export const PH_POS = 'PEID or Subscriber ID';

export const ATTR_ARIA_REQ_TRUE = 'true';
export const ATTR_NAME_ID_FN = 'firstName';
export const ATTR_NAME_ID_LN = 'lastName';
export const ATTR_NAME_ID_DOB = 'dob';
export const ATTR_NAME_ID_POS = 'peIdOrSubscriberId';

export const ATTR_INPUT_TYPE_TEXT = 'text';
export const ATTR_INPUT_TYPE_BUTTON_ID = 'submit';

export const PII_SUCCESS = 'PII_SUCCESS';
export const PII_REQUEST = 'PII_REQUEST';
export const PII_FAILURE = 'PII_FAILURE';

export const CUSTOMER_SEARCH = 'Customer Search';
export const CUSTOMER_SEARCH_SUCCESS = 'CUSTOMER_SEARCH_SUCCESS';
export const CUSTOMER_SEARCH_REQUEST = 'CUSTOMER_SEARCH_REQUEST';
export const CUSTOMER_SEARCH_FAILURE = 'CUSTOMER_SEARCH_FAILURE';
export const CUSTOMER_SEARCH_CRITERIA_LINE_1 = 'Search by PEID/Subscriber ID or';
export const CUSTOMER_SEARCH_CRITERIA_LINE_2 = 'First Name, Last Name, and Date of Birth';
export const CUSTOMER_SEARCH_CRITERIA_LINE_3 = 'to find Customer.';
export const CUSTOMER_SEARCH_REQUEST_MSG = 'Please enter Customer Information or PEID/Subscriber Id.';

export const PII_SSN_PREFIX = 'XXX-XX-';

export const RESET_DATA = 'RESET_DATA';
export const VIEW_ACCOUNT = 'View Account';

export const NO_RESULTS_FOUND = 'No Results Found.';
export const PLEASE_SEARCH_AGAIN = 'Please search again.';

export const FIRST_NAME_COLUMN_HEADER = 'First Name';
export const LAST_NAME_COLUMN_HEADER = 'Last Name';
export const SSN_COLUMN_HEADER = 'Last 4 SSN';

export const SERVICING = 'servicing';