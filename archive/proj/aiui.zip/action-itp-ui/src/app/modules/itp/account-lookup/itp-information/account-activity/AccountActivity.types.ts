import { IReduxError } from '../../../../../common/types';

export interface IAccountActivityResponse {
    accountActivityList: IAccountActivityResponseData[];
}

export interface IAccountActivityResponseData {
    accountActivityId: ULongRange;
    productEnrollmentId: string;
    activityDesc: string;
    previousData: string;
    newData: string;
    operator: string;
    requestDate: string;
}

export interface IAccountActivityRequest {
    productEnrollmentId: string | number;
}

export interface IFetchAccountActivityRequestAction {
    type: 'FETCH_ACCOUNT_ACTIVITY_REQUEST';
    payload: IAccountActivityRequest;
}

export interface IFetchAccountActivitySuccessAction {
    type: 'FETCH_ACCOUNT_ACTIVITY_SUCCESS';
    payload: IAccountActivityResponse;
}

export interface IFetchAccountActivityFailureAction {
    type: 'FETCH_ACCOUNT_ACTIVITY_FAILURE';
    payload: IReduxError;
}

export interface IFetchAccountActivityState {
    accountActivityData: IAccountActivityResponse | null;
}

export interface IResetData {
    type: 'RESET_DATA';
}

export type TFetchAccountActivityAction = IFetchAccountActivityRequestAction | IFetchAccountActivityFailureAction | IFetchAccountActivitySuccessAction | IResetData;