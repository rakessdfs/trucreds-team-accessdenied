import axios from 'axios';
import { ThunkDispatch } from 'redux-thunk';
import { IReduxState } from 'src/app/store/Store.types';
import { IReduxError } from '../../../../../common/types';
import { validateResponse } from '../../../../../common/utils/ITPUtils';
import { getAuthCookie } from '../../../../login/LoginUtils';
import {
    URL_ACTION_ITP_API_HOSTNAME,
    URL_ACTION_ITP_API_HOSTNAME_LOCAL,
    URL_ACTION_ITP_RECORD_CALL
} from '../../../../../common/constants/ITPConstants';
import { attemptLogout } from '../../../../login/Login.actions';
import {
    IRecordCallFailureAction,
    IRecordCallRequest,
    IRecordCallRequestAction,
    IRecordCallSuccessAction
} from './RecordCall.types';
import { ITP_RECORD_CALL_FAILURE, ITP_RECORD_CALL_REQUEST, ITP_RECORD_CALL_SUCCESS } from './CancelConstants';

export const itpRecordCallRequest = ({ customerType, productEnrollmentId, tagType }: IRecordCallRequest): IRecordCallRequestAction => ({
    type: ITP_RECORD_CALL_REQUEST,
    payload: {
        customerType,
        productEnrollmentId,
        tagType
    }
});

export const itpRecordCallSuccess = (): IRecordCallSuccessAction => ({
    type: ITP_RECORD_CALL_SUCCESS
});

export const itpRecordCallFailure = (error: IReduxError): IRecordCallFailureAction => ({
    type: ITP_RECORD_CALL_FAILURE,
    payload: error
});

export const itpRecordCall = (tagType: string) => {
    return async (dispatch: ThunkDispatch<IReduxState, unknown, IRecordCallRequestAction | IRecordCallFailureAction | IRecordCallSuccessAction>, getState: () => IReduxState): Promise<void> => {
        const agentName = getState().user.data?.userName;
        const productEnrollmentId = getState().itpEnrollmentData.data?.productEnrollmentId || '';
        const customerType = getState().itpEnrollmentData.data?.customerType;

        dispatch(itpRecordCallRequest({
            customerType,
            productEnrollmentId,
            tagType
        }));

        let response;

        try {
            response = await axios({
                method: 'post',
                url: (URL_ACTION_ITP_API_HOSTNAME || URL_ACTION_ITP_API_HOSTNAME_LOCAL) + URL_ACTION_ITP_RECORD_CALL,
                data: {
                    customerType,
                    productEnrollmentId,
                    tagType
                },
                headers: {
                    Authorization: `Bearer ${getAuthCookie()}`,
                    'X-DFSUSER-USER-ID': agentName
                }
            });

            const error = validateResponse(response, 'customer');

            if (error) {
                dispatch(itpRecordCallFailure(error));
                return;
            }
        } catch (e) {
            if (e.response?.status === 401) {
                dispatch(attemptLogout((validateResponse(e.response, 'customer') as IReduxError)));
                return;
            }
            dispatch(itpRecordCallFailure((validateResponse(e.response, 'customer') as IReduxError)));
            return;
        }
        dispatch(itpRecordCallSuccess());
    };
};