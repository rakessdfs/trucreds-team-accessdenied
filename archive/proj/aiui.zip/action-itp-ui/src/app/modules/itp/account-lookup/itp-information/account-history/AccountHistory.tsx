import React, { ReactElement, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { CircularSpinner } from '../../../../../common/Components/CircularSpinner/CircularSpinner';
import { IReduxState } from '../../../../../store/Store.types';
import { COMPLAINT_FEEDBACK, COMPLAINT_FEEDBACK_URL } from '../ItpInformationConstants';
import styles from './AccountHistory.module.scss';
import { MemoPreviewContainer } from './MemoPreview/MemoPreviewContainer';
import { attemptFetchMemoRequest } from './MemoPreview/MemoPreview.actions';

export const AccountHistory = (): ReactElement => {
    const reduxDispatch = useDispatch();
    const { data } = useSelector((state: IReduxState) => state.itpEnrollmentData);
    const { isFetching } = useSelector((state: IReduxState) => state.memo);
    const peid = data?.productEnrollmentId;

    useEffect(() => {
        if (peid) {
            reduxDispatch(attemptFetchMemoRequest(`${peid}`));
        }
    }, [reduxDispatch, peid]);

    return (
        <div className={styles.accountHistorySection}>
            {isFetching ? <CircularSpinner isButton={false} /> : <MemoPreviewContainer />}
            <a
                className={styles.feedbackButton}
                href={COMPLAINT_FEEDBACK_URL}
                target='_blank'
                rel='noopener noreferrer'
            >
                {COMPLAINT_FEEDBACK}
            </a>
        </div>
    );
};