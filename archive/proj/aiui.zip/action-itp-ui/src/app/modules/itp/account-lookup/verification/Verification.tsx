import React, { ReactElement, useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from '../../../../common/Components/Buttons/Button';
import { IReduxState } from '../../../../store/Store.types';
import { CircularSpinner } from '../../../../common/Components/CircularSpinner/CircularSpinner';
import { ErrorSection } from '../AccountLookup/ErrorSection';
import { errorHandling } from '../../../../common/utils/ITPUtils';
import { NonCriticalError } from '../itp-information/cancel/NonCriticalError';
import {
    TAGGING_ERROR_HEADER_SERVICING,
    TAGGING_ERROR_SUB_HEADER
} from '../itp-information/cancel/CancelConstants';
import { itpRecordCall } from '../itp-information/cancel/RecordCall.actions';
import { SERVICING } from '../AccountLookup/AccountLookupConstants';
import styles from './Verification.module.scss';
import * as VerificationConstants from './VerificationConstants';

interface IVerificationProps {
    onSkip: () => void;
    onConfirm: () => void;
}

export const Verification = ({ onSkip, onConfirm }: IVerificationProps): ReactElement => {
    const { data } = useSelector((state: IReduxState) => state.pii);
    const { error, isFetching } = useSelector((state: IReduxState) => state.itpEnrollmentData);
    const { error: recordError, isFetching: isRecordFetching } = useSelector((state: IReduxState) => state.recordCall);

    const [isShowNonCriticalError, setIsShowNonCriticalError] = useState(false);
    const ssn = data?.ssn;
    const dispatch = useDispatch();

    useEffect(() => {
        if (recordError) {
            setIsShowNonCriticalError(true);
        }
    }, [recordError]);

    useEffect(() => {
        if (!isFetching) {
            dispatch(itpRecordCall(SERVICING));
        }
    }, [dispatch, isFetching]);

    if (error) {
        return (
            <ErrorSection errors={errorHandling(undefined, false, false,
                false, [error])}
            />
        );
    } else if (isFetching || isRecordFetching) {
        return <CircularSpinner isButton={false} />;
    } else {
        return (
            <div className={styles.verificationSection}>
                <div className={styles.verificationSectionSubContainer}>
                    <p className={styles.verificationTitle}>{VerificationConstants.VERIFYING_SECURITY}</p>
                    <p className={styles.verificationMessage}>{VerificationConstants.VERIFICATION_MESSAGE}</p>
                    <p className={styles.verificationSsn}>{VerificationConstants.VERIFICATION_SSN}: {ssn?.substr(ssn.length - 4)}</p>
                    <div className={styles.verificationButtons}>
                        <Button
                            className={styles.skipButton}
                            onClick={(): void => onSkip()}
                        >
                            {VerificationConstants.VERIFICATION_SKIP_BTN}
                        </Button>
                        <Button
                            className={styles.verifyButton}
                            onClick={(): void => onConfirm()}
                        >
                            {VerificationConstants.VERIFICATION_VERIFY_BTN}
                        </Button>
                    </div>
                </div>
                {isShowNonCriticalError &&
                <NonCriticalError
                    header={TAGGING_ERROR_HEADER_SERVICING}
                    subHeader={TAGGING_ERROR_SUB_HEADER}
                    onXButtonClick={(): void => {
                        setIsShowNonCriticalError(false);
                    }}
                />}
            </div>
        );
    }
};