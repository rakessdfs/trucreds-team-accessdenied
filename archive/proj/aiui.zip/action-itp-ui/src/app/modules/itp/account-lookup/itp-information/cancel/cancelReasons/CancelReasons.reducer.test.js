import { buildReduxError } from '../../../../../../common/utils/ITPUtils';
import { resetData } from '../../../AccountLookup/CustomerPII.actions';
import { itpCancelReasonsFailure, itpCancelReasonsRequest, itpCancelReasonsSuccess } from './CancelReasons.actions';
import { itpCancelReasonsReducer } from './CancelReasons.reducer';

describe('itpCancelReasonsReducer', () => {
    let initialState;

    beforeEach(() => {
        initialState = {
            error: null,
            isFetching: true,
            data: null
        };
    });

    describe('itpCancelReasonsRequest', () => {
        test('sets the state correctly', () => {
            const itpRequestData = {
                customerType: ''
            };

            expect(itpCancelReasonsReducer(initialState, itpCancelReasonsRequest(itpRequestData))).toEqual({
                ...initialState,
                isFetching: true,
                error: null,
                data: null
            });
        });
    });

    describe('itpCancelReasonsSuccess', () => {
        beforeEach(() => {
            initialState = {
                ...initialState,
                data: {
                    ...initialState.data
                }
            };
        });

        test('Get Cancel Reasons Success', () => {
            expect(itpCancelReasonsReducer(initialState, itpCancelReasonsSuccess())).toEqual({
                ...initialState,
                isFetching: false,
                error: null,
                data: {
                    ...initialState.data
                }
            });
        });
    });

    describe('itpCancelReasonsFailure', () => {
        test('Error creating memo', () => {
            expect(itpCancelReasonsReducer(initialState, itpCancelReasonsFailure(buildReduxError('some custom error', '')))).toEqual({
                ...initialState,
                isFetching: false,
                error: {
                    cause: [''],
                    message: ['some custom error']
                },
                data: null
            });
        });
    });

    describe('resetData', () => {
        test('sets the state correctly', () => {
            expect(itpCancelReasonsReducer(initialState, resetData())).toEqual({
                ...initialState,
                data: null,
                isFetching: false,
                error: null
            });
        });
    });
});