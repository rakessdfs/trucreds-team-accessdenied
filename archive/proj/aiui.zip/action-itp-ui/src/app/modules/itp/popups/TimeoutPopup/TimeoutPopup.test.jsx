import thunk from 'redux-thunk';
import createMockStore from 'redux-mock-store';
import { screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import React from 'react';
import {
    STAY_LOGGED_IN_BUTTON,
    LOGOUT_BUTTON,
    TIMEOUT_POPUP_MESSAGE,
    TIMEOUT_POPUP_TITLE
} from '../../../../common/constants/ITPConstants';
import { logout } from '../../../login/Login.actions';
import { renderContainer } from '../../../../common/utils/test-utils';
import { TimeoutPopup } from './TimeoutPopup';

describe('Timeout Popup Modal', () => {
    let initialState, store, closeModalMock, resetMock;

    beforeEach(() => {
        closeModalMock = jest.fn();
        resetMock = jest.fn();
        initialState = {
            user: {
                data: {
                    isAuthenticated: true,
                    userName: 'SOME_USERNAME',
                    fullName: 'Some FullName',
                    email: 'someEmail'
                }
            }
        };
    });

    const setupRTL = () => {
        store = createMockStore([thunk])(initialState);
        return renderContainer(
            <TimeoutPopup
                reset={resetMock}
                closeModal={closeModalMock}
            />,
            {
                store
            }
        );
    };

    test('verify timeout popup title, message, and buttons (logout & extend)', () => {
        setupRTL();
        expect(screen.getByText(TIMEOUT_POPUP_TITLE)).toBeInTheDocument();
        expect(screen.getByText(TIMEOUT_POPUP_MESSAGE)).toBeInTheDocument();
        expect(screen.getByText(LOGOUT_BUTTON)).toBeInTheDocument();
        expect(screen.getByText(STAY_LOGGED_IN_BUTTON)).toBeInTheDocument();
    });

    test('extend button should close modal', () => {
        setupRTL();
        userEvent.click(screen.getByRole('button', { name: STAY_LOGGED_IN_BUTTON }));
        expect(closeModalMock).toHaveBeenCalled();
    });

    test('logout button should close modal', () => {
        setupRTL();
        userEvent.click(screen.getByRole('button', { name: LOGOUT_BUTTON }));

        const actions = store.getActions();

        expect(actions[1]).toEqual(logout({
            cause: [],
            message: []
        }));
    });
});