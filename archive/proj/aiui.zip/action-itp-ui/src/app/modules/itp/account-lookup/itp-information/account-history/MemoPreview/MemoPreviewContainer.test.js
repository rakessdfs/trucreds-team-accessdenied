import { screen } from '@testing-library/dom';
import React from 'react';
import createMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { renderContainer } from '../../../../../../common/utils/test-utils';
import { INTERNAL_SERVER_ERROR } from '../../../../../../common/constants/ITPConstants';
import { MemoPreviewContainer } from './MemoPreviewContainer';
import { memoData } from './memoData';

describe('MemoPreviewContainer', () => {
    let initialState, store;

    beforeEach(() => {
        jest.clearAllMocks();
        initialState = {
            memo: {
                isFetching: false,
                error: null,
                data: null
            },
            itpEnrollmentData: {
                data: {
                    subscriberNumber: 'subscriber',
                    enrollmentDate: 'enroll date',
                    enrollmentStatus: 'status',
                    enrollmentFailedReason: 'failed reason',
                    cancellationDate: 'cancel date',
                    cancellationRequestDate: 'cancel request date',
                    productEnrollmentId: 'PEID'
                },
                error: null,
                isFetching: false
            }
        };
    });

    const setupRTL = () => {
        store = createMockStore([thunk])(initialState);
        return renderContainer(<MemoPreviewContainer />, {
            store
        });
    };

    describe('Loading State', () => {
        beforeEach(() => {
            initialState = {
                ...initialState,
                memo: {
                    ...initialState.memo,
                    isFetching: true,
                    error: null
                }
            };
        });
    });

    describe('Error State', () => {
        beforeEach(() => {
            initialState = {
                ...initialState,
                memo: {
                    ...initialState.memo,
                    error: {
                        cause: [INTERNAL_SERVER_ERROR],
                        message: []
                    },
                    isFetching: false,
                    data: null
                }
            };
        });

        test('Shows error message if present', () => {
            setupRTL();
            expect(screen.getByText(INTERNAL_SERVER_ERROR)).toBeInTheDocument();
        });
    });

    describe('Happy Path', () => {
        beforeEach(() => {
            jest.clearAllMocks();
            initialState = {
                ...initialState,
                memo: {
                    ...initialState.memo,
                    error: null,
                    isFetching: false,
                    data: memoData
                }
            };
        });

        test('Renders MemoPreviewGroups for each passed in', () => {
            setupRTL();
            expect(screen.getByText('September 2020')).toBeInTheDocument();
            expect(screen.getByText('Enrolled into ITP F&F')).toBeInTheDocument();
            expect(screen.getByText('09/03/20, 07:32:56 pm | test')).toBeInTheDocument();
        });
    });
});