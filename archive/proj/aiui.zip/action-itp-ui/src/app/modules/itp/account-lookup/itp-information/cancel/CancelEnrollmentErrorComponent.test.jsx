import React from 'react';
import { screen } from '@testing-library/react';
import { renderContainer } from '../../../../../common/utils/test-utils';
import { CancelEnrollmentErrorComponent } from './CancelEnrollmentErrorComponent';
import { CANCELLATION_HEADER, CANCELLATION_SUB_HEADER, SYSTEM_MESSAGE } from './CancelConstants';

describe('CancelEnrollmentErrorComponent', () => {
    const setupRTL = () => {
        return renderContainer(
            <CancelEnrollmentErrorComponent />
        );
    };

    test('Render static content', () => {
        setupRTL();
        expect(screen.getByText(SYSTEM_MESSAGE)).toBeInTheDocument();
        expect(screen.getByText(CANCELLATION_HEADER)).toBeInTheDocument();
        expect(screen.getByText(CANCELLATION_SUB_HEADER)).toBeInTheDocument();
    });
});