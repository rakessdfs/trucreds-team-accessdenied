import React, { ReactElement } from 'react';
import { useSelector } from 'react-redux';
import { IReduxState } from '../../../../../../store/Store.types';
import { ErrorSection } from '../../../AccountLookup/ErrorSection';
import { errorHandling } from '../../../../../../common/utils/ITPUtils';
import { IFetchMemoState } from './MemoPreview.types';
import { MemoPreviewGroup } from './MemoPreviewGroup';
import styles from './MemoPreviewContainer.module.scss';

export const MemoPreviewContainer = (): ReactElement | null => {
    const { data: memosData, error: memoError } = useSelector((state: IReduxState) => state.memo);
    if (memoError) {
        return (
            <ErrorSection
                errors={errorHandling(undefined, false, false,
                    false, [memoError])}
                className={styles.accountHistoryError}
            />
        );
    } else if (!memosData) {
        return null;
    } else {
        const { memoData } = (memosData as IFetchMemoState);
        return (
            <section
                className={styles.memoPreviewContainer}
                data-testid='memo-preview-section'
            >
                { memoData?.allMemos.map((memoGroup) => (
                    <MemoPreviewGroup
                        month={memoGroup.month}
                        memos={memoGroup.memos}
                        key={memoGroup.month}
                    />
                ))}
            </section>
        );
    }
};