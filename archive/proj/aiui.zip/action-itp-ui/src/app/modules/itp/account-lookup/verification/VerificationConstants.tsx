export const VERIFYING_SECURITY = 'Verifying Security';
export const VERIFICATION_MESSAGE = 'If the caller is unable to verify SSN, they can self service online.';
export const VERIFICATION_SSN = 'SSN';
export const VERIFICATION_SKIP_BTN = 'Skip';
export const VERIFICATION_VERIFY_BTN = 'Verified';