import { fireEvent, screen } from '@testing-library/react';
import React from 'react';
import createMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { renderContainer } from 'src/app/common/utils/test-utils';
import {
    BTN_POST_MEMO,
    CANCELLATION,
    ENROLLMENT,
    GENERAL_SERVICING,
    TRANSFER_TO_ECS
} from '../../../common/constants/ITPConstants';
import { UtilityMenu } from './UtilityMenu';
import { createMemoRequest } from './UtilityMenu.actions';
import { MEMO_POSTING_ERROR, MEMO_SUCCESS } from './UtilityMenuContants';

describe('UtilityMenu', () => {
    let initialState, store;

    beforeEach(() => {
        jest.clearAllMocks();
        initialState = {
            itpEnrollmentData: {
                data: {
                    subscriberNumber: 'subscriber',
                    enrollmentDate: 'enroll date',
                    enrollmentStatus: 'status',
                    enrollmentFailedReason: 'failed reason',
                    cancellationDate: 'cancel date',
                    cancellationRequestDate: 'cancel request date',
                    productEnrollmentId: 'PEID'
                },
                error: null,
                isFetching: false
            },
            memo: {
                error: null,
                isFetching: false,
                data: {
                    memoText: '',
                    productEnrollmentId: ''
                }
            },
            createMemo: {
                error: null,
                isFetching: false,
                data: {
                    memoText: '',
                    productEnrollmentId: '',
                    createdSuccessfully: false
                }
            }
        };
    });

    const setupRTL = () => {
        store = createMockStore([thunk])(initialState);
        return renderContainer(<UtilityMenu />, {
            store
        });
    };

    describe('Happy Path', () => {
        test('UtilityMenu renders 5 checkboxes, textarea and button ', () => {
            setupRTL();

            expect(screen.getByText(ENROLLMENT)).toBeInTheDocument();
            expect(screen.getByText(CANCELLATION)).toBeInTheDocument();
            expect(screen.getByText(GENERAL_SERVICING)).toBeInTheDocument();
            expect(screen.getByText(TRANSFER_TO_ECS)).toBeInTheDocument();
            expect(screen.getByRole('textbox')).toBeInTheDocument();
            expect(screen.getByRole('button', { name: BTN_POST_MEMO })).toBeInTheDocument();

            const checkBoxList = screen.getAllByRole('checkbox');

            expect(checkBoxList.length === 5).toBeTruthy();
        });

        test('UtilityMenu textarea maxLength is 180 ', () => {
            setupRTL();

            const textbox = screen.getByRole('textbox');

            expect(textbox.getAttribute('maxLength') === '180').toBeTruthy();
        });

        test('Total memo size is less than  250 ', () => {
            setupRTL();

            const quickMemo = 'Enrollment Cancellation General Servicing Transfer to ECS ';
            const textbox = screen.getByRole('textbox');

            const textBoxMaxLength = textbox.getAttribute('maxLength');
            let totalMemoLength = 0;

            if (textBoxMaxLength !== null) {
                totalMemoLength = parseInt(textBoxMaxLength);
            }
            expect(totalMemoLength === 0).toBeFalsy();

            totalMemoLength += quickMemo.length;

            expect(totalMemoLength <= 250).toBeTruthy();
        });

        test('Confirmation message is shown for 5 seconds when a memo is successfully posted', () => {
            jest.useFakeTimers();
            initialState = {
                ...initialState,
                createMemo: {
                    ...initialState.memo,
                    data: {
                        ...initialState.memo.data,
                        createdSuccessfully: true
                    }
                }
            };

            setupRTL();

            expect(screen.getByText(MEMO_SUCCESS)).toBeInTheDocument();

            jest.runAllTimers();

            expect(screen.queryByText(MEMO_SUCCESS)).not.toBeInTheDocument();
        });

        test('error message is shown for 5 seconds when a memo errored out in posting', () => {
            jest.useFakeTimers();
            initialState = {
                ...initialState,
                createMemo: {
                    error: {
                        message: [],
                        cause: ['1011']
                    }
                }
            };

            setupRTL();

            expect(screen.getByText(MEMO_POSTING_ERROR)).toBeInTheDocument();

            jest.runAllTimers();

            expect(screen.queryByText(MEMO_POSTING_ERROR)).not.toBeInTheDocument();
        });

        test('When Enrollment checkbox is checked and post memo is submitted', () => {
            setupRTL();

            const requestData = {
                memoText: 'Enrollment',
                productEnrollmentId: 'PEID'
            };

            fireEvent.click(screen.getByTestId('enrollmentCheckbox'));
            fireEvent.click(screen.getByRole('button', { name: BTN_POST_MEMO }));

            const actions = store.getActions();

            expect(actions[0]).toEqual(createMemoRequest(requestData));

            // await waitFor(() => {
            //     expect(actions[1]).toEqual(createMemoSuccess());
            // });
        });

        test('Fetching spinner is shown when a memo api is successfully called', () => {
            initialState = {
                ...initialState,
                createMemo: {
                    isFetching: true
                }
            };
            setupRTL();
            expect(screen.getByTestId('circularSpinner')).toBeInTheDocument();
            expect(screen.queryByText(MEMO_SUCCESS)).not.toBeInTheDocument();
        });
    });
});