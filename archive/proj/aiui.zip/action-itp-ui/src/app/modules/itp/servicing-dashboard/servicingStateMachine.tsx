import { Machine, StateMachine } from 'xstate';

interface ICustomerServiceSchema {
    states: {
        customerSearch: {};
        verifyInfo: {};
        servicingDashboard: {};
        cancelEnrollment: {};
    };
}

type customerServiceEvents = { type: 'VERIFY' } | { type: 'SKIP' } | { type: 'VIEW_ACCOUNT'} |
    { type: 'BACK_TO_SEARCH' } | { type: 'CANCEL_ENROLLMENT'} | { type: 'BACK_TO_DASHBOARD'};

interface IServiceCustomerFlowMachineProps {
    onSkip: () => unknown;
    onVerify: () => unknown;
}

// eslint-disable-next-line max-len
export const serviceCustomerFlowMachine = ({ onSkip, onVerify }: IServiceCustomerFlowMachineProps): StateMachine<unknown, ICustomerServiceSchema, customerServiceEvents> => Machine<unknown, ICustomerServiceSchema, customerServiceEvents>({
    id: 'serviceCustomerFlowMachine',
    initial: 'customerSearch',
    states: {
        customerSearch: {
            on: {
                VIEW_ACCOUNT: 'verifyInfo'
            }
        },
        verifyInfo: {
            on: {
                VERIFY: {
                    target: 'servicingDashboard',
                    actions: ['onVerifyCustomerInfo']
                },
                SKIP: {
                    target: 'servicingDashboard',
                    actions: ['onSkipVerifyCustomerInfo']
                },
                BACK_TO_SEARCH: 'customerSearch'
            }
        },
        servicingDashboard: {
            on: {
                BACK_TO_SEARCH: 'customerSearch',
                CANCEL_ENROLLMENT: 'cancelEnrollment'
            }
        },
        cancelEnrollment: {
            on: {
                BACK_TO_SEARCH: 'customerSearch',
                BACK_TO_DASHBOARD: 'servicingDashboard'
            }
        }
    }
}, {
    actions: {
        onVerifyCustomerInfo: (): unknown => onVerify(),
        onSkipVerifyCustomerInfo: (): unknown => onSkip()
    }
});