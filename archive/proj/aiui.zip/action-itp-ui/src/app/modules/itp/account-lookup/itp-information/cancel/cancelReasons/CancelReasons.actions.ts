import axios from 'axios';
import { ThunkDispatch } from 'redux-thunk';
import { IReduxState } from 'src/app/store/Store.types';
import { IReduxError } from '../../../../../../common/types';
import { validateResponse } from '../../../../../../common/utils/ITPUtils';
import { getAuthCookie } from '../../../../../login/LoginUtils';
import {
    URL_ACTION_ITP_API_HOSTNAME,
    URL_ACTION_ITP_API_HOSTNAME_LOCAL,
    URL_ACTION_ITP_CANCEL_REASONS
} from '../../../../../../common/constants/ITPConstants';
import { attemptLogout } from '../../../../../login/Login.actions';
import { ITP_CANCEL_REASONS_FAILURE, ITP_CANCEL_REASONS_REQUEST, ITP_CANCEL_REASONS_SUCCESS } from '../CancelConstants';
import {
    ICancelReasonsRequestAction,
    ICancelReasonsFailureAction,
    ICancelReasonsRequest,
    ICancelReasonsSuccessAction,
    ICancelReasonsResponse
} from './CancelReasons.types';

export const itpCancelReasonsRequest = ({ customerType }: ICancelReasonsRequest): ICancelReasonsRequestAction => ({
    type: ITP_CANCEL_REASONS_REQUEST,
    payload: {
        customerType
    }
});

export const itpCancelReasonsSuccess = (response: ICancelReasonsResponse): ICancelReasonsSuccessAction => ({
    type: ITP_CANCEL_REASONS_SUCCESS,
    payload: response
});

export const itpCancelReasonsFailure = (error: IReduxError): ICancelReasonsFailureAction => ({
    type: ITP_CANCEL_REASONS_FAILURE,
    payload: error
});

export const itpCancelReasons = () => {
    return async (dispatch: ThunkDispatch<IReduxState, unknown, ICancelReasonsRequestAction | ICancelReasonsFailureAction | ICancelReasonsSuccessAction>, getState: () => IReduxState): Promise<void> => {
        const agentName = getState().user.data?.userName;
        const customerType = getState().itpEnrollmentData.data?.customerType;

        dispatch(itpCancelReasonsRequest({
            customerType
        }));

        let response;

        try {
            response = await axios({
                method: 'get',
                url: `${(URL_ACTION_ITP_API_HOSTNAME || URL_ACTION_ITP_API_HOSTNAME_LOCAL)}${URL_ACTION_ITP_CANCEL_REASONS}${customerType}`,
                headers: {
                    Authorization: `Bearer ${getAuthCookie()}`,
                    'X-DFSUSER-USER-ID': agentName
                }
            });

            const error = validateResponse(response, 'customer');

            if (error) {
                dispatch(itpCancelReasonsFailure(error));
                return;
            }
        } catch (e) {
            if (e.response?.status === 401) {
                dispatch(attemptLogout((validateResponse(e.response, 'customer') as IReduxError)));
                return;
            }
            dispatch(itpCancelReasonsFailure((validateResponse(e.response, 'customer') as IReduxError)));
            return;
        }
        dispatch(itpCancelReasonsSuccess(response?.data));
    };
};