import React, { ReactElement, useState } from 'react';
import './ItpInformation.scss';
import { buildClasses } from '../../../../common/utils/ITPUtils';
import { toggles } from '../../../../common/toggle/toggles';
import { toggleNames } from '../../../../common/toggle/toggleNames';
import { FeatureToggle, FeatureToggleProvider } from '../../../../common/toggle';
import { AccountHistory } from './account-history/AccountHistory';
import { ItpDataComponent } from './BillingData/ItpDataComponent';
import {
    ACCOUNT_ACTIVITY,
    ACCOUNT_HISTORY,
    ITP_DATA,
    ITP_INFORMATION
} from './ItpInformationConstants';
import { AccountActivity } from './account-activity/AccountActivity';

interface IItpInformationProps {
    onCancel: () => void;
}

export const ItpInformation = ({ onCancel }: IItpInformationProps): ReactElement => {
    const [currentTab, setCurrentTab] = useState<'data'|'account'|'accountActivity'>('data');

    return (
        <div className='itpInformationBg'>
            <h3 className='itpInformationTitle'>{ITP_INFORMATION}</h3>
            <div className='itpDataSection'>
                <div className='itpDataAlignSection'>
                    <button
                        className={buildClasses(['enrollmentDetailsSectionHeader', currentTab === 'data' && 'active'])}
                        onClick={(): void => setCurrentTab('data')}
                    >
                        {ITP_DATA}
                    </button>
                    <button
                        className={buildClasses(['enrollmentDetailsSectionHeader', currentTab === 'account' && 'active'])}
                        onClick={(): void => setCurrentTab('account')}
                    >
                        {ACCOUNT_HISTORY}
                    </button>
                    <FeatureToggleProvider featureToggleList={toggles}>
                        <FeatureToggle featureName={toggleNames.SHOW_REQUEST_ACTIVITY}>
                            <button
                                className={buildClasses(['enrollmentDetailsSectionHeader', currentTab === 'accountActivity' && 'active'])}
                                onClick={(): void => setCurrentTab('accountActivity')}
                            >
                                {ACCOUNT_ACTIVITY}
                            </button>
                        </FeatureToggle>
                    </FeatureToggleProvider>
                </div>
                <div className='enrollmentDetailsSectionDetail'>
                    {currentTab === 'data' &&
                    <ItpDataComponent
                        onCancel={onCancel}
                    />}
                    {currentTab === 'account' && <AccountHistory />}
                    {currentTab === 'accountActivity' && <AccountActivity />}
                </div>
            </div>
        </div>
    );
};