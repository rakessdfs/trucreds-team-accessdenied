import React, { ReactElement, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import * as CONSTANT from '../AccountLookupConstants';
import { ErrorSection } from '../ErrorSection';
import { IFormFields } from '../AccountLookup';
import { piiFailure } from '../CustomerPII.actions';
import { IReduxState } from '../../../../../store/Store.types';
import { toggles } from '../../../../../common/toggle/toggles';
import { FeatureToggle, FeatureToggleProvider } from '../../../../../common/toggle';
import { toggleNames } from '../../../../../common/toggle/toggleNames';
import { errorHandling, formatDateOfBirth } from '../../../../../common/utils/ITPUtils';
import { attemptCustomerSearchRequest, customerSearchFailure } from './CustomerSearch.actions';
import styles from './AccountLookupSearch.module.scss';

export const AccountLookupSearch = (): ReactElement => {
    const { register, handleSubmit, errors, reset, getValues } = useForm<IFormFields>({
        mode: 'onSubmit',
        reValidateMode: 'onSubmit',
        defaultValues: {
            [CONSTANT.ATTR_NAME_ID_FN]: '',
            [CONSTANT.ATTR_NAME_ID_LN]: '',
            [CONSTANT.ATTR_NAME_ID_DOB]: '',
            [CONSTANT.ATTR_NAME_ID_POS]: ''
        }
    });

    const { error: searchErrors } = useSelector((store: IReduxState) => store.customerSearch);
    const { error: piiErrors } = useSelector((store: IReduxState) => store.pii);

    const [isValidSearch, setIsValidSearch] = useState(true);
    const [isValidSearchCriteria, setIsValidSearchCriteria] = useState(false);
    const [isDisabledPii, setIsDisabledPii] = useState(false);
    const [isDisabledPeid, setIsDisabledPeid] = useState(false);
    const [dateOfBirth, setDateOfBirth] = useState('');

    const dispatch = useDispatch();

    const checkValidSearch = (
        fName: string,
        lName: string,
        dob: string,
        peIdOrSubscriberId: string
    ): boolean => {
        fName = fName.trim();
        lName = lName.trim();
        if (peIdOrSubscriberId) {
            peIdOrSubscriberId = peIdOrSubscriberId.trim();
        }

        return (isDisabledPeid && (fName.length > 0 && lName.length > 0 && dob.length > 0)) ||
            (isDisabledPii && peIdOrSubscriberId.length > 0);
    };

    const clearErrorMessage = (): void => {
        setIsValidSearch(true);
        setIsValidSearchCriteria(false);
    };

    const clearErrors = (): void => {
        dispatch(customerSearchFailure({
            message: [],
            cause: []
        }));
        dispatch(piiFailure({
            message: [],
            cause: []
        }));
    };

    const onSubmit = ({ firstName, lastName, dob, peIdOrSubscriberId }: IFormFields): void => {
        if (!isDisabledPeid && !isDisabledPii) {
            setIsValidSearchCriteria(true);
        } else {
            setIsValidSearch(checkValidSearch(firstName, lastName, dob, peIdOrSubscriberId));
            if (isDisabledPeid && checkValidSearch(firstName, lastName, dob, peIdOrSubscriberId)) {
                dispatch(attemptCustomerSearchRequest(firstName, lastName, dob, peIdOrSubscriberId));
            } else if (isDisabledPii && checkValidSearch(firstName, lastName, dob, peIdOrSubscriberId)) {
                dispatch(attemptCustomerSearchRequest(firstName, lastName, dob, peIdOrSubscriberId.trim().toUpperCase()));
            }
        }
    };

    const handleOnPeidChange = (e: { target: { value: string } }): void => {
        clearErrorMessage();
        if (e.target.value) {
            setIsDisabledPii(true);
        } else {
            setIsDisabledPii(false);
        }
    };

    const handleOnPiiChange = (e: { target: { value: string } }): void => {
        clearErrorMessage();
        if (e.target.value) {
            setIsDisabledPeid(true);
        } else if (getValues().firstName === '' && getValues().lastName === '' && getValues().dob === '') {
            setIsDisabledPeid(false);
        }
    };

    const handleOnDobChange = (e: { target: { value: string } }): void => {
        clearErrorMessage();
        if (e.target.value.length <= 10) {
            setDateOfBirth(e.target.value);
        }
        if (e.target.value) {
            setIsDisabledPeid(true);
        } else if (getValues().firstName === '' && getValues().lastName === '' && getValues().dob === '') {
            setIsDisabledPeid(false);
        }
    };

    const getPiiNameRef = (): { required: boolean; pattern: RegExp } => {
        return ((isDisabledPeid) ?
            {
                required: true,
                pattern: CONSTANT.PATTERN_NAME
            } :
            {
                required: false,
                pattern: CONSTANT.PATTERN_NAME
            });
    };

    const getPiiDobRef = (): { required: boolean; pattern: RegExp } => {
        return ((isDisabledPeid) ?
            {
                required: true,
                pattern: CONSTANT.PATTERN_DOB
            } :
            {
                required: false,
                pattern: CONSTANT.PATTERN_DOB
            });
    };
    return (
        <>
            <ErrorSection
                errors={errorHandling(errors, (!isDisabledPii && !isValidSearch), (!isDisabledPeid && !isValidSearch),
                    isValidSearchCriteria, [searchErrors, piiErrors])}
            />
            <form onSubmit={handleSubmit(onSubmit)}>
                <FeatureToggleProvider featureToggleList={toggles}>
                    <FeatureToggle featureName={toggleNames.SHOW_PEID_OR_SUBSCRIBERID}>
                        <div className={styles.inputContainer}>
                            <label htmlFor='peIdOrSubscriberId'>{CONSTANT.LABEL_PEID_OR_SUBSCRIBER_ID}
                                <span className={styles.asterisk}>{CONSTANT.LABEL_ASTERISK}</span>
                            </label>
                            <p>
                                <input
                                    type={CONSTANT.ATTR_INPUT_TYPE_TEXT}
                                    name={CONSTANT.ATTR_NAME_ID_POS}
                                    id={CONSTANT.ATTR_NAME_ID_POS}
                                    aria-required={true}
                                    maxLength={CONSTANT.LENGTH_NAME}
                                    disabled={isDisabledPeid}
                                    onChange={handleOnPeidChange}
                                    placeholder={CONSTANT.PH_POS}
                                    ref={register({ required: false })}
                                />
                            </p>
                        </div>
                        <div className={styles.orContainer}>
                            <label
                                data-testid='or'
                                className={styles.orText}
                            >
                                {CONSTANT.LABEL_OR}
                            </label>
                        </div>
                    </FeatureToggle>
                </FeatureToggleProvider>
                <div className={styles.inputGroup}>
                    <div className={styles.inputContainer}>
                        <label htmlFor='firstName'>{CONSTANT.LABEL_FIRST_NAME}
                            <span className={styles.asterisk}>{CONSTANT.LABEL_ASTERISK}</span>
                        </label>
                        <input
                            type={CONSTANT.ATTR_INPUT_TYPE_TEXT}
                            name={CONSTANT.ATTR_NAME_ID_FN}
                            id={CONSTANT.ATTR_NAME_ID_FN}
                            aria-required={true}
                            maxLength={CONSTANT.LENGTH_NAME}
                            disabled={isDisabledPii}
                            onChange={handleOnPiiChange}
                            placeholder={CONSTANT.PH_FIRST_NAME}
                            ref={register(getPiiNameRef())}
                        />
                    </div>
                    <div className={styles.inputContainer}>
                        <label htmlFor='lastName'>{CONSTANT.LABEL_LAST_NAME}
                            <span className={styles.asterisk}>{CONSTANT.LABEL_ASTERISK}</span>
                        </label>
                        <input
                            type={CONSTANT.ATTR_INPUT_TYPE_TEXT}
                            name={CONSTANT.ATTR_NAME_ID_LN}
                            id={CONSTANT.ATTR_NAME_ID_LN}
                            aria-required={CONSTANT.ATTR_ARIA_REQ_TRUE}
                            maxLength={CONSTANT.LENGTH_NAME}
                            disabled={isDisabledPii}
                            onChange={handleOnPiiChange}
                            placeholder={CONSTANT.PH_LAST_NAME}
                            ref={register(getPiiNameRef())}
                        />
                    </div>
                    <div className={styles.inputContainer}>
                        <label htmlFor='dob'>{CONSTANT.LABEL_DOB}
                            <span className={styles.asterisk}>{CONSTANT.LABEL_ASTERISK}</span>
                        </label>{' '}
                        <input
                            type={CONSTANT.ATTR_INPUT_TYPE_TEXT}
                            name={CONSTANT.ATTR_NAME_ID_DOB}
                            id={CONSTANT.ATTR_NAME_ID_DOB}
                            maxLength={CONSTANT.LENGTH_DOB}
                            value={formatDateOfBirth(dateOfBirth)}
                            disabled={isDisabledPii}
                            onChange={handleOnDobChange}
                            aria-required={CONSTANT.ATTR_ARIA_REQ_TRUE}
                            placeholder={CONSTANT.PH_DOB}
                            ref={register(getPiiDobRef())}
                        />
                    </div>
                </div>
                <div className={styles.buttonContainer}>
                    <button
                        onClick={(): void => {
                            reset();
                            clearErrors();
                            clearErrorMessage();
                            setDateOfBirth('');
                            setIsDisabledPii(false);
                            setIsDisabledPeid(false);
                        }}
                        className={styles.button}
                        type='button'
                    >
                        {CONSTANT.BTN_CLEAR}
                    </button>
                    <button
                        type={CONSTANT.ATTR_INPUT_TYPE_BUTTON_ID}
                        id={CONSTANT.ATTR_INPUT_TYPE_BUTTON_ID}
                        onClick={(): void => {
                            clearErrors();
                            handleSubmit(onSubmit);
                        }}
                        className={styles.button}
                    >
                        {CONSTANT.BTN_SEARCH}
                    </button>
                </div>
            </form>
        </>
    );
};