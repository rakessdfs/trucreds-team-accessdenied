import { ThunkDispatch } from 'redux-thunk';
import axios from 'axios';
import { IReduxError } from '../../../common/types';
import { IReduxState } from '../../../store/Store.types';
import {
    URL_ACTION_ITP_API_HOSTNAME,
    URL_ACTION_ITP_API_HOSTNAME_LOCAL, URL_ACTION_ITP_FETCH_MEMO_CONTEXT
} from '../../../common/constants/ITPConstants';
import { getAuthCookie } from '../../login/LoginUtils';
import { validateResponse } from '../../../common/utils/ITPUtils';
import { attemptLogout } from '../../login/Login.actions';
import { attemptFetchMemoRequest } from '../account-lookup/itp-information/account-history/MemoPreview/MemoPreview.actions';
import { CREATE_MEMO_FAILURE, CREATE_MEMO_REQUEST, CREATE_MEMO_SUCCESS } from './UtilityMenuContants';
import {
    ICreateMemoFailureAction,
    ICreateMemoRequest,
    ICreateMemoRequestAction,
    ICreateMemoSuccessAction
} from './UtilityMenu.types';

export const createMemoSuccess = (): ICreateMemoSuccessAction => ({
    type: CREATE_MEMO_SUCCESS,
    payload: null
});

export const createMemoRequest = ({ memoText, productEnrollmentId }: ICreateMemoRequest): ICreateMemoRequestAction => ({
    type: CREATE_MEMO_REQUEST,
    payload: {
        memoText,
        productEnrollmentId
    }
});

export const createMemoFailure = (error: IReduxError): ICreateMemoFailureAction => ({
    type: CREATE_MEMO_FAILURE,
    payload: error
});

export const attemptCreateMemoRequest = (memoText: string) => {
    return async (dispatch: ThunkDispatch<IReduxState, unknown, ICreateMemoRequestAction | ICreateMemoFailureAction | ICreateMemoSuccessAction>, getState: () => IReduxState): Promise<void> => {
        const productEnrollmentId = getState().itpEnrollmentData.data?.productEnrollmentId || '';
        dispatch(createMemoRequest({
            memoText,
            productEnrollmentId
        }));

        let response;

        try {
            response = await axios({
                method: 'post',
                url: (URL_ACTION_ITP_API_HOSTNAME || URL_ACTION_ITP_API_HOSTNAME_LOCAL) + URL_ACTION_ITP_FETCH_MEMO_CONTEXT,
                data: {
                    memoText,
                    productEnrollmentId
                },
                headers: {
                    Authorization: `Bearer ${getAuthCookie()}`
                }
            });

            const error = validateResponse(response, 'create memo');

            if (error) {
                dispatch(createMemoFailure(error));
                return;
            }
        } catch (e) {
            if (e.response?.status === 401) {
                dispatch(attemptLogout((validateResponse(e.response, 'create memo') as IReduxError)));
                return;
            }
            dispatch(createMemoFailure((validateResponse(e.response, 'create memo') as IReduxError)));
            return;
        }
        dispatch(createMemoSuccess());
        dispatch(attemptFetchMemoRequest(productEnrollmentId));
    };
};