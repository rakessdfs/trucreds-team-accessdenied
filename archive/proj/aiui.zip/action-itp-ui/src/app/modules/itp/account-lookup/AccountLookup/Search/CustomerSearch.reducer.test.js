import { buildReduxError } from 'src/app/common/utils/ITPUtils';
import { customerSearchSuccessResponse } from 'src/msw/responses/customerSearch/responses';
import { customerSearchFailure, customerSearchRequest, customerSearchSuccess } from './CustomerSearch.actions';
import { customerSearchReducer } from './CustomerSearch.reducer';

describe('customerSearchReducer', () => {
    let initialState;

    beforeEach(() => {
        initialState = {
            error: null,
            isFetching: false,
            data: null
        };
    });

    describe('customerSearchRequest', () => {
        test('sets the state correctly', () => {
            const requestData = {
                firstName: 'test',
                lastName: 'user',
                dateOfBirth: '01/01/2020'
            };
            expect(customerSearchReducer(initialState, customerSearchRequest(requestData))).toEqual({
                ...initialState,
                isFetching: true,
                data: null
            });
        });
    });

    describe('customerSearchSuccess', () => {
        test('sets the state correctly', () => {
            expect(customerSearchReducer(initialState, customerSearchSuccess(customerSearchSuccessResponse))).toEqual({
                ...initialState,
                data: customerSearchSuccessResponse
            });
        });
    });

    describe('customerSearchFailure', () => {
        test('sets the state correctly', () => {
            expect(customerSearchReducer(initialState, customerSearchFailure(buildReduxError('some custom error', '')))).toEqual({
                ...initialState,
                isFetching: false,
                error: {
                    cause: [''],
                    message: ['some custom error']
                },
                data: null
            });
        });
    });
});