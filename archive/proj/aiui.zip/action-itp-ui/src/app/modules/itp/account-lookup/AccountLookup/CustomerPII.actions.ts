import axios from 'axios';
import { ThunkDispatch } from 'redux-thunk';
import { IReduxState } from 'src/app/store/Store.types';
import {
    URL_ACTION_ITP_API_HOSTNAME,
    URL_ACTION_ITP_API_HOSTNAME_LOCAL,
    URL_ACTION_ITP_PII_CONTEXT
} from '../../../../common/constants/ITPConstants';
import { IReduxError } from '../../../../common/types';
import { validateResponse } from '../../../../common/utils/ITPUtils';
import { getAuthCookie } from '../../../login/LoginUtils';
import { attemptLogout } from '../../../login/Login.actions';
import {
    IPiiFailureAction,
    IPiiRequest,
    IPiiRequestAction,
    IPiiResponse,
    IPiiSuccessAction,
    IResetData
} from './AccountLookup.types';
import { PII_FAILURE, PII_REQUEST, PII_SUCCESS, RESET_DATA } from './AccountLookupConstants';

export const piiSuccess = (response: IPiiResponse): IPiiSuccessAction => ({
    type: PII_SUCCESS,
    payload: response
});

export const piiRequest = ({ partyId }: IPiiRequest): IPiiRequestAction => ({
    type: PII_REQUEST,
    payload: {
        partyId
    }
});

export const piiFailure = (error: IReduxError): IPiiFailureAction => ({
    type: PII_FAILURE,
    payload: error
});

export const resetData = (): IResetData => ({
    type: RESET_DATA
});

export const attemptCustomerPiiRequest = (partyId: string) => {
    return async (dispatch: ThunkDispatch<IReduxState, unknown, IPiiRequestAction | IPiiFailureAction | IPiiSuccessAction>, getState: () => IReduxState): Promise<void> => {
        const agentName = getState().user.data?.userName;

        dispatch(piiRequest({
            partyId
        }));

        let response;

        try {
            response = await axios({
                method: 'get',
                url: `${URL_ACTION_ITP_API_HOSTNAME || URL_ACTION_ITP_API_HOSTNAME_LOCAL}${URL_ACTION_ITP_PII_CONTEXT}${partyId}`,
                headers: {
                    Authorization: `Bearer ${getAuthCookie()}`,
                    'X-DFSUSER-USER-ID': agentName
                }
            });

            const error = validateResponse(response, 'customer');

            if (error) {
                dispatch(piiFailure(error));
                return;
            }
        } catch (e) {
            if (e.response?.status === 401) {
                dispatch(attemptLogout((validateResponse(e.response, 'customer') as IReduxError)));
                return;
            }
            dispatch(piiFailure((validateResponse(e.response, 'customer') as IReduxError)));
            return;
        }
        dispatch(piiSuccess(response?.data));
    };
};