import React, { ReactElement } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { CANCEL_ENROLLMENT } from '../ItpInformationConstants';
import { Button } from '../../../../../common/Components/Buttons/Button';
import { toggles } from '../../../../../common/toggle/toggles';
import { toggleNames } from '../../../../../common/toggle/toggleNames';
import { FeatureToggle, FeatureToggleProvider } from '../../../../../common/toggle';
import { itpRecordCall } from '../cancel/RecordCall.actions';
import { IReduxState } from '../../../../../store/Store.types';
import { CANCEL, CANCELLATION_CODE, PENDING_CANCELLATION_CODE } from '../../../../../common/constants/ITPConstants';
import { itpCancelReasons } from '../cancel/cancelReasons/CancelReasons.actions';
import { EnrollmentDetails } from './EnrollmentDetails';
import { BillingDetails } from './BillingDetails';
import './ItpDataComponent.scss';

interface IItpDataProps {
    onCancel: () => void;
}

export const ItpDataComponent = ({ onCancel }: IItpDataProps): ReactElement => {
    const dispatch = useDispatch();
    const { data } = useSelector((state: IReduxState) => state.itpEnrollmentData);

    return (
        <div className='itpDataDetailsContainer'>
            <div className='itpDataDetails'>
                <EnrollmentDetails />
                <BillingDetails />
            </div>
            <FeatureToggleProvider featureToggleList={toggles}>
                <FeatureToggle featureName={toggleNames.CANCEL_ENROLLMENT}>
                    <div className='cancelSection'>
                        <Button
                            className='feedbackButton'
                            onClick={(): void => {
                                onCancel();
                                dispatch(itpRecordCall(CANCEL));
                                dispatch(itpCancelReasons());
                            }}
                            primary={false}
                            disabled={
                                data?.standingCode === PENDING_CANCELLATION_CODE ||
                                data?.standingCode === CANCELLATION_CODE}
                        >
                            {CANCEL_ENROLLMENT}
                        </Button>
                    </div>
                </FeatureToggle>
            </FeatureToggleProvider>
        </div>
    );
};