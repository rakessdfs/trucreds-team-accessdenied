import React from 'react';
import { screen } from '@testing-library/react';
import createMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import userEvent from '@testing-library/user-event';
import { renderContainer } from '../../../../common/utils/test-utils';
import * as allToggles from '../../../../common/toggle/toggles';
import { toggleNames } from '../../../../common/toggle/toggleNames';
import { ItpInformation } from './ItpInformation';
import {
    COMPLAINT_FEEDBACK,
    ACCOUNT_HISTORY,
    ENROLLMENT_DETAILS,
    BILLING_DETAILS,
    ITP_DATA,
    ITP_INFORMATION, ACCOUNT_ACTIVITY
} from './ItpInformationConstants';

describe('Render ITP Information component', () => {
    let initialState, store;

    beforeEach(() => {
        jest.clearAllMocks();
        Object.defineProperty(allToggles, 'toggles', {
            value: {
                [toggleNames.SHOW_REQUEST_ACTIVITY]: true
            }
        });
        initialState = {
            itpEnrollmentData: {
                data: {
                    subscriberNumber: 'subscriber',
                    enrollmentDate: 'enroll date',
                    enrollmentStatus: 'status',
                    enrollmentFailedReason: 'failed reason',
                    cancellationDate: 'cancel date',
                    cancellationRequestDate: 'cancel request date',
                    productEnrollmentId: 'PEID',
                    customerType: 'ITP_FF'
                },
                error: null,
                isFetching: false
            },
            memo: {
                isFetching: false,
                error: null,
                data: null
            },
            billingData: {
                data: {
                    pcmFirstName: 'first name',
                    pcmLastName: 'last name',
                    pcmAccountNumber: 'acc number',
                    presenceOfSecondary: 'yes'
                },
                error: null,
                isFetching: false
            },
            user: {
                data: {
                    userName: 'test'
                }
            },
            accountActivity: {
                data: {
                    userName: 'test'
                }
            }
        };
    });

    const setupRTL = () => {
        store = createMockStore([thunk])(initialState);
        return renderContainer(<ItpInformation />, {
            store
        });
    };

    test('Render ITP information static content', () => {
        setupRTL();

        expect(screen.getByText(ITP_INFORMATION)).toBeInTheDocument();
        expect(screen.getByText(ITP_DATA)).toBeInTheDocument();
        expect(screen.getByText(ACCOUNT_HISTORY)).toBeInTheDocument();
        expect(screen.getByText(ACCOUNT_ACTIVITY)).toBeInTheDocument();
    });

    test('Render ITP Data tab content', () => {
        setupRTL();

        const button = screen.getByRole('button', { name: ITP_DATA });

        userEvent.click(button);

        screen.findByText(ENROLLMENT_DETAILS);
        screen.findByText(BILLING_DETAILS);
    });

    test('Render Account History tab content', () => {
        setupRTL();

        const button = screen.getByRole('button', { name: ACCOUNT_HISTORY });

        userEvent.click(button);

        expect(screen.getByRole('link', { name: COMPLAINT_FEEDBACK })).toBeInTheDocument();
    });

    test('Render Request Activity content', () => {
        setupRTL();

        const button = screen.getByRole('button', { name: ACCOUNT_ACTIVITY });

        userEvent.click(button);

        screen.findByText('sfdsdf');
    });
});