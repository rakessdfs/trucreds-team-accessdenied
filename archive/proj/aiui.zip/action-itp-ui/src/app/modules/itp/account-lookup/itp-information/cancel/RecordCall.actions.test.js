import thunk from 'redux-thunk';
import configureMockStore from 'redux-mock-store';
import { SERVICING } from '../../AccountLookup/AccountLookupConstants';
import { CANCEL } from '../../../../../common/constants/ITPConstants';
import { ITP_RECORD_CALL_FAILURE, ITP_RECORD_CALL_REQUEST, ITP_RECORD_CALL_SUCCESS } from './CancelConstants';
import { itpRecordCallSuccess, itpRecordCallFailure, itpRecordCallRequest, itpRecordCall } from './RecordCall.actions';

describe('itpRecordCallActions', () => {
    test('itpRecordCallRequest', () => {
        const data = {
            customerType: '',
            productEnrollmentId: '',
            tagType: ''
        };
        const result = itpRecordCallRequest(data);
        expect(result).toEqual({
            type: ITP_RECORD_CALL_REQUEST,
            payload: {
                ...data
            }
        });
    });

    test('itpRecordCallSuccess', () => {
        const result = itpRecordCallSuccess();
        expect(result).toEqual({
            type: ITP_RECORD_CALL_SUCCESS
        });
    });

    test('itpRequestCallFailure', () => {
        const error = {
            message: ['error'],
            cause: ['unknown']
        };
        expect(itpRecordCallFailure(error)).toEqual({
            type: ITP_RECORD_CALL_FAILURE,
            payload: error
        });
    });

    describe('itpRecordCall test', () => {
        const middleware = [thunk];
        const mockStore = configureMockStore(middleware);
        let store, initialState;

        beforeEach(() => {
            jest.resetAllMocks();
        });

        test('handles 200 success path - Servicing', async () => {
            initialState = {
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'test',
                        customerType: 'ITP_FF'
                    }
                },
                user: {
                    data: {
                        userName: 'TestAgent'
                    }
                }
            };
            store = mockStore(initialState);
            await store.dispatch(itpRecordCall(SERVICING));
            const actions = store.getActions();
            expect(actions[0]).toEqual({
                type: ITP_RECORD_CALL_REQUEST,
                payload: {
                    customerType: 'ITP_FF',
                    productEnrollmentId: 'test',
                    tagType: 'servicing'
                }
            });
            expect(actions[1]).toEqual(itpRecordCallSuccess());
        });

        test('handles 200 success path - Cancel', async () => {
            initialState = {
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'test',
                        customerType: 'ITP_FF'
                    }
                },
                user: {
                    data: {
                        userName: 'TestAgent'
                    }
                }
            };
            store = mockStore(initialState);
            await store.dispatch(itpRecordCall(CANCEL));
            const actions = store.getActions();
            expect(actions[0]).toEqual({
                type: ITP_RECORD_CALL_REQUEST,
                payload: {
                    customerType: 'ITP_FF',
                    productEnrollmentId: 'test',
                    tagType: 'cancel'
                }
            });
            expect(actions[1]).toEqual(itpRecordCallSuccess());
        });

        test('handles 400 response code', async () => {
            initialState = {
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'test111',
                        customerType: 'ITP_FF'
                    }
                },
                user: {
                    data: {
                        userName: 'TestAgent'
                    }
                }
            };
            store = mockStore(initialState);
            await store.dispatch(itpRecordCall(SERVICING));
            const actions = store.getActions();

            expect(actions[1]).toEqual(itpRecordCallFailure({
                cause: ['1012'],
                message: ['Invalid request. Please resolve and try again.']
            }));
        });

        test('handles failure path', async () => {
            initialState = {
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'test222',
                        customerType: 'ITP_FF'
                    }
                },
                user: {
                    data: {
                        userName: 'TestAgent'
                    }
                }
            };
            store = mockStore(initialState);
            await store.dispatch(itpRecordCall(SERVICING));
            const actions = store.getActions();
            expect(actions[1]).toEqual(itpRecordCallFailure({
                cause: ['1026'],
                message: ['Call recording error']
            }));
        });
    });

    test('createMemoFailure', () => {
        const error = {
            errorCode: '1',
            message: ['some message']
        };
        const result = itpRecordCallFailure(error);
        expect(result).toEqual({
            type: ITP_RECORD_CALL_FAILURE,
            payload: error
        });
    });
});