import thunk from 'redux-thunk';
import configureMockStore from 'redux-mock-store';
import { INTERNAL_SERVER_ERROR } from '../../../../../common/constants/ITPConstants';
import { resetData } from '../../AccountLookup/CustomerPII.actions';
import {
    cancelEnrollment,
    cancelEnrollmentFailure,
    cancelEnrollmentReset,
    cancelEnrollmentSuccess
} from './CancelEnrollment.actions';
import { CANCEL_ENROLLMENT_FAILURE, CANCEL_ENROLLMENT_RESET_DATA, CANCEL_ENROLLMENT_SUCCESS } from './CancelConstants';

describe('cancelEnrollmentActions', () => {
    test('cancelEnrollmentSuccess', () => {
        const result = cancelEnrollmentSuccess();
        expect(result).toEqual({
            type: CANCEL_ENROLLMENT_SUCCESS
        });
    });

    test('cancelEnrollmentFailure', () => {
        const error = {
            message: ['error'],
            cause: ['unknown']
        };
        expect(cancelEnrollmentFailure(error)).toEqual({
            type: CANCEL_ENROLLMENT_FAILURE,
            payload: error
        });
    });

    test('cancelEnrollmentResetData', () => {
        expect(cancelEnrollmentReset()).toEqual({
            type: CANCEL_ENROLLMENT_RESET_DATA
        });
    });

    describe('cancelEnrollmentActions test scenarios ', () => {
        const middleware = [thunk];
        const mockStore = configureMockStore(middleware);
        let store, initialState, cancelReasonCode;

        beforeEach(() => {
            cancelReasonCode = 'DNW';
            initialState = {
                user: {
                    data: {
                        userName: 'testUser123'
                    }
                },
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: '909001012010202020'
                    }
                }
            };
            store = mockStore(initialState);
            jest.resetAllMocks();
            document.cookie = 'auth-token=jwt-token';
        });

        test('handles 200 success path', async () => {
            await store.dispatch(cancelEnrollment(cancelReasonCode));
            const actions = store.getActions();
            expect(actions[0]).toEqual(cancelEnrollmentSuccess());
        });

        test('handles failure path for 401 error', async () => {
            initialState = {
                ...initialState,
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: '401'
                    }
                }
            };
            store = mockStore(initialState);
            await store.dispatch(cancelEnrollment(cancelReasonCode));
            const actions = store.getActions();
            expect(actions[0]).toEqual(resetData());
        });

        test('handles failure path for 200 response with error', async () => {
            initialState = {
                ...initialState,
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: '403'
                    }
                }
            };
            store = mockStore(initialState);
            await store.dispatch(cancelEnrollment(cancelReasonCode));
            const actions = store.getActions();
            expect(actions[0]).toEqual(cancelEnrollmentFailure({
                cause: ['Service is currently unavailable. Please retry or open a ticket with the command center.'],
                message: []
            }));
        });

        test('handles failure path for invalid peid', async () => {
            initialState = {
                ...initialState,
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'emptyPeid'
                    }
                }
            };
            store = mockStore(initialState);
            await store.dispatch(cancelEnrollment(cancelReasonCode));
            const actions = store.getActions();
            expect(actions[0]).toEqual(cancelEnrollmentFailure({
                cause: ['1035'],
                message: ['Invalid request. Please resolve and try again.']
            }));
        });

        test('handles failure path for 500 error', async () => {
            initialState = {
                ...initialState,
                itpEnrollmentData: {
                    data: {
                        productEnrollmentId: 'error'
                    }
                }
            };
            store = mockStore(initialState);
            await store.dispatch(cancelEnrollment(cancelReasonCode));
            const actions = store.getActions();
            expect(actions[0]).toEqual(cancelEnrollmentFailure({
                cause: [INTERNAL_SERVER_ERROR],
                message: [INTERNAL_SERVER_ERROR]
            }));
        });
    });
});