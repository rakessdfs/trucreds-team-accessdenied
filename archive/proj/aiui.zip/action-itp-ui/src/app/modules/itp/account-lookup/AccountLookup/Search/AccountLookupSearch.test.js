import { waitFor } from '@testing-library/dom';
import { fireEvent, screen, cleanup } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import React from 'react';
import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { renderContainer } from '../../../../../common/utils/test-utils';
import {
    INVALID_DOB,
    INVALID_FIRST_NAME,
    INVALID_LAST_NAME,
    INVALID_PEID_OR_SUBSCRIBER_ID
} from '../../../../../common/constants/ITPConstants';
import {
    BTN_CLEAR,
    BTN_SEARCH, CUSTOMER_SEARCH_REQUEST_MSG,
    ERROR_MSG_ALL_FIELDS, LABEL_ASTERISK,
    LABEL_DOB,
    LABEL_FIRST_NAME,
    LABEL_LAST_NAME,
    LABEL_PEID_OR_SUBSCRIBER_ID
} from '../AccountLookupConstants';
import * as allToggles from '../../../../../common/toggle/toggles';
import { toggleNames } from '../../../../../common/toggle/toggleNames';
import { AccountLookupSearch } from './AccountLookupSearch';
import { customerSearchRequest } from './CustomerSearch.actions';

describe('AccountLookupSearch', () => {
    let initialState, store;

    beforeEach(() => {
        initialState = {
            pii: {
                isFetching: false,
                error: null,
                data: {
                    firstName: '',
                    lastName: '',
                    dateOfBirth: '',
                    ssn: '',
                    address: '',
                    primaryPhone: '',
                    email: ''
                }
            },
            user: {
                data: {
                    userName: 'testUser123'
                }
            },
            customerSearch: {
                isFetching: false,
                error: null,
                data: null
            }
        };

        Object.defineProperty(allToggles, 'toggles', {
            value: {
                [toggleNames.SHOW_PEID_OR_SUBSCRIBERID]: true
            }
        });

        jest.resetAllMocks();
    });

    afterEach(cleanup);

    // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
    const setupRTL = () => {
        store = configureMockStore([thunk])(initialState);
        return renderContainer(<AccountLookupSearch />, { store });
    };

    describe('Renders 3 input fields, a search button, and a clear button', () => {
        describe('renders input for first name, last name, and dob', () => {
            describe('first name input', () => {
                test('valid input does not cause invalid first name error', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: `${LABEL_FIRST_NAME} ${LABEL_ASTERISK}` });
                    const button = screen.getByRole('button', { name: BTN_SEARCH });

                    await userEvent.type(input, 'validFirstName');
                    userEvent.click(button);

                    expect(screen.queryByText(INVALID_FIRST_NAME)).toBeNull();

                    const error = await screen.findByText(ERROR_MSG_ALL_FIELDS);
                    expect(error).toBeInTheDocument();
                });

                test('invalid input regex causes an error to be displayed', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: `${LABEL_FIRST_NAME} ${LABEL_ASTERISK}` });
                    const button = screen.getByRole('button', { name: BTN_SEARCH });

                    await userEvent.type(input, '123');
                    userEvent.click(button);

                    await screen.findByText(INVALID_FIRST_NAME);

                    await screen.findByText(ERROR_MSG_ALL_FIELDS);
                });

                test('invalid first name length', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: `${LABEL_FIRST_NAME} ${LABEL_ASTERISK}` });
                    const button = screen.getByRole('button', { name: BTN_SEARCH });

                    await userEvent.type(input, 'abcdefabcdefabcdef');

                    userEvent.click(button);

                    await screen.findByText(INVALID_FIRST_NAME);
                    await screen.findByText(ERROR_MSG_ALL_FIELDS);
                });

                test('valid input with spaces does not cause invalid first name error', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: `${LABEL_FIRST_NAME} ${LABEL_ASTERISK}` });
                    const button = screen.getByRole('button', { name: BTN_SEARCH });

                    await userEvent.type(input, '   validFirstName   ');
                    userEvent.click(button);

                    expect(screen.queryByText(INVALID_FIRST_NAME)).toBeNull();

                    const error = await screen.findByText(ERROR_MSG_ALL_FIELDS);
                    expect(error).toBeInTheDocument();
                });
            });

            describe('last name input', () => {
                test('valid input does not cause error', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: `${LABEL_LAST_NAME} ${LABEL_ASTERISK}` });
                    const button = screen.getByRole('button', { name: BTN_SEARCH });

                    await userEvent.type(input, 'validLastName');
                    userEvent.click(button);

                    expect(screen.queryByText(INVALID_LAST_NAME)).toBeNull();
                    await screen.findByText(ERROR_MSG_ALL_FIELDS);
                });

                test('invalid input causes an error to be displayed', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: `${LABEL_LAST_NAME} ${LABEL_ASTERISK}` });
                    const button = screen.getByRole('button', { name: BTN_SEARCH });

                    await userEvent.type(input, '1234');
                    userEvent.click(button);

                    await screen.findByText(INVALID_LAST_NAME);
                    await screen.findByText(ERROR_MSG_ALL_FIELDS);
                });

                test('invalid last name length', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: `${LABEL_LAST_NAME} ${LABEL_ASTERISK}` });
                    const button = screen.getByRole('button', { name: BTN_SEARCH });

                    await userEvent.type(input, 'abcdefabcdefabcdef');

                    userEvent.click(button);

                    await screen.findByText(INVALID_LAST_NAME);
                    await screen.findByText(ERROR_MSG_ALL_FIELDS);
                });
            });

            describe('date of birth input', () => {
                test('valid input does not cause error', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: `${LABEL_DOB} ${LABEL_ASTERISK}` });
                    const button = screen.getByRole('button', { name: BTN_SEARCH });

                    await userEvent.type(input, '01/01/1999');
                    userEvent.click(button);

                    expect(screen.queryByText(INVALID_DOB)).toBeNull();
                    await screen.findByText(ERROR_MSG_ALL_FIELDS);
                });

                test('invalid input causes an error to be displayed', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: `${LABEL_DOB} ${LABEL_ASTERISK}` });
                    const button = screen.getByRole('button', { name: BTN_SEARCH });

                    await userEvent.type(input, '11/11/1111');
                    userEvent.click(button);
                    await screen.findByText(INVALID_DOB);
                    await screen.findByText(ERROR_MSG_ALL_FIELDS);
                });
            });

            describe('peid/subscriber id label and input validation', () => {
                test('PEID or Subscriber ID field is rendered when PEID feature is enabled', () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: /peid or subscriber id/i });
                    expect(input).toBeInTheDocument();
                    expect(screen.queryByTestId('or')).toBeInTheDocument();
                    expect(screen.queryByText(/Invalid value for PEID or Subscriber ID/i)).toBeNull();
                });

                test('PEID or Subscriber ID field is not rendered when PEID feature is disabled', () => {
                    Object.defineProperty(allToggles, 'toggles', {
                        value: {
                            [toggleNames.SHOW_PEID_OR_SUBSCRIBERID]: false
                        }
                    });
                    setupRTL();
                    expect(screen.queryByText('textbox', { name: /peid or subscriber id/i })).not.toBeInTheDocument();
                    expect(screen.queryByTestId('or')).not.toBeInTheDocument();
                    expect(screen.queryByText(/Invalid value for PEID or Subscriber ID/i)).toBeNull();
                });

                test('error displayed for invalid peid - length validation fails, blank space', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: /PEID or Subscriber ID/i });
                    const button = screen.getByRole('button', { name: /Search/i });

                    await userEvent.type(input, '  ');
                    userEvent.click(button);

                    await expect(screen.findByText(/invalid peid or subscriber number/i));
                });

                test('error displayed for invalid peid - input validation fails for 9191', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: /PEID Or Subscriber ID/i });
                    const button = screen.getByRole('button', { name: /Search/i });

                    await userEvent.type(input, '9191');
                    userEvent.click(button);

                    await expect(screen.findByText(/Invalid value for PEID Or Subscriber ID/i));
                });

                test('error displayed for invalid subscriber id - input validation fails for PK', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: /PEID or Subscriber ID/i });
                    const button = screen.getByRole('button', { name: /Search/i });

                    await userEvent.type(input, 'PT');
                    userEvent.click(button);

                    await expect(screen.findByText(/Invalid value for PEID Or Subscriber ID/i));
                });

                test('first/last name, dob fields disabled when there is input in peid/subscriber id field', async () => {
                    setupRTL();

                    const input = screen.getByRole('textbox', { name: /peid or subscriber id/i });
                    const firstName = screen.getByRole('textbox', { name: /first name/i });
                    const lastName = screen.getByRole('textbox', { name: /last name/i });
                    const dob = screen.getByRole('textbox', { name: /date of birth/i });
                    await userEvent.type(input, '1');
                    expect(firstName.disabled).toEqual(true);
                    expect(lastName.disabled).toEqual(true);
                    expect(dob.disabled).toEqual(true);
                });

                test('first/last name, dob fields disabled when there is blank space in peid/subscriber id field', async () => {
                    setupRTL();

                    const input = screen.getByRole('textbox', { name: /peid or subscriber id/i });
                    const firstName = screen.getByRole('textbox', { name: /first name/i });
                    const lastName = screen.getByRole('textbox', { name: /last name/i });
                    const dob = screen.getByRole('textbox', { name: /date of birth/i });
                    await userEvent.type(input, '   ');
                    expect(firstName.disabled).toEqual(true);
                    expect(lastName.disabled).toEqual(true);
                    expect(dob.disabled).toEqual(true);
                });

                test('peid/subId field disabled when there is input in first name field', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: /first name/i });
                    const peidOrSubscriberId = screen.getByRole('textbox', { name: /PEID Or Subscriber ID/i });

                    expect(peidOrSubscriberId.disabled).toEqual(false);

                    await userEvent.type(input, '1');

                    expect(peidOrSubscriberId.disabled).toEqual(true);
                });

                test('peid/subId field disabled when there is input in last name field', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: /last name/i });

                    const peidOrSubscriberId = screen.getByRole('textbox', { name: /peid or subscriber id/i });

                    await userEvent.type(input, '1');

                    expect(peidOrSubscriberId.disabled).toEqual(true);
                });

                test('peid/subId field disabled when there is input in dob field', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: /date of birth/i });

                    const peidOrSubscriberId = screen.getByRole('textbox', { name: /peid or subscriber id/i });

                    await userEvent.type(input, '1');

                    expect(peidOrSubscriberId.disabled).toEqual(true);
                });

                test('first/last name, dob fields re-enabled when there is no input in peid/subscriber id field', async () => {
                    setupRTL();

                    const input = screen.getByRole('textbox', { name: /peid or subscriber id/i });
                    const firstName = screen.getByRole('textbox', { name: /first name/i });
                    const lastName = screen.getByRole('textbox', { name: /last name/i });
                    const dob = screen.getByRole('textbox', { name: /date of birth/i });
                    await userEvent.type(input, '1');
                    expect(firstName.disabled).toEqual(true);
                    expect(lastName.disabled).toEqual(true);
                    expect(dob.disabled).toEqual(true);

                    await fireEvent.change(input, { target: { value: '' } });

                    expect(firstName.disabled).toEqual(false);
                    expect(lastName.disabled).toEqual(false);
                    expect(dob.disabled).toEqual(false);
                });

                test('peid/subId field re-enabled when there is no input in first name field', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: /first name/i });

                    const peidOrSubscriberId = screen.getByRole('textbox', { name: /peid or subscriber id/i });

                    expect(peidOrSubscriberId.disabled).toEqual(false);

                    await userEvent.type(input, '1');

                    expect(peidOrSubscriberId.disabled).toEqual(true);

                    fireEvent.change(input, { target: { value: '' } });

                    expect(peidOrSubscriberId.disabled).toEqual(false);
                });

                test('peid/subId field re-enabled when there is no input in last name field', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: /last name/i });

                    const peidOrSubscriberId = screen.getByRole('textbox', { name: /peid or subscriber id/i });

                    expect(peidOrSubscriberId.disabled).toEqual(false);

                    await userEvent.type(input, '1');

                    expect(peidOrSubscriberId.disabled).toEqual(true);

                    fireEvent.change(input, { target: { value: '' } });

                    expect(peidOrSubscriberId.disabled).toEqual(false);
                });

                test('peid/subId field re-enabled when there is no input in dob field', async () => {
                    setupRTL();
                    const input = screen.getByRole('textbox', { name: /date of birth/i });

                    const peidOrSubscriberId = screen.getByRole('textbox', { name: /peid or subscriber id/i });

                    expect(peidOrSubscriberId.disabled).toEqual(false);

                    await userEvent.type(input, '1');

                    expect(peidOrSubscriberId.disabled).toEqual(true);

                    fireEvent.change(input, { target: { value: '' } });

                    expect(peidOrSubscriberId.disabled).toEqual(false);
                });
            });
        });

        describe('Field Clear Button', () => {
            const expectEmptyStrings = async (input, input2, input3) => {
                await waitFor(() => {
                    expect(input).toHaveValue('');
                    expect(input2).toHaveValue('');
                    expect(input3).toHaveValue('');
                });
            };
            const testPiiFields = async () => {
                const input = screen.getByRole('textbox', { name: `${LABEL_FIRST_NAME} ${LABEL_ASTERISK}` });
                const input2 = screen.getByRole('textbox', { name: `${LABEL_LAST_NAME} ${LABEL_ASTERISK}` });
                const input3 = screen.getByRole('textbox', { name: `${LABEL_DOB} ${LABEL_ASTERISK}` });
                const resetButton = screen.getByRole('button', { name: BTN_CLEAR });

                await userEvent.type(input, '1234');
                await userEvent.type(input2, 'abc');
                await userEvent.type(input3, '01/01/1990');

                expect(input).toHaveValue('1234');
                expect(input2).toHaveValue('abc');
                expect(input3).toHaveValue('01/01/1990');

                userEvent.click(resetButton);

                await expectEmptyStrings(input, input2, input3);
            };

            test('Button will reset all form fields to empty strings and enable peid field', async () => {
                setupRTL();
                const peidOrSubscriberId = screen.getByRole('textbox', { name: /peid or subscriber id/i });

                await testPiiFields();
                expect(peidOrSubscriberId.disabled).toEqual(false);
            });

            test('Button will reset all form fields to empty strings and enable pii fields', async () => {
                setupRTL();

                const input1 = screen.getByRole('textbox', { name: /first name/i });
                const input2 = screen.getByRole('textbox', { name: /last name/i });
                const input3 = screen.getByRole('textbox', { name: /date of birth/i });
                const resetButton = screen.getByRole('button', { name: /Clear/i });
                const input = screen.getByRole('textbox', { name: /peid or subscriber id/i });

                await userEvent.type(input, '1234');

                expect(input).toHaveValue('1234');
                expect(input.disabled).toEqual(false);
                expect(input1.disabled).toEqual(true);
                expect(input2.disabled).toEqual(true);
                expect(input3.disabled).toEqual(true);

                userEvent.click(resetButton);

                await waitFor(() => {
                    expect(input).toHaveValue('');
                });
                expect(input.disabled).toEqual(false);
                expect(input1.disabled).toEqual(false);
                expect(input2.disabled).toEqual(false);
                expect(input3.disabled).toEqual(false);
            });

            test('Button will reset all form fields to empty strings when PEID is Disabled', async () => {
                Object.defineProperty(allToggles, 'toggles', {
                    value: {
                        [toggleNames.SHOW_PEID_OR_SUBSCRIBERID]: false
                    }
                });
                setupRTL();
                await testPiiFields();
            });
        });

        describe('renders search button', () => {
            test('button triggers validation and does not clear if invalid user', async () => {
                setupRTL();
                const input = screen.getByRole('textbox', { name: `${LABEL_FIRST_NAME} ${LABEL_ASTERISK}` });
                const button = screen.getByRole('button', { name: BTN_SEARCH });
                await userEvent.type(input, '');
                userEvent.click(button);
                await screen.findByText(CUSTOMER_SEARCH_REQUEST_MSG);
            });

            const testSearchButton = async (firstName, lastName, dob, peidOrSubscriberId) => {
                const values = {
                    firstName: firstName,
                    lastName: lastName,
                    dateOfBirth: dob,
                    peidOrSubscriberId: peidOrSubscriberId
                };

                const button = screen.getByRole('button', { name: BTN_SEARCH });

                userEvent.click(button);
                expect(screen.queryByText(INVALID_PEID_OR_SUBSCRIBER_ID)).toBeNull();

                await waitFor(() => {
                    expect(store.getActions()).toContainEqual(customerSearchRequest(values));
                });
            };

            test('Submitting form with valid input dispatches request, PEID Enabled', async () => {
                Object.defineProperty(allToggles, 'toggles', {
                    value: {
                        [toggleNames.SHOW_PEID_OR_SUBSCRIBERID]: true
                    }
                });

                setupRTL();
                const peidOrSubscriberId = 'PDDB203091733124810';

                const input4 = screen.getByRole('textbox', { name: `${LABEL_PEID_OR_SUBSCRIBER_ID} ${LABEL_ASTERISK}` });

                await userEvent.type(input4, peidOrSubscriberId);

                await testSearchButton('', '', '', peidOrSubscriberId);
            });

            test('Submitting form with valid input dispatches request, PEID Disabled', async () => {
                Object.defineProperty(allToggles, 'toggles', {
                    value: {
                        [toggleNames.SHOW_PEID_OR_SUBSCRIBERID]: false
                    }
                });

                setupRTL();

                const firstName = 'itp';
                const lastName = 'user';
                const dateOfBirth = '11/22/1999';

                const input1 = screen.getByRole('textbox', { name: `${LABEL_FIRST_NAME} ${LABEL_ASTERISK}` });
                const input2 = screen.getByRole('textbox', { name: `${LABEL_LAST_NAME} ${LABEL_ASTERISK}` });
                const input3 = screen.getByRole('textbox', { name: `${LABEL_DOB} ${LABEL_ASTERISK}` });

                await userEvent.type(input1, firstName);
                await userEvent.type(input2, lastName);
                await userEvent.type(input3, dateOfBirth);

                await testSearchButton(firstName, lastName, dateOfBirth, undefined);
            });

            test('Submitting form with valid peid input dispatches request', async () => {
                setupRTL();
                const values = {
                    firstName: '',
                    lastName: '',
                    dateOfBirth: '',
                    peidOrSubscriberId: '9090203091733124810'
                };

                const input = screen.getByRole('textbox', { name: /PEID or Subscriber ID/i });
                const button = screen.getByRole('button', { name: /Search/i });

                await userEvent.type(input, '9090203091733124810');
                userEvent.click(button);

                expect(screen.queryByText(/invalid peid or subscriber number/i)).toBeNull();

                await waitFor(() => {
                    expect(store.getActions()).toContainEqual(customerSearchRequest(values));
                });
            });

            test('Submitting form with valid subscriber id input dispatches request', async() => {
                setupRTL();
                const values = {
                    firstName: '',
                    lastName: '',
                    dateOfBirth: '',
                    peidOrSubscriberId: 'PDDB203091733124810'
                };

                const input = screen.getByRole('textbox', { name: /PEID or Subscriber ID/i });
                const button = screen.getByRole('button', { name: /Search/i });

                await userEvent.type(input, 'PDDB203091733124810');
                userEvent.click(button);

                expect(screen.queryByText(/Invalid value for PEID Or Subscriber ID/i)).toBeNull();

                await waitFor(() => {
                    expect(store.getActions()).toContainEqual(customerSearchRequest(values));
                });
            });

            test('Submitting form with valid lowercase peid input dispatches request', async () => {
                setupRTL();
                const values = {
                    firstName: '',
                    lastName: '',
                    dateOfBirth: '',
                    peidOrSubscriberId: 'PDDB203091733124810'
                };
                const input = screen.getByRole('textbox', { name: /PEID or Subscriber ID/i });
                const button = screen.getByRole('button', { name: /Search/i });

                await userEvent.type(input, 'pddb203091733124810');
                userEvent.click(button);

                expect(screen.queryByText(/Invalid value for PEID Or Subscriber ID/i)).toBeNull();

                await waitFor(() => {
                    expect(store.getActions()).toContainEqual(customerSearchRequest(values));
                });
            });
        });
    });
});