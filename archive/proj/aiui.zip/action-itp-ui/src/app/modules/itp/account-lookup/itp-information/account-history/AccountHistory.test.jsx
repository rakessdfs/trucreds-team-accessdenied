import React from 'react';
import { screen } from '@testing-library/react';
import thunk from 'redux-thunk';
import createMockStore from 'redux-mock-store';
import { renderContainer } from '../../../../../common/utils/test-utils';
import { COMPLAINT_FEEDBACK, COMPLAINT_FEEDBACK_URL } from '../ItpInformationConstants';
import { AccountHistory } from './AccountHistory';
import { memoData } from './MemoPreview/memoData';

describe('AccountHistory', () => {
    let store, initialState;

    beforeEach(() => {
        jest.clearAllMocks();
        initialState = {
            memo: {
                isFetching: false,
                error: null,
                data: memoData
            },
            itpEnrollmentData: {
                data: {
                    subscriberNumber: 'subscriber',
                    enrollmentDate: 'enroll date',
                    enrollmentStatus: 'status',
                    enrollmentFailedReason: 'failed reason',
                    cancellationDate: 'cancel date',
                    cancellationRequestDate: 'cancel request date',
                    productEnrollmentId: 'PEID'
                },
                error: null,
                isFetching: false
            }
        };
    });

    const setupRTL = () => {
        store = createMockStore([thunk])(initialState);
        return renderContainer(<AccountHistory />, {
            store
        });
    };

    describe('Happy path renders account history', () => {
        test('Renders complaint/feedback button', () => {
            setupRTL();

            const complaintLink = screen.getByRole('link', { name: COMPLAINT_FEEDBACK });

            expect(complaintLink).toHaveAttribute('href', COMPLAINT_FEEDBACK_URL);
            expect(complaintLink).toHaveAttribute('target', '_blank');
            expect(complaintLink).toHaveAttribute('rel', 'noopener noreferrer');
        });
    });

    describe('Fetching state', () => {
        test('show memo preview', () => {
            setupRTL();
            expect(screen.getByTestId('memo-preview-section')).toBeInTheDocument();
        });

        test('show spinner', () => {
            initialState = {
                ...initialState,
                memo: {
                    ...initialState.memo,
                    isFetching: true
                }
            };
            setupRTL();
            expect(screen.getByTestId('circularSpinner')).toBeInTheDocument();
        });
    });
});