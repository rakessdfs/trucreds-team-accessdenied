import axios from 'axios';
import { ThunkDispatch } from 'redux-thunk';
import { IReduxState } from 'src/app/store/Store.types';
import {
    URL_ACTION_ITP_API_HOSTNAME,
    URL_ACTION_ITP_API_HOSTNAME_LOCAL,
    URL_ACTION_ITP_CUSTOMER_SEARCH_CONTEXT
} from '../../../../../common/constants/ITPConstants';
import { IReduxError } from '../../../../../common/types';
import { validateResponse } from '../../../../../common/utils/ITPUtils';
import { getAuthCookie } from '../../../../login/LoginUtils';
import { attemptLogout } from '../../../../login/Login.actions';
import {
    CUSTOMER_SEARCH_FAILURE,
    CUSTOMER_SEARCH_REQUEST,
    CUSTOMER_SEARCH_SUCCESS
} from '../AccountLookupConstants';
import {
    ICustomerSearchFailureAction,
    ICustomerSearchRequest,
    ICustomerSearchRequestAction,
    ICustomerSearchResponse,
    ICustomerSearchSuccessAction,
    TCustomerSearchAction
} from './CustomerSearch.types';

export const customerSearchSuccess = (response: ICustomerSearchResponse): ICustomerSearchSuccessAction => ({
    type: CUSTOMER_SEARCH_SUCCESS,
    payload: response
});

export const customerSearchRequest = ({ firstName, lastName, dateOfBirth, peidOrSubscriberId }: ICustomerSearchRequest): ICustomerSearchRequestAction => ({
    type: CUSTOMER_SEARCH_REQUEST,
    payload: {
        firstName,
        lastName,
        dateOfBirth,
        peidOrSubscriberId
    }
});

export const customerSearchFailure = (error: IReduxError): ICustomerSearchFailureAction => ({
    type: CUSTOMER_SEARCH_FAILURE,
    payload: error
});

export const attemptCustomerSearchRequest = (firstName: string, lastName: string, dateOfBirth: string, peidOrSubscriberId: string) => {
    return async (dispatch: ThunkDispatch<IReduxState, unknown, TCustomerSearchAction>, getState: () => IReduxState): Promise<void> => {
        const agentName = getState().user.data?.userName;
        dispatch(customerSearchRequest({
            firstName,
            lastName,
            dateOfBirth,
            peidOrSubscriberId
        }));

        let response;

        try {
            response = await axios({
                method: 'post',
                url: (URL_ACTION_ITP_API_HOSTNAME || URL_ACTION_ITP_API_HOSTNAME_LOCAL) + URL_ACTION_ITP_CUSTOMER_SEARCH_CONTEXT,
                data: {
                    firstName,
                    lastName,
                    dateOfBirth,
                    peidOrSubscriberId
                },
                headers: {
                    Authorization: `Bearer ${getAuthCookie()}`,
                    'X-DFSUSER-USER-ID': agentName
                }
            });

            const error = validateResponse(response, 'customers');

            if (error) {
                dispatch(customerSearchFailure(error));
                return;
            }
        } catch (e) {
            if (e.response?.status === 401) {
                dispatch(attemptLogout((validateResponse(e.response, 'customer') as IReduxError)));
                return;
            }
            dispatch(customerSearchFailure((validateResponse(e.response, 'customer') as IReduxError)));
            return;
        }
        dispatch(customerSearchSuccess(response?.data));
    };
};