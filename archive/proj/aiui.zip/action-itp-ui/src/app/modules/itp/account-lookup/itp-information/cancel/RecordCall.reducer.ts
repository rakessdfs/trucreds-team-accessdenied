import { IApiState } from '../../../../../common/types';
import { RESET_DATA } from '../../AccountLookup/AccountLookupConstants';
import { TRecordCallAction } from './RecordCall.types';
import { ITP_RECORD_CALL_FAILURE, ITP_RECORD_CALL_REQUEST, ITP_RECORD_CALL_SUCCESS } from './CancelConstants';

export const initialState: IApiState<{}> = {
    error: null,
    isFetching: false,
    data: null
};

export const itpRecordCallReducer = (state = initialState, action: TRecordCallAction): IApiState<{}> => {
    switch (action.type) {
        case ITP_RECORD_CALL_REQUEST:
            return {
                ...state,
                isFetching: true,
                data: null,
                error: null
            };
        case ITP_RECORD_CALL_SUCCESS:
            return {
                ...state,
                isFetching: false,
                data: {
                },
                error: null
            };
        case ITP_RECORD_CALL_FAILURE:
            return {
                ...state,
                isFetching: false,
                data: null,
                error: action.payload
            };
        case RESET_DATA:
            return {
                ...state,
                data: null,
                isFetching: false,
                error: null
            };
        default:
            return state;
    }
};