import React, { ReactElement } from 'react';
import { IMemo } from './MemoPreview.types';
import styles from './MemoPreview.module.scss';

interface IMemoPreviewProps {
    memo: IMemo;
}

export const MemoPreview = ({ memo }: IMemoPreviewProps): ReactElement => {
    return (
        <div className={styles.memoPreviewRow}>
            <p>{`${memo.CREATE_DATE}, ${memo.CREATE_TIME} | ${memo.CREATE_AGENT_ID}` }</p>
            <p>{memo.MEMO_TEXT}</p>
        </div>
    );
};