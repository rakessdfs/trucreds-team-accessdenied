import React, { ReactElement } from 'react';
import styles from './CancelEnrollment.module.scss';
import { ITP_TALKING_POINT } from './CancelConstants';

interface ITalkingPoint {
    message: string;
    subMessage: string | null;
}

export const TalkingPoint = ({ message, subMessage }: ITalkingPoint): ReactElement => {
    return (
        <div className={styles.talkingPointContainer}>
            <div className={styles.talkingPointLabel}>
                {ITP_TALKING_POINT}
            </div>
            <div className={styles.talkingPointSection}>
                <p className={styles.talkingPointText}>{message}</p>
                {
                    subMessage !== null &&
                    <p
                        className={styles.talkingPointText}
                        data-testid='subMessage-id'
                    >{subMessage}</p>
                }
            </div>
        </div>
    );
};