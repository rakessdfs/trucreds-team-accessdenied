import React, { ReactElement } from 'react';
import { Button } from '../../../../../common/Components/Buttons/Button';
import './CancelEnrollmentErrorComponent.scss';
import { CANCELLATION_HEADER, CANCELLATION_SUB_HEADER, ITP_END_PROCESS, SYSTEM_MESSAGE } from './CancelConstants';

interface ICancelEnrollmentErrorProps {
    onEndProcess: () => void;
}

export const CancelEnrollmentErrorComponent = ({ onEndProcess }: ICancelEnrollmentErrorProps): ReactElement => {
    return (
        <div className='cancelEnrollmentErrorContainer'>
            <p className='systemMessage'>{SYSTEM_MESSAGE}</p>
            <div className='innerCancelEnrollmentErrorContainer'>
                <div className='redHeader' />
                <div className='cancelEnrollmentErrorContent'>
                    <p className='cancellationHeader'>{CANCELLATION_HEADER}</p>
                    <p className='cancellationSubHeader'>{CANCELLATION_SUB_HEADER}</p>
                    <Button
                        className='endProcessButton'
                        onClick={onEndProcess}
                    >{ITP_END_PROCESS}</Button>
                </div>
            </div>
        </div>
    );
};