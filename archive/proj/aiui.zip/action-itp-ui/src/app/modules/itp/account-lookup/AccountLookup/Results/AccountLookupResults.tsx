import React, { ReactElement, useEffect, useState } from 'react';
import { Icon } from '@iconify/react';
import magnifyIcon from '@iconify/icons-mdi-light/magnify';
import { useDispatch, useSelector } from 'react-redux';
import { IReduxState } from '../../../../../store/Store.types';
import { fetchITPData } from '../../itp-information/BillingData/ItpData.actions';
import { attemptCustomerPiiRequest } from '../CustomerPII.actions';
import { CircularSpinner } from '../../../../../common/Components/CircularSpinner/CircularSpinner';
import {
    CUSTOMER_SEARCH_CRITERIA_LINE_1,
    CUSTOMER_SEARCH_CRITERIA_LINE_2,
    CUSTOMER_SEARCH_CRITERIA_LINE_3,
    FIRST_NAME_COLUMN_HEADER,
    LAST_NAME_COLUMN_HEADER,
    NO_RESULTS_FOUND,
    PLEASE_SEARCH_AGAIN,
    SSN_COLUMN_HEADER,
    VIEW_ACCOUNT
} from '../AccountLookupConstants';
import styles from './AccountLookupResults.module.scss';

interface IAccountLookupResultsProps {
    onViewAccount: () => void;
}

export const AccountLookupResults = ({ onViewAccount }: IAccountLookupResultsProps): ReactElement => {
    let messagingContent, tableContent;

    const { data, isFetching } = useSelector((state: IReduxState) => state.customerSearch);
    const { data: piiData, isFetching: isPiiFetching } = useSelector((state: IReduxState) => state.pii);

    const [isClicked, setIsClicked] = useState(false);
    const [indexOnClick, setIndexOnClick] = useState(0);

    const dispatch = useDispatch();

    const results = data?.customers;

    useEffect(() => {
        if (isClicked && piiData) {
            onViewAccount();
            setIsClicked(false);
        }
    }, [piiData, isClicked, onViewAccount]);

    if (typeof results === 'undefined') {
        if (!isFetching) {
            messagingContent = (
                <div className={styles.resultMessaging}>
                    <Icon
                        data-testid='magnifying-glass'
                        icon={magnifyIcon}
                        width={90}
                        height={90}
                    />
                    <p>{CUSTOMER_SEARCH_CRITERIA_LINE_1}</p>
                    <p>{CUSTOMER_SEARCH_CRITERIA_LINE_2}</p>
                    <p>{CUSTOMER_SEARCH_CRITERIA_LINE_3}</p>
                </div>
            );
        } else {
            messagingContent = (
                <div className={styles.resultMessaging}>
                    <CircularSpinner isButton={false} />
                </div>
            );
        }
    } else if (results.length === 0) {
        messagingContent = (
            <div className={styles.resultMessaging}>
                <Icon
                    data-testid='magnifying-glass'
                    icon={magnifyIcon}
                    width={90}
                    height={90}
                />
                <p>{NO_RESULTS_FOUND}</p>
                <p>{PLEASE_SEARCH_AGAIN}</p>
            </div>
        );
    } else {
        tableContent = (
            <tbody>
                {results?.map((result, index) => {
                    return (
                        <tr
                            key={result.ssn}
                            data-testid='search-result-row'
                            className={styles.resultRow}
                        >
                            <td className={styles.wide}>{result.firstName}</td>
                            <td className={styles.wide}>{result.lastName}</td>
                            <td className={styles.narrow}>{result.ssn}</td>
                            <td className={styles.narrow}>
                                <div className={styles.viewAccount}>
                                    <button
                                        className={styles.viewAccountButton}
                                        onClick={(): void => {
                                            dispatch(attemptCustomerPiiRequest(result.partyId));
                                            dispatch(fetchITPData(result.partyId));
                                            setIsClicked(true);
                                            setIndexOnClick(index);
                                        }}
                                    >
                                        {VIEW_ACCOUNT}
                                    </button>
                                    {(isPiiFetching && (index === indexOnClick)) && <CircularSpinner />}
                                </div>
                            </td>
                        </tr>
                    );
                })}
            </tbody>
        );
    }
    return (
        <div className={styles.tableContainer}>
            <table>
                <thead>
                    <tr className={styles.resultRow}>
                        <th className={styles.wide}>{FIRST_NAME_COLUMN_HEADER}</th>
                        <th className={styles.wide}>{LAST_NAME_COLUMN_HEADER}</th>
                        <th className={styles.narrow}>{SSN_COLUMN_HEADER}</th>
                        <th className={styles.narrow} />
                    </tr>
                </thead>
                { tableContent }
            </table>
            { messagingContent }
        </div>
    );
};