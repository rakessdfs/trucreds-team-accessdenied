import { buildReduxError } from '../../../../common/utils/ITPUtils';
import { piiFailure, piiRequest, piiSuccess, resetData } from './CustomerPII.actions';
import { piiReducer } from './CustomerPII.reducer';

describe('piiReducer', () => {
    let initialState;

    beforeEach(() => {
        initialState = {
            error: null,
            isFetching: false,
            data: {
                firstName: '',
                lastName: '',
                dateOfBirth: '',
                ssn: '',
                addressLine1: '',
                addressLine2: '',
                primaryPhone: '',
                email: ''
            }
        };
    });

    describe('piiRequest', () => {
        test('sets the state correctly', () => {
            expect(piiReducer(initialState, piiRequest('1234'))).toEqual({
                ...initialState,
                isFetching: true,
                data: null
            });
        });
    });

    describe('piiSuccess', () => {
        beforeEach(() => {
            initialState = {
                ...initialState,
                data: {
                    ...initialState.data,
                    firstName: 'fName',
                    lastName: 'lName',
                    dateOfBirth: 'dateOfBirth',
                    ssn: 'ssn'
                }
            };
        });

        test('sets the new state correctly', () => {
            const apiResponseData = {
                firstName: 'fName',
                lastName: 'lName',
                dateOfBirth: 'dateOfBirth',
                ssn: 'ssn',
                address: {
                    barCode: '0',
                    cityName: 'NYC',
                    countryCode: 'USA',
                    postalCode: '01234',
                    addressLine1: 'addressLine1',
                    addressLine2: 'addressLine2',
                    stateOrSectionCode: 'NY',
                    forbidAutoFormatting: false
                },
                primaryPhone: '1234567890',
                email: 'email'
            };

            expect(
                piiReducer(initialState, piiSuccess(apiResponseData))
            ).toEqual({
                ...initialState,
                data: {
                    ...initialState.data,
                    firstName: 'fName',
                    lastName: 'lName',
                    dateOfBirth: 'dateOfBirth',
                    ssn: 'XXX-XX-ssn',
                    addressLine1: 'addressLine1 addressLine2',
                    addressLine2: 'NYC, NY 01234',
                    primaryPhone: '(123) 456-7890',
                    email: 'email'
                }
            });
        });

        test('sets the null data state correctly', () => {
            const apiResponseData = {
                firstName: 'fName1',
                lastName: 'lName2',
                dateOfBirth: 'dateOfBirth',
                ssn: 'ssn',
                address: null,
                primaryPhone: '',
                email: ''
            };

            expect(
                piiReducer(initialState, piiSuccess(apiResponseData))
            ).toEqual({
                ...initialState,
                data: {
                    ...initialState.data,
                    firstName: 'fName1',
                    lastName: 'lName2',
                    dateOfBirth: 'dateOfBirth',
                    ssn: 'XXX-XX-ssn',
                    addressLine1: ' ',
                    addressLine2: '  ',
                    primaryPhone: '',
                    email: ''
                }
            });
        });
    });

    describe('piiFailure', () => {
        test('sets the state correctly', () => {
            expect(piiReducer(initialState, piiFailure(buildReduxError('some custom error', '')))).toEqual({
                ...initialState,
                isFetching: false,
                error: {
                    cause: [''],
                    message: ['some custom error']
                },
                data: null
            });
        });
    });

    describe('dataReset', () => {
        test('sets the state correctly', () => {
            expect(piiReducer(initialState, resetData())).toEqual({
                ...initialState,
                data: null,
                isFetching: false,
                error: null
            });
        });
    });
});