import { buildReduxError } from '../../../../../../common/utils/ITPUtils';
import { resetData } from '../../../AccountLookup/CustomerPII.actions';
import { memoPreviewReducer } from './MemoPreview.reducer';
import { fetchMemoFailure, fetchMemoRequest, fetchMemoSuccess } from './MemoPreview.actions';

describe('memoPreviewReducer', () => {
    let initialState;

    beforeEach(() => {
        initialState = {
            error: null,
            isFetching: false,
            data: null
        };
    });

    describe('fetchMemoRequest', () => {
        const requestData = {
            productEnrollmentId: '145'
        };

        test('sets the state correctly', () => {
            expect(memoPreviewReducer(initialState, fetchMemoRequest(requestData))).toEqual({
                ...initialState,
                isFetching: true,
                data: {
                    memoData: null
                },
                error: null
            });
        });
    });

    describe('fetchMemoSuccess', () => {
        beforeEach(() => {
            initialState = {
                ...initialState,
                data: {
                    memoData: null
                }
            };
        });

        test('sets the new state correctly', () => {
            const apiResponseData = {
                allMemos: [
                    {
                        month: 'September 2020',
                        memos: [
                            {
                                MEMO_TEXT: 'Enrolled into ITP F&F',
                                CREATE_AGENT_ID: 'ksekar1',
                                CREATE_DATE: '09/03/20',
                                CREATE_TIME: '07:32:56 pm',
                                CREATE_MONTH: 'September 2020'
                            }
                        ]
                    }
                ]
            };

            expect(
                memoPreviewReducer(initialState, fetchMemoSuccess(apiResponseData))
            ).toEqual({
                ...initialState,
                data: {
                    memoData: {
                        allMemos: [
                            {
                                month: 'September 2020',
                                memos: [
                                    {
                                        MEMO_TEXT: 'Enrolled into ITP F&F',
                                        CREATE_AGENT_ID: 'ksekar1',
                                        CREATE_DATE: '09/03/20',
                                        CREATE_TIME: '07:32:56 pm',
                                        CREATE_MONTH: 'September 2020'
                                    }
                                ]
                            }
                        ]
                    }
                }
            });
        });
    });

    describe('fetchMemoFailure', () => {
        test('sets the state correctly', () => {
            expect(memoPreviewReducer(initialState, fetchMemoFailure(buildReduxError('some custom error', '')))).toEqual({
                ...initialState,
                isFetching: false,
                error: {
                    cause: [''],
                    message: ['some custom error']
                },
                data: null
            });
        });
    });

    describe('resetData', () => {
        test('sets the state correctly', () => {
            expect(memoPreviewReducer(initialState, resetData())).toEqual({
                ...initialState,
                data: null,
                isFetching: false,
                error: null
            });
        });
    });
});