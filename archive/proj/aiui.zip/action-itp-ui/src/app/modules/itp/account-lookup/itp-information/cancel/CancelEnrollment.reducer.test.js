import { buildReduxError } from '../../../../../common/utils/ITPUtils';
import { cancelEnrollmentReducer } from './CancelEnrollment.reducer';
import { cancelEnrollmentFailure, cancelEnrollmentReset, cancelEnrollmentSuccess } from './CancelEnrollment.actions';

describe('cancelEnrollmentReducer', () => {
    let initialState;

    beforeEach(() => {
        initialState = {
            error: null,
            isFetching: true,
            data: null
        };
    });

    describe('cancelEnrollmentSuccess', () => {
        beforeEach(() => {
            initialState = {
                ...initialState
            };
        });

        test('Cancel Enrollment Success', () => {
            expect(cancelEnrollmentReducer(initialState, cancelEnrollmentSuccess())).toEqual({
                ...initialState,
                isFetching: false,
                error: null,
                data: {}
            });
        });
    });

    describe('cancelEnrollmentFailure', () => {
        test('Error requesting cancellation', () => {
            expect(cancelEnrollmentReducer(initialState, cancelEnrollmentFailure(buildReduxError('some custom error', '')))).toEqual({
                ...initialState,
                isFetching: false,
                error: {
                    cause: [''],
                    message: ['some custom error']
                },
                data: null
            });
        });
    });

    describe('cancelEnrollmentResetData', () => {
        test('resets the state correctly', () => {
            expect(cancelEnrollmentReducer(initialState, cancelEnrollmentReset())).toEqual({
                ...initialState,
                data: null,
                isFetching: false,
                error: null
            });
        });
    });
});