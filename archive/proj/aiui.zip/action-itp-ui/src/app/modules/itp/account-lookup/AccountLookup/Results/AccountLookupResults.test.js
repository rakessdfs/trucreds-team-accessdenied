import { screen } from '@testing-library/react';
import { waitFor } from '@testing-library/dom';
import userEvent from '@testing-library/user-event';
import React from 'react';
import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { customerSearchSuccessResponse } from '../../../../../../msw/responses/customerSearch/responses';
import { renderContainer } from '../../../../../common/utils/test-utils';
import { itpDataRequest } from '../../itp-information/BillingData/ItpData.actions';
import { piiRequest } from '../CustomerPII.actions';
import { successfulPiiResponse } from '../testData';
import {
    CUSTOMER_SEARCH_CRITERIA_LINE_1,
    CUSTOMER_SEARCH_CRITERIA_LINE_2,
    CUSTOMER_SEARCH_CRITERIA_LINE_3,
    FIRST_NAME_COLUMN_HEADER,
    LAST_NAME_COLUMN_HEADER,
    NO_RESULTS_FOUND,
    PLEASE_SEARCH_AGAIN,
    SSN_COLUMN_HEADER,
    VIEW_ACCOUNT
} from '../AccountLookupConstants';
import { AccountLookupResults } from './AccountLookupResults';

describe('AccountLookupResults', () => {
    let onViewAccountMock, initialState, store;

    beforeEach(() => {
        onViewAccountMock = jest.fn();
        initialState = {
            customerSearch: {
                data: {
                    ...customerSearchSuccessResponse
                },
                error: null,
                isFetching: false
            },
            user: {
                data: {
                    userName: 'testUser456'
                }
            },
            pii: {
                data: {
                    ...successfulPiiResponse
                },
                error: null,
                isFetching: false
            },
            itpEnrollmentData: {
                data: {
                    productEnrollmentId: {}
                }
            }
        };
    });

    const setupRTL = () => {
        store = configureMockStore([thunk])(initialState);
        return renderContainer(
            <AccountLookupResults
                onViewAccount={onViewAccountMock}
            />,
            { store }
        );
    };

    test('Renders table column headers', () => {
        setupRTL();
        expect(screen.getByRole('columnheader', { name: FIRST_NAME_COLUMN_HEADER })).toBeInTheDocument();
        expect(screen.getByRole('columnheader', { name: LAST_NAME_COLUMN_HEADER })).toBeInTheDocument();
        expect(screen.getByRole('columnheader', { name: SSN_COLUMN_HEADER })).toBeInTheDocument();
    });

    describe('Initial state', () => {
        test('Renders Search instructions and icon', () => {
            initialState = {
                ...initialState,
                customerSearch: {
                    ...initialState.customerSearch,
                    data: null
                }
            };
            setupRTL();
            expect(screen.getByTestId('magnifying-glass')).toBeInTheDocument();
            expect(screen.getByText(CUSTOMER_SEARCH_CRITERIA_LINE_1)).toBeInTheDocument();
            expect(screen.getByText(CUSTOMER_SEARCH_CRITERIA_LINE_2)).toBeInTheDocument();
            expect(screen.getByText(CUSTOMER_SEARCH_CRITERIA_LINE_3)).toBeInTheDocument();
        });
    });

    describe('Empty Results state', () => {
        test('Renders Search instructions and icon', () => {
            initialState = {
                ...initialState,
                customerSearch: {
                    ...initialState.customerSearch,
                    data: {
                        customers: []
                    }
                }
            };
            setupRTL();
            expect(screen.getByTestId('magnifying-glass')).toBeInTheDocument();
            expect(screen.getByText(NO_RESULTS_FOUND)).toBeInTheDocument();
            expect(screen.getByText(PLEASE_SEARCH_AGAIN)).toBeInTheDocument();
        });
    });

    describe('Valid Results returned and displayed', () => {
        test('Renders table row for each person in results list', () => {
            setupRTL();
            expect(screen.getAllByTestId('search-result-row')).toHaveLength(4);
            expect(screen.getAllByRole('cell', { name: 'test' })).toHaveLength(2);
            expect(screen.getByRole('cell', { name: 'user' })).toBeInTheDocument();
            expect(screen.getByRole('cell', { name: '1234' })).toBeInTheDocument();
            expect(screen.getAllByRole('cell', { name: VIEW_ACCOUNT })).toHaveLength(4);
        });

        test('Clicking View Account button will dispatch request', () => {
            setupRTL();

            const viewAccountButtons = screen.getAllByRole('button', { name: VIEW_ACCOUNT });

            expect(viewAccountButtons).toHaveLength(4);
            userEvent.click(viewAccountButtons[0]);

            const actions = store.getActions();

            expect(actions).toContainEqual(itpDataRequest({ partyId: '1234' }));
            waitFor(() => {
                expect(actions).toContainEqual(piiRequest({ partyId: '1234' }));
            });
        });
    });

    describe('Fetching search data', () => {
        test('isFetching search', () => {
            initialState = {
                ...initialState,
                customerSearch: {
                    isFetching: true
                }
            };
            setupRTL();
            expect(screen.getByTestId('circularSpinner')).toBeInTheDocument();
        });

        test('isFetching pii data', () => {
            initialState = {
                ...initialState,
                pii: {
                    isFetching: true
                }
            };
            setupRTL();
            expect(screen.getByTestId('circularSpinner')).toBeInTheDocument();
        });
    });
});