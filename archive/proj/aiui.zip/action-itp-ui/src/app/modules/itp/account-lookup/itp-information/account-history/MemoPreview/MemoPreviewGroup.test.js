import { screen } from '@testing-library/dom';
import React from 'react';
import { renderContainer } from '../../../../../../common/utils/test-utils';
import { MemoPreviewGroup } from './MemoPreviewGroup';

describe('MemoPreviewGroup', () => {
    const memoData = {
        month: 'January 2020',
        memos: [
            {
                CREATE_DATE: '01/01/0101',
                CREATE_TIME: '12:00:00 AM',
                CREATE_AGENT_ID: 'Robin',
                MEMO_TEXT: 'One Memo'
            },
            {
                CREATE_DATE: '02/02/0202',
                CREATE_TIME: '1:00:00 AM',
                CREATE_AGENT_ID: 'Joker',
                MEMO_TEXT: 'Two Memo'
            }
        ]
    };
    const setupRTL = () => {
        return renderContainer(
            <MemoPreviewGroup
                month={memoData.month}
                memos={memoData.memos}
            />
        );
    };

    test('Renders Preview Month', () => {
        setupRTL();
        expect(screen.getByText(memoData.month)).toBeInTheDocument();
    });

    test('Renders MemoPreviews for each passed in', () => {
        setupRTL();
        memoData.memos.forEach((memo) => {
            expect(screen.getByText(memo.MEMO_TEXT)).toBeInTheDocument();
        });
    });
});