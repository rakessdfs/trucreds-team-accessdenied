import React from 'react';
import { screen } from '@testing-library/dom';
import { renderContainer } from '../../../../../common/utils/test-utils';
import { TalkingPoint } from './TalkingPoint';
import {
    FF_CANCEL_MESSAGE,
    FF_CANCEL_SUB_MESSAGE,
    ITP_TALKING_POINT,
    BM_CANCEL_MESSAGE
} from './CancelConstants';

describe('Talking Point', () => {
    const setupRTL = (message, subMessage) => {
        return renderContainer(
            <TalkingPoint
                message={message}
                subMessage={subMessage}
            />
        );
    };

    test('renders static content', () => {
        setupRTL(FF_CANCEL_MESSAGE, FF_CANCEL_SUB_MESSAGE);

        expect(screen.getByText(ITP_TALKING_POINT)).toBeInTheDocument();
        expect(screen.getByText(FF_CANCEL_MESSAGE)).toBeInTheDocument();
        expect(screen.getByText(FF_CANCEL_SUB_MESSAGE)).toBeInTheDocument();
    });

    test('renders static component without sub message', () => {
        setupRTL(BM_CANCEL_MESSAGE, null);

        expect(screen.getByText(ITP_TALKING_POINT)).toBeInTheDocument();
        expect(screen.getByText(BM_CANCEL_MESSAGE)).toBeInTheDocument();
        expect(screen.queryByTestId('subMessage-id')).not.toBeInTheDocument();
    });
});