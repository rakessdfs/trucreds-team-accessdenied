import { IReduxError } from '../../../../../common/types';
export interface IMembershipResponse {
    subscriberNumber: string;
    enrollmentDate: Date;
    enrollmentStatus: string;
    enrollmentFailedReason: string;
    cancellationDate: Date;
    cancellationRequestDate: Date;
    productEnrollmentId: number;
    customerType: string;
    partyId: string;
    standingCode: string;
}

export interface IMembershipRequest {
    partyId: string;
}

export interface IMembershipRequestAction {
    type: 'ITP_ENROLLMENT_REQUEST';
    payload: IMembershipRequest;
}

export interface IMembershipSuccessAction {
    type: 'ITP_ENROLLMENT_SUCCESS';
    payload: IMembershipResponse;
}

export interface IMembershipFailureAction {
    type: 'ITP_ENROLLMENT_FAILURE';
    payload: IReduxError;
}

export interface IResetData {
    type: 'RESET_DATA';
}

export interface IMembershipState {
    subscriberNumber: string | null;
    enrollmentDate: Date | null;
    enrollmentStatus: string | null;
    enrollmentFailedReason: string | null;
    cancellationDate: Date | null;
    cancellationRequestDate: Date | null;
    cancellationReason: string | null;
    productEnrollmentId: number | 0;
    customerType: string | '';
    partyId: string | '';
    standingCode: string;
}

export type TMembershipAction = IMembershipRequestAction | IMembershipFailureAction | IMembershipSuccessAction | IResetData;