import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { memoData } from '../../../../../../../msw/responses/memo/fetchMemoResponses';
import { attemptFetchMemoRequest, fetchMemoRequest, fetchMemoFailure, fetchMemoSuccess } from './MemoPreview.actions';
import { FETCH_MEMO_FAILURE, FETCH_MEMO_REQUEST, FETCH_MEMO_SUCCESS } from './MemoPreviewConstants';

describe('MemoActions', () => {
    test('fetchMemoSuccess', () => {
        const data = {
            ...memoData
        };

        const result = fetchMemoSuccess(data);
        expect(result).toEqual({
            type: FETCH_MEMO_SUCCESS,
            payload: {
                ...data
            }
        });
    });

    test('fetchMemoRequest', () => {
        const data = {
            productEnrollmentId: '13578'
        };

        expect(fetchMemoRequest(data)).toEqual({
            type: FETCH_MEMO_REQUEST,
            payload: {
                ...data
            }
        });
    });

    test('fetchMemoFailure', () => {
        const error = {
            message: ['error'],
            cause: ['unknown']
        };
        expect(fetchMemoFailure(error)).toEqual({
            type: FETCH_MEMO_FAILURE,
            payload: error
        });
    });

    describe('attemptFetchMemoRequest', () => {
        const middleware = [thunk];
        const mockStore = configureMockStore(middleware);
        let store, data;

        beforeEach(() => {
            store = mockStore({});
            jest.resetAllMocks();
            data = {
                productEnrollmentId: '123'
            };
        });

        test('handles 200 success path', async () => {
            await store.dispatch(attemptFetchMemoRequest(data.productEnrollmentId));
            const actions = store.getActions();

            expect(actions[1].type).toEqual(FETCH_MEMO_SUCCESS);
            expect(actions[1].payload.allMemos.length).toEqual(1);
            expect(actions[1].payload.allMemos[0].memos[0].CREATE_AGENT_ID).toEqual('test');
            expect(actions[1].payload.allMemos[0].memos[0].MEMO_TEXT).toEqual('Enrolled into ITP F&F');
        });

        test('handles 204 invalid user', async () => {
            await store.dispatch(attemptFetchMemoRequest('2683'));
            const actions = store.getActions();
            expect(actions[1]).toEqual(fetchMemoFailure({
                cause: [],
                message: ['No Memo Available.']
            }));
        });

        test('handles 400 response code', async () => {
            await store.dispatch(attemptFetchMemoRequest(''));
            const actions = store.getActions();

            expect(actions[1]).toEqual(fetchMemoFailure({
                cause: ['1012'],
                message: ['Invalid request. Please resolve and try again.']
            }));
        });

        test('handles failure path', async () => {
            await store.dispatch(attemptFetchMemoRequest('5673'));
            const actions = store.getActions();
            expect(actions[1]).toEqual(fetchMemoFailure({
                cause: ['5006'],
                message: ['Unable to load Memo at this time. Please try again.']
            }));
        });
    });

    test('fetchMemoFailure', () => {
        const error = {
            errorCode: '1',
            message: ['some message']
        };
        const result = fetchMemoFailure(error);
        expect(result).toEqual({
            type: FETCH_MEMO_FAILURE,
            payload: error
        });
    });
});