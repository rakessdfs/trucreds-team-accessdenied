import { screen } from '@testing-library/react';
import React from 'react';
import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { renderContainer } from '../../../../common/utils/test-utils';
import {
    INTERNAL_SERVER_ERROR,
    INVALID_DOB,
    INVALID_FIRST_NAME,
    INVALID_LAST_NAME
} from '../../../../common/constants/ITPConstants';
import { errorHandling } from '../../../../common/utils/ITPUtils';
import { ErrorSection } from './ErrorSection';
import {
    ERROR_MSG_ALL_FIELDS,
    VALIDATION_MSG_PEID_SUBSCRIBER_ID
} from './AccountLookupConstants';

describe('ErrorSection', () => {
    let validationErrors, piiSearchError, peidSearchError;

    beforeEach(() => {
        piiSearchError = false;
        peidSearchError = false;
        validationErrors = {};
    });

    const setupRTL = (error) => {
        const store = configureMockStore([thunk])();
        return renderContainer(
            <ErrorSection
                errors={errorHandling(validationErrors, piiSearchError, peidSearchError,
                    false, [error])}
            />, {
                store
            });
    };

    describe('form validation errors', () => {
        test('first name validation', () => {
            validationErrors = {
                ...validationErrors,
                firstName: {
                    type: 'pattern'
                }
            };

            setupRTL();

            expect(screen.getByText(INVALID_FIRST_NAME)).toBeInTheDocument();
        });

        test('last name validation', () => {
            validationErrors = {
                ...validationErrors,
                lastName: {
                    type: 'pattern'
                }
            };

            setupRTL();

            expect(screen.getByText(INVALID_LAST_NAME)).toBeInTheDocument();
        });

        test('dob validation', () => {
            validationErrors = {
                ...validationErrors,
                dob: {
                    type: 'pattern'
                }
            };

            setupRTL();

            expect(screen.getByText(INVALID_DOB)).toBeInTheDocument();
        });

        describe('all fields required', () => {
            test('firstName', () => {
                validationErrors = {
                    ...validationErrors,
                    firstName: {
                        type: 'required'
                    }
                };

                setupRTL();

                expect(screen.getByText(ERROR_MSG_ALL_FIELDS)).toBeInTheDocument();
            });

            test('last name', () => {
                validationErrors = {
                    ...validationErrors,
                    lastName: {
                        type: 'required'
                    }
                };

                setupRTL();

                expect(screen.getByText(ERROR_MSG_ALL_FIELDS)).toBeInTheDocument();
            });

            test('dob', () => {
                validationErrors = {
                    ...validationErrors,
                    dob: {
                        type: 'required'
                    }
                };

                setupRTL();

                expect(screen.getByText(ERROR_MSG_ALL_FIELDS)).toBeInTheDocument();
            });
        });

        describe('peid and pii search errors', () => {
            test('pii search error', () => {
                piiSearchError = true;
                setupRTL();

                expect(screen.getByText(ERROR_MSG_ALL_FIELDS)).toBeInTheDocument();
            });

            test('peid search error', () => {
                peidSearchError = true;
                setupRTL();

                expect(screen.getByText(VALIDATION_MSG_PEID_SUBSCRIBER_ID)).toBeInTheDocument();
            });
        });
    });

    describe('api (redux) errors', () => {
        test('invalid dob', () => {
            setupRTL({ cause: ['1002'] });

            expect(screen.getByText(INVALID_DOB)).toBeInTheDocument();
        });

        test('invalid first name', () => {
            setupRTL({ cause: ['1008'] });

            expect(screen.getByText(INVALID_FIRST_NAME)).toBeInTheDocument();
        });

        test('invalid last name', () => {
            setupRTL({ cause: ['1004'] });

            expect(screen.getByText(INVALID_LAST_NAME)).toBeInTheDocument();
        });

        test('an unknown code maps to an unknown error', () => {
            setupRTL({ cause: ['999'] });

            expect(screen.getByText(INTERNAL_SERVER_ERROR)).toBeInTheDocument();
        });
    });
});