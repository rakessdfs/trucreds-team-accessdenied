import React, { ReactElement } from 'react';
import styles from './AccountLookup.module.scss';
import { AccountLookupSearch } from './Search/AccountLookupSearch';
import { AccountLookupResults } from './Results/AccountLookupResults';
import { CUSTOMER_SEARCH } from './AccountLookupConstants';

interface IAccountLookupProps {
    onViewAccount: () => void;
}

export interface IFormFields {
    firstName: string;
    lastName: string;
    dob: string;
    peIdOrSubscriberId: string;
}

export const AccountLookup = ({ onViewAccount }: IAccountLookupProps): ReactElement => {
    return (
        <div className={styles.accountLookupContainer}>
            <h1 className={styles.sectionHeader}>{CUSTOMER_SEARCH}</h1>
            <AccountLookupSearch />
            <AccountLookupResults onViewAccount={onViewAccount} />
        </div>
    );
};