import { IApiState } from '../../../common/types';
import { RESET_DATA } from '../account-lookup/AccountLookup/AccountLookupConstants';
import { ICreateMemoState, TCreateMemoAction } from './UtilityMenu.types';
import { CREATE_MEMO_FAILURE, CREATE_MEMO_REQUEST, CREATE_MEMO_SUCCESS } from './UtilityMenuContants';

export const initialState: IApiState<ICreateMemoState> = {
    error: null,
    isFetching: false,
    data: null
};

export const createMemoReducer = (state = initialState, action: TCreateMemoAction): IApiState<ICreateMemoState> => {
    switch (action.type) {
        case CREATE_MEMO_REQUEST:
            return {
                ...state,
                isFetching: true,
                data: {
                    memoText: action.payload.memoText,
                    productEnrollmentId: action.payload.productEnrollmentId,
                    createdSuccessfully: false
                },
                error: null
            };
        case CREATE_MEMO_SUCCESS:
            return {
                ...state,
                isFetching: false,
                data: {
                    memoText: '',
                    productEnrollmentId: '',
                    createdSuccessfully: true
                },
                error: null
            };
        case CREATE_MEMO_FAILURE:
            return {
                ...state,
                isFetching: false,
                data: null,
                error: action.payload
            };
        case RESET_DATA:
            return {
                ...state,
                data: null,
                isFetching: false,
                error: null
            };
        default:
            return state;
    }
};