import { IReduxError } from '../../../../../common/types';

export interface ICustomerSearchResponse {
    customers: ICustomerSearchItem[];
}

export interface ICustomerSearchItem {
    firstName: string;
    lastName: string;
    partyId: string;
    ssn: string;
}

export interface ICustomerSearchRequest {
    firstName: string;
    lastName: string;
    dateOfBirth: string;
    peidOrSubscriberId: string;
}

export interface ICustomerSearchSuccessAction {
    type: 'CUSTOMER_SEARCH_SUCCESS';
    payload: ICustomerSearchResponse;
}

export interface ICustomerSearchFailureAction {
    type: 'CUSTOMER_SEARCH_FAILURE';
    payload: IReduxError;
}

export interface ICustomerSearchRequestAction {
    type: 'CUSTOMER_SEARCH_REQUEST';
    payload: ICustomerSearchRequest;
}

export interface ILogoutAction {
    type: 'LOGOUT';
    payload: IReduxError;
}

export interface IResetData {
    type: 'RESET_DATA';
}

export type TCustomerSearchAction = ICustomerSearchRequestAction | ICustomerSearchSuccessAction | ICustomerSearchFailureAction | ILogoutAction | IResetData;