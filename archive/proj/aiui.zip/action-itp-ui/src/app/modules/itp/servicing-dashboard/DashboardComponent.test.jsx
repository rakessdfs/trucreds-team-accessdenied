import { waitFor } from '@testing-library/dom';
import { screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import React from 'react';
import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { renderContainer } from 'src/app/common/utils/test-utils';
import {
    customerSearchRequest
} from '../account-lookup/AccountLookup/Search/CustomerSearch.actions';
import {
    BTN_SEARCH,
    LABEL_ASTERISK,
    LABEL_DOB,
    LABEL_FIRST_NAME, LABEL_LAST_NAME
} from '../account-lookup/AccountLookup/AccountLookupConstants';
import * as allToggles from '../../../common/toggle/toggles';
import { toggleNames } from '../../../common/toggle/toggleNames';
import { DashboardComponent } from './DashboardComponent';

const formData = {
    firstName: 'valid',
    lastName: 'lastname',
    dateOfBirth: '12/12/1990',
    peidOrSubscriberId: ''
};

describe('DashboardComponent', () => {
    let initialState, store;

    const setupRTL = () => {
        store = configureMockStore([thunk])(initialState);
        return renderContainer(<DashboardComponent />, {
            store
        });
    };

    describe('Happy Path', () => {
        beforeEach(() => {
            initialState = {
                user: {
                    data: {
                        userName: 'username',
                        fullName: 'full name',
                        email: 'test@test.com'
                    }
                },
                pii: {
                    data: null,
                    error: null,
                    isFetching: false
                },
                itpEnrollmentData: {
                    data: {
                        subscriberNumber: 'subscriber',
                        enrollmentDate: 'enroll date',
                        enrollmentStatus: 'status',
                        enrollmentFailedReason: 'failed reason',
                        cancellationDate: 'cancel date',
                        cancellationRequestDate: 'cancel request date',
                        productEnrollmentId: 'PEID'
                    },
                    error: null,
                    isFetching: false
                },
                createMemo: {
                    data: null,
                    error: null,
                    isFetching: false
                },
                billingData: {
                    data: {
                        pcmFirstName: 'first name',
                        pcmLastName: 'last name',
                        pcmAccountNumber: 'acc number',
                        presenceOfSecondary: 'yes'
                    },
                    error: null,
                    isFetching: false
                },
                customerSearch: {
                    data: null,
                    error: null,
                    isFetching: false
                }
            };
        });

        describe('Renders Customer Search Fields', () => {
            test('Submitting PII form fields dispatches request, user can verify information, and then see users info', async () => {
                Object.defineProperty(allToggles, 'toggles', {
                    value: {
                        [toggleNames.SHOW_PEID_OR_SUBSCRIBERID]: true
                    }
                });
                setupRTL();

                const fnField = screen.getByRole('textbox', { name: `${LABEL_FIRST_NAME} ${LABEL_ASTERISK}` });
                const lnField = screen.getByRole('textbox', { name: `${LABEL_LAST_NAME} ${LABEL_ASTERISK}` });
                const dobField = screen.getByRole('textbox', { name: `${LABEL_DOB} ${LABEL_ASTERISK}` });
                const submitButton = screen.getByRole('button', { name: BTN_SEARCH });

                await userEvent.type(fnField, formData.firstName);
                await userEvent.type(lnField, formData.lastName);
                await userEvent.type(dobField, formData.dateOfBirth);

                userEvent.click(submitButton);

                await waitFor(() => {
                    expect(store.getActions()).toContainEqual(customerSearchRequest({ ...formData }));
                });

                // await waitFor(() => {
                //     expect(store.getActions()).toContainEqual(customerSearchFailure(customerSearchSuccessResponse));
                // });

                // see results
                // await waitFor(() => {
                //     expect(screen.getAllByRole('row')).toHaveLength(4);
                // });
                // click on a result

                // expect 2 more requests to be made

                // expect(screen.getByText(VerificationConstants.VERIFYING_SECURITY)).toBeInTheDocument();
                // expect(screen.getByText(VerificationConstants.VERIFICATION_MESSAGE)).toBeInTheDocument();
                // expect(screen.getByText(`${VerificationConstants.VERIFICATION_SSN}: 6789`)).toBeInTheDocument();
                // expect(screen.getByRole('button', { name: VerificationConstants.VERIFICATION_SKIP_BTN })).toBeInTheDocument();
                // userEvent.click(screen.getByRole('button', { name: VerificationConstants.VERIFICATION_VERIFY_BTN }));

                // await waitFor(() => {
                //     expect(store.getActions()).toContainEqual(createMemoRequest({
                //         memoText: 'Customer Verification Completed',
                //         productEnrollmentId: 'PEID'
                //     }));
                // });

                // expect(screen.getByRole('heading', { name: 'ITP Information' })).toBeInTheDocument();
            });

            test('Submitting form fields dispatches request, user can skip verifying customer information, and then see users info', async () => {
                Object.defineProperty(allToggles, 'toggles', {
                    value: {
                        [toggleNames.SHOW_PEID_OR_SUBSCRIBERID]: true
                    }
                });
                setupRTL();

                const fnField = screen.getByRole('textbox', { name: `${LABEL_FIRST_NAME} ${LABEL_ASTERISK}` });
                const lnField = screen.getByRole('textbox', { name: `${LABEL_LAST_NAME} ${LABEL_ASTERISK}` });
                const dobField = screen.getByRole('textbox', { name: `${LABEL_DOB} ${LABEL_ASTERISK}` });
                const submitButton = screen.getByRole('button', { name: BTN_SEARCH });

                await userEvent.type(fnField, formData.firstName);
                await userEvent.type(lnField, formData.lastName);
                await userEvent.type(dobField, formData.dateOfBirth);

                userEvent.click(submitButton);

                const actions = store.getActions();

                await waitFor(() => {
                    expect(actions).toContainEqual(customerSearchRequest({ ...formData }));
                });

                // expect(screen.getByText(VerificationConstants.VERIFYING_SECURITY)).toBeInTheDocument();
                // expect(screen.getByText(VerificationConstants.VERIFICATION_MESSAGE)).toBeInTheDocument();
                // expect(screen.getByText(`${VerificationConstants.VERIFICATION_SSN}: 6789`)).toBeInTheDocument();
                // expect(screen.getByRole('button', { name: VerificationConstants.VERIFICATION_VERIFY_BTN })).toBeInTheDocument();
                // userEvent.click(screen.getByRole('button', { name: VerificationConstants.VERIFICATION_SKIP_BTN }));

                // await waitFor(() => {
                //     expect(actions).toContainEqual(createMemoRequest({
                //         memoText: 'Customer Verification Skipped',
                //         productEnrollmentId: 'PEID'
                //     }));
                // });

                // expect(screen.getByRole('heading', { name: 'ITP Information' })).toBeInTheDocument();
            });
        });
    });
});