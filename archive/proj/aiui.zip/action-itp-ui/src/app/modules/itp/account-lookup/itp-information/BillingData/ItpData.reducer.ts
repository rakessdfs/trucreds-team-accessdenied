import { IApiState } from '../../../../../common/types';
import { RESET_DATA } from '../../AccountLookup/AccountLookupConstants';
import { IMembershipState, TMembershipAction } from './MembershipState.types';
import { ITP_ENROLLMENT_FAILURE, ITP_ENROLLMENT_REQUEST, ITP_ENROLLMENT_SUCCESS } from './ItpDataConstants';

export const initialState: IApiState<IMembershipState> = {
    error: null,
    isFetching: false,
    data: null
};

export const itpDataReducer = (state = initialState, action: TMembershipAction): IApiState<IMembershipState> => {
    switch (action.type) {
        case ITP_ENROLLMENT_REQUEST:
            return {
                ...state,
                isFetching: true,
                data: null,
                error: null
            };
        case ITP_ENROLLMENT_SUCCESS:
            return {
                ...state,
                isFetching: false,
                data: {
                    ...action.payload
                },
                error: null
            };
        case ITP_ENROLLMENT_FAILURE:
            return {
                ...state,
                isFetching: false,
                data: null,
                error: action.payload
            };
        case RESET_DATA:
            return {
                ...state,
                data: null,
                isFetching: false,
                error: null
            };
        default:
            return state;
    }
};