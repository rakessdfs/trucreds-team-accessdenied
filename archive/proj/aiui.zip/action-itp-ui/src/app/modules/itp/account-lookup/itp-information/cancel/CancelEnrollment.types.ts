import { IReduxError } from '../../../../../common/types';

export interface ICancelEnrollmentSuccessAction {
    type: 'CANCEL_ENROLLMENT_SUCCESS';
}

export interface ICancelEnrollmentFailureAction {
    type: 'CANCEL_ENROLLMENT_FAILURE';
    payload: IReduxError;
}

export interface ICancelEnrollmentResetAction {
    type: 'CANCEL_ENROLLMENT_RESET_DATA';
}

export type TCancelEnrollmentAction = ICancelEnrollmentSuccessAction | ICancelEnrollmentFailureAction | ICancelEnrollmentResetAction;