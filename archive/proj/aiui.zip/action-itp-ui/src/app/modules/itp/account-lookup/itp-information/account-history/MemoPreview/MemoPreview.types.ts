import { IReduxError } from '../../../../../../common/types';
export interface IMemoData {
   allMemos: IMemoGroup[];
}

export interface IMemoGroup {
    month: string;
    memos: IMemo[];
}

export interface IMemoResponse {
    memosList: IMemoResponseData[];
}

export interface IMemoResponseData {
    memoId: ULongRange;
    productEnrollmentId: string;
    memoText: string;
    createAgentId: string;
    createTs: string;
    updateAgentId: string;
    updateTs: string;
}

export interface IMemo {
    'CREATE_MONTH': string;
    'CREATE_DATE': string;
    'CREATE_TIME': string;
    'CREATE_AGENT_ID': string;
    'MEMO_TEXT': string;
}

export interface IFetchMemoRequest {
    productEnrollmentId: string | number;
}

export interface IFetchMemoRequestAction {
    type: 'FETCH_MEMO_REQUEST';
    payload: IFetchMemoRequest;
}

export interface IFetchMemoSuccessAction {
    type: 'FETCH_MEMO_SUCCESS';
    payload: IMemoData;
}

export interface IFetchMemoFailureAction {
    type: 'FETCH_MEMO_FAILURE';
    payload: IReduxError;
}

export interface IFetchMemoState {
    memoData: IMemoData | null;
}

export interface IResetData {
    type: 'RESET_DATA';
}

export type TFetchMemoAction = IFetchMemoRequestAction | IFetchMemoFailureAction | IFetchMemoSuccessAction | IResetData;