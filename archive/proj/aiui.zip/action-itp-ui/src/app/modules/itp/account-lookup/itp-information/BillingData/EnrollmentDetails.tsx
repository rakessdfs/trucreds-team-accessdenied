import React, { ReactElement } from 'react';
import { useSelector } from 'react-redux';
import { IReduxState } from '../../../../../store/Store.types';
import * as EnrollmentDetailsConstants from '../ItpInformationConstants';
import * as ITPConstants from '../../../../../common/constants/ITPConstants';
import './ItpDataComponent.scss';
import { CircularSpinner } from '../../../../../common/Components/CircularSpinner/CircularSpinner';
import { ErrorSection } from '../../AccountLookup/ErrorSection';
import { errorHandling } from '../../../../../common/utils/ITPUtils';
import { IMembershipState } from './MembershipState.types';

export const EnrollmentDetails = (): ReactElement | null => {
    const { data, error, isFetching } = useSelector((state: IReduxState) => state.itpEnrollmentData);

    if (isFetching) {
        return <CircularSpinner isButton={false} />;
    } else if (error) {
        return (
            <ErrorSection errors={errorHandling(undefined, false, false,
                false, [error])}
            />
        );
    } else if (!data) {
        return null;
    } else {
        const { subscriberNumber, cancellationDate, cancellationRequestDate, cancellationReason, enrollmentDate,
            enrollmentFailedReason, enrollmentStatus, customerType } = (data as IMembershipState);
        return (
            <div className='enrollmentDetailsSection'>
                <h3 className='enrollmentDetailsHeader'>{EnrollmentDetailsConstants.ENROLLMENT_DETAILS}</h3>
                <section>
                    <div className='enrollmentDetailsRow'>
                        <p className='enrollmentDetailsHData'>{EnrollmentDetailsConstants.SUBSCRIBER_NUMBER}</p>
                        <p
                            className='enrollmentDetailsData'
                            data-testid='subscriber-data'
                        >{subscriberNumber || EnrollmentDetailsConstants.NO_DATA_DASH}</p>
                    </div>
                </section>
                <section>
                    <div className='enrollmentDetailsRow'>
                        <p className='enrollmentDetailsHData'>{EnrollmentDetailsConstants.ENROLLMENT_DATE}</p>
                        <p
                            className='enrollmentDetailsData'
                            data-testid='enrollment-date'
                        >{enrollmentDate || EnrollmentDetailsConstants.NO_DATA_DASH}</p>
                    </div>
                </section>
                <section>
                    <div className='enrollmentDetailsRow'>
                        <p className='enrollmentDetailsHData'>{EnrollmentDetailsConstants.STATUS}</p>
                        <p
                            className='enrollmentDetailsData'
                            data-testid='enrollment-status'
                        >{enrollmentStatus || EnrollmentDetailsConstants.NO_DATA_DASH}</p>
                    </div>
                </section>
                <section>
                    <div className='enrollmentDetailsRow'>
                        <p className='enrollmentDetailsHData'>{EnrollmentDetailsConstants.ENROLLED_FAIL_REASON}</p>
                        <p
                            className='enrollmentDetailsData'
                            data-testid='enrollment-failreason'
                        >{enrollmentFailedReason || EnrollmentDetailsConstants.NO_DATA_DASH}</p>
                    </div>
                </section>
                <section>
                    <div className='enrollmentDetailsRow'>
                        <p className='enrollmentDetailsHData'>{EnrollmentDetailsConstants.CANCELLATION_DATE}</p>
                        <p
                            className='enrollmentDetailsData'
                            data-testid='cancellation-date'
                        >{cancellationDate || EnrollmentDetailsConstants.NO_DATA_DASH}</p>
                    </div>
                </section>
                <section>
                    <div className='enrollmentDetailsRow'>
                        <p className='enrollmentDetailsHData'>{EnrollmentDetailsConstants.CANCELLATION_REQUEST_DATE}</p>
                        <p
                            className='enrollmentDetailsData'
                            data-testid='cancellation-request-date'
                        >{cancellationRequestDate || EnrollmentDetailsConstants.NO_DATA_DASH}</p>
                    </div>
                </section>
                { (customerType === ITPConstants.ITP_BM || customerType === ITPConstants.ITP_BM_FREE) &&
                    <section>
                        <div className='enrollmentDetailsRow'>
                            <p className='enrollmentDetailsHData'>{EnrollmentDetailsConstants.CANCELLATION_REASON}</p>
                            <p
                                className='enrollmentDetailsData'
                                data-testid='cancellation-reason'
                            >{cancellationReason || EnrollmentDetailsConstants.NO_DATA_DASH}</p>
                        </div>
                    </section>
                }
            </div>
        );
    }
};