import React, { ReactElement } from 'react';
import { useSelector } from 'react-redux';
import { Box, Flex } from 'reflexbox';
import { IReduxState } from '../../../store/Store.types';
import { IPiiState } from '../account-lookup/AccountLookup/AccountLookup.types';
import './CustomerPIIComponent.scss';
import { CircularSpinner } from '../../../common/Components/CircularSpinner/CircularSpinner';
import * as CONSTANTS from '../../../common/constants/ITPConstants';

export const CustomerPII = (): ReactElement | null => {
    const { data, error, isFetching } = useSelector((state: IReduxState) => state.pii);
    const { data: itpData } = useSelector((state: IReduxState) => state.itpEnrollmentData);

    if (isFetching) {
        return <CircularSpinner isButton={false} />;
    } else if (error) {
        return <p>{error.message.join(', ')}</p>;
    } else if (!data) {
        return null;
    }
    const { firstName, lastName, ssn, email, addressLine1, addressLine2, primaryPhone, dateOfBirth } = (data as IPiiState);
    const enrollmentDate = itpData?.enrollmentDate;
    const productEnrollmentId = itpData?.productEnrollmentId;
    const customerType = itpData?.customerType;
    const standingCode = itpData?.standingCode;

    let customerTypeText = CONSTANTS.BM_CUSTOMER_TEXT;
    if (customerType === CONSTANTS.ITP_BM_FREE && standingCode === CONSTANTS.PENDING_ENROLLMENT_CODE) {
        customerTypeText = CONSTANTS.BM_CUSTOMER_PENDING_PAYMENT;
    } else if (customerType === CONSTANTS.ITP_FF) {
        customerTypeText = '';
    }

    return (
        <Flex className='flex-container wrap'>
            <div className='item'>
                <Box
                    id='peid-id'
                    pt={10}
                >
                    <Flex>
                        <Box p={2}>
                            <p className='peid'>{productEnrollmentId}</p>
                        </Box>
                    </Flex>
                </Box>
            </div>

            <div className='item'>
                <Box
                    id='name-id'
                    pt={10}
                >
                    <Flex>
                        <Box p={2}>
                            <p className='name'>{firstName}</p>
                            <p className='name'>{lastName}</p>
                        </Box>
                    </Flex>
                    <Flex>
                        <Box>
                            <p className='left-pad enrollment-date'>{customerTypeText}</p>
                            <p className='left-pad enrollment-date'>Opened: {enrollmentDate}</p>
                        </Box>
                    </Flex>
                </Box>
            </div>

            <div className='item'>
                <Box
                    id='address-id'
                    pt={10}
                >
                    <Flex>
                        <Box p={2}>
                            <p className='menu-header'>ADDRESS</p>
                            <p
                                data-testid='address-text'
                                className='addressLineHeight'
                            >{addressLine1?.trim() === '' ? CONSTANTS.NOT_AVAILABLE : addressLine1 }</p>
                            <p>{addressLine2?.trim() === '' ? '' : addressLine2}</p>
                        </Box>
                    </Flex>
                </Box>
            </div>

            <div className='item'>
                <Box
                    id='primary-ph-id'
                    pt={10}
                >
                    <Flex>
                        <Box p={2}>
                            <p className='menu-header'>PRIMARY PHONE</p>
                            <p data-testid='phone-text'>{primaryPhone?.trim() === '' ? CONSTANTS.NOT_AVAILABLE : primaryPhone}</p>
                        </Box>
                    </Flex>
                </Box>
            </div>

            <div className='item'>
                <Box
                    id='email-id'
                    pt={10}
                >
                    <Flex>
                        <Box p={2}>
                            <p className='menu-header'>EMAIL</p>
                            <p data-testid='email-text'>{email?.trim() === '' ? CONSTANTS.NOT_AVAILABLE : email}</p>
                        </Box>
                    </Flex>
                </Box>
            </div>

            <div className='item'>
                <Box
                    id='dob-id'
                    pt={10}
                >
                    <Flex>
                        <Box p={2}>
                            <p className='menu-header'>DATE OF BIRTH</p>
                            <p>{dateOfBirth}</p>
                        </Box>
                    </Flex>
                </Box>
            </div>

            <div className='item'>
                <Box
                    id='email-id'
                    pt={10}
                >
                    <Flex>
                        <Box p={2}>
                            <p className='menu-header'>SSN</p>
                            <p>{ssn}</p>
                        </Box>
                    </Flex>
                </Box>
            </div>
        </Flex>
    );
};