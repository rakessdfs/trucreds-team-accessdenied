export const FETCH_MEMO_SUCCESS = 'FETCH_MEMO_SUCCESS';
export const FETCH_MEMO_REQUEST = 'FETCH_MEMO_REQUEST';
export const FETCH_MEMO_FAILURE = 'FETCH_MEMO_FAILURE';
export const DATE_FORMAT = 'MM/DD/YY';
export const HOUR_FORMAT = 'hh:mm:ss a';
export const MONTH_YEAR_FORMAT = 'MMMM YYYY';