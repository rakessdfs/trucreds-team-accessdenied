import React, { ReactElement } from 'react';
import { IMemoGroup } from './MemoPreview.types';
import { MemoPreview } from './MemoPreview';
import styles from './MemoPreviewGroup.module.scss';

export const MemoPreviewGroup = ({ month, memos }: IMemoGroup): ReactElement => {
    return (
        <div className={styles.memoPreviewGroupContainer}>
            <p className={styles.previewGroupHeader}>{month}</p>
            <>
                {memos.map((memo) => (
                    <MemoPreview
                        memo={memo}
                        key={memo.CREATE_TIME}
                    />
                ))}
            </>
        </div>
    );
};