import React, { ReactElement } from 'react';
import './NonCriticalError.scss';
import { X_BUTTON } from './CancelConstants';

interface INonCriticalErrorProps {
    header: string;
    subHeader: string;
    onXButtonClick: () => void;
}

export const NonCriticalError = ({ header, subHeader, onXButtonClick }: INonCriticalErrorProps): ReactElement => {
    return (
        <div className='nonCriticalErrorContainer'>
            <div className='nonCriticalErrorTextContainer'>
                <p className='nonCriticalHeader'>{header}</p>
                <p className='nonCriticalSubHeader'>{subHeader}</p>
            </div>
            <div className='dividerContainer'>
                <div className='divider'>
                </div>
            </div>
            <div className='xButtonContainer'>
                <button
                    className='xButton'
                    data-testid='x-button'
                    onClick={(): void => onXButtonClick()}
                    onKeyDown={(): void => onXButtonClick()}
                    tabIndex={0}
                >
                    {X_BUTTON}
                </button>
            </div>
        </div>
    );
};