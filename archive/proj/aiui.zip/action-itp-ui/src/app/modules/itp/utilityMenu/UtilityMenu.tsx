import React, { ReactElement, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import './UtilityMenu.scss';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from '../../../common/Components/Buttons/Button';
import {
    BLANKSTRING, BTN_POST_MEMO,
    CANCELLATION,
    ENROLLMENT,
    GENERAL_SERVICING,
    MAX_MANUAL_MEMO_TEXT_SIZE,
    TRANSFER_TO_ECS
} from '../../../common/constants/ITPConstants';
import { IReduxState } from '../../../store/Store.types';
import { CircularSpinner } from '../../../common/Components/CircularSpinner/CircularSpinner';
import { ErrorSection } from '../account-lookup/AccountLookup/ErrorSection';
import { errorHandling } from '../../../common/utils/ITPUtils';
import { attemptCreateMemoRequest } from './UtilityMenu.actions';
import { overAllMemoText, validateMemoTextLength } from './UtilityMenuUtils';
import { MEMO_SUCCESS, PEID_UNDEFINED, NEW_MEMO_TITLE } from './UtilityMenuContants';

export const UtilityMenu = (): ReactElement | null => {
    const { handleSubmit } = useForm({
        mode: 'onSubmit',
        reValidateMode: 'onSubmit'
    });
    const dispatch = useDispatch();
    const { data } = useSelector((state: IReduxState) => state.itpEnrollmentData);
    const { data: createMemoData, error: createMemoError, isFetching } = useSelector((state: IReduxState) => state.createMemo);
    const peid = data?.productEnrollmentId;

    const [isEnrollmentCheck, setIsEnrollmentCheck] = useState(false);
    const [isCancellationCheck, setIsCancellationCheck] = useState(false);
    const [isGeneralServicingCheck, setIsGeneralServicingCheck] = useState(false);
    const [isTransferToEcsCheck, setIsTransferToEcsCheck] = useState(false);
    const [isCommentsCheck, setIsCommentsCheck] = useState(false);
    const [manualMemoText, setManualMemoText] = useState('');
    const [isMemoUndefined, setIsMemoUndefined] = useState(false);

    const [shouldShowMemoPostConfirmationAlert, setShouldShowMemoPostConfirmationAlert] = useState(false);
    const [shouldShowMemoErrorAlert, setShouldShowMemoErrorAlert] = useState(false);

    const wasMemoCreatedSuccessfully = createMemoData?.createdSuccessfully;

    useEffect(() => {
        if (wasMemoCreatedSuccessfully) {
            setShouldShowMemoPostConfirmationAlert(true);
            setTimeout(() => setShouldShowMemoPostConfirmationAlert(false), 5000);
        }
    }, [wasMemoCreatedSuccessfully]);

    useEffect(() => {
        if (createMemoError) {
            setShouldShowMemoErrorAlert(true);
            setTimeout(() => setShouldShowMemoErrorAlert(false), 5000);
        }
    }, [createMemoError]);

    const onSubmit = (): void => {
        if (typeof (peid) !== undefined) {
            const finalMemoText = overAllMemoText({
                isEnrollmentCheck,
                isCancellationCheck,
                isGeneralServicingCheck,
                isTransferToEcsCheck,
                isCommentsCheck,
                manualMemoText
            });

            if (validateMemoTextLength(finalMemoText)) {
                dispatch(attemptCreateMemoRequest(finalMemoText));
                setIsEnrollmentCheck(false);
                setIsCancellationCheck(false);
                setIsGeneralServicingCheck(false);
                setIsTransferToEcsCheck(false);
                setIsCommentsCheck(false);
                setManualMemoText(BLANKSTRING);
            } else {
                setIsMemoUndefined(true);
            }
        } else {
            setIsMemoUndefined(true);
        }
    };

    const clearErrorMsg = (): void => {
        setIsMemoUndefined(false);
    };

    return (
        <form onSubmit={handleSubmit(onSubmit)}>
            <div className='flex-container wrap'>
                <h3 className='newMemoTitle'>{NEW_MEMO_TITLE}</h3>
                {isMemoUndefined && (
                    <p
                        className='errorMessage'
                        data-testid='undefined-tag'
                    >
                        {PEID_UNDEFINED}
                    </p>
                )}
                {shouldShowMemoErrorAlert && (
                    <ErrorSection errors={errorHandling(undefined, false, false,
                        false, [createMemoError])}
                    />
                )}
                {shouldShowMemoPostConfirmationAlert && (
                    <p
                        className='successMessage'
                        data-testid='success-tag'
                    >
                        {MEMO_SUCCESS}
                    </p>
                )}
                <div className='checkboxMemo'>
                    <div className='checkboxMemoData'>
                        <input
                            data-testid='enrollmentCheckbox'
                            className='checkboxMemoDataInput'
                            value='Enrollment'
                            type='checkbox'
                            checked= { isEnrollmentCheck }
                            onChange= { (): void => {
                                clearErrorMsg();
                                setIsEnrollmentCheck(!isEnrollmentCheck);
                            } }
                        />{ENROLLMENT}
                    </div>
                    <div className='checkboxMemoData'>
                        <input
                            data-testid='cancellationCheckbox'
                            className='checkboxMemoDataInput'
                            value='Cancellation'
                            type='checkbox'
                            checked= { isCancellationCheck }
                            onChange= { (): void => {
                                clearErrorMsg();
                                setIsCancellationCheck(!isCancellationCheck);
                            } }
                        />{CANCELLATION}
                    </div>
                    <div className='checkboxMemoData'>
                        <input
                            data-testid='generalServicingCheckbox'
                            className='checkboxMemoDataInput'
                            value='GeneralServicing'
                            type='checkbox'
                            checked= { isGeneralServicingCheck }
                            onChange= { (): void => {
                                clearErrorMsg();
                                setIsGeneralServicingCheck(!isGeneralServicingCheck);
                            } }
                        />{GENERAL_SERVICING}
                    </div>
                    <div className='checkboxMemoData'>
                        <input
                            data-testid='transferToEcsCheckbox'
                            className='checkboxMemoDataInput'
                            value='TransferToECS'
                            type='checkbox'
                            checked= { isTransferToEcsCheck }
                            onChange= { (): void => {
                                clearErrorMsg();
                                setIsTransferToEcsCheck(!isTransferToEcsCheck);
                            } }
                        />{TRANSFER_TO_ECS}
                    </div>
                    <div className='checkboxMemoData'>
                        <input
                            data-testid='commentsCheckbox'
                            className='checkboxMemoDataInput'
                            type='checkbox'
                            checked= { isCommentsCheck }
                            onChange= { (): void => {
                                clearErrorMsg();
                                setIsCommentsCheck(!isCommentsCheck);
                            } }
                        />
                        <textarea
                            className='manualMemoDataInput'
                            data-testid='manualMemoDataInput'
                            placeholder='Manual memo'
                            maxLength={MAX_MANUAL_MEMO_TEXT_SIZE}
                            value= {manualMemoText}
                            onChange={(e): void => {
                                clearErrorMsg();
                                setManualMemoText(e.target.value);
                            }}
                        />
                    </div>
                    <div className='postMemoSection'>
                        <div className='postMemoAlign'>
                            <Button className='postMemoButton'>{BTN_POST_MEMO}</Button>
                            { isFetching && <CircularSpinner /> }
                        </div>
                    </div>
                </div>
            </div>
        </form>
    );
};