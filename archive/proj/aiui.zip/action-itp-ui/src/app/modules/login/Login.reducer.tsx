import { LOGIN_SUCCESS, LOGIN_REQUEST, LOGIN_FAILURE, LOGOUT } from '../../common/constants/ITPConstants';
import { IApiState } from '../../common/types';
import { TLoginAction, IUserState } from './Login.types';

export const initialState: IApiState<IUserState> = {
    error: null,
    isFetching: false,
    data: null
};

export const userReducer = (state = initialState, action: TLoginAction): IApiState<IUserState> => {
    switch (action.type) {
        case LOGIN_REQUEST:
            return {
                ...state,
                isFetching: true,
                data: null,
                error: null
            };
        case LOGIN_SUCCESS:
            return {
                ...state,
                isFetching: false,
                data: {
                    isAuthenticated: true,
                    fullName: action.payload.fullName,
                    email: action.payload.email,
                    userName: action.payload.userName
                },
                error: null
            };
        case LOGIN_FAILURE:
            return {
                ...state,
                isFetching: false,
                data: null,
                error: action.payload
            };
        case LOGOUT:
            return {
                ...state,
                data: null,
                isFetching: false,
                error: action.payload
            };
        default:
            return state;
    }
};