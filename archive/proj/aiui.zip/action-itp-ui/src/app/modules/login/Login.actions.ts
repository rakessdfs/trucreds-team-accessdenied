import axios from 'axios';
import { Dispatch } from 'redux';
import {
    LOGIN_FAILURE,
    LOGIN_REQUEST,
    LOGIN_SUCCESS, LOGOUT,
    URL_ACTION_ITP_API_HOSTNAME,
    URL_ACTION_ITP_API_HOSTNAME_LOCAL,
    URL_ACTION_ITP_LOGIN_API_CONTEXT
} from '../../common/constants/ITPConstants';
import { validateResponse } from '../../common/utils/ITPUtils';
import { IReduxError } from '../../common/types';
import { resetData } from '../itp/account-lookup/AccountLookup/CustomerPII.actions';
import {
    ILoginFailureAction,
    ILoginFailureMessageAction,
    ILoginRequestAction,
    ILoginResponse,
    ILoginSuccessAction, ILogoutAction
} from './Login.types';
import { setAuthCookie, removeAuthCookie } from './LoginUtils';

export const loginSuccess = ({ fullName, email, userName }: ILoginResponse): ILoginSuccessAction => ({
    type: LOGIN_SUCCESS,
    payload: {
        fullName,
        email,
        userName
    }
});

export const loginRequest = (): ILoginRequestAction => ({
    type: LOGIN_REQUEST
});

export const loginFailure = (error: IReduxError): ILoginFailureAction => ({
    type: LOGIN_FAILURE,
    payload: error
});

export const logout = (error: IReduxError): ILogoutAction => ({
    type: LOGOUT,
    payload: error
});

export const loginFailureMessage = (error: string): ILoginFailureMessageAction => ({
    type: LOGIN_FAILURE,
    payload: {
        error
    }
});

export const attemptLogout = (error: IReduxError) => {
    return (dispatch: Dispatch): void => {
        removeAuthCookie();
        dispatch(resetData());
        dispatch(logout(error));
    };
};

export const attemptLogin = (racf: string, psswd: string) => {
    return async (dispatch: Dispatch): Promise<void> => {
        dispatch(loginRequest());

        let response;

        try {
            response = await axios({
                method: 'post',
                url: (URL_ACTION_ITP_API_HOSTNAME || URL_ACTION_ITP_API_HOSTNAME_LOCAL) + URL_ACTION_ITP_LOGIN_API_CONTEXT,
                data: {
                    racf,
                    psswd
                }
            });
            setAuthCookie(response?.headers);
        } catch (e) {
            dispatch(loginFailure(validateResponse(e.response, 'User') as IReduxError));
            return;
        }
        dispatch(loginSuccess(response?.data));
    };
};