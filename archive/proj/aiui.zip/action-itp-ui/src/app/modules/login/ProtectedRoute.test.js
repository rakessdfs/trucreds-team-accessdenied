import React from 'react';
import thunk from 'redux-thunk';
import { screen } from '@testing-library/react';
import setupMockStore from 'redux-mock-store';
import { renderContainer } from '../../common/utils/test-utils';
import { ProtectedRoute } from './ProtectedRoute';

describe('ProtectedRoute', () => {
    let store, initialState, testComponent;

    beforeEach(() => {
        initialState = {
            user: {
                data: {
                    isAuthenticated: true
                }
            }
        };
    });

    const setupRTL = () => {
        store = setupMockStore([thunk])(initialState);
        testComponent = () => <h1>Hello Test</h1>;
        return renderContainer(
            <ProtectedRoute
                component={testComponent}
                path='/'
            />,
            {
                store
            }
        );
    };

    describe('Handles authenticated path', () => {
        test('Renders component from prop when authenticated', () => {
            setupRTL();
            expect(screen.getByRole('heading', { name: /Hello Test/ })).toBeInTheDocument();
        });
    });
});