import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { loginSuccess as loginSuccessResponse } from '../../../msw/responses/login/loginResponses';
import {
    INTERNAL_SERVER_ERROR,
    LOGIN_FAILURE,
    LOGIN_REQUEST,
    LOGIN_SUCCESS,
    LOGOUT
} from '../../common/constants/ITPConstants';
import { resetData } from '../itp/account-lookup/AccountLookup/CustomerPII.actions';
import {
    attemptLogin,
    loginFailure,
    loginFailureMessage,
    loginRequest,
    loginSuccess,
    logout,
    attemptLogout
} from './Login.actions';

describe('loginActions', () => {
    test('loginSuccess', () => {
        const data = {
            userName: 'user',
            email: 'example@d.com',
            fullName: 'user user'
        };

        const result = loginSuccess(data);
        expect(result).toEqual({
            type: LOGIN_SUCCESS,
            payload: {
                ...data
            }
        });
    });

    test('loginRequest', () => {
        expect(loginRequest()).toEqual({
            type: LOGIN_REQUEST
        });
    });

    test('loginFailure', () => {
        const error = 'error';
        expect(loginFailure(error)).toEqual({
            type: LOGIN_FAILURE,
            payload: error
        });
    });

    test('loginFailureMessage', () => {
        const error = 'error';
        expect(loginFailureMessage(error)).toEqual({
            type: LOGIN_FAILURE,
            payload: {
                error
            }
        });
    });

    test('logout', () => {
        const error = {
            message: [],
            cause: []
        };
        expect(logout(error)).toEqual({
            type: LOGOUT,
            payload: error
        });
    });

    describe('attemptLogout', () => {
        const middleware = [thunk];
        const mockStore = configureMockStore(middleware);
        let store, error;

        beforeEach(() => {
            store = mockStore({});
            jest.resetAllMocks();
            error = {
                message: [],
                cause: []
            };
            const cookie = 'auth-token=jwt-token';
            document.cookie = cookie;
        });

        test('test logout attempt', () => {
            store.dispatch(attemptLogout(error));
            const actions = store.getActions();

            expect(actions[0]).toEqual(resetData());
            expect(actions[1]).toEqual(logout(error));
            expect(document.cookie
                .split(';')
                .find((row) => row.startsWith('auth-token')))
                .toBeUndefined();
        });
    });

    describe('attemptLogin', () => {
        const middleware = [thunk];
        const mockStore = configureMockStore(middleware);
        let store, data;

        beforeEach(() => {
            store = mockStore({});
            jest.resetAllMocks();
            data = {
                racf: 'batman1',
                psswd: 'somePsswd'
            };
        });

        test('handles 200 success path', async () => {
            await store.dispatch(attemptLogin('itp', data.psswd));
            const actions = store.getActions();

            const tokenValue = document.cookie
                .split('; ')
                .find((row) => row.startsWith('auth-token'))
                .split('=')[1];

            expect(actions[0]).toEqual(loginRequest());
            expect(actions[1]).toEqual(loginSuccess(loginSuccessResponse));
            expect(tokenValue).toEqual('jwt-token');
        });

        test('handles invalid username or psswrd input (401)', async () => {
            await store.dispatch(attemptLogin('notReal', 'notReal'));
            const actions = store.getActions();
            expect(actions[1]).toEqual(loginFailure({
                cause: ['1009'],
                message: []
            }));
        });

        test('handles failure path (500)', async () => {
            await store.dispatch(attemptLogin('mockFail', data.psswd));
            const actions = store.getActions();

            expect(actions[0]).toEqual(loginRequest());
            expect(actions[1]).toEqual(loginFailure({
                cause: [INTERNAL_SERVER_ERROR],
                message: [INTERNAL_SERVER_ERROR]
            }));
        });
    });
});