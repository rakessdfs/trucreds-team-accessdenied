import Cookies from 'universal-cookie';
import * as ITPConstants from '../../common/constants/ITPConstants';
import { IAuthorizationCookieHeader } from './Login.types';

export const isValidLoginAttempt = (username: string, password: string): boolean => {
    return !(username === ITPConstants.BLANKSTRING || password === ITPConstants.BLANKSTRING || username.trim().length <= 0 || password.trim().length <= 0);
};

export const actionItpApiErrors = (status: number): string => {
    if (status === ITPConstants.RESPONSE_BAD_REQUEST_STATUS) {
        return ITPConstants.ERROR_MSG_INPUTS_BLANK;
    } else if (status === ITPConstants.RESPONSE_UNAUTHORISED_STATUS) {
        return ITPConstants.ERROR_MSG_INVALID_CREDENTIALS;
    } else if (status === ITPConstants.RESPONSE_INTERNAL_SERVER_ERROR_STATUS) {
        return ITPConstants.ERROR_MSG_SERVER_UNAVAILABLE;
    } else {
        return ITPConstants.ERROR_MSG_SOMETHING_WENT_WRONG;
    }
};

export const extractAuthHeader = (headers: IAuthorizationCookieHeader): string => {
    return headers?.authorization || '';
};

export const setAuthCookie = (headers: IAuthorizationCookieHeader): void => {
    const cookies = new Cookies();
    const authHeader = extractAuthHeader(headers);
    cookies.set('auth-token', authHeader, { path: '/' });
};

export const removeAuthCookie = (): void => {
    const cookies = new Cookies();
    cookies.remove('auth-token');
};

export const getAuthCookie = (): string => {
    const cookies = new Cookies();
    return cookies.get('auth-token');
};