/* eslint-disable import/no-extraneous-dependencies */
import { waitFor } from '@testing-library/dom';
import userEvent from '@testing-library/user-event';
import React from 'react';
import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { fireEvent, screen } from '@testing-library/react';
import { renderContainer } from '../../common/utils/test-utils';
import { loginSuccess as loginSuccessResponse } from '../../../msw/responses/login/loginResponses';
import {
    INTERNAL_SERVER_ERROR,
    INVALID_DOB,
    BLANKSTRING,
    TXT_PLACEHOLDER_USER_NAME, TXT_PLACEHOLDER_USER_PASSWORD, BTN_LOGIN, ERROR_MSG_INPUTS_BLANK, ACTION_ITP
} from '../../common/constants/ITPConstants';
import { loginFailure, loginRequest, loginSuccess } from './Login.actions';
import { Login } from './LoginComponent';

describe('LoginComponent', () => {
    let initialState, store;

    beforeEach(() => {
        initialState = {
            user: {
                isAuthenticated: false,
                data: null,
                error: null,
                isFetching: false
            }
        };

        jest.resetAllMocks();
    });

    const setupRTL = () => {
        store = configureMockStore([thunk])(initialState);
        return renderContainer(<Login />, { store });
    };

    test('Login component should render with initial value', () => {
        setupRTL();
        expect(screen.getByRole('heading', { name: ACTION_ITP })).toBeInTheDocument();
    });

    test('When username and/or password is not entered, an error message is displayed on login screen', async () => {
        setupRTL();

        fireEvent.change(screen.getByPlaceholderText(TXT_PLACEHOLDER_USER_NAME), {
            target: { value: BLANKSTRING }
        });

        fireEvent.change(screen.getByPlaceholderText(TXT_PLACEHOLDER_USER_PASSWORD), {
            target: { value: BLANKSTRING }
        });

        fireEvent.click(screen.getByRole('button', { name: BTN_LOGIN }));

        const actions = store.getActions();
        await waitFor(() => {
            expect(actions[0]).not.toEqual(loginRequest());
        });

        expect(screen.getByText(ERROR_MSG_INPUTS_BLANK)).toBeInTheDocument();
    });

    test('When invalid username and password are entered, an error message is displayed on login screen, input fields should be cleared', async () => {
        setupRTL();

        await userEvent.type(screen.getByPlaceholderText(TXT_PLACEHOLDER_USER_NAME), 'itpuser1');

        await userEvent.type(screen.getByPlaceholderText(TXT_PLACEHOLDER_USER_PASSWORD), 'discover123456');

        await userEvent.click(screen.getByRole('button', { name: BTN_LOGIN }));
        const actions = store.getActions();
        expect(actions[0]).toEqual(loginRequest());
        await waitFor(() => {
            expect(actions[1]).toEqual(loginFailure({
                cause: ['1009'],
                message: []
            }));
        });
    });

    test('Handles 403 invalid token', async () => {
        setupRTL();

        await userEvent.type(screen.getByPlaceholderText(TXT_PLACEHOLDER_USER_NAME), '403');

        await userEvent.type(screen.getByPlaceholderText(TXT_PLACEHOLDER_USER_PASSWORD), 'discover123456');

        await userEvent.click(screen.getByRole('button', { name: BTN_LOGIN }));
        const actions = store.getActions();
        expect(actions[0]).toEqual(loginRequest());
        await waitFor(() => {
            expect(actions[1]).toEqual(loginFailure({
                cause: [INTERNAL_SERVER_ERROR],
                message: [INTERNAL_SERVER_ERROR]
            }));
        });
    });

    test('When valid username and password are entered, a login request is attempted', async () => {
        setupRTL();

        fireEvent.change(screen.getByPlaceholderText(TXT_PLACEHOLDER_USER_NAME), {
            target: { value: 'itp' }
        });

        fireEvent.change(screen.getByPlaceholderText(TXT_PLACEHOLDER_USER_PASSWORD), {
            target: { value: 'discover123' }
        });

        fireEvent.click(screen.getByRole('button', { name: BTN_LOGIN }));

        const actions = store.getActions();

        expect(actions[0]).toEqual(loginRequest());

        await waitFor(() => {
            expect(actions[1]).toEqual(loginSuccess(loginSuccessResponse));
        });
    });

    test('Displays errors from Redux if present', () => {
        initialState = {
            ...initialState,
            user: {
                ...initialState.user,
                data: null,
                error: {
                    message: [],
                    cause: ['5005', '1002']
                }
            }
        };

        setupRTL();

        expect(screen.getByText(INTERNAL_SERVER_ERROR)).toBeInTheDocument();
        expect(screen.getByText(INVALID_DOB)).toBeInTheDocument();
    });

    test('Fetching state', () => {
        initialState = {
            ...initialState,
            user: {
                ...initialState.user,
                isFetching: true
            }
        };
        setupRTL();
        expect(screen.getByTestId('circularSpinner')).toBeInTheDocument();
    });
});