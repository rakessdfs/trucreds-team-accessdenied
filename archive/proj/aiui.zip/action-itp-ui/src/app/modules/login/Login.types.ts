import { IReduxError } from '../../common/types';

export interface ILoginResponse {
  email: string;
  fullName: string;
  userName: string;
}

export interface ILoginRequestAction {
  type: 'LOGIN_REQUEST';
}

export interface ILoginSuccessAction {
  type: 'LOGIN_SUCCESS';
  payload: ILoginResponse;
}

export interface ILoginFailureAction {
  type: 'LOGIN_FAILURE';
  payload: IReduxError;
}

export interface ILogoutAction {
  type: 'LOGOUT';
  payload: IReduxError;
}

export interface ILoginFailureMessageAction {
  type: 'LOGIN_FAILURE';
  payload: {
    error: string;
  };
}
export interface IUserState {
  isAuthenticated: boolean;
  fullName: string | null;
  email: string | null;
  userName: string | null;
}

export interface IAuthorizationCookieHeader {
  authorization: string;
}

export type TLoginAction = ILoginRequestAction | ILoginFailureAction | ILoginSuccessAction | ILogoutAction;