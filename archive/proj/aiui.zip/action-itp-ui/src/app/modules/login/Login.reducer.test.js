import { buildReduxError } from '../../common/utils/ITPUtils';
import { loginSuccess, loginRequest, loginFailure, logout } from './Login.actions';
import { userReducer, initialState } from './Login.reducer';

describe('userReducer', () => {
    test('sets the initial state', () => {
        expect(
            userReducer(undefined, {
                type: 'RANDOM_TYPE'
            })
        ).toEqual(initialState);
    });

    describe('loginRequest', () => {
        test('sets the state correctly', () => {
            expect(userReducer(initialState, loginRequest())).toEqual({
                ...initialState,
                isFetching: true,
                error: null
            });
        });
    });

    describe('loginSuccess', () => {
        test('sets the new state correctly', () => {
            const successData = {
                fullName: 'user',
                email: 'email',
                userName: 'name'
            };

            expect(
                userReducer(initialState, loginSuccess(successData))
            ).toEqual({
                data: {
                    ...successData,
                    isAuthenticated: true
                },
                isFetching: false,
                error: null
            });
        });
    });

    describe('loginFailure', () => {
        test('sets the state correctly', () => {
            expect(userReducer(initialState, loginFailure(buildReduxError('some custom error', '')))).toEqual({
                ...initialState,
                error: {
                    cause: [''],
                    message: ['some custom error']
                }
            });
        });
    });

    describe('logout', () => {
        test('sets the state correctly', () => {
            expect(userReducer(initialState, logout(buildReduxError('some custom error', '')))).toEqual({
                ...initialState,
                error: {
                    cause: [''],
                    message: ['some custom error']
                }
            });
        });
    });
});