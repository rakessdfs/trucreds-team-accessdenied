import {
    ERROR_MSG_SOMETHING_WENT_WRONG,
    ERROR_MSG_INVALID_CREDENTIALS,
    ERROR_MSG_INPUTS_BLANK,
    ERROR_MSG_SERVER_UNAVAILABLE
} from '../../common/constants/ITPConstants';
import { actionItpApiErrors, extractAuthHeader, getAuthCookie, setAuthCookie, removeAuthCookie } from './LoginUtils';

const deleteAllCookies = () => {
    const cookies = document.cookie.split(';');

    for (let i = 0;i < cookies.length;i++) {
        const cookie = cookies[i];
        const eqPos = cookie.indexOf('=');
        const name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
        document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT`;
    }
};

describe('LoginUtils', () => {
    describe('actionItpApiErrors', () => {
        test('matches 400 response to error message', () => {
            expect(actionItpApiErrors(400)).toEqual(ERROR_MSG_INPUTS_BLANK);
        });

        test('matches 401 response to error message', () => {
            expect(actionItpApiErrors(401)).toEqual(ERROR_MSG_INVALID_CREDENTIALS);
        });

        test('matches 500 response to error message', () => {
            expect(actionItpApiErrors(500)).toEqual(ERROR_MSG_SERVER_UNAVAILABLE);
        });

        test('matches any other response code to general error message', () => {
            expect(actionItpApiErrors(999)).toEqual(ERROR_MSG_SOMETHING_WENT_WRONG);
        });
    });

    describe('AuthCookie', () => {
        let jwtToken;

        beforeEach(() => {
            jwtToken = 'some-jwt-token';
            deleteAllCookies();
        });

        test('sets auth-token cookie from Authorization response headers', () => {
            const headers = { authorization: jwtToken };
            setAuthCookie(headers);
            expect(document.cookie
                .split('; ')
                .find((row) => row.startsWith('auth-token'))
                .split('=')[1]).toEqual(jwtToken);
        });

        test('gets auth-token cookie', () => {
            document.cookie = `auth-token=${jwtToken}`;
            expect(getAuthCookie()).toEqual(jwtToken);
        });

        test('extracts Authorization header value', () => {
            const headers = { authorization: jwtToken };
            expect(extractAuthHeader(headers)).toEqual(jwtToken);
        });

        test('remove auth token cookie', () => {
            document.cookie = `auth-token=${jwtToken}`;
            removeAuthCookie();
            expect(document.cookie
                .split(';')
                .find((row) => row.startsWith('auth-token')))
                .toBeUndefined();
        });
    });
});