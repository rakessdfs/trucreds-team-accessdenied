import React, { ReactElement } from 'react';
import { Redirect, BrowserRouter, Route, Switch } from 'react-router-dom';
import { DashboardComponent } from '../itp/servicing-dashboard/DashboardComponent';
import { Login } from './LoginComponent';
import { ProtectedRoute } from './ProtectedRoute';

export const LoginRouter = (): ReactElement => {
    return (
        <BrowserRouter>
            <Switch>
                <Route
                    exact
                    path='/login'
                >
                    <Login />
                </Route>
                <ProtectedRoute
                    path='/dashboard'
                    component={DashboardComponent}
                />
                <Route path='/'>
                    <Redirect
                        from='/'
                        to='/login'
                    />
                </Route>
            </Switch>
        </BrowserRouter>
    );
};