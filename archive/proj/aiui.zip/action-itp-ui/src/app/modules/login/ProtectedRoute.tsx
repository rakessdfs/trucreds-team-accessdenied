/* eslint-disable react/prop-types */
import React, { ReactElement } from 'react';
import { Route, Redirect, RouteComponentProps } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { IReduxState } from 'src/app/store/Store.types';

type Props = {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  component: React.ComponentType<RouteComponentProps<any>> | React.ComponentType<any>;
  path: string;
};

// eslint-disable-next-line @typescript-eslint/naming-convention
export const ProtectedRoute = ({ component: Component, ...rest }: Props): ReactElement => {
    const isAuthenticated = useSelector(
        (state: IReduxState) => state.user.data?.isAuthenticated
    );

    return (
        <Route
            {...rest}
            render={(props): ReactElement => {
                if (isAuthenticated) {
                    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
                    // @ts-ignore-next-line
                    return <Component {...props} />;
                } else {
                    return (
                        <Redirect
                            to={{
                                pathname: '/login',
                                state: {
                                    // eslint-disable-next-line react/prop-types
                                    from: props.location
                                }
                            }}
                        />
                    );
                }
            }}
        />
    );
};