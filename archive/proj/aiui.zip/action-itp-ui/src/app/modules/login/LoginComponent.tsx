/* eslint-disable jsx-a11y/no-autofocus */
import React, { ReactElement, useState, useRef, useEffect, ChangeEvent } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Redirect } from 'react-router-dom';
import { Flex, Box } from 'reflexbox';
import { ClosableTextInput } from '@action-org/discover-react-ui';
import * as ITPConstants from '../../common/constants/ITPConstants';
import { IReduxState } from '../../store/Store.types';
import { mapMessageToCause } from '../../common/utils/ITPUtils';
import Logo from '../../assets/ActionITPLogo.svg';
import PreUserIcon from '../../assets/username-01.png';
import passwordIcon from '../../assets/password-01.png';
import './Login.scss';
import { CircularSpinner } from '../../common/Components/CircularSpinner/CircularSpinner';
import { isValidLoginAttempt } from './LoginUtils';
import { attemptLogin } from './Login.actions';

export const Login = (): ReactElement => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [isValidateUser, setIsValidateUser] = useState(true);
    const [isError, setError] = useState(true);
    const { data, error, isFetching } = useSelector(
        (state: IReduxState) => state.user
    );

    const inputBoxRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        if (inputBoxRef?.current) {
            inputBoxRef.current.focus();
        }
    }, [error]);

    const dispatch = useDispatch();

    if (data?.isAuthenticated) {
        return <Redirect to='/dashboard' />;
    }

    const submitHandler = (event: React.FormEvent): void => {
        event.preventDefault();
        setIsValidateUser(true);
        setError(true);
        if (!isValidLoginAttempt(username, password)) {
            setIsValidateUser(false);
            setError(false);
        } else {
            dispatch(attemptLogin(username, password));
        }
        setPassword(ITPConstants.BLANKSTRING);
        setUsername(ITPConstants.BLANKSTRING);
    };

    return (
        <div
            id='login-div'
            className='comp-login'
        >

            <form onSubmit={submitHandler}>
                <div className='page-align'>
                    <table className='center'>
                        <tbody>
                            <tr>
                                <td data-testid='logo-id'>
                                    <h1>
                                        <Box className='login-box'>
                                            <Flex className='login-flex'>
                                                <Box
                                                    className='logo-box'
                                                    pb={2}
                                                >
                                                    <img
                                                        className='logo'
                                                        src={Logo}
                                                        alt='Action - ITP'
                                                    />
                                                </Box>
                                            </Flex>
                                        </Box>
                                    </h1>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    {error && isError && (error?.cause?.map((cause) => {
                                        return (
                                            <p
                                                key={cause}
                                                className='error-message'
                                            >
                                                {mapMessageToCause(cause)}
                                            </p>
                                        );
                                    }))}
                                    {!isValidateUser && (
                                        <p className='error-message'>{ITPConstants.ERROR_MSG_INPUTS_BLANK}</p>)
                                    }

                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <table className='center'>
                        <tbody>
                            <tr>

                                <td className='custom-padding'>
                                    <Flex>
                                        <Box>
                                            <ClosableTextInput
                                                autoFocus
                                                iconSrc={PreUserIcon}
                                                type='text'
                                                placeholder='Username'
                                                value={username}
                                                onChange={(event: ChangeEvent<HTMLInputElement>): void => setUsername(event.target.value)}
                                            />
                                        </Box>
                                    </Flex>
                                </td>
                            </tr>
                            <tr>
                                <td className='custom-padding'>
                                    <Flex className='input-flex'>
                                        <Box className='input-box'>
                                            <ClosableTextInput
                                                iconSrc={passwordIcon}
                                                type='password'
                                                placeholder='Password'
                                                value={password}
                                                onChange={(event: ChangeEvent<HTMLInputElement>): void => setPassword(event.target.value)}
                                            />
                                        </Box>
                                    </Flex>
                                </td>
                            </tr>
                            <tr>
                                <td className='center-button'>
                                    <div className='button-spinner-container'>
                                        <Box className='button-box'>
                                            <button
                                                type='submit'
                                                className='primary-button large-button submit-button'
                                                onClick={submitHandler}
                                            >
                                                {ITPConstants.BTN_LOGIN}
                                            </button>
                                            <div className='spinner'>
                                                {isFetching && <CircularSpinner />}
                                            </div>
                                        </Box>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </form>
        </div>
    );
};