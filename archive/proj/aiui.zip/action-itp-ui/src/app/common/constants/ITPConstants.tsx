export const BLANKSTRING = '';

export const URL_ACTION_ITP_API_HOSTNAME = process.env.REACT_APP_ACTION_ITP_API_BASE_URL;

export const URL_ACTION_ITP_API_HOSTNAME_LOCAL = 'http://localhost:8080';

export const URL_ACTION_ITP_LOGIN_API_CONTEXT = process.env.REACT_APP_ACTION_ITP_API_LOGIN_URL;

export const URL_ACTION_ITP_PII_CONTEXT = process.env.REACT_APP_ACTION_ITP_API_ACCOUNT_LOOKUP_URL;

export const URL_ACTION_ITP_FETCH_MEMO_CONTEXT = process.env.REACT_APP_ACTION_ITP_API_FETCH_MEMO_URL;

export const URL_ACTION_ITP_DATA_CONTEXT = process.env.REACT_APP_ACTION_ITP_API_ACCOUNT_ITPDATA_URL;

export const URL_ACTION_BILLING_DATA_CONTEXT = process.env.REACT_APP_ACTION_ITP_API_ACCOUNT_BILLINGDATA_URL;

export const URL_ACTION_ITP_CUSTOMER_SEARCH_CONTEXT = process.env.REACT_APP_ACTION_ITP_CUSTOMER_SEARCH_URL;

export const URL_ACTION_ITP_FETCH_REQUEST_ACTIVITY_CONTEXT = process.env.REACT_APP_ACTION_ITP_API_FETCH_REQUEST_ACTIVITY_URL;

export const URL_ACTION_ITP_RECORD_CALL = process.env.REACT_APP_ACTION_ITP_RECORD_CALL_URL;

export const URL_ACTION_ITP_CANCEL_ENROLLMENT = process.env.REACT_APP_ACTION_ITP_CANCEL_ENROLLMENT_URL;

export const URL_ACTION_ITP_CANCEL_REASONS = process.env.REACT_APP_ACTION_ITP_CANCEL_REASONS_URL;

export const ACTION_ITP = 'Action - ITP';
export const BTN_LOGIN = 'Sign In';

export const ERROR_MSG_INVALID_CREDENTIALS =
    'Error: Invalid username and/or password';

export const ERROR_MSG_INPUTS_BLANK =
    'Please enter your credentials. Credentials cannot be blank';

export const ERROR_MSG_SOMETHING_WENT_WRONG =
    'Something went wrong. Please contact the System Administrator or try after sometime';

export const ERROR_MSG_SERVER_UNAVAILABLE =
    'Server is unavailable. Please contact the System Administrator or try after sometime';

export const TXT_PLACEHOLDER_USER_NAME = 'Username';
export const TXT_PLACEHOLDER_USER_PASSWORD = 'Password';

export const RESPONSE_SUCCESS_STATUS = 200;
export const RESPONSE_BAD_REQUEST_STATUS = 400;
export const RESPONSE_UNAUTHORISED_STATUS = 401;
export const RESPONSE_INTERNAL_SERVER_ERROR_STATUS = 500;

export const LOGIN_SUCCESS = 'LOGIN_SUCCESS';
export const LOGIN_REQUEST = 'LOGIN_REQUEST';
export const LOGIN_FAILURE = 'LOGIN_FAILURE';
export const LOGOUT = 'LOGOUT';

export const MAX_MANUAL_MEMO_TEXT_SIZE = 180;
export const ENROLLMENT = 'Enrollment';
export const CANCELLATION = 'Cancellation';
export const GENERAL_SERVICING = 'General Servicing';
export const TRANSFER_TO_ECS = 'Transfer to ECS';
export const SPACED_COMMA_DELIMITER = ', ';
export const BTN_POST_MEMO = 'Post Memo';

export const RETRIEVING_CUSTOMER_ERROR = 'Error retrieving customer information at this time. Please try again.';
export const INTERNAL_SERVER_ERROR = 'Service is currently unavailable. Please retry or open a ticket with the command center.';
export const LOGIN_ERROR = 'Login failed. Please re-enter your login information and try again.';
export const RETRIEVING_DATA_ERROR = 'Error retrieving membership information. Please go back to search and try again.';
export const RETRIEVING_BILLING_DATA_ERROR = 'Billing Details are currently unavailable. Please retry or open a ticket with the command center.';
export const MEMO_POSTING_ERROR = 'Error creating new memo. Please try again';
export const BILLING_INFORMATION_WARNING = 'Billing details no longer available. Customer’s membership (is pending cancellation/has been cancelled).';

export const INVALID_DOB = 'Invalid Date of Birth';
export const INVALID_FIRST_NAME = 'Invalid First Name';
export const INVALID_LAST_NAME = 'Invalid Last Name';
export const INVALID_USERNAME = 'Invalid Username';
export const INVALID_PASSWORD = 'Invalid Password';
export const INVALID_PRODUCT_ENROLLMENT_ID = 'Invalid Product Enrollment Id';
export const INVALID_PEID_OR_SUBSCRIBER_ID = 'Invalid PEID or Subscriber ID';

export const LOGOUT_BUTTON = 'Log Out';
export const STAY_LOGGED_IN_BUTTON = 'Stay Logged In';

export const TIMEOUT_POPUP_TITLE = 'Need More Time?';
export const TIMEOUT_POPUP_MESSAGE = 'Your session is about to expire in 2 minutes. To continue the session, select "Stay Logged In". Otherwise, you will be automatically logged out.';

export const WARNING_TIMEOUT_VALUE = (1000 * 60 * 13);
export const TIMEOUT_VALUE = (1000 * 60 * 2);
export const EST_TIMEZONE = 'America/New_York';
export const YYYY_MM_DD_HH_MM_SS = 'YYYY-MM-DD HH:mm:ss';
export const MONTH = 'month';

export const ITP_FF = 'ITP_FF';
export const NOT_AVAILABLE = 'Not Available';
export const ITP_BM = 'ITP_BM';
export const BM_CUSTOMER_TEXT = 'ITP 3B Broad Market';
export const NOT_AVAILABLE_ACRONYM = 'N/A';
export const ITP_BM_FREE = 'ITP_BM_FREE';
export const BM_CUSTOMER_PENDING_PAYMENT = 'ITP 3B Broad Market (Pending Customer Payment)';
export const COL_HEADER_REQ_DATE = 'Request Date';
export const COL_HEADER_REQ_ACTIVITY = 'Request/Activity';
export const COL_HEADER_COM_DATE = 'Complete Date';
export const COL_HEADER_OPERATOR = 'Operator';
export const COL_HEADER_STATUS = 'Status';
export const CANCEL = 'cancel';
export const REQUEST_COMPLETE = 'REQUEST COMPLETE';

export const PENDING_CANCELLATION_CODE = 'PCN';
export const PENDING_ENROLLMENT_CODE = 'PEN';
export const CANCELLATION_CODE = 'CAN';