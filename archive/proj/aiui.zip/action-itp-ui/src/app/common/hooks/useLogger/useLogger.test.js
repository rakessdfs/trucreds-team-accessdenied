import { renderHook } from '@testing-library/react-hooks';
import { useLogger } from './useLogger';

describe('useLogger', () => {
    const setupRTL = () => {
        return renderHook(() => useLogger());
    };

    describe('can call App Dynamics API using hook.logger', () => {
        test('test', () => {
            const { result } = setupRTL();
            const args = { msg: 'error!' };
            result.current.logger(args);
            expect(window.ADRUM.report).toHaveBeenCalledWith(args);
        });

        test('testLine', () => {
            const { result } = setupRTL();
            const args = { msg: 'error!' };
            const argsLine = { line: '10' };
            result.current.logger({
                ...args,
                ...argsLine
            });

            expect(window.ADRUM.report).toHaveBeenCalledWith({
                ...args,
                ...argsLine
            });
        });

        test('testLineUrl', () => {
            const { result } = setupRTL();
            const args = { msg: 'error!' };
            const argsLine = { line: '10' };
            const argsUrl = { url: 'http://foo.bar' };
            result.current.logger({
                ...args,
                ...argsLine,
                ...argsUrl
            });

            expect(window.ADRUM.report).toHaveBeenCalledWith({
                ...args,
                ...argsLine,
                ...argsUrl
            });
        });
    });
});