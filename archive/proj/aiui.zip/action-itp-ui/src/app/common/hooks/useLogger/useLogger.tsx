import { useRef } from 'react';

export interface IUseLogger {
    logger: (args: loggerArgs) => void;
}

type loggerArgs = {
    msg?: string;
    line?: number;
    url?: string;
}

export const useLogger = (): IUseLogger => {
    const logger = useRef<(args: loggerArgs) => void>(({ msg, line, url }: loggerArgs): void => {
        const tracker: loggerArgs = {
            msg
        };
        if (line) {
            tracker.line = line;
        }
        if (url) {
            tracker.url = url;
        }
        if (window?.ADRUM) {
            window.ADRUM.report(tracker);
        }
    });

    return {
        logger: logger.current
    };
};