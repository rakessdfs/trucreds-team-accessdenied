import React from 'react';
import { screen } from '@testing-library/react';
import { renderContainer } from '../../utils/test-utils';
import { CircularSpinner } from './CircularSpinner';

describe('Circular Spinner', () => {
    beforeEach(() => {
        jest.resetAllMocks();
    });

    const setupRTL = () => {
        return renderContainer(
            <CircularSpinner />
        );
    };

    test('renders div', () => {
        setupRTL();
        expect(screen.getByTestId('circularSpinner')).toBeInTheDocument();
    });
});