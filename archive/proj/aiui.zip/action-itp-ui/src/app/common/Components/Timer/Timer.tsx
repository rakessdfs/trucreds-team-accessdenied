import React, { ReactElement, useEffect, useState } from 'react';
import { useIdleTimer } from 'react-idle-timer';
import { useDispatch } from 'react-redux';
import { TimeoutPopup } from '../../../modules/itp/popups/TimeoutPopup/TimeoutPopup';
import { attemptLogout } from '../../../modules/login/Login.actions';
import { WARNING_TIMEOUT_VALUE, TIMEOUT_VALUE } from '../../constants/ITPConstants';

type ITimerProps = {
    showModal: boolean;
}

export const Timer = (({ showModal }: ITimerProps): ReactElement => {
    let timeout: NodeJS.Timeout;

    const [isModalOpen, setIsModalOpen] = useState(showModal);
    const dispatch = useDispatch();

    const handleOnIdle = (): void => {
        setIsModalOpen(true);
    };

    const { isIdle, reset } = useIdleTimer({
        timeout: WARNING_TIMEOUT_VALUE,
        onIdle: handleOnIdle,
        stopOnIdle: true
    });

    useEffect(() => {
        if (isModalOpen) {
            // eslint-disable-next-line
            timeout = setTimeout(() => {
                if (isIdle()) {
                    dispatch(attemptLogout({
                        message: [],
                        cause: []
                    }));
                }
            }, (TIMEOUT_VALUE));
        }
    }, [isModalOpen, isIdle]);

    return (
        <>
            {isModalOpen && (
                <TimeoutPopup
                    reset={(): void => reset()}
                    closeModal={(): void => {
                        setIsModalOpen(false);
                        clearTimeout(timeout);
                    }}
                />
            )}
        </>
    );
});