import { screen } from '@testing-library/react';
import React from 'react';
import { renderContainer } from '../../utils/test-utils';
import { PopupModal } from './PopupModal';

describe('Popup Modal', () => {
    beforeEach(() => {
        jest.resetAllMocks();
    });

    const setupRTL = () => {
        return renderContainer(
            <PopupModal>
                <h1>hello from the child</h1>
            </PopupModal>
        );
    };

    test('renders Popup Modal container', () => {
        setupRTL();
        expect(screen.getByTestId('popupModal')).toBeInTheDocument();
    });

    test('renders children', () => {
        setupRTL();
        expect(screen.getByRole('heading', { name: /hello from the child/i })).toBeInTheDocument();
    });
});