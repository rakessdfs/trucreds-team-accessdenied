import React from 'react';
import { render, screen } from '@testing-library/react';
import { Button } from './Button';
import styles from './Button.module.scss';

describe('Input', () => {
    let primary;

    beforeEach(() => {
        primary = undefined;
    });

    const setupRTL = () => {
        return render(
            <Button
                primary={primary}
            >
                Button Text
            </Button>
        );
    };

    describe('Default Props', () => {
        describe('primary', () => {
            test('Default to display primary button', () => {
                setupRTL();

                const btn = screen.getByText('Button Text');
                expect(btn).toBeInTheDocument();
                expect(btn).toHaveClass(styles.btnPrimary);
                expect(btn).not.toHaveClass(styles.btnSecondary);
            });

            test('Can be overridden to display secondary button', () => {
                primary = false;
                setupRTL();

                const btn = screen.getByText('Button Text');
                expect(btn).toBeInTheDocument();
                expect(btn).toHaveClass(styles.btnSecondary);
                expect(btn).not.toHaveClass(styles.btnPrimary);
            });
        });
    });
});