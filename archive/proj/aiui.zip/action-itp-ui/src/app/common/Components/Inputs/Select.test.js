import { fireEvent } from '@testing-library/dom';
import { screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import React from 'react';
import { renderContainer } from '../../../common/utils/test-utils';
import { Select } from './Select';

describe('Select', () => {
    let defaultOption, options, label, shouldShowWarning, shouldShowError, errorMessage, warningMessage, className;

    beforeEach(() => {
        defaultOption = 'No Longer Wants/Needs';
        options = ['No Longer Wants/Needs', 'Alleged Unauthorized Enrollment', 'Already Cancelled Still Billing',
            'Product Service Concern'];
        label = 'my-test-label';
        shouldShowWarning = false;
        shouldShowError = false;
        errorMessage = 'test error message';
        warningMessage = 'test warning message';
        className = 'someClassName';
    });

    const setupRTL = () => {
        return renderContainer(
            <Select
                defaultOption={defaultOption}
                options={options}
                label={label}
                shouldShowError={shouldShowError}
                shouldShowWarning={shouldShowWarning}
                errorMessage={errorMessage}
                warningMessage={warningMessage}
                className={className}
            />
        );
    };

    test('label & ClassName', () => {
        setupRTL();

        const input = screen.getByLabelText(label);

        expect(input).toBeInTheDocument();
        expect(input).toHaveClass(className);
    });

    describe('shouldShowWarning', () => {
        beforeEach(() => {
            shouldShowWarning = true;
        });

        test('Warning will not show until the user blurs from the input', () => {
            setupRTL();

            expect(screen.queryByText(warningMessage)).not.toBeInTheDocument();
            expect(screen.queryByTestId('warning-icon')).not.toBeInTheDocument();

            userEvent.selectOptions(screen.getByRole('combobox'), defaultOption);

            fireEvent.blur(screen.getByRole('combobox'));

            expect(screen.getByText(warningMessage)).toBeInTheDocument();
            expect(screen.getByTestId('warning-icon')).toBeInTheDocument();
        });
    });

    describe('shouldShowError', () => {
        beforeEach(() => {
            shouldShowError = true;
        });

        test('Error will show immediately if passed in', () => {
            setupRTL();

            expect(screen.getByText(errorMessage)).toBeInTheDocument();
            expect(screen.getByTestId('error-icon')).toBeInTheDocument();
        });
    });

    test('Options can be selected and changed', () => {
        setupRTL();

        expect(screen.getByRole('combobox')).toHaveValue(defaultOption);

        userEvent.selectOptions(screen.getByRole('combobox'), options[0]);

        expect(screen.getByRole('combobox')).toHaveValue(options[0]);
    });
});