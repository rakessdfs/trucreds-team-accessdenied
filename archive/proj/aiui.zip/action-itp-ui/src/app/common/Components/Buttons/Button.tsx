
import React, { ButtonHTMLAttributes, forwardRef, ReactElement, Ref } from 'react';
import { buildClasses } from '../../utils/ITPUtils';
import styles from './Button.module.scss';

export interface IButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
    primary?: boolean;
    children?: ReactElement | string;
}

export const Button = forwardRef(({
    primary = true,
    children,
    className,
    ...rest
}: IButtonProps,
ref: Ref<HTMLButtonElement>
): ReactElement => {
    return (
        <button
            ref={ref}
            className={buildClasses([className, styles.btn, primary ? styles.btnPrimary : styles.btnSecondary])}
            {...rest}
        >
            {children}
        </button>
    );
});