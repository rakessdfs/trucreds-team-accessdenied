import { screen } from '@testing-library/react';
import React from 'react';
import userEvent from '@testing-library/user-event';
import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { renderContainer } from '../../utils/test-utils';
import { LOGOUT_BUTTON, STAY_LOGGED_IN_BUTTON } from '../../constants/ITPConstants';
import { logout } from '../../../modules/login/Login.actions';
import { Timer } from './Timer';

describe('Timeout Popup Modal', () => {
    let store;

    beforeEach(() => {
        jest.resetAllMocks();
    });

    const setupRTL = () => {
        store = configureMockStore([thunk])();
        return renderContainer(
            <Timer showModal={true} />,
            { store }
        );
    };

    describe('modal', () => {
        test('should be closed when agent clicks on stay logged in button', () => {
            setupRTL();
            userEvent.click(screen.getByRole('button', { name: STAY_LOGGED_IN_BUTTON }));
            expect(screen.queryByTestId('popupModal')).not.toBeInTheDocument();
        });

        test('should be closed and agent should be logged out when clicked on log out button', async () => {
            setupRTL();
            userEvent.click(screen.getByRole('button', { name: LOGOUT_BUTTON }));

            const actions = store.getActions();

            await expect(actions[1]).toEqual(logout({
                message: [],
                cause: []
            }));
        });
    });
});