import React, { ReactElement } from 'react';
import { buildClasses } from '../../utils/ITPUtils';
import styles from './CircularSpinner.module.scss';

export interface ICircularSpinner {
    isButton?: boolean;
}

export const CircularSpinner = ({
    isButton = true
}: ICircularSpinner): ReactElement => {
    return (
        <div
            data-testid='circularSpinner'
            className={buildClasses([isButton ? styles.circularSpinnerSmall : styles.circularSpinnerMedium, styles.circularSpinnerStyle])}
        >
            <div className={styles.subStyle} />
            <div className={styles.subStyle} />
            <div className={styles.subStyle} />
            <div className={styles.subStyle} />
            <div className={styles.subStyle} />
            <div className={styles.subStyle} />
            <div className={styles.subStyle} />
            <div className={styles.subStyle} />
            <div className={styles.subStyle} />
            <div className={styles.subStyle} />
            <div className={styles.subStyle} />
            <div className={styles.subStyle} />
            { !isButton &&
            <>
                <div className={styles.subStyle} />
                <div className={styles.subStyle} />
                <div className={styles.subStyle} />
                <div className={styles.subStyle} />
                <div className={styles.subStyle} />
                <div className={styles.subStyle} />
                <div className={styles.subStyle} />
                <div className={styles.subStyle} />
                <div className={styles.subStyle} />
                <div className={styles.subStyle} />
                <div className={styles.subStyle} />
                <div className={styles.subStyle} />
            </>
            }
        </div>
    );
};