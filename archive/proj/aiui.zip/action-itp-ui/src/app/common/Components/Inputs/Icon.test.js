import React from 'react';
import { screen } from '@testing-library/react';
import { renderContainer } from '../../../common/utils/test-utils';
import { Icon } from './Icon';

describe('Icon', () => {
    let name, testId, customClass;

    const setupRTL = () => {
        return renderContainer(
            <Icon
                name={name}
                testId={testId}
                customClass={customClass}
            />
        );
    };

    beforeEach(() => {
        testId = 'testId';
        customClass = 'someClass';
        name = 'errorTriangle';
    });

    test('assigns test id and class from props', () => {
        setupRTL();
        const icon = screen.getByTestId(testId);

        expect(icon).toBeInTheDocument();
        expect(icon).toHaveClass(customClass);
    });

    test('empty name returns nothing', () => {
        name = '';
        const { container } = setupRTL();
        expect(container).toBeEmpty();
    });

    test('default case returns nothing', () => {
        name = 'NOT A REAL ICON NAME';
        const { container } = setupRTL();
        expect(container).toBeEmpty();
    });
});