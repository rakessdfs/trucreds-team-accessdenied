export interface ICustomInputProps {
    optional?: boolean;
    shouldShowWarning?: boolean;
    shouldShowError?: boolean;
    warningMessage?: string;
    errorMessage?: string;
    label: string;
    className?: string;
}