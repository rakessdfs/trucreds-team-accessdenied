import React, { ReactElement, SelectHTMLAttributes, useState } from 'react';
import ReactTooltip from 'react-tooltip';
import { buildClasses } from '../../utils/ITPUtils';
import { ICustomInputProps } from './types';
import { Icon } from './Icon';
import styles from './Input.module.sass';

export interface ISelectProps extends ICustomInputProps, SelectHTMLAttributes<HTMLSelectElement> {
    defaultOption: string | number;
    options: (string | number)[];
}

export const Select = (
    {
        optional,
        label,
        shouldShowWarning,
        shouldShowError,
        errorMessage,
        warningMessage,
        options,
        defaultOption,
        className,
        value,
        ...rest
    }: ISelectProps): ReactElement => {
    const [hasBlurred, setHasBlurred] = useState(false);

    const warningImage = (
        <Icon
            name='warningAlert'
            customClass={styles.icon}
            testId='warning-icon'
        />
    );
    const errorImage = (
        <Icon
            name='errorTriangle'
            customClass={styles.icon}
            testId='error-icon'

        />
    );

    const willShowWarning = shouldShowWarning && hasBlurred;

    let icon;

    if (willShowWarning) {
        icon = warningImage;
    } else if (shouldShowError) {
        icon = errorImage;
    } else {
        icon = null;
    }
    const labelComponent = (
        <label
            style={{ color: '#8a8a8a' }}
            htmlFor={label}
            data-testid='label-component-wrapper'
        >
            {label}
        </label>
    );
    const inputComponent = (
        <div data-testid='select-component-wrapper'>
            <div className={styles.inputWithIconContainer}>
                <span
                    className={styles.tooltipSpan}
                    data-place='bottom'
                    data-effect='solid'
                    data-tip=''
                    data-for={`input-warn-tooltip-${label}`}
                    data-background-color='#ffffff'
                    data-text-color='#293033'
                    data-border={true}
                    data-border-color='#dbdbdb'
                >
                    <div className={buildClasses([
                        styles.selectWrapper,
                        willShowWarning && styles.warning,
                        shouldShowError && styles.error
                    ])}
                    >
                        <select
                            {...rest}
                            required={!optional}
                            className={buildClasses([
                                styles.input,
                                styles.select,
                                className,
                                willShowWarning && styles.warning,
                                shouldShowError && styles.error
                            ])}
                            id={label}
                            onBlur={(): void => setHasBlurred(true)}
                            value={value}
                        >
                            {
                                options.includes(defaultOption) ?
                                    null :
                                    (
                                        <option
                                            key={defaultOption}
                                            value=''
                                        >
                                            {defaultOption}
                                        </option>
                                    )
                            }
                            {
                                options.map((option) => (
                                    <option
                                        value={option}
                                        key={option}
                                    >
                                        {option}
                                    </option>
                                ))
                            }
                        </select>
                        <div
                            className={buildClasses([styles.pseudoSelect, styles.input, shouldShowError && styles.error])}
                            data-testid='pseudo-select'
                        >
                            <p className={styles.pseudoSelectText}>
                                {value === '' ? defaultOption : value}
                            </p>
                            <div className={styles.pseudoSelectArrow} />
                        </div>
                    </div>
                </span>
                <ReactTooltip
                    id={`input-warn-tooltip-${label}`}
                    getContent={(): JSX.Element | null => (willShowWarning ? (
                        <p
                            role='alert'
                            data-testid='input-warning-tooltip'
                        >
                            {warningMessage}
                        </p>
                    ) : null)}
                />
                {icon}
            </div>
            {shouldShowError && (
                <p
                    className={styles.errorMessage}
                    role='alert'
                >
                    {errorMessage}
                </p>
            )}
        </div>
    );
    return (
        <div className={styles.inputContainer}>
            {labelComponent}
            {inputComponent}
        </div>
    );
};