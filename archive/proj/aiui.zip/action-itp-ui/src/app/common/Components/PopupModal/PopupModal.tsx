import React, { ReactElement, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { buildClasses } from '../../utils/ITPUtils';
import styles from './PopupModal.module.scss';

type IPopupModalProps = {
    children: ReactElement;
    className?: string;
}

export const PopupModal = (({ children, className }: IPopupModalProps): ReactElement => {
    const buttonRef = useRef<HTMLButtonElement>(null);
    const modalRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (buttonRef?.current) {
            buttonRef.current.focus();
        }
    });

    return createPortal(
        <section
            aria-modal='true'
            role='dialog'
            className={styles.modalCover}
            data-testid='popupModal'
        >
            <div
                className={buildClasses([styles.modalContainer, className])}
                ref={modalRef}
            >
                {children}
            </div>
        </section>,
        document.body
    );
});