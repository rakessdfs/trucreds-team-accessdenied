/* eslint-disable */
import React from 'react';
import { render } from '@testing-library/react';
import { Provider } from 'react-redux';
import setupMockStore from 'redux-mock-store';
import { createMemoryHistory } from 'history';
import { Router, Switch, Route } from 'react-router-dom';

export const renderContainer = (
    ui,
    {
        store = setupMockStore()({}),
        route = '/',
        history = createMemoryHistory({ initialEntries: [route] })
    } = {}
) => {
    const wrappedUI = (
        <Provider store={store}>
            <Router history={history}>
                <Switch>
                    <Route render={() => ui} />
                </Switch>
            </Router>
        </Provider>
    );
    return {
        ...render(wrappedUI),
        // adding `store` to the returned utilities to allow us
        // to reference it in our tests (just try to avoid using
        // this to test implementation details).
        store,
        history,
        UI: wrappedUI
    };
};