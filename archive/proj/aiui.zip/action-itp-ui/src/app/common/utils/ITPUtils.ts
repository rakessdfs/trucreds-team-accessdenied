import { AxiosResponse } from 'axios';
import moment from 'moment';
import {} from 'moment-timezone';
import { FieldErrors } from 'react-hook-form';
import {
    INTERNAL_SERVER_ERROR,
    INVALID_DOB,
    INVALID_FIRST_NAME,
    INVALID_LAST_NAME,
    MEMO_POSTING_ERROR,
    INVALID_PASSWORD,
    INVALID_PRODUCT_ENROLLMENT_ID,
    INVALID_USERNAME,
    LOGIN_ERROR,
    RETRIEVING_CUSTOMER_ERROR,
    EST_TIMEZONE,
    YYYY_MM_DD_HH_MM_SS,
    RETRIEVING_DATA_ERROR,
    RETRIEVING_BILLING_DATA_ERROR,
    INVALID_PEID_OR_SUBSCRIBER_ID,
    BILLING_INFORMATION_WARNING
} from '../constants/ITPConstants';
import { IFormFields } from '../../modules/itp/account-lookup/AccountLookup/AccountLookup';
import * as CONSTANT from '../../modules/itp/account-lookup/AccountLookup/AccountLookupConstants';
import { IReduxError } from '../types';

export const formatPhoneNumber = (phoneNumberString: string): string => {
    const cleaned = (`${phoneNumberString}`).replace(/\D/g, '');
    const match = cleaned.match(/^([0-9][0-9][0-9])([0-9][0-9][0-9])([0-9][0-9][0-9][0-9])$/);
    if (match) {
        return `(${match[1]}) ${match[2]}-${match[3]}`;
    }
    return phoneNumberString;
};

export const capitalizeFirstLetter = (input: string, multi = false): string => {
    if (multi) {
        return input.split(' ').map((word) => capitalizeFirstLetter(word)).join(' ');
    }
    return input.charAt(0).toUpperCase() + input.slice(1);
};

export const validateResponse = (response: AxiosResponse, entityName: string): IReduxError | null => {
    const message: string[] = [];
    const cause: string[] = [];

    if (response?.data?.errors) {
        switch (response?.status) {
            case 400:
                message.push(`Invalid request. Please resolve and try again.`);
                cause.push(...Object.keys(response.data.errors));
                break;
            case 401:
                cause.push(...Object.keys(response.data.errors));
                break;
            case 403:
                message.push(`Forbidden error occurred.`);
                cause.push(...Object.keys(response.data.errors));
                break;
            case 500:
                if (Object.keys(response.data.errors)[0] === '1026') {
                    message.push('Call recording error');
                } else {
                    message.push(`Unable to load ${capitalizeFirstLetter(entityName, true)} at this time. Please try again.`);
                }
                cause.push(...Object.keys(response.data.errors));
                break;
            default:
                cause.push(INTERNAL_SERVER_ERROR);
                break;
        }
    } else if (response?.status) {
        switch (response.status) {
            case 200:
                return null;
            case 201:
                return null;
            case 204:
                message.push(`No ${capitalizeFirstLetter(entityName, true)} Available.`);
                break;
            case 401:
            case 403:
            case 404:
            case 500:
            default:
                message.push(INTERNAL_SERVER_ERROR);
                cause.push(INTERNAL_SERVER_ERROR);
                break;
        }
    } else {
        cause.push('Unknown Server Error Occurred');
    }

    return {
        message,
        cause
    };
};

export const buildReduxError = (message: string, cause: string): IReduxError => ({
    message: [message],
    cause: [cause]
});

export const mapMessageToCause = (cause: string): string => {
    let message = '';
    switch (cause) {
        case '1002':
            message = INVALID_DOB;
            break;
        case '1004':
            message = INVALID_LAST_NAME;
            break;
        case '1005':
            message = INVALID_USERNAME;
            break;
        case '1006':
            message = INVALID_PASSWORD;
            break;
        case '1008':
            message = INVALID_FIRST_NAME;
            break;
        case '1009':
            message = LOGIN_ERROR;
            break;
        case '1011':
            message = MEMO_POSTING_ERROR;
            break;
        case '1012':
            message = INVALID_PRODUCT_ENROLLMENT_ID;
            break;
        case '1015':
            message = RETRIEVING_BILLING_DATA_ERROR;
            break;
        case '1019':
            message = INVALID_PEID_OR_SUBSCRIBER_ID;
            break;
        case '5001':
            message = BILLING_INFORMATION_WARNING;
            break;
        case '5002':
            message = RETRIEVING_CUSTOMER_ERROR;
            break;
        case '5003':
            message = RETRIEVING_DATA_ERROR;
            break;
        case '5005':
        case '5006':
        default:
            message = INTERNAL_SERVER_ERROR;
            break;
    }
    return message;
};

export const buildClasses = (classes: (string | boolean | undefined)[]): string => {
    return classes.filter(Boolean).join(' ');
};

export const formatDateInEST = (dateTime: string): string => {
    const date = dateTime.toString();
    const newDate = date.split(',');

    const updatedDateTime = newDate.map((val, i) => {
        let newVal = Number.parseInt(val);
        if (i === 1) {
            newVal -= 1;
        }
        return newVal;
    });

    const utcDateTime = moment.utc(updatedDateTime);
    return utcDateTime.tz(EST_TIMEZONE).format(YYYY_MM_DD_HH_MM_SS);
};

export const formatDateOfBirth = (dob: string): string => {
    if (!dob) {
        return dob;
    }
    const currentValue = dob.replace(/[^\d]/g, '').slice(0, 8);
    const cvLength = currentValue.length;
    if (cvLength < 3) {
        return currentValue;
    }
    if (cvLength < 5) {
        return `${currentValue.slice(0, 2)}/${currentValue.slice(2)}`;
    }
    return `${currentValue.slice(0, 2)}/${currentValue.slice(2, 4)}/${currentValue.slice(4, 8)}`;
};

export const formatDate = (date: string): string => {
    return moment(date).format('YYYY-MM-DD');
};

function determineErrors(errors: FieldErrors<IFormFields> | undefined,
    piiSearchError: boolean | undefined,
    peidSearchError: boolean | undefined,
    searchCriteriaError: boolean | undefined): string[] {
    const errorContent = [];
    if (peidSearchError) {
        errorContent.push(CONSTANT.VALIDATION_MSG_PEID_SUBSCRIBER_ID);
        return errorContent;
    }
    if (searchCriteriaError) {
        errorContent.push(CONSTANT.CUSTOMER_SEARCH_REQUEST_MSG);
        return errorContent;
    }
    if (errors?.firstName?.type === CONSTANT.VALIDATION_PATTERN) {
        errorContent.push(CONSTANT.ERROR_MSG_FIRST_NAME);
    }
    if (errors?.lastName?.type === CONSTANT.VALIDATION_PATTERN) {
        errorContent.push(CONSTANT.ERROR_MSG_LAST_NAME);
    }
    if (errors?.dob?.type === CONSTANT.VALIDATION_PATTERN) {
        errorContent.push(CONSTANT.ERROR_MSG_DOB);
    }
    if (errors?.firstName?.type === CONSTANT.VALIDATION_REQUIRED ||
        errors?.lastName?.type === CONSTANT.VALIDATION_REQUIRED ||
        errors?.dob?.type === CONSTANT.VALIDATION_REQUIRED || piiSearchError) {
        errorContent.push(CONSTANT.ERROR_MSG_ALL_FIELDS);
    }
    return errorContent;
}

export const errorHandling = (errors: FieldErrors<IFormFields> | undefined,
    piiSearchError: boolean | undefined,
    peidSearchError: boolean | undefined,
    searchCriteriaError: boolean | undefined,
    reduxErrors: Array<IReduxError | null>): string[] => {
    let errorContent: string[] = [];
    if (errors) {
        errorContent = determineErrors(errors, piiSearchError, peidSearchError, searchCriteriaError);
    }

    if (reduxErrors) {
        reduxErrors.forEach((reduxError) => {
            reduxError &&
            reduxError.cause.map((cause) => {
                return errorContent.push(mapMessageToCause(cause));
            });
        });
    }
    return errorContent;
};