import {
    INTERNAL_SERVER_ERROR,
    INVALID_DOB,
    INVALID_FIRST_NAME,
    INVALID_LAST_NAME,
    MEMO_POSTING_ERROR,
    INVALID_PASSWORD,
    INVALID_PRODUCT_ENROLLMENT_ID,
    INVALID_USERNAME,
    LOGIN_ERROR,
    RETRIEVING_CUSTOMER_ERROR, RETRIEVING_BILLING_DATA_ERROR, INVALID_PEID_OR_SUBSCRIBER_ID
} from '../constants/ITPConstants';
import * as CONSTANT from '../../modules/itp/account-lookup/AccountLookup/AccountLookupConstants';
import {
    buildClasses,
    buildReduxError,
    capitalizeFirstLetter, errorHandling,
    formatPhoneNumber,
    mapMessageToCause,
    validateResponse
} from './ITPUtils';

describe('ITPUtils', () => {
    describe('formatPhoneNumber', () => {
        test('correctly formats 10 digits to (xxx) xxx-xxxx format', () => {
            expect(formatPhoneNumber('1234567890')).toEqual('(123) 456-7890');
        });

        test('Removes any non-digits and formats 10 digits to (xxx) xxx-xxxx format', () => {
            expect(formatPhoneNumber('x1z2a3!4f5u6f7$8%9.0!')).toEqual('(123) 456-7890');
        });

        test('Returns original string if it is not a phone number', () => {
            expect(formatPhoneNumber('abc123')).toEqual('abc123');
        });
    });

    describe('capitalizeFirstLetter', () => {
        test('correctly capitalizes the first letter', () => {
            expect(capitalizeFirstLetter('abc123')).toEqual('Abc123');
        });

        test('Optionally can capitalize the first letter of every word when passed second param as true', () => {
            expect(capitalizeFirstLetter('the quick brown fox', true)).toEqual('The Quick Brown Fox');
        });
    });

    describe('validateResponse', () => {
        let response = {
            status: 200,
            data: {}
        };

        test('200', () => {
            expect(validateResponse(response, 'test entity')).toEqual(null);
        });

        test('201', () => {
            response = {
                ...response,
                status: 201
            };

            expect(validateResponse(response, 'test entity')).toEqual(null);
        });

        test('204', () => {
            response = {
                ...response,
                status: 204
            };

            expect(validateResponse(response, 'test entity')).toEqual({
                message: ['No Test Entity Available.'],
                cause: []
            });
        });

        test('400', () => {
            response = {
                ...response,
                status: 400,
                data: {
                    errors: {
                        1001: 'First name invalid',
                        1002: 'Last name invalid'
                    }
                }
            };

            expect(validateResponse(response, 'test entity')).toEqual({
                message: ['Invalid request. Please resolve and try again.'],
                cause: ['1001', '1002']
            });
        });

        test('matches 401 with 1009 error cause', () => {
            response = {
                ...response,
                status: 401,
                data: {
                    errors: {
                        1009: 'User not authenticated'
                    }
                }
            };

            const validatedResponse = validateResponse(response, 'test entity');
            expect(validatedResponse).toEqual({
                message: [],
                cause: ['1009']
            });
            expect(mapMessageToCause(validatedResponse.cause[0]))
                .toBe('Login failed. Please re-enter your login information and try again.');
        });

        test('matches 401 without errors object', () => {
            response = {
                ...response,
                status: 401,
                data: {
                    error: '1001',
                    // eslint-disable-next-line @typescript-eslint/camelcase
                    error_description: 'Unauthorized!'
                }
            };

            const validatedResponse = validateResponse(response, 'test entity');
            expect(validatedResponse).toEqual({
                message: [INTERNAL_SERVER_ERROR],
                cause: [INTERNAL_SERVER_ERROR]
            });
            expect(mapMessageToCause(validatedResponse.cause[0]))
                .toBe(INTERNAL_SERVER_ERROR);
        });

        test('matches 403 response to error message', () => {
            response = {
                ...response,
                status: 403,
                data: {
                    errors: {
                        1003: 'Forbidden - Not authorized to access the resource!'
                    }
                }
            };

            expect(validateResponse(response, 'test entity')).toEqual({
                message: ['Forbidden error occurred.'],
                cause: ['1003']
            });
        });

        test('matches 404 response to error message', () => {
            response = {
                ...response,
                status: 404,
                data: null

            };

            expect(validateResponse(response, 'test entity')).toEqual({
                message: [INTERNAL_SERVER_ERROR],
                cause: [INTERNAL_SERVER_ERROR]
            });
        });

        test('500 without errors object', () => {
            response = {
                ...response,
                status: 500,
                data: null
            };

            expect(validateResponse(response, 'test entity')).toEqual({
                message: [INTERNAL_SERVER_ERROR],
                cause: [INTERNAL_SERVER_ERROR]
            });
        });

        test('handles unknown code with no errors object by default', () => {
            response = {
                ...response,
                status: 999
            };

            expect(validateResponse(response, 'test entity')).toEqual({
                message: [INTERNAL_SERVER_ERROR],
                cause: [INTERNAL_SERVER_ERROR]
            });
        });

        test('handles unknown code with an errors object by default', () => {
            response = {
                ...response,
                data: {
                    errors: [
                        'abcd'
                    ]
                },
                status: 999
            };

            expect(validateResponse(response, 'test entity')).toEqual({
                message: [],
                cause: [INTERNAL_SERVER_ERROR]
            });
        });

        test('handles error when there is no status code or errors on the object', () => {
            response = {};

            expect(validateResponse(response, 'test entity')).toEqual({
                message: [],
                cause: ['Unknown Server Error Occurred']
            });
        });
    });

    describe('buildReduxError', () => {
        let result;

        beforeEach(() => {
            result = {
                message: ['starter message'],
                cause: ['unknown']
            };
        });

        test('returns error object with new message', () => {
            expect(buildReduxError('starter message', 'unknown')).toEqual(result);
        });
    });

    describe('mapMessageToCause', () => {
        const testData = [
            {
                cause: '1002',
                message: INVALID_DOB
            },
            {
                cause: '1004',
                message: INVALID_LAST_NAME
            },
            {
                cause: '1005',
                message: INVALID_USERNAME
            },
            {
                cause: '1006',
                message: INVALID_PASSWORD
            },
            {
                cause: '1008',
                message: INVALID_FIRST_NAME
            },
            {
                cause: '1009',
                message: LOGIN_ERROR
            },
            {
                cause: '1011',
                message: MEMO_POSTING_ERROR
            }, {
                cause: '1012',
                message: INVALID_PRODUCT_ENROLLMENT_ID
            },
            {
                cause: '1015',
                message: RETRIEVING_BILLING_DATA_ERROR
            },
            {
                cause: '1019',
                message: INVALID_PEID_OR_SUBSCRIBER_ID
            },
            {
                cause: '5002',
                message: RETRIEVING_CUSTOMER_ERROR
            },
            {
                cause: '5005',
                message: INTERNAL_SERVER_ERROR
            },
            {
                cause: '9999',
                message: INTERNAL_SERVER_ERROR
            }
        ];

        test('maps message to cause', () => {
            testData.forEach(function (testItem) {
                expect(mapMessageToCause(testItem.cause)).toBe(testItem.message);
            });
        });
    });

    describe('buildClasses', () => {
        test('returns a single string if passed a single class', () => {
            const classInput = [
                'class1'
            ];
            expect(buildClasses(classInput)).toEqual('class1');
        });

        test('Removes any falsy values and returns truthy values', () => {
            const classInput = [
                'class1',
                // eslint-disable-next-line sonarjs/no-redundant-boolean
                false,
                // eslint-disable-next-line sonarjs/no-redundant-boolean
                'class2',
                undefined
            ];
            expect(buildClasses(classInput)).toEqual('class1 class2');
        });
    });

    describe('errorHandling', () => {
        test('first name error returns first name error message', () => {
            const errors = {
                firstName: {
                    type: 'pattern'
                }
            };

            expect(errorHandling(errors, false, false, false, null)).toContain(CONSTANT.ERROR_MSG_FIRST_NAME);
        });

        test('last name error returns last name error message', () => {
            const errors = {
                lastName: {
                    type: 'pattern'
                }
            };

            expect(errorHandling(errors, false, false, false, null)).toContain(CONSTANT.ERROR_MSG_LAST_NAME);
        });

        test('date of birth error returns date of birth error message', () => {
            const errors = {
                dob: {
                    type: 'pattern'
                }
            };

            expect(errorHandling(errors, false, false, false, null)).toContain(CONSTANT.ERROR_MSG_DOB);
        });

        test('missing field returns required message', () => {
            const errors = {
                firstName: {
                    type: 'required'
                }
            };

            expect(errorHandling(errors, false, false, false, null)).toContain(CONSTANT.ERROR_MSG_ALL_FIELDS);
        });

        test('pii search error returns required message', () => {
            const errors = {};

            expect(errorHandling(errors, true, false, false, null)).toContain(CONSTANT.ERROR_MSG_ALL_FIELDS);
        });

        test('peid search error returns required message', () => {
            const errors = {};

            expect(errorHandling(errors, false, true, false, null)).toContain(CONSTANT.VALIDATION_MSG_PEID_SUBSCRIBER_ID);
        });

        test('search criteria error returns required message', () => {
            const errors = {};

            expect(errorHandling(errors, false, false, true, null)).toContain(CONSTANT.CUSTOMER_SEARCH_REQUEST_MSG);
        });

        test('redux error returns required message', () => {
            const reduxError = [
                {
                    message: ['invalid first name'],
                    cause: ['1008']
                }
            ];

            expect(errorHandling(undefined, false, false, false, reduxError)).toContain(INVALID_FIRST_NAME);
        });
    });
});