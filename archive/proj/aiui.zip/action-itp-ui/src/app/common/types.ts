export type TApiResponse<T> = IApiFailureResponse | IApiSuccessResponse<T>;

export interface IApiError {
    errors: {
        [key: string]: string;
    };
}

export interface IReduxError {
    message: string[];
    cause: string[];
}

export interface IApiFailureResponse {
    successResponse: null;
    errorResponse: IApiError;
}

export interface IApiSuccessResponse<T> {
    data: T;
}

type TReduxFailureState = {
    data: null;
    error: IReduxError;
    isFetching: false;
}

type TReduxSuccessState<T> = {
    data: Partial<T>;
    error: null;
    isFetching: false;
}

type TReduxFetchingState<T> = {
    data: Partial<T> | null;
    error: null;
    isFetching: true;
}

type TReduxInitialState = {
    data: null;
    error: null;
    isFetching: false;
}

export type IApiState<T> = TReduxFailureState | TReduxFetchingState<T> | TReduxSuccessState<T> | TReduxInitialState;