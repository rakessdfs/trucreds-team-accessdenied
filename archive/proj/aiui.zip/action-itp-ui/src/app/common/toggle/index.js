import FeatureToggle from './FeatureToggle';
import FeatureToggleProvider from './FeatureToggleProvider';

export { FeatureToggleProvider, FeatureToggle };