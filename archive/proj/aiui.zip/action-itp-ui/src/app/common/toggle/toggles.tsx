import { toggleNames } from './toggleNames';

export const toggles = {
    [toggleNames.SHOW_PEID_OR_SUBSCRIBERID]: true,
    [toggleNames.SHOW_LAST_AND_NEXT_BILLING_DATE]: true,
    [toggleNames.SHOW_REQUEST_ACTIVITY]: true,
    [toggleNames.CANCEL_ENROLLMENT]: true
};