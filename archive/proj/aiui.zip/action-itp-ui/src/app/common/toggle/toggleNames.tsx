export const toggleNames = {
    SHOW_PEID_OR_SUBSCRIBERID: 'showPeidOrSubidType',
    SHOW_LAST_AND_NEXT_BILLING_DATE: 'showLastAndNextBillingDate',
    SHOW_REQUEST_ACTIVITY: 'showRequestActivity',
    CANCEL_ENROLLMENT: 'Cancel Enrollment'
};