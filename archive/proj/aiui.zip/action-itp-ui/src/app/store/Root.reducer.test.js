import { rootReducer } from './Root.reducer';

describe('rootReducer', () => {
    const initialState = {
        user: {
            error: null,
            isFetching: false,
            data: null
        },
        pii: {
            error: null,
            isFetching: false,
            data: null
        },
        memo: {
            error: null,
            isFetching: false,
            data: null
        },
        itpEnrollmentData: {
            error: null,
            isFetching: false,
            data: null
        },
        createMemo: {
            error: null,
            isFetching: false,
            data: null
        },
        billingData: {
            data: null,
            error: null,
            isFetching: false
        },
        cancelEnrollment: {
            data: null,
            error: null,
            isFetching: false
        },
        cancelReasons: {
            data: null,
            error: null,
            isFetching: false
        },
        customerSearch: {
            data: null,
            error: null,
            isFetching: false
        },
        accountActivity: {
            data: null,
            error: null,
            isFetching: false
        },
        recordCall: {
            data: null,
            error: null,
            isFetching: false
        }
    };

    test('initializes reducer  State to default', () => {
        expect(rootReducer(undefined, { type: 'NOT_A_REAL_ACTION' })
        ).toEqual(initialState);
    });
});