/* eslint-disable no-underscore-dangle */
import { createStore, applyMiddleware, compose } from 'redux';
import { composeWithDevTools } from 'redux-devtools-extension';
import thunk from 'redux-thunk';
import { rootReducer } from './Root.reducer';

const middleware = applyMiddleware(thunk);

export const store = process.env.NODE_ENV === 'production' ?
    createStore(
        rootReducer,
        compose(middleware)
    ) :
    createStore(
        rootReducer,
        composeWithDevTools(middleware)
    );