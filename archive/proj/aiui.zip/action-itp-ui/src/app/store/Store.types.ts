import { IApiState } from '../common/types';
import { IUserState } from '../modules/login/Login.types';
import { IPiiState } from '../modules/itp/account-lookup/AccountLookup/AccountLookup.types';
import { IFetchMemoState } from '../modules/itp/account-lookup/itp-information/account-history/MemoPreview/MemoPreview.types';
import { IMembershipState } from '../modules/itp/account-lookup/itp-information/BillingData/MembershipState.types';
import { ICreateMemoState } from '../modules/itp/utilityMenu/UtilityMenu.types';
import { IBillingState } from '../modules/itp/account-lookup/itp-information/BillingData/BillingState.types';
import { ICustomerSearchResponse } from '../modules/itp/account-lookup/AccountLookup/Search/CustomerSearch.types';
import { IFetchAccountActivityState } from '../modules/itp/account-lookup/itp-information/account-activity/AccountActivity.types';
import { ICancelReasonsState } from '../modules/itp/account-lookup/itp-information/cancel/cancelReasons/CancelReasons.types';

export interface IReduxState {
    user: IApiState<IUserState>;
    pii: IApiState<IPiiState>;
    memo: IApiState<IFetchMemoState>;
    itpEnrollmentData: IApiState<IMembershipState>;
    createMemo: IApiState<ICreateMemoState>;
    billingData: IApiState<IBillingState>;
    customerSearch: IApiState<ICustomerSearchResponse>;
    accountActivity: IApiState<IFetchAccountActivityState>;
    recordCall: IApiState<{}>;
    cancelEnrollment: IApiState<{}>;
    cancelReasons: IApiState<ICancelReasonsState>;
}