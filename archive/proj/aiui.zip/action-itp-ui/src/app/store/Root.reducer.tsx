import { combineReducers } from 'redux';
import { userReducer } from '../modules/login/Login.reducer';
import { piiReducer } from '../modules/itp/account-lookup/AccountLookup/CustomerPII.reducer';
import { memoPreviewReducer } from '../modules/itp/account-lookup/itp-information/account-history/MemoPreview/MemoPreview.reducer';
import { itpDataReducer } from '../modules/itp/account-lookup/itp-information/BillingData/ItpData.reducer';
import { createMemoReducer } from '../modules/itp/utilityMenu/UtilityMenu.reducer';
import { billingDataReducer } from '../modules/itp/account-lookup/itp-information/BillingData/BillingData.reducer';
import { customerSearchReducer } from '../modules/itp/account-lookup/AccountLookup/Search/CustomerSearch.reducer';
import { accountActivityReducer } from '../modules/itp/account-lookup/itp-information/account-activity/AccountActivity.reducer';
import { itpRecordCallReducer } from '../modules/itp/account-lookup/itp-information/cancel/RecordCall.reducer';
import { cancelEnrollmentReducer } from '../modules/itp/account-lookup/itp-information/cancel/CancelEnrollment.reducer';
import { itpCancelReasonsReducer } from '../modules/itp/account-lookup/itp-information/cancel/cancelReasons/CancelReasons.reducer';

export const rootReducer = combineReducers({
    user: userReducer,
    pii: piiReducer,
    memo: memoPreviewReducer,
    itpEnrollmentData: itpDataReducer,
    createMemo: createMemoReducer,
    billingData: billingDataReducer,
    customerSearch: customerSearchReducer,
    accountActivity: accountActivityReducer,
    recordCall: itpRecordCallReducer,
    cancelEnrollment: cancelEnrollmentReducer,
    cancelReasons: itpCancelReasonsReducer
});