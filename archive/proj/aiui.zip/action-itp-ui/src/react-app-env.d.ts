// / <reference types="react-scripts" />
// / <reference types="node" />

declare namespace NodeJS {
    // eslint-disable-next-line @typescript-eslint/interface-name-prefix, @typescript-eslint/naming-convention
    interface ProcessEnv {
        readonly NODE_ENV: 'development' | 'production';
    }
}
// / <reference types="react-scripts" />
declare module '*.module.scss' {
    const classes: {
        readonly [key: string]: string;
    };
    // eslint-disable-next-line import/no-default-export
    export default classes;
}

declare module '*.module.sass' {
    const classes: {
        readonly [key: string]: string;
    };
    // eslint-disable-next-line import/no-default-export
    export default classes;
}

declare module '.scss';
declare module '.sass';