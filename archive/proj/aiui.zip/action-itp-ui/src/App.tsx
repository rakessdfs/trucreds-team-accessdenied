import React, { ReactElement } from 'react';
import './App.scss';
import { LoginRouter } from './app/modules/login/LoginRouter';

export const App = (): ReactElement => {
    return (
        <div>
            <LoginRouter />
        </div>
    );
};