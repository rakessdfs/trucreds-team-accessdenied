import { screen } from '@testing-library/react';
import React from 'react';
import configureMockStore from 'redux-mock-store';
import { App } from './App';
import { renderContainer } from './app/common/utils/test-utils';

describe('App', () => {
    let initialState, store;

    beforeEach(() => {
        initialState = {
            user: {
                data: {
                    isAuthenticated: false
                }
            },
            itpEnrollmentData: {
                data: {
                    subscriberNumber: 'subscriber',
                    enrollmentDate: 'enroll date',
                    enrollmentStatus: 'status',
                    enrollmentFailedReason: 'failed reason',
                    cancellationDate: 'cancel date',
                    cancellationRequestDate: 'cancel request date',
                    productEnrollmentId: 'PEID'
                },
                error: null,
                isFetching: false
            },
            customerSearch: {
                data: null,
                error: null,
                isFetching: false
            }
        };
    });

    const setupRTL = () => {
        store = configureMockStore()(initialState);
        return renderContainer(<App />, { store });
    };

    test('Welcome page is rendered after successful login', () => {
        initialState = {
            ...initialState,
            user: {
                ...initialState.user,
                data: {
                    ...initialState.user.data,
                    isAuthenticated: true
                }
            },
            pii: {
                successResponse: {
                    firstName: '',
                    lastName: '',
                    dob: '',
                    ssn: '',
                    address: '',
                    primaryPhone: '',
                    email: ''
                },
                errorResponse: null,
                isFetching: false
            }
        };

        setupRTL();
        expect(screen.getByText('Identity Theft Protection')).toBeInTheDocument();
    });
});