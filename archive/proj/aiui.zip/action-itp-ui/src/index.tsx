import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';
import React from 'react';
import ReactDOM from 'react-dom';
import './index.scss';
import { Provider } from 'react-redux';
import { App } from './App';
import { store } from './app/store/Store';

type eventTracker = {
    url?: string;
    msg?: string;
    line?: number;
}
/* global ADRUM */
declare global {
    // eslint-disable-next-line @typescript-eslint/interface-name-prefix, @typescript-eslint/naming-convention
    interface Window {
        ADRUM?: {
            report: (tracker: eventTracker) => void;
        };
    }
}

/* istanbul ignore file */
ReactDOM.render(
    <React.StrictMode>
        <Provider store={store}>
            <App />
        </Provider>
    </React.StrictMode>,
    document.getElementById('root')
);

// This is intentionally commented out so that it can be used as needed and will be enabled always on local
// once we implement env configs in an upcoming story
// if (process.env.REACT_APP_ENV === 'development'){
 require('../src/msw/server').worker.start();
// }