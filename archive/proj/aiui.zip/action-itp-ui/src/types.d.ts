/* eslint-disable import/no-default-export */
declare module '@action-org/discover-react-ui';

declare module '*.svg' {
    const content: string;
    export default content;
  }

  declare module '*.png' {
    const content: string;
    export default content;
  }