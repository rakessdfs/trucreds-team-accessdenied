import { customerSearchHandler } from './customerSearchHandler';
import { loginHandlers } from './login';
import { customerPIILookupHandler } from './customerPIILookup';
import { memoHandlers } from './memo';
import { itpDataHandler } from './itpDataHandler';
import { billingDataHandler } from './billingDataHandler';
import { accountActivityHandlers } from './accountActivityHandler';
import { recordCallHandlers } from './recordCall';
import { cancelReasonHandlers } from './cancelReasons';
import { cancelEnrollmentHandler } from './cancelEnrollmentHandler';

export const handlers = [
    ...loginHandlers,
    ...customerPIILookupHandler,
    ...itpDataHandler,
    ...memoHandlers,
    ...billingDataHandler,
    ...customerSearchHandler,
    ...accountActivityHandlers,
    ...recordCallHandlers,
    ...cancelReasonHandlers,
    ...cancelEnrollmentHandler
];