// eslint-disable-next-line import/no-extraneous-dependencies
import { rest } from 'msw';
import {
    URL_ACTION_ITP_API_HOSTNAME,
    URL_ACTION_ITP_RECORD_CALL
} from '../../app/common/constants/ITPConstants';
import { loginFailure } from '../responses/login/loginResponses';
import { recordCallFailure400Res, recordCallFailure500Res } from '../responses/recordCall/recordCallResponses';

export const recordCallHandlers = [

    rest.post(`${URL_ACTION_ITP_API_HOSTNAME}${URL_ACTION_ITP_RECORD_CALL}`, (req, res, ctx) => {
        const tokenValue = req.headers.get('authorization').split(' ')[1];
        if (!tokenValue) {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(401),
                ctx.delay(0),
                ctx.json(loginFailure)
            );
        } else if (req.body.productEnrollmentId === 'test111') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(400),
                ctx.delay(1000),
                ctx.json(recordCallFailure400Res)
            );
        } else if (req.body.productEnrollmentId === 'test222') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(500),
                ctx.delay(1000),
                ctx.json(recordCallFailure500Res)
            );
        } else {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(200),
                ctx.delay(1000)
            );
        }
    })
];