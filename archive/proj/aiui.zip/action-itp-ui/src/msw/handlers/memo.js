// eslint-disable-next-line import/no-extraneous-dependencies
import { rest } from 'msw';
import {
    URL_ACTION_ITP_API_HOSTNAME,
    URL_ACTION_ITP_DATA_CONTEXT,
    URL_ACTION_ITP_FETCH_MEMO_CONTEXT
} from '../../app/common/constants/ITPConstants';
import {
    fetchMemoFailure400Res,
    fetchMemoFailure500Res,
    fetchMemoSuccessRes
} from '../responses/memo/fetchMemoResponses';
import { loginFailure } from '../responses/login/loginResponses';
import { itpDataSuccessResponse } from '../responses/itpData/itpDataSucess';
import { createMemoFailure400Res } from '../responses/memo/createMemoResponses';

export const memoHandlers = [
    rest.get(`${URL_ACTION_ITP_API_HOSTNAME}${URL_ACTION_ITP_FETCH_MEMO_CONTEXT}:productEnrollmentId`, (req, res, ctx) => {
        const tokenValue = req.headers.get('authorization').split(' ')[1];
        const { productEnrollmentId } = req.params;
        if (!tokenValue) {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(401),
                ctx.delay(0),
                ctx.json(loginFailure)
            );
        }
        if (productEnrollmentId === '2683') {
            // not found
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(204),
                ctx.delay(1000)
            );
        } else if (productEnrollmentId === '5673') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(500),
                ctx.delay(1000),
                ctx.json(fetchMemoFailure500Res)
            );
        } else {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(200),
                ctx.delay(1000),
                ctx.json(fetchMemoSuccessRes)
            );
        }
    }),
    rest.get(`${URL_ACTION_ITP_API_HOSTNAME}${URL_ACTION_ITP_FETCH_MEMO_CONTEXT}`, (req, res, ctx) => {
        const tokenValue = req.headers.get('authorization').split(' ')[1];
        if (!tokenValue) {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(401),
                ctx.delay(0),
                ctx.json(loginFailure)
            );
        } else {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(400),
                ctx.delay(1000),
                ctx.json(fetchMemoFailure400Res)
            );
        }
    }),
    rest.get(`${URL_ACTION_ITP_API_HOSTNAME}${URL_ACTION_ITP_DATA_CONTEXT}:partyId`, (req, res, ctx) => {
        const { partyId } = req.params;
        if (partyId === '1234') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(200),
                ctx.delay(1000),
                ctx.json(itpDataSuccessResponse)
            );
        }
    }),
    rest.post(`${URL_ACTION_ITP_API_HOSTNAME}${URL_ACTION_ITP_FETCH_MEMO_CONTEXT}`, (req, res, ctx) => {
        const tokenValue = req.headers.get('authorization').split(' ')[1];
        if (!tokenValue) {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(401),
                ctx.delay(0),
                ctx.json(loginFailure)
            );
        } else if (req.body.memoText === 'memo400') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(400),
                ctx.delay(1000),
                ctx.json(createMemoFailure400Res)
            );
        } else if (req.body.memoText === 'memo500') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(500),
                ctx.delay(1000),
                ctx.json(fetchMemoFailure500Res)
            );
        } else {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(201),
                ctx.delay(1000)
            );
        }
    })
];