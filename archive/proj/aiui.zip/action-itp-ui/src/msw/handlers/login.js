// eslint-disable-next-line import/no-extraneous-dependencies
import { rest } from 'msw';
import { URL_ACTION_ITP_API_HOSTNAME, URL_ACTION_ITP_LOGIN_API_CONTEXT } from '../../app/common/constants/ITPConstants';
import { loginFailure, loginSuccess } from '../responses/login/loginResponses';

export const loginHandlers = [
    rest.post(`${URL_ACTION_ITP_API_HOSTNAME}${URL_ACTION_ITP_LOGIN_API_CONTEXT}`, (req, res, ctx) => {
        if (req.body.racf === 'itp') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*',
                    Authorization: 'jwt-token'
                }),
                ctx.status(200),
                ctx.cookie('auth-token', 'abc123'),
                ctx.delay(0),
                ctx.json(loginSuccess)
            );
        } else if (req.body.racf === 'mockFail') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(500),
                ctx.delay(0)
            );
        } else if (req.body.racf === '403') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(403),
                ctx.delay(0)
            );
        } else {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(401),
                ctx.delay(0),
                ctx.json(loginFailure)
            );
        }
    })
];