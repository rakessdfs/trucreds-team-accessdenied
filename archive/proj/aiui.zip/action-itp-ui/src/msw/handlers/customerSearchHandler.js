// eslint-disable-next-line import/no-extraneous-dependencies
import { rest } from 'msw';
import {
    URL_ACTION_ITP_API_HOSTNAME,
    URL_ACTION_ITP_CUSTOMER_SEARCH_CONTEXT
} from '../../app/common/constants/ITPConstants';
import {
    customerSearchDOBError,
    customerSearchFirstNameError,
    customerSearchLastNameError,
    customerSearchNoResults,
    customerSearchSuccessResponse
} from '../responses/customerSearch/responses';
import { loginFailure } from '../responses/login/loginResponses';

export const customerSearchHandler = [
    rest.post(`${URL_ACTION_ITP_API_HOSTNAME}${URL_ACTION_ITP_CUSTOMER_SEARCH_CONTEXT}`, (req, res, ctx) => {
        const tokenValue = req.headers.get('authorization').split(' ')[1];
        const name = req.body.firstName;
        const agentName = req.headers.get('X-DFSUSER-USER-ID');

        if (!tokenValue || !agentName) {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(401),
                ctx.delay(0),
                ctx.json(loginFailure)
            );
        } else if (name === 'noResults') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(200),
                ctx.delay(1000),
                ctx.json(customerSearchNoResults)
            );
        } else if (name === '500error') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(500),
                ctx.delay(1000)
            );
        } else if (name === 'invalidFirstName') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(400),
                ctx.delay(1000),
                ctx.json(customerSearchFirstNameError)
            );
        } else if (name === 'invalidLastName') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(400),
                ctx.delay(1000),
                ctx.json(customerSearchLastNameError)
            );
        } else if (name === 'invalidDOB') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(400),
                ctx.delay(1000),
                ctx.json(customerSearchDOBError)
            );
        } else {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(200),
                ctx.delay(1000),
                ctx.json(customerSearchSuccessResponse)
            );
        }
    })
];