// eslint-disable-next-line import/no-extraneous-dependencies
import { rest } from 'msw';
import {
    URL_ACTION_BILLING_DATA_CONTEXT,
    URL_ACTION_ITP_API_HOSTNAME
} from '../../app/common/constants/ITPConstants';
import { billingDataSuccessResponse } from '../responses/itpData/billingDataSuccess';
import { billingDataErrorResponse } from '../responses/itpData/billingDataError';
import { loginFailure } from '../responses/login/loginResponses';

export const billingDataHandler = [
    rest.get(`${URL_ACTION_ITP_API_HOSTNAME}${URL_ACTION_BILLING_DATA_CONTEXT.replace(/\?(.*)/, '')}`, (req, res, ctx) => {
        const tokenValue = req.headers.get('authorization').split(' ')[1];
        const peid = req.url.searchParams.get('peid');
        if (!tokenValue) {
            // valid response
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(401),
                ctx.delay(0),
                ctx.json(loginFailure)
            );
        } else if (peid === 'error') {
            // valid response
            return res(
                ctx.status(500)
            );
        } else if (peid === 'emptyPeid') {
            // valid response
            return res(
                ctx.status(400),
                ctx.delay(1000),
                ctx.json(billingDataErrorResponse)
            );
        } else {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(200),
                ctx.delay(1000),
                ctx.json(billingDataSuccessResponse)
            );
        }
    })
];