// eslint-disable-next-line import/no-extraneous-dependencies
import { rest } from 'msw';
import { URL_ACTION_ITP_API_HOSTNAME, URL_ACTION_ITP_CANCEL_ENROLLMENT } from '../../app/common/constants/ITPConstants';
import { loginFailure } from '../responses/login/loginResponses';
import {
    cancelEnrollmentErrorResponse,
    cancelEnrollmentForbiddenResponse
} from '../responses/cancelEnrollment/cancelEnrollmentResponses';

export const cancelEnrollmentHandler = [
    rest.post(`${URL_ACTION_ITP_API_HOSTNAME}${URL_ACTION_ITP_CANCEL_ENROLLMENT.replace(/\?(.*)/, '')}`, (req, res, ctx) => {
        const tokenValue = req.headers.get('authorization').split(' ')[1];
        const productEnrollmentId = req.url.searchParams.get('productEnrollmentId');
        const cancelReasonCode = req.url.searchParams.get('cancelReasonCode');

        if (!tokenValue) {
            // valid response
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(401),
                ctx.delay(0),
                ctx.json(loginFailure)
            );
        } else if (productEnrollmentId === 'error') {
            // valid response
            return res(
                ctx.status(500)
            );
        } else if (productEnrollmentId === 'emptyPeid' || cancelReasonCode === 'emptyCancelReason') {
            // valid response
            return res(
                ctx.status(400),
                ctx.delay(1000),
                ctx.json(cancelEnrollmentErrorResponse)
            );
        } else if (productEnrollmentId === '401') {
            return res(
                ctx.status(401)
            );
        } else if (productEnrollmentId === '403') {
            return res(
                ctx.status(200),
                ctx.delay(1000),
                ctx.json(cancelEnrollmentForbiddenResponse)
            );
        } else {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(200),
                ctx.delay(1000)
            );
        }
    })
];