// eslint-disable-next-line import/no-extraneous-dependencies
import { rest } from 'msw';
import {
    URL_ACTION_ITP_API_HOSTNAME,
    URL_ACTION_ITP_DATA_CONTEXT
} from '../../app/common/constants/ITPConstants';
import { itpDataSuccessResponse } from '../responses/itpData/itpDataSucess';
import { itpDataError } from '../responses/itpData/itpDataError';
import { loginFailure } from '../responses/login/loginResponses';

export const itpDataHandler = [
    rest.get(`${URL_ACTION_ITP_API_HOSTNAME}${URL_ACTION_ITP_DATA_CONTEXT.replace(/\?(.*)/, '')}`, (req, res, ctx) => {
        const tokenValue = req.headers.get('authorization').split(' ')[1];
        const partyID = req.url.searchParams.get('partyId');
        if (!tokenValue) {
            // valid response
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(401),
                ctx.delay(0),
                ctx.json(loginFailure)
            );
        } else if (partyID === 'error') {
            // valid response
            return res(
                ctx.status(500)
            );
        } else if (partyID === 'emptyPartyId') {
            // valid response
            return res(
                ctx.status(400),
                ctx.delay(1000),
                ctx.json(itpDataError)
            );
        } else if (partyID === 'unauth') {
            // valid response
            return res(
                ctx.status(401),
                ctx.delay(1000),
                ctx.json(loginFailure)
            );
        } else {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(200),
                ctx.delay(1000),
                ctx.json(itpDataSuccessResponse)
            );
        }
    })
];