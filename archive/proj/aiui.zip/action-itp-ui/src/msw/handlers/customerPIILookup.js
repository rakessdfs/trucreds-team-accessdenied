// eslint-disable-next-line import/no-extraneous-dependencies
import { rest } from 'msw';
import { URL_ACTION_ITP_API_HOSTNAME, URL_ACTION_ITP_PII_CONTEXT } from '../../app/common/constants/ITPConstants';
import { piiLookupSuccess } from '../responses/customerPIILookup/piiLookupSuccess';
import { loginFailure } from '../responses/login/loginResponses';

export const customerPIILookupHandler = [
    rest.get(`${URL_ACTION_ITP_API_HOSTNAME}${URL_ACTION_ITP_PII_CONTEXT.replace(/\?(.*)/, '')}`, (req, res, ctx) => {
        const tokenValue = req.headers.get('authorization').split(' ')[1];
        const partyId = req.url.searchParams.get('party-id');
        const agentName = req.headers.get('X-DFSUSER-USER-ID');

        if (!tokenValue || !agentName) {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(401),
                ctx.delay(0),
                ctx.json(loginFailure)
            );
        }

        if (partyId === 'notFound') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(204),
                ctx.delay(1000)
            );
        } else if (partyId === 'mockFailure') {
            return res(
                ctx.status(500)
            );
        } else {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(200),
                ctx.delay(1000),
                ctx.json(piiLookupSuccess)
            );
        }
    })
];