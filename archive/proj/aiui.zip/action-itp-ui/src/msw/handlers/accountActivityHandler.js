// eslint-disable-next-line import/no-extraneous-dependencies
import { rest } from 'msw';
import { URL_ACTION_ITP_API_HOSTNAME, URL_ACTION_ITP_FETCH_REQUEST_ACTIVITY_CONTEXT } from '../../app/common/constants/ITPConstants';
import { accountActivitySuccessResponse, fetchAccountActivity400, fetchAccountActivity500, fetchAccountActivity401, accountActivitySuccessResponseNoCustomData } from '../responses/accountactivity/AccountActivityResponses';

export const accountActivityHandlers = [
    rest.get(`${URL_ACTION_ITP_API_HOSTNAME}${URL_ACTION_ITP_FETCH_REQUEST_ACTIVITY_CONTEXT}:productEnrollmentId`, (req, res, ctx) => {
        const { productEnrollmentId } = req.params;
        if (productEnrollmentId === '213') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(204),
                ctx.delay(1000)
            );
        } else if (productEnrollmentId === '123') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(400),
                ctx.delay(1000),
                ctx.json(fetchAccountActivity400)
            );
        } else if (productEnrollmentId === '000') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(500),
                ctx.delay(1000),
                ctx.json(fetchAccountActivity500)
            );
        } else if (productEnrollmentId === '401') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(401),
                ctx.delay(1000),
                ctx.json(fetchAccountActivity401)
            );
        } else if (productEnrollmentId === '222') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(200),
                ctx.delay(1000),
                ctx.json(accountActivitySuccessResponseNoCustomData)
            );
        } else {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(200),
                ctx.delay(1000),
                ctx.json(accountActivitySuccessResponse)
            );
        }
    })];