// eslint-disable-next-line import/no-extraneous-dependencies
import { rest } from 'msw';
import {
    URL_ACTION_ITP_API_HOSTNAME,
    URL_ACTION_ITP_CANCEL_REASONS
} from '../../app/common/constants/ITPConstants';
import { loginFailure } from '../responses/login/loginResponses';
import { cancelReasonsFailure500Res, cancelReasonsSuccess, cancelReasonsFailure400 } from '../responses/cancelReasons/responses';

export const cancelReasonHandlers = [
    rest.get(`${URL_ACTION_ITP_API_HOSTNAME}${URL_ACTION_ITP_CANCEL_REASONS.replace(/\?(.*)/, '')}`, (req, res, ctx) => {
        const tokenValue = req.headers.get('authorization').split(' ')[1];
        const customerType = req.url.searchParams.get('customerType');
        if (!tokenValue) {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(401),
                ctx.delay(0),
                ctx.json(loginFailure)
            );
        } else if (customerType === 'ITP_TEST_400') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(400),
                ctx.delay(1000),
                ctx.json(cancelReasonsFailure400)
            );
        } else if (customerType === 'ITP_TEST_401ERROR') {
            return res(
                ctx.status(401)
            );
        } else if (customerType === 'ITP_TEST_500ERROR') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(500),
                ctx.delay(1000),
                ctx.json(cancelReasonsFailure500Res)
            );
        } else if (customerType === 'ITP_TEST_200_ERRORS') {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(200),
                ctx.delay(1000),
                ctx.json(cancelReasonsFailure500Res)
            );
        } else {
            return res(
                ctx.set({
                    'Access-Control-Allow-Origin': '*'
                }),
                ctx.status(200),
                ctx.delay(1000),
                ctx.json(cancelReasonsSuccess)
            );
        }
    })
];