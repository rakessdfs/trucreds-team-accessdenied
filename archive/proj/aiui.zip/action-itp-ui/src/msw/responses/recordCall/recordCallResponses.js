export const recordCallFailure400Res = {
    errors: { 1012: 'Invalid productEnrollmentId can\'t be null or blank' }
};

export const recordCallFailure500Res = {
    errors: { 1026: 'Error while starting call recording' }
};