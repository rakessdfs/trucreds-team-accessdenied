export const billingDataErrorResponse = {
    errors: {
        1002: 'Invalid request. Please resolve and try again.'
    }
};