export const itpDataError = {
    errors: {
        1002: 'Invalid request. Please resolve and try again.'
    }
};