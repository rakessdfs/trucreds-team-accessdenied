export const billingDataSuccessResponse = {
    pcmFirstName: 'firstname',
    pcmLastName: 'lastname',
    pcmAccountNumber: 'testaccnumber',
    presenceOfSecondary: 'yes',
    nextBillingDate: '2020-11-20'
};