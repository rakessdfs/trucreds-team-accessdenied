export const itpDataSuccessResponse = {
    subscriberNumber: '9090TEST32229473040',
    enrollmentDate: '2021-01-01',
    enrollmentStatus: 'Pending Enrollment',
    enrollmentFailedReason: '',
    cancellationDate: '',
    cancellationRequestDate: '',
    productEnrollmentId: 'PDCDTEST32229473040',
    customerType: 'ITP_BM_FREE'
};