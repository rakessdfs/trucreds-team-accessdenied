export const piiLookupSuccess = {
    firstName: 'TWANEY',
    lastName: 'AZARIYA',
    email: 'user123@user.com',
    address: {
        barCode: '0',
        cityName: 'LIVERPOOL',
        countryCode: 'USA',
        postalCode: '123456',
        addressLine1: '38 BLUE PARK',
        addressLine2: '33 FLOOR',
        stateOrSectionCode: 'NY',
        forbidAutoFormatting: false
    },
    primaryPhone: '9876543210',
    ssn: '2641',
    dateOfBirth: '01/01/1970'
};