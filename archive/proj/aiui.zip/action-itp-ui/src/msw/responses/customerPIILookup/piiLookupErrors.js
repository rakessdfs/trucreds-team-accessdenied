export const lookupInvalidFirstName = {
    errors: {
        1003: 'invalid first name'
    }
};

export const lookupInvalidLastName = {
    errors: {
        1004: 'invalid last name'
    }
};

export const lookupInvalidDOB = {
    errors: {
        1002: 'invalid dob'
    }
};