export const accountActivitySuccessResponse = {
    accountActivityList: [
        {
            accountActivityId: 0,
            activityDesc: 'test act desc',
            newData: 'this is new data',
            operator: 'INTERNET',
            previousData: 'this is old data',
            productEnrollmentId: 'string',
            requestDate: [2021, 2, 17, 18, 53, 50]
        }
    ]
};

export const accountActivitySuccessResponseNoCustomData = {
    accountActivityList: [
        {
            accountActivityId: 0,
            activityDesc: 'test act desc',
            newData: '',
            operator: 'INTERNET',
            previousData: '',
            productEnrollmentId: 'string',
            requestDate: [2021, 2, 17, 18, 53, 50]
        }
    ]
};

export const fetchAccountActivity400 = {
    errors: { 1012: 'Invalid request. Please resolve and try again.' }
};

export const fetchAccountActivity500 = {
    errors: { 5006: 'Unable to load Request Activity at this time. Please try again.' }
};

export const fetchAccountActivity401 = {
    errors: { 1234: 'Unauthorized' }
};