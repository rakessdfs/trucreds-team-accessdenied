export const customerSearchSuccessResponse = ({
    customers: [
        {
            firstName: 'test',
            lastName: 'user',
            partyId: '1234',
            ssn: '1234'
        },
        {
            firstName: 'test',
            lastName: 'user2',
            partyId: '5678',
            ssn: '5678'
        },
        {
            firstName: 'unknown',
            lastName: 'user3',
            partyId: 'notFound',
            ssn: '9101'
        },
        {
            firstName: 'failed',
            lastName: 'user4',
            partyId: 'mockFailure',
            ssn: '9101'
        }
    ]
});

export const customerSearchNoResults = ({
    customers: []
});

export const customerSearchFirstNameError = {
    errors: {
        1003: 'invalid first name'
    }
};

export const customerSearchLastNameError = {
    errors: {
        1004: 'invalid last name'
    }
};

export const customerSearchDOBError = {
    errors: {
        1002: 'invalid dob'
    }
};