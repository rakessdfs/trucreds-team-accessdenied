export const cancelReasonsFailure400Res = {
    errors: { 1012: 'Invalid productEnrollmentId can\'t be null or blank' }
};

export const cancelReasonsFailure500Res = {
    errors: { 1027: 'Error' }
};

export const cancelReasonsSuccess = {
    requestReasons: [
        {
            code: 'ABC',
            description: 'ABC Description'
        }, {
            code: 'NLW',
            description: 'No Longer Wants/Needs'
        }
    ]
};

export const cancelReasonsFailure400 = {
    errors: { 1028: 'Request reasons not found' }
};