export const loginSuccess = {
    fullName: 'test user',
    email: 'test@user.com',
    userName: 'testUser1'
};

export const loginFailure = {
    errors: {
        1009: 'Unauthorized'
    }
};