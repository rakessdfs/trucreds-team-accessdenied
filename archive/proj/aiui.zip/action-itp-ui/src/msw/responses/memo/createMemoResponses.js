export const createMemoFailure400Res = {
    errors: { 1012: 'Invalid productEnrollmentId can\'t be null or blank' }
};

export const fetchMemoFailure500Res = {
    errors: { 5006: 'Internal server error' }
};