export const cancelEnrollmentErrorResponse = {
    errors: {
        1035: 'Invalid request. Please resolve and try again.'
    }
};

export const cancelEnrollmentForbiddenResponse = {
    errors: {
        403: 'Something went wrong'
    }
};