// eslint-disable-next-line import/no-extraneous-dependencies
import { rest, setupWorker } from 'msw';
// eslint-disable-next-line import/no-extraneous-dependencies
import { setupServer } from 'msw/node';
import { handlers } from './handlers/index';

const server = setupServer(...handlers);
const worker = setupWorker(...handlers);
export { server, rest, worker };