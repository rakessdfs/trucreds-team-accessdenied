const CopyModulesPlugin = require("copy-modules-webpack-plugin");

module.exports = {
    webpack: {
        plugins: [
            new CopyModulesPlugin({
                destination: 'webpack-modules'
            })
        ]
    }
};